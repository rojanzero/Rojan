self.__BUILD_MANIFEST = function(c, s, e, t, i, a, n, o) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [{
                source: "/robots.txt",
                destination: "/api/robots"
            }, {
                source: "/sitemap",
                destination: "/api/sitemap"
            }],
            fallback: []
        },
        "/404": ["static/chunks/pages/404-e8c8e4f1b8cb945c.js"],
        "/_error": ["static/chunks/pages/_error-ae8f024eb23d9a5d.js"],
        "/checkout/[...idInvoice]": [c, s, e, t, n, i, o, a, "static/chunks/pages/checkout/[...idInvoice]-86e37179c4ce7d1c.js"],
        "/contact-form": [c, s, e, t, n, i, "static/chunks/644-e19b240598ae46f9.js", "static/chunks/693-c54d652e4eccb784.js", "static/css/30fd6dae99bf48e4.css", "static/chunks/764-f725e56f3f3798b5.js", a, "static/chunks/674-87d21fc98e9feabc.js", "static/chunks/pages/contact-form-61c10473ef262e94.js"],
        "/error/404": [c, s, e, t, n, i, a, "static/chunks/pages/error/404-c8a936ce0b1364a8.js"],
        "/error/500": [c, s, e, t, n, i, a, "static/chunks/pages/error/500-82d2f1b42b67b6d9.js"],
        "/invoice/print/[idInvoice]": [c, s, e, t, n, i, a, "static/chunks/pages/invoice/print/[idInvoice]-b28f8e5af54a68e1.js"],
        "/invoice/[idInvoice]": [c, s, e, t, n, i, o, a, "static/chunks/pages/invoice/[idInvoice]-c173cbf80437039f.js"],
        "/[[...slug]]": [c, s, e, t, i, a, "static/chunks/pages/[[...slug]]-c2a58b9f0c8d13e9.js"],
        sortedPages: ["/404", "/_app", "/_error", "/checkout/[...idInvoice]", "/contact-form", "/error/404", "/error/500", "/invoice/print/[idInvoice]", "/invoice/[idInvoice]", "/[[...slug]]"]
    }
}("static/chunks/c9184924-375a28b79120852d.js", "static/chunks/228771e0-4f25607fabbf3101.js", "static/chunks/65291039-c6f0e50e59aa756d.js", "static/chunks/1b8dab7b-99ffffda4fe4c03e.js", "static/chunks/561-9ce6a7286ef4ef3b.js", "static/chunks/692-942df7d7594c8cc7.js", "static/chunks/664-ac374a67af56732d.js", "static/chunks/675-1918b3cbce167ef3.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();