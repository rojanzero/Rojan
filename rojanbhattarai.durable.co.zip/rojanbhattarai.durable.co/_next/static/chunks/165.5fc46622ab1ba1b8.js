"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [165], {
        165: function(l, e, s) {
            s.r(e), s.d(e, {
                default: function() {
                    return S
                }
            });
            var i = s(14251),
                t = s(85893),
                o = s(31996),
                n = s(67294),
                a = s(41664),
                c = s.n(a),
                d = s(90387),
                r = s(52077),
                u = s(90434),
                v = s(41984),
                x = s(71029),
                h = s(85296),
                g = s(44171),
                m = s(43180),
                f = s(10151),
                j = s(36234),
                p = s(66909),
                b = s(49791),
                y = s(28239),
                N = s(48192),
                w = s(94206),
                k = s(13487),
                Z = s(43751),
                F = s(72510),
                D = s(18732),
                C = s(74007),
                A = [{
                    id: "facebook",
                    host: "facebook.com"
                }, {
                    id: "twitter",
                    host: "twitter.com"
                }, {
                    id: "linkedin",
                    host: "linkedin.com"
                }, {
                    id: "youtube",
                    host: "youtube.com"
                }, {
                    id: "pinterest",
                    host: "pinterest.com"
                }, {
                    id: "instagram",
                    host: "instagram.com"
                }, {
                    id: "tiktok",
                    host: "tiktok.com"
                }, {
                    id: "thumbtack",
                    host: "thumbtack.com"
                }, {
                    id: "homeadvisor",
                    host: "homeadvisor.com"
                }, {
                    id: "angi",
                    host: "angi.com"
                }, {
                    id: "behance",
                    host: "behance.net"
                }, {
                    id: "dribbble",
                    host: "dribbble.com"
                }];

            function S(l) {
                var e, s, a = l.website,
                    S = (l.office, (0, n.useState)(!1)),
                    L = S[0],
                    K = S[1],
                    M = (0, n.useState)("#FFFFFF"),
                    _ = M[0],
                    E = M[1],
                    P = (0, n.useState)("#111827"),
                    z = P[0],
                    W = P[1],
                    I = (0, n.useState)(""),
                    R = I[0],
                    O = I[1],
                    B = (0, n.useState)(null),
                    U = B[0],
                    V = B[1],
                    T = (0, d.useRouter)(),
                    $ = null === a || void 0 === a ? void 0 : a.footer,
                    q = null === a || void 0 === a ? void 0 : a.header,
                    G = null === (s = null === (e = a.pages) || void 0 === e ? void 0 : e.filter((function(l) {
                        return !0 === l.showOnFooter || void 0 === l.showOnFooter
                    }))) || void 0 === s ? void 0 : s.map((function(l) {
                        var e = {
                            href: "/".concat(l.slug || ""),
                            name: l.label,
                            current: T.asPath === "/".concat(l.slug || ""),
                            type: l.type
                        };
                        return "parent" === e.type && (e.nests = a.pages.filter((function(e) {
                            return e.Parent === l._id
                        })).map((function(e) {
                            return {
                                href: "/".concat(l.slug, "/").concat(e.slug || ""),
                                name: e.label,
                                current: T.asPath === "/".concat(l.slug, "/").concat(e.slug || "")
                            }
                        })), 0 === e.nests.length) ? null : e
                    })).filter((function(l) {
                        return null !== l
                    })),
                    H = function() {
                        var l, e, s, n, c, d, r, u;
                        return $.showLogo && "branding" === $.source && (null === a || void 0 === a ? void 0 : a.logo) ? (0, t.jsxs)(t.Fragment, {
                            children: [(0, t.jsx)("img", {
                                className: "hidden lg:block transition-all object-contain",
                                src: null === a || void 0 === a || null === (l = a.logo) || void 0 === l ? void 0 : l.url,
                                alt: null === $ || void 0 === $ ? void 0 : $.businessName,
                                style: {
                                    height: (null === $ || void 0 === $ || null === (e = $.logoDesktop) || void 0 === e ? void 0 : e.height) + "px"
                                }
                            }), (0, t.jsx)("img", {
                                className: "lg:hidden transition-all object-contain",
                                src: null === a || void 0 === a || null === (s = a.logo) || void 0 === s ? void 0 : s.url,
                                alt: null === $ || void 0 === $ ? void 0 : $.businessName,
                                style: {
                                    height: (null === $ || void 0 === $ || null === (n = $.logoMobile) || void 0 === n ? void 0 : n.height) + "px"
                                }
                            })]
                        }) : $.showLogo && "upload" === $.source && (null === $ || void 0 === $ ? void 0 : $.customLogo) ? (0, t.jsxs)(t.Fragment, {
                            children: [(0, t.jsx)("img", {
                                className: "hidden lg:block transition-all object-contain",
                                src: null === $ || void 0 === $ || null === (c = $.customLogo) || void 0 === c ? void 0 : c.url,
                                alt: null === $ || void 0 === $ ? void 0 : $.businessName,
                                style: {
                                    height: (null === $ || void 0 === $ || null === (d = $.logoDesktop) || void 0 === d ? void 0 : d.height) + "px"
                                }
                            }), (0, t.jsx)("img", {
                                className: "lg:hidden transition-all object-contain text-2xl",
                                src: null === $ || void 0 === $ || null === (r = $.customLogo) || void 0 === r ? void 0 : r.url,
                                alt: null === $ || void 0 === $ ? void 0 : $.businessName,
                                style: {
                                    height: (null === $ || void 0 === $ || null === (u = $.logoMobile) || void 0 === u ? void 0 : u.height) + "px"
                                }
                            })]
                        }) : (0, t.jsx)("h3", {
                            className: (0, o.AK)("text-xl lg:text-2xl", "simple-right" !== (null === $ || void 0 === $ ? void 0 : $.style) && "simple-center" !== (null === $ || void 0 === $ ? void 0 : $.style) && "xl:text-h3"),
                            style: (0, i.Z)({
                                color: z
                            }, (0, o.j2)(a)),
                            children: null === $ || void 0 === $ ? void 0 : $.businessName
                        })
                    },
                    J = function() {
                        if (0 === (null === G || void 0 === G ? void 0 : G.length)) return (0, t.jsx)(t.Fragment, {});
                        var l = (0, o.h)(_, -10);
                        return l !== z && l !== _ || (l = (0, o.h)(_, 10)), (0, t.jsx)("ul", {
                            className: (0, o.AK)("flex flex-col lg:flex-row items-start lg:items-center flex-wrap gap-6", "stacked-right" === (null === $ || void 0 === $ ? void 0 : $.style) && "justify-end items-end", ("stacked-center" === (null === $ || void 0 === $ ? void 0 : $.style) || "simple-center" === (null === $ || void 0 === $ ? void 0 : $.style)) && "justify-center items-center"),
                            style: {
                                color: z
                            },
                            children: null === G || void 0 === G ? void 0 : G.filter((function(l) {
                                return "nested" !== l.type
                            })).map((function(e) {
                                var s;
                                return (0, t.jsx)("li", {
                                    className: (0, o.AK)("border-b-2"),
                                    style: {
                                        borderColor: e.current ? "".concat(z) : "transparent"
                                    },
                                    children: "parent" === e.type ? (0, t.jsxs)(t.Fragment, {
                                        children: [(0, t.jsx)(C.Z, {
                                            className: "!hidden lg:!inline-block",
                                            openUp: !0,
                                            buttonClassName: "inline-flex items-center gap-2 py-1.5",
                                            itemsContainerClass: "!pl-6 !pr-12 w-max max-w-120",
                                            button: (0, t.jsxs)(t.Fragment, {
                                                children: [(0, t.jsx)("span", {
                                                    className: "font-light whitespace-nowrap",
                                                    children: e.name
                                                }), (0, t.jsx)(u.Z, {
                                                    className: "w-4 h-4"
                                                })]
                                            }),
                                            itemsContainerStyle: {
                                                backgroundColor: l,
                                                color: z
                                            },
                                            children: null === (s = e.nests) || void 0 === s ? void 0 : s.map((function(l) {
                                                return (0, t.jsx)(F.v.Item, {
                                                    children: (0, t.jsx)(c(), {
                                                        href: l.href,
                                                        legacyBehavior: !1,
                                                        className: "block py-2 font-light border-b-2",
                                                        style: {
                                                            borderColor: l.current ? "".concat(z) : "transparent"
                                                        },
                                                        children: l.name
                                                    })
                                                }, "page-link-".concat(l.href))
                                            }))
                                        }), (0, t.jsxs)("button", {
                                            className: "inline-flex lg:hidden items-center gap-2",
                                            onClick: function() {
                                                K(!0), V(e.nests)
                                            },
                                            children: [(0, t.jsx)("span", {
                                                children: e.name
                                            }), (0, t.jsx)(v.Z, {
                                                className: "w-4 h-4",
                                                "aria-hidden": "true"
                                            })]
                                        })]
                                    }) : (0, t.jsx)(c(), {
                                        href: e.href,
                                        children: (0, t.jsx)("a", {
                                            className: "block py-1.5 font-light",
                                            children: e.name
                                        })
                                    })
                                }, "page-link-".concat(e.href))
                            }))
                        })
                    },
                    Q = function() {
                        return (0, t.jsx)("ul", {
                            className: (0, o.AK)("flex items-center gap-x-4 gap-y-2 flex-wrap", "stacked-right" === (null === $ || void 0 === $ ? void 0 : $.style) && "justify-end", ("stacked-center" === (null === $ || void 0 === $ ? void 0 : $.style) || "simple-center" === (null === $ || void 0 === $ ? void 0 : $.style)) && "justify-center"),
                            children: Array.isArray(a.social) && a.social.map((function(l, e) {
                                var s = A.find((function(e) {
                                        return e.id === l.type
                                    })),
                                    i = l.link;
                                return "custom" !== l.type && (i = (i = l.link.replace(/[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\//gi, "").replace(/https?:/g, "").replace(/^\/\/?/g, "")).replace(null === s || void 0 === s ? void 0 : s.host, ""), i = "https://".concat(null === s || void 0 === s ? void 0 : s.host, "/").concat(i)), (0, t.jsx)("li", {
                                    children: (0, t.jsx)(c(), {
                                        href: i,
                                        children: (0, t.jsx)("a", {
                                            target: "_blank",
                                            children: Y(l)
                                        })
                                    })
                                }, "social-icon-header-".concat(e))
                            }))
                        })
                    },
                    X = function() {
                        return !1 === $.madeWithDurable ? (0, t.jsx)(t.Fragment, {}) : (0, t.jsxs)("p", {
                            className: (0, o.AK)("text-body lg:text-right whitespace-nowrap", ("stacked-center" === (null === $ || void 0 === $ ? void 0 : $.style) || "simple-center" === (null === $ || void 0 === $ ? void 0 : $.style)) && "!text-center", "stacked-left" === (null === $ || void 0 === $ ? void 0 : $.style) && "!text-left"),
                            children: [(0, t.jsx)("span", {
                                children: "Made with\xa0"
                            }), (0, t.jsx)(c(), {
                                href: "https://durable.co?referrer=".concat(encodeURIComponent(R)),
                                children: (0, t.jsx)("a", {
                                    target: "_blank",
                                    className: "underline",
                                    style: {
                                        color: z
                                    },
                                    children: "Durable"
                                })
                            })]
                        })
                    },
                    Y = function(l) {
                        var e = "w-8 h-8";
                        switch (l.type) {
                            case "angi":
                                return (0, t.jsx)(x.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "behance":
                                return (0, t.jsx)(h.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "dribbble":
                                return (0, t.jsx)(g.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "facebook":
                                return (0, t.jsx)(m.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "homeadvisor":
                                return (0, t.jsx)(f.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "instagram":
                                return (0, t.jsx)(j.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "linkedin":
                                return (0, t.jsx)(p.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "pinterest":
                                return (0, t.jsx)(b.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "tiktok":
                                return (0, t.jsx)(y.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "thumbtack":
                                return (0, t.jsx)(N.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "twitter":
                                return (0, t.jsx)(w.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "youtube":
                                return (0, t.jsx)(k.Z, {
                                    className: e,
                                    style: {
                                        color: z
                                    }
                                });
                            case "custom":
                                var s, i;
                                return (0, t.jsx)("div", {
                                    className: (0, o.AK)("flex-shrink-0 relative", e),
                                    children: (0, t.jsx)("div", {
                                        className: "absolute w-full h-full",
                                        style: {
                                            backgroundColor: z || "#000000",
                                            WebkitMaskImage: 'url("'.concat(null === l || void 0 === l || null === (s = l.icon) || void 0 === s ? void 0 : s.url, '")'),
                                            maskImage: 'url("'.concat(null === l || void 0 === l || null === (i = l.icon) || void 0 === i ? void 0 : i.url, '")'),
                                            WebkitMaskPosition: "center",
                                            maskPosition: "center",
                                            WebkitMaskRepeat: "no-repeat",
                                            maskRepeat: "no-repeat",
                                            WebkitMaskSize: "contain",
                                            maskSize: "contain"
                                        }
                                    })
                                })
                        }
                    },
                    ll = function() {
                        K(!1), V(null)
                    };
                return (0, n.useEffect)((function() {
                    if ($) {
                        var l;
                        if (E($.background || "#FFFFFF"), $.showName && (null === $.businessName || void 0 === $.businessName)) $.businessName = null === a || void 0 === a || null === (l = a.Business) || void 0 === l ? void 0 : l.name;
                        null !== $.businessAddress && void 0 !== $.businessAddress || ($.businessAddress = "")
                    }
                }), [$]), (0, n.useEffect)((function() {
                    _ && W((0, o.$O)(_))
                }), [_]), (0, n.useEffect)((function() {
                    T && ll()
                }), [T]), (0, n.useEffect)((function() {
                    O(null === location || void 0 === location ? void 0 : location.origin)
                }), []), (0, t.jsxs)(t.Fragment, {
                    children: [(0, t.jsx)("footer", {
                        className: "flex-1",
                        style: {
                            backgroundColor: _,
                            color: z
                        },
                        children: (0, t.jsx)("div", {
                            className: "container mx-auto py-12 lg:py-14 xl:py-20",
                            children: "split-left" === (null === $ || void 0 === $ ? void 0 : $.style) ? (0, t.jsxs)("div", {
                                className: "flex flex-col lg:flex-row lg:justify-between gap-12",
                                children: [(0, t.jsxs)("div", {
                                    className: "flex flex-col items-start gap-12 lg:gap-6",
                                    children: [H(), (0, t.jsxs)("div", {
                                        className: "flex flex-col lg:flex-row lg:items-center gap-12",
                                        children: [J(), $.showSocial && Q(), (null === $ || void 0 === $ ? void 0 : $.button) && (0, t.jsx)(r.Z, {
                                            className: "lg !py-2",
                                            button: $.button,
                                            website: a
                                        })]
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "flex flex-col gap-6",
                                    children: [!!$.additionalDetails && (0, t.jsx)("div", {
                                        className: "lg:text-right",
                                        style: {
                                            color: z
                                        },
                                        children: null === $ || void 0 === $ ? void 0 : $.additionalDetails
                                    }), X()]
                                })]
                            }) : "stacked-right" === $.style ? (0, t.jsxs)("div", {
                                className: "flex flex-col justify-end items-end gap-12 text-right",
                                children: [(0, t.jsxs)("div", {
                                    className: "flex flex-col items-end gap-6",
                                    children: [H(), !!$.additionalDetails && (0, t.jsx)("div", {
                                        style: {
                                            color: z
                                        },
                                        children: null === $ || void 0 === $ ? void 0 : $.additionalDetails
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "flex flex-col justify-end gap-12 lg:gap-14",
                                    children: [J(), $.showSocial && Q(), (null === $ || void 0 === $ ? void 0 : $.button) && (0, t.jsx)("div", {
                                        children: (0, t.jsx)(r.Z, {
                                            className: "lg !py-2",
                                            button: $.button,
                                            website: a
                                        })
                                    })]
                                }), X()]
                            }) : "stacked-center" === $.style ? (0, t.jsxs)("div", {
                                className: "flex flex-col justify-center gap-12 text-center",
                                children: [(0, t.jsxs)("div", {
                                    className: "flex flex-col items-center gap-6",
                                    children: [H(), !!$.additionalDetails && (0, t.jsx)("div", {
                                        style: {
                                            color: z
                                        },
                                        children: null === $ || void 0 === $ ? void 0 : $.additionalDetails
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "flex flex-col justify-center gap-12 lg:gap-14",
                                    children: [J(), $.showSocial && Q(), (null === $ || void 0 === $ ? void 0 : $.button) && (0, t.jsx)("div", {
                                        children: (0, t.jsx)(r.Z, {
                                            className: "lg !py-2",
                                            button: $.button,
                                            website: a
                                        })
                                    })]
                                }), X()]
                            }) : "stacked-left" === $.style ? (0, t.jsxs)("div", {
                                className: "flex flex-col items-start gap-12 text-left",
                                children: [(0, t.jsxs)("div", {
                                    className: "flex flex-col items-start gap-6",
                                    children: [H(), !!$.additionalDetails && (0, t.jsx)("div", {
                                        style: {
                                            color: z
                                        },
                                        children: null === $ || void 0 === $ ? void 0 : $.additionalDetails
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "flex flex-col items-start gap-12 lg:gap-14",
                                    children: [J(), $.showSocial && Q(), (null === $ || void 0 === $ ? void 0 : $.button) && (0, t.jsx)("div", {
                                        children: (0, t.jsx)(r.Z, {
                                            className: "lg !py-2",
                                            button: $.button,
                                            website: a
                                        })
                                    })]
                                }), X()]
                            }) : "simple-right" === $.style ? (0, t.jsxs)("div", {
                                className: "flex flex-col lg:flex-row gap-12",
                                children: [(0, t.jsxs)("div", {
                                    className: (0, o.AK)("flex flex-col lg:flex-row items-start lg:items-center gap-6", (null === $ || void 0 === $ ? void 0 : $.showLogo) ? "lg:gap-10" : "lg:gap-2"),
                                    children: [H(), !!$.additionalDetails && (0, t.jsxs)(t.Fragment, {
                                        children: [!(null === $ || void 0 === $ ? void 0 : $.showLogo) && (0, t.jsx)("span", {
                                            className: "hidden lg:inline-block",
                                            children: "\xb7"
                                        }), (0, t.jsx)("div", {
                                            className: "text-body",
                                            style: {
                                                color: z
                                            },
                                            children: null === $ || void 0 === $ ? void 0 : $.additionalDetails
                                        })]
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "flex-1 w-full flex flex-col lg:flex-row lg:items-center gap-12 lg:gap-14 justify-end",
                                    children: [(0, t.jsxs)("div", {
                                        className: "flex flex-col lg:flex-row items-start lg:items-center lg:justify-end gap-12 lg:gap-14 w-full lg:w-auto max-w-[100vw]",
                                        children: [J(), $.showSocial && Q(), (null === $ || void 0 === $ ? void 0 : $.button) && (0, t.jsx)(r.Z, {
                                            className: "lg !py-2",
                                            button: $.button,
                                            website: a
                                        })]
                                    }), X()]
                                })]
                            }) : "simple-center" === $.style ? (0, t.jsxs)("div", {
                                className: "flex flex-col justify-center gap-12 text-center",
                                children: [(0, t.jsxs)("div", {
                                    className: (0, o.AK)("flex flex-col justify-center lg:items-center gap-6", (null === $ || void 0 === $ ? void 0 : $.showLogo) ? "lg:gap-6" : "lg:flex-row lg:gap-2"),
                                    children: [H(), !!$.additionalDetails && (0, t.jsxs)(t.Fragment, {
                                        children: [!(null === $ || void 0 === $ ? void 0 : $.showLogo) && (0, t.jsx)("span", {
                                            className: "hidden lg:inline-block",
                                            children: "\xb7"
                                        }), (0, t.jsx)("div", {
                                            className: "text-body",
                                            style: {
                                                color: z
                                            },
                                            children: null === $ || void 0 === $ ? void 0 : $.additionalDetails
                                        })]
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "flex flex-col lg:flex-row lg:items-center justify-center gap-12 lg:gap-14",
                                    children: [J(), $.showSocial && Q(), (null === $ || void 0 === $ ? void 0 : $.button) && (0, t.jsx)(r.Z, {
                                        className: "lg !py-2",
                                        button: $.button,
                                        website: a
                                    }), X()]
                                })]
                            }) : (0, t.jsxs)("div", {
                                className: "flex flex-col lg:flex-row items-start lg:justify-between gap-12",
                                children: [(0, t.jsxs)("div", {
                                    className: "flex flex-col gap-6",
                                    children: [H(), !!(null === $ || void 0 === $ ? void 0 : $.additionalDetails) && (0, t.jsx)("div", {
                                        style: {
                                            color: z
                                        },
                                        children: null === $ || void 0 === $ ? void 0 : $.additionalDetails
                                    })]
                                }), (0, t.jsxs)("div", {
                                    className: "flex flex-col gap-12 lg:gap-6",
                                    children: [(0, t.jsxs)("div", {
                                        className: "flex flex-col lg:flex-row gap-12 lg:items-center lg:justify-end",
                                        children: [J(), $.showSocial && Q(), (null === $ || void 0 === $ ? void 0 : $.button) && (0, t.jsx)(r.Z, {
                                            className: "lg !py-2",
                                            button: $.button,
                                            website: a
                                        })]
                                    }), X()]
                                })]
                            })
                        })
                    }), (0, t.jsx)(D.V, {
                        open: L,
                        onClose: ll,
                        className: "relative z-[3000] h-full",
                        children: (0, t.jsx)(D.V.Panel, {
                            className: "fixed inset-0 flex flex-col h-full",
                            style: {
                                backgroundColor: _,
                                color: z
                            },
                            children: (0, t.jsxs)("div", {
                                className: "flex-1 flex flex-col h-full container mx-auto pb-6",
                                children: [(0, t.jsxs)("div", {
                                    className: (0, o.AK)("items-center gap-3 py-6", "left" !== (null === q || void 0 === q ? void 0 : q.style) ? "grid" : "flex justify-between"),
                                    style: "left" !== (null === q || void 0 === q ? void 0 : q.style) ? {
                                        gridTemplateColumns: "1fr auto 1fr"
                                    } : {},
                                    children: [("center" === (null === q || void 0 === q ? void 0 : q.style) || "full-center" === (null === q || void 0 === q ? void 0 : q.style)) && (0, t.jsx)("div", {}), function() {
                                        var l, e, s, n, d, r, u, v;
                                        return (null === q || void 0 === q ? void 0 : q.showLogo) && "branding" === (null === q || void 0 === q ? void 0 : q.source) && (null === a || void 0 === a ? void 0 : a.logo) ? (0, t.jsx)(c(), {
                                            href: "/",
                                            children: (0, t.jsxs)("a", {
                                                children: [(0, t.jsx)("img", {
                                                    className: "hidden lg:block transition-all object-contain",
                                                    src: null === a || void 0 === a || null === (l = a.logo) || void 0 === l ? void 0 : l.url,
                                                    alt: null === q || void 0 === q ? void 0 : q.siteName,
                                                    style: {
                                                        height: (null === q || void 0 === q || null === (e = q.logoDesktop) || void 0 === e ? void 0 : e.height) + "px"
                                                    }
                                                }), (0, t.jsx)("img", {
                                                    className: "lg:hidden transition-all object-contain",
                                                    src: null === a || void 0 === a || null === (s = a.logo) || void 0 === s ? void 0 : s.url,
                                                    alt: null === q || void 0 === q ? void 0 : q.siteName,
                                                    style: {
                                                        height: (null === q || void 0 === q || null === (n = q.logoMobile) || void 0 === n ? void 0 : n.height) + "px"
                                                    }
                                                })]
                                            })
                                        }) : (null === q || void 0 === q ? void 0 : q.showLogo) && "upload" === (null === q || void 0 === q ? void 0 : q.source) && (null === q || void 0 === q ? void 0 : q.customLogo) ? (0, t.jsx)(c(), {
                                            href: "/",
                                            children: (0, t.jsxs)("a", {
                                                children: [(0, t.jsx)("img", {
                                                    className: "hidden lg:block transition-all object-contain",
                                                    src: null === q || void 0 === q || null === (d = q.customLogo) || void 0 === d ? void 0 : d.url,
                                                    alt: null === q || void 0 === q ? void 0 : q.siteName,
                                                    style: {
                                                        height: (null === q || void 0 === q || null === (r = q.logoDesktop) || void 0 === r ? void 0 : r.height) + "px"
                                                    }
                                                }), (0, t.jsx)("img", {
                                                    className: "lg:hidden transition-all object-contain",
                                                    src: null === q || void 0 === q || null === (u = q.customLogo) || void 0 === u ? void 0 : u.url,
                                                    alt: null === q || void 0 === q ? void 0 : q.siteName,
                                                    style: {
                                                        height: (null === q || void 0 === q || null === (v = q.logoMobile) || void 0 === v ? void 0 : v.height) + "px"
                                                    }
                                                })]
                                            })
                                        }) : (0, t.jsx)(c(), {
                                            href: "/",
                                            children: (0, t.jsx)("a", {
                                                children: (0, t.jsx)("h1", {
                                                    className: "text-h6 lg:text-h4 xl:text-h3 font-medium truncate",
                                                    style: (0, i.Z)({
                                                        color: z
                                                    }, (0, o.j2)(a)),
                                                    children: null === q || void 0 === q ? void 0 : q.siteName
                                                })
                                            })
                                        })
                                    }(), (0, t.jsx)("div", {
                                        className: "ml-auto lg:hidden",
                                        children: (0, t.jsx)("button", {
                                            className: "inline-flex items-center justify-center p-2 rounded-md focus:outline-none",
                                            style: {
                                                color: z
                                            },
                                            onClick: ll,
                                            children: (0, t.jsx)(Z.Z, {
                                                className: "block h-5 w-5",
                                                "aria-hidden": "true"
                                            })
                                        })
                                    })]
                                }), (0, t.jsx)("ul", {
                                    className: (0, o.AK)("flex-1 flex flex-col justify-center gap-4 w-full py-6 overflow-auto", "center" === (null === $ || void 0 === $ ? void 0 : $.style) || "full-center" === (null === $ || void 0 === $ ? void 0 : $.style) ? "text-center" : ""),
                                    style: {
                                        color: z
                                    },
                                    children: null === U || void 0 === U ? void 0 : U.map((function(l) {
                                        return (0, t.jsx)("li", {
                                            className: (0, o.AK)("font-light text-xl py-2 border-b-2"),
                                            style: {
                                                borderColor: l.current ? "".concat(z) : "transparent"
                                            },
                                            children: (0, t.jsx)(c(), {
                                                href: l.href,
                                                children: (0, t.jsx)("a", {
                                                    className: "block w-full",
                                                    children: l.name
                                                })
                                            })
                                        }, "page-link-".concat(l.href))
                                    }))
                                })]
                            })
                        })
                    })]
                })
            }
        }
    }
]);