"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [617], {
        52077: function(e, s, l) {
            l.d(s, {
                Z: function() {
                    return d
                }
            });
            var a = l(85893),
                n = l(41664),
                t = l.n(n),
                i = l(16494),
                o = l(31996);

            function d(e) {
                var s, l, n, d, r, c, u = e.button,
                    m = e.type,
                    v = e.website,
                    x = e.action,
                    g = e.loading,
                    h = e.className,
                    f = (null === v || void 0 === v || null === (s = v.button) || void 0 === s ? void 0 : s.background) || (null === v || void 0 === v ? void 0 : v.secondaryColor),
                    b = {
                        background: "outline" === (null === v || void 0 === v || null === (l = v.button) || void 0 === l ? void 0 : l.style) ? "transparent" : f,
                        borderRadius: isNaN(null === v || void 0 === v || null === (n = v.button) || void 0 === n ? void 0 : n.cornerRadius) ? 8 : v.button.cornerRadius,
                        color: "outline" === (null === v || void 0 === v || null === (d = v.button) || void 0 === d ? void 0 : d.style) ? f : (0, o.$O)(f),
                        border: "2px solid ".concat(f)
                    };
                return x && "function" === typeof x || "submit" === m ? (0, a.jsx)("button", {
                    type: "submit" === m ? "submit" : "button",
                    onClick: x,
                    className: (0, o.AK)("button primary", h),
                    style: b,
                    disabled: g,
                    children: g ? (0, a.jsx)(i.Z, {}) : u.label
                }) : (0, a.jsx)(t(), {
                    href: function(e) {
                        if (e) {
                            if ("email" === e.type) return "mailto:" + e.link;
                            if ("phone" === e.type) return "tel:" + e.link;
                            if ("page" === e.type) {
                                var s, l, a, n = null === v || void 0 === v || null === (s = v.pages) || void 0 === s ? void 0 : s.find((function(s) {
                                        return s._id === e.page
                                    })),
                                    t = (null === n || void 0 === n ? void 0 : n.Parent) ? null === v || void 0 === v || null === (l = v.pages) || void 0 === l ? void 0 : l.find((function(e) {
                                        return e._id === (null === n || void 0 === n ? void 0 : n.Parent)
                                    })) : null,
                                    i = "";
                                return t && (i += "".concat(t.slug, "/")), i += null !== (a = null === n || void 0 === n ? void 0 : n.slug) && void 0 !== a ? a : "/"
                            }
                            var o, d = null === (o = e.link) || void 0 === o ? void 0 : o.replace(/https?:\/\//gi, "");
                            return d && "#" !== d ? "https://" + d : "#"
                        }
                        return "/"
                    }(u),
                    children: (0, a.jsx)("a", {
                        className: (0, o.AK)("button primary", h),
                        target: !0 === u.newPage ? "_blank" : (null === v || void 0 === v || null === (r = v.button) || void 0 === r ? void 0 : r.target) ? null === v || void 0 === v || null === (c = v.button) || void 0 === c ? void 0 : c.target : "_self",
                        style: b,
                        children: u.label
                    })
                })
            }
        },
        16494: function(e, s, l) {
            l.d(s, {
                Z: function() {
                    return t
                }
            });
            var a = l(85893),
                n = l(31996);

            function t(e) {
                var s = e.text,
                    l = e.className;
                switch (e.variant) {
                    case "form":
                        return (0, a.jsx)("div", {
                            className: "w-full max-w-screen-sm my-8",
                            children: (0, a.jsxs)("div", {
                                className: "animate-pulse flex space-y-8 flex-col",
                                children: [(0, a.jsxs)("div", {
                                    className: "space-y-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "h-4 bg-gray-100 rounded w-1/2"
                                    }), (0, a.jsx)("div", {
                                        className: "h-9 bg-gray-100 rounded"
                                    }), (0, a.jsx)("div", {
                                        className: "h-2 bg-gray-100 rounded w-5/6"
                                    })]
                                }), (0, a.jsx)("hr", {}), (0, a.jsxs)("div", {
                                    className: "space-y-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "h-4 bg-gray-100 rounded w-1/4"
                                    }), (0, a.jsx)("div", {
                                        className: "h-9 bg-gray-100 rounded"
                                    }), (0, a.jsx)("div", {
                                        className: "h-2 bg-gray-100 rounded w-1/2"
                                    })]
                                }), (0, a.jsx)("hr", {}), (0, a.jsxs)("div", {
                                    className: "space-y-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "h-4 bg-gray-100 rounded w-1/4"
                                    }), (0, a.jsx)("div", {
                                        className: "h-9 bg-gray-100 rounded"
                                    }), (0, a.jsx)("div", {
                                        className: "h-2 bg-gray-100 rounded w-1/2"
                                    })]
                                }), (0, a.jsx)("hr", {}), (0, a.jsxs)("div", {
                                    className: "space-y-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "h-4 bg-gray-100 rounded w-1/6"
                                    }), (0, a.jsx)("div", {
                                        className: "h-9 bg-gray-100 rounded"
                                    }), (0, a.jsx)("div", {
                                        className: "h-2 bg-gray-100 rounded w-3/4"
                                    })]
                                }), (0, a.jsx)("div", {
                                    className: "h-10 bg-gray-200 rounded w-1/4 ml-auto mt-4"
                                })]
                            })
                        });
                    case "table":
                        return (0, a.jsx)("div", {
                            className: "w-full my-8",
                            children: (0, a.jsxs)("div", {
                                className: "animate-pulse flex space-y-2 flex-col",
                                children: [(0, a.jsxs)("div", {
                                    className: "space-x-2 flex",
                                    children: [(0, a.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, a.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, a.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, a.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, a.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, a.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    })]
                                }), [1, 2, 3, 4, 5, 6].map((function(e) {
                                    return (0, a.jsxs)("div", {
                                        className: "space-x-2 flex",
                                        children: [(0, a.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, a.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, a.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, a.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, a.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, a.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        })]
                                    }, e)
                                }))]
                            })
                        });
                    default:
                        return (0, a.jsxs)("div", {
                            className: (0, n.AK)("inline-flex items-center", l),
                            children: [(0, a.jsxs)("svg", {
                                className: (0, n.AK)("animate-spin ml-1 mr-3 h-4 w-4", l && "text-indigo-600"),
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                children: [(0, a.jsx)("circle", {
                                    className: "opacity-25",
                                    cx: "12",
                                    cy: "12",
                                    r: "10",
                                    stroke: "currentColor",
                                    strokeWidth: "4"
                                }), (0, a.jsx)("path", {
                                    className: "opacity-75",
                                    fill: "currentColor",
                                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                })]
                            }), s || "" === s ? s : "Loading..."]
                        })
                }
            }
        },
        40617: function(e, s, l) {
            l.r(s), l.d(s, {
                default: function() {
                    return c
                }
            });
            var a = l(14251),
                n = l(85893),
                t = l(31996),
                i = l(67294),
                o = l(29260),
                d = l.n(o),
                r = l(52077);

            function c(e) {
                var s = e.block,
                    l = e.website,
                    o = (0, i.useState)(null),
                    c = o[0],
                    u = o[1],
                    m = (0, i.useState)(!1),
                    v = m[0],
                    x = m[1],
                    g = (0, i.useState)(!1),
                    h = g[0],
                    f = g[1],
                    b = (0, i.useState)(!1),
                    j = b[0],
                    y = b[1],
                    N = (0, i.useState)(!1),
                    p = N[0],
                    w = N[1],
                    k = (0, i.useState)(!1),
                    S = k[0],
                    A = k[1],
                    C = (0, i.useState)(null),
                    _ = C[0],
                    F = C[1],
                    K = (0, i.useState)(null),
                    P = K[0],
                    R = K[1],
                    M = (0, i.useState)(null),
                    Z = (M[0], M[1]),
                    z = (0, i.useState)(null),
                    I = z[0],
                    W = z[1],
                    E = (0, i.useState)("#FFFFFF"),
                    H = E[0],
                    B = E[1],
                    L = (0, i.useState)("#111827"),
                    O = L[0],
                    $ = L[1],
                    T = function(e) {
                        return "small" === e ? "rounded-sm" : "medium" === e ? "rounded-md" : "large" === e ? "rounded-lg" : ""
                    };
                return (0, i.useEffect)((function() {
                    s && (u(s.headline), x(s.showImage), f(s.showIcon), y(s.showHeading), w(s.showContent), A(s.showButton), F(s.aspectRatio), R(s.cornerRadius), Z(s.justify), W(s.align), B(s.background))
                }), [s]), (0, i.useEffect)((function() {
                    H && $((0, t.$O)(H))
                }), [H]), (0, n.jsx)("section", {
                    className: "flex-shrink-0",
                    style: {
                        backgroundColor: H
                    },
                    children: (0, n.jsxs)("div", {
                        className: (0, t.AK)("container mx-auto py-12 lg:py-14 xl:py-20"),
                        children: [c && (0, n.jsx)("h2", {
                            className: (0, t.AK)("text-h3 lg:text-h1 font-medium mb-4 lg:mb-10", "text-".concat(I)),
                            style: (0, a.Z)({
                                color: O
                            }, (0, t.j2)(l)),
                            children: c
                        }), (null === s || void 0 === s ? void 0 : s.items) && (0, n.jsxs)("div", {
                            className: (0, t.AK)("flex flex-col sm:flex-row flex-wrap gap-10", "justify-".concat("left" === I ? "start" : "center" === I ? "center" : "end")),
                            children: [(0, n.jsx)("span", {
                                className: "hidden justify-center justify-end justify-start"
                            }), s.items.map((function(e, i) {
                                var o, c, u, m, x, g, f;
                                return (0, n.jsxs)("div", {
                                    className: "block-list-item w-full",
                                    children: [v && e.image && (0, n.jsx)("div", {
                                        className: (0, t.AK)("flex-shrink-0 relative mb-6", (f = _, "1:1" === f ? "aspect-w-1 aspect-h-1" : "2:3" === f ? "aspect-w-2 aspect-h-3" : "3:2" === f ? "aspect-w-3 aspect-h-2" : "aspect-w-16 aspect-h-9")),
                                        children: (0, n.jsx)(d(), {
                                            src: e.image.url,
                                            objectFit: (null === s || void 0 === s ? void 0 : s.imageFit) || "cover",
                                            objectPosition: "".concat(e.imagePositionX || "center", " ").concat(e.imagePositionY || "center"),
                                            layout: "fill",
                                            alt: e.title,
                                            className: T(P)
                                        })
                                    }), h && (null === (o = e.icon) || void 0 === o ? void 0 : o.media) && (0, n.jsx)("div", {
                                        className: (0, t.AK)("flex-shrink-0 relative mb-6", (null === s || void 0 === s ? void 0 : s.iconSize) || "w-12 h-12", "left" === I ? "mr-auto" : "center" === I ? "mx-auto" : "ml-auto"),
                                        children: (0, n.jsx)("div", {
                                            className: "absolute w-full h-full",
                                            style: {
                                                backgroundColor: (null === (c = e.icon) || void 0 === c ? void 0 : c.color) || "#1F2937",
                                                WebkitMaskImage: 'url("'.concat(null === e || void 0 === e || null === (u = e.icon) || void 0 === u || null === (m = u.media) || void 0 === m ? void 0 : m.url, '")'),
                                                maskImage: 'url("'.concat(null === e || void 0 === e || null === (x = e.icon) || void 0 === x || null === (g = x.media) || void 0 === g ? void 0 : g.url, '")'),
                                                WebkitMaskPosition: "center",
                                                maskPosition: "center",
                                                WebkitMaskRepeat: "no-repeat",
                                                maskRepeat: "no-repeat",
                                                WebkitMaskSize: "contain",
                                                maskSize: "contain"
                                            }
                                        })
                                    }), (0, n.jsxs)("div", {
                                        className: "text-".concat(I),
                                        children: [j && (0, n.jsx)("p", {
                                            className: "text-xl lg:text-2xl xl:text-h3 font-medium mb-2",
                                            style: (0, a.Z)({
                                                color: O
                                            }, (0, t.j2)(l)),
                                            children: e.title
                                        }), p && (0, n.jsx)("div", {
                                            className: "rich-text-block",
                                            style: {
                                                color: O
                                            },
                                            dangerouslySetInnerHTML: {
                                                __html: e.content
                                            }
                                        }), S && (null === e || void 0 === e ? void 0 : e.button) && (0, n.jsx)(r.Z, {
                                            button: e.button,
                                            website: l,
                                            className: "lg mt-4"
                                        })]
                                    })]
                                }, i)
                            }))]
                        })]
                    })
                })
            }
        }
    }
]);