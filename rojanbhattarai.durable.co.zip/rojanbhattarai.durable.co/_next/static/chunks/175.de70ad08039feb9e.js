"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [175], {
        73175: function(l, e, i) {
            i.r(e), i.d(e, {
                default: function() {
                    return z
                }
            });
            var n = i(14251),
                o = i(85893),
                t = i(31996),
                s = i(67294),
                a = i(52077),
                r = i(90387),
                c = i(41664),
                d = i.n(c),
                u = i(72510),
                v = i(18732),
                h = i(71029),
                m = i(85296),
                f = i(44171),
                x = i(43180),
                g = i(10151),
                p = i(36234),
                y = i(66909),
                j = i(49791),
                b = i(28239),
                N = i(48192),
                k = i(94206),
                w = i(13487),
                A = i(32713),
                C = i(65710),
                Z = i(43751),
                S = i(3677),
                F = i(41984),
                K = i(74007),
                _ = [{
                    id: "facebook",
                    host: "facebook.com"
                }, {
                    id: "twitter",
                    host: "twitter.com"
                }, {
                    id: "linkedin",
                    host: "linkedin.com"
                }, {
                    id: "youtube",
                    host: "youtube.com"
                }, {
                    id: "pinterest",
                    host: "pinterest.com"
                }, {
                    id: "instagram",
                    host: "instagram.com"
                }, {
                    id: "tiktok",
                    host: "tiktok.com"
                }, {
                    id: "thumbtack",
                    host: "thumbtack.com"
                }, {
                    id: "homeadvisor",
                    host: "homeadvisor.com"
                }, {
                    id: "angi",
                    host: "angi.com"
                }, {
                    id: "behance",
                    host: "behance.net"
                }, {
                    id: "dribbble",
                    host: "dribbble.com"
                }];

            function z(l) {
                var e, i, c, z, M, P, E, L, T, W, D = l.website,
                    B = (0, t.ac)("(max-width: 1023px)"),
                    I = (0, s.useState)(!1),
                    O = I[0],
                    R = I[1],
                    H = (0, s.useState)("#FFFFFF"),
                    V = H[0],
                    $ = H[1],
                    q = (0, s.useState)("#000000"),
                    G = q[0],
                    J = q[1],
                    Q = (0, s.useState)(null),
                    U = Q[0],
                    X = Q[1],
                    Y = (0, r.useRouter)(),
                    ll = null === D || void 0 === D ? void 0 : D.header,
                    el = null === (i = null === (e = D.pages) || void 0 === e ? void 0 : e.filter((function(l) {
                        return (!0 === l.showOnHeader || void 0 === l.showOnHeader) && null !== l.slug
                    }))) || void 0 === i ? void 0 : i.map((function(l) {
                        var e = {
                            href: "/".concat(l.slug || ""),
                            name: l.label,
                            current: Y.asPath === "/".concat(l.slug || ""),
                            type: l.type
                        };
                        return "parent" === e.type && (e.nests = D.pages.filter((function(e) {
                            return e.Parent === l._id
                        })).map((function(e) {
                            return {
                                href: "/".concat(l.slug, "/").concat(e.slug || ""),
                                name: e.label,
                                current: Y.asPath === "/".concat(l.slug, "/").concat(e.slug || "")
                            }
                        })), 0 === e.nests.length) ? null : e
                    })).filter((function(l) {
                        return null !== l
                    })),
                    il = function(l, e) {
                        var i = e ? "w-6 h-6 lg:w-8 lg:h-8" : "w-8 h-8";
                        switch (l.type) {
                            case "angi":
                                return (0, o.jsx)(h.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "behance":
                                return (0, o.jsx)(m.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "dribbble":
                                return (0, o.jsx)(f.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "facebook":
                                return (0, o.jsx)(x.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "homeadvisor":
                                return (0, o.jsx)(g.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "instagram":
                                return (0, o.jsx)(p.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "linkedin":
                                return (0, o.jsx)(y.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "pinterest":
                                return (0, o.jsx)(j.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "tiktok":
                                return (0, o.jsx)(b.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "thumbtack":
                                return (0, o.jsx)(N.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "twitter":
                                return (0, o.jsx)(k.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "youtube":
                                return (0, o.jsx)(w.Z, {
                                    className: i,
                                    style: {
                                        color: G
                                    }
                                });
                            case "custom":
                                var n, s;
                                return (0, o.jsx)("div", {
                                    className: (0, t.AK)("flex-shrink-0 relative", i),
                                    children: (0, o.jsx)("div", {
                                        className: "absolute w-full h-full",
                                        style: {
                                            backgroundColor: G || "#000000",
                                            WebkitMaskImage: 'url("'.concat(null === l || void 0 === l || null === (n = l.icon) || void 0 === n ? void 0 : n.url, '")'),
                                            maskImage: 'url("'.concat(null === l || void 0 === l || null === (s = l.icon) || void 0 === s ? void 0 : s.url, '")'),
                                            WebkitMaskPosition: "center",
                                            maskPosition: "center",
                                            WebkitMaskRepeat: "no-repeat",
                                            maskRepeat: "no-repeat",
                                            WebkitMaskSize: "contain",
                                            maskSize: "contain"
                                        }
                                    })
                                })
                        }
                    },
                    nl = function() {
                        return (0, o.jsx)("div", {
                            className: (0, t.AK)("hidden lg:flex items-center flex-shrink-0"),
                            children: (0, o.jsx)(a.Z, {
                                className: "xl !text-2xl !py-1.5",
                                button: null === ll || void 0 === ll ? void 0 : ll.button,
                                website: D
                            })
                        })
                    },
                    ol = function(l, e) {
                        return (0, o.jsx)("ul", {
                            className: (0, t.AK)("lg:flex items-center gap-x-4 gap-y-2 flex-wrap", "full-center" !== l ? "justify-end" : "", !e && "hidden"),
                            children: Array.isArray(D.social) && D.social.map((function(l, i) {
                                var n = _.find((function(e) {
                                        return e.id === l.type
                                    })),
                                    t = l.link;
                                return "custom" !== l.type && (t = (t = l.link.replace(/[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\//gi, "").replace(/https?:/g, "").replace(/^\/\/?/g, "")).replace(null === n || void 0 === n ? void 0 : n.host, ""), t = "https://".concat(null === n || void 0 === n ? void 0 : n.host, "/").concat(t)), (0, o.jsx)("li", {
                                    children: (0, o.jsx)(d(), {
                                        href: t,
                                        children: (0, o.jsx)("a", {
                                            target: "_blank",
                                            children: il(l, e)
                                        })
                                    })
                                }, "social-icon-header-".concat(i))
                            }))
                        })
                    },
                    tl = function() {
                        var l, e, i, s, a, r, c, u;
                        return (null === ll || void 0 === ll ? void 0 : ll.showLogo) && "branding" === (null === ll || void 0 === ll ? void 0 : ll.source) && (null === D || void 0 === D ? void 0 : D.logo) ? (0, o.jsx)(d(), {
                            href: "/",
                            children: (0, o.jsxs)("a", {
                                children: [(0, o.jsx)("img", {
                                    className: "hidden lg:block transition-all object-contain",
                                    src: null === D || void 0 === D || null === (l = D.logo) || void 0 === l ? void 0 : l.url,
                                    alt: null === ll || void 0 === ll ? void 0 : ll.siteName,
                                    style: {
                                        height: (null === ll || void 0 === ll || null === (e = ll.logoDesktop) || void 0 === e ? void 0 : e.height) + "px"
                                    }
                                }), (0, o.jsx)("img", {
                                    className: "lg:hidden transition-all object-contain",
                                    src: null === D || void 0 === D || null === (i = D.logo) || void 0 === i ? void 0 : i.url,
                                    alt: null === ll || void 0 === ll ? void 0 : ll.siteName,
                                    style: {
                                        height: (null === ll || void 0 === ll || null === (s = ll.logoMobile) || void 0 === s ? void 0 : s.height) + "px"
                                    }
                                })]
                            })
                        }) : (null === ll || void 0 === ll ? void 0 : ll.showLogo) && "upload" === (null === ll || void 0 === ll ? void 0 : ll.source) && (null === ll || void 0 === ll ? void 0 : ll.customLogo) ? (0, o.jsx)(d(), {
                            href: "/",
                            children: (0, o.jsxs)("a", {
                                children: [(0, o.jsx)("img", {
                                    className: "hidden lg:block transition-all object-contain",
                                    src: null === ll || void 0 === ll || null === (a = ll.customLogo) || void 0 === a ? void 0 : a.url,
                                    alt: null === ll || void 0 === ll ? void 0 : ll.siteName,
                                    style: {
                                        height: (null === ll || void 0 === ll || null === (r = ll.logoDesktop) || void 0 === r ? void 0 : r.height) + "px"
                                    }
                                }), (0, o.jsx)("img", {
                                    className: "lg:hidden transition-all object-contain",
                                    src: null === ll || void 0 === ll || null === (c = ll.customLogo) || void 0 === c ? void 0 : c.url,
                                    alt: null === ll || void 0 === ll ? void 0 : ll.siteName,
                                    style: {
                                        height: (null === ll || void 0 === ll || null === (u = ll.logoMobile) || void 0 === u ? void 0 : u.height) + "px"
                                    }
                                })]
                            })
                        }) : (0, o.jsx)(d(), {
                            href: "/",
                            children: (0, o.jsx)("a", {
                                children: (0, o.jsx)("h1", {
                                    className: "text-h6 lg:text-h4 xl:text-h3 font-medium truncate",
                                    style: (0, n.Z)({
                                        color: G
                                    }, (0, t.j2)(D)),
                                    children: null === ll || void 0 === ll ? void 0 : ll.siteName
                                })
                            })
                        })
                    },
                    sl = function(l) {
                        var e;
                        if (0 === (null === el || void 0 === el ? void 0 : el.length)) return (0, o.jsx)(o.Fragment, {});
                        var i = (0, t.h)(V, -10);
                        return i !== G && i !== V || (i = (0, t.h)(V, 10)), (0, o.jsx)("ul", {
                            className: (0, t.AK)("hidden lg:flex items-center flex-wrap gap-x-6", "left" === l && "justify-end", "full-center" === l && "justify-center"),
                            style: {
                                color: G
                            },
                            children: null === (e = null === el || void 0 === el ? void 0 : el.filter((function(l) {
                                return "nested" !== l.type
                            }))) || void 0 === e ? void 0 : e.map((function(l) {
                                var e;
                                return (0, o.jsx)("li", {
                                    className: "border-b-2",
                                    style: {
                                        borderColor: l.current ? "".concat(G) : "transparent"
                                    },
                                    children: "parent" === l.type ? (0, o.jsx)(K.Z, {
                                        buttonClassName: "inline-flex items-center gap-2 py-1.5",
                                        itemsContainerClass: "!pl-6 !pr-12 w-max max-w-120",
                                        button: (0, o.jsxs)(o.Fragment, {
                                            children: [(0, o.jsx)("span", {
                                                className: "text-xl font-light whitespace-nowrap",
                                                children: l.name
                                            }), (0, o.jsx)(A.Z, {
                                                className: "w-4 h-4"
                                            })]
                                        }),
                                        itemsContainerStyle: {
                                            backgroundColor: i,
                                            color: G
                                        },
                                        children: null === (e = l.nests) || void 0 === e ? void 0 : e.map((function(l) {
                                            return (0, o.jsx)(u.v.Item, {
                                                children: (0, o.jsx)(d(), {
                                                    href: l.href,
                                                    legacyBehavior: !1,
                                                    className: "block py-2 text-xl font-light border-b-2",
                                                    style: {
                                                        borderColor: l.current ? "".concat(G) : "transparent"
                                                    },
                                                    children: l.name
                                                })
                                            }, "page-link-".concat(l.href))
                                        }))
                                    }) : (0, o.jsx)(d(), {
                                        href: l.href,
                                        children: (0, o.jsx)("a", {
                                            className: "block py-1.5 text-xl font-light whitespace-nowrap",
                                            children: l.name
                                        })
                                    })
                                }, "page-link-".concat(l.href))
                            }))
                        })
                    };
                return (0, s.useEffect)((function() {
                    if (ll) {
                        var l, e, i;
                        if ($(ll.background), null === ll.siteName || void 0 === ll.siteName) ll.siteName = null === D || void 0 === D || null === (i = D.Business) || void 0 === i ? void 0 : i.name;
                        ll.style || (ll.style = "left"), (null === (l = ll.logoDesktop) || void 0 === l ? void 0 : l.height) || (ll.logoDesktop = {
                            height: 80
                        }), (null === (e = ll.logoMobile) || void 0 === e ? void 0 : e.height) || (ll.logoMobile = {
                            height: 40
                        })
                    }
                }), [ll]), (0, s.useEffect)((function() {
                    V && J((0, t.$O)(V))
                }), [V]), (0, s.useEffect)((function() {
                    R(!1), X(null)
                }), [Y, B]), (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsx)("header", {
                        className: (0, t.AK)((null === ll || void 0 === ll ? void 0 : ll.sticky) ? "sticky top-0 shadow-sm" : "", (null === ll || void 0 === ll ? void 0 : ll.sticky) && !O ? "!z-[2000]" : ""),
                        style: {
                            backgroundColor: V,
                            color: G
                        },
                        children: (0, o.jsx)("div", {
                            className: (0, t.AK)("grid items-center lg:gap-6 xl:gap-10 mx-auto py-6", (null === ll || void 0 === ll ? void 0 : ll.fullWidth) ? "px-6 lg:px-12" : "container"),
                            style: (W = null === ll || void 0 === ll ? void 0 : ll.style, "center" === W ? {
                                gridTemplateColumns: "1fr auto 1fr"
                            } : "full-center" === W ? (null === el || void 0 === el ? void 0 : el.length) > 6 ? {
                                gridTemplateColumns: "1fr 4fr 1fr"
                            } : {
                                gridTemplateColumns: "1fr 1fr 1fr"
                            } : {
                                gridTemplateColumns: "auto auto auto"
                            }),
                            children: "center" === (null === ll || void 0 === ll ? void 0 : ll.style) ? (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)("div", {
                                    className: "w-9 lg:w-auto",
                                    children: sl(null === ll || void 0 === ll ? void 0 : ll.style)
                                }), (0, o.jsx)("div", {
                                    className: "flex justify-center truncate",
                                    children: tl()
                                }), (0, o.jsxs)("div", {
                                    className: "flex justify-end",
                                    children: [(0, o.jsxs)("div", {
                                        className: "hidden lg:flex item-center gap-10",
                                        children: [(null === ll || void 0 === ll ? void 0 : ll.showSocial) && ol(null === ll || void 0 === ll ? void 0 : ll.style), (null === ll || void 0 === ll ? void 0 : ll.button) && nl()]
                                    }), (0, o.jsxs)("div", {
                                        className: "ml-auto lg:hidden",
                                        children: [((null === ll || void 0 === ll ? void 0 : ll.button) || (null === el || void 0 === el ? void 0 : el.length) > 0 || (null === ll || void 0 === ll ? void 0 : ll.showSocial) && Array.isArray(null === D || void 0 === D ? void 0 : D.social) && (null === D || void 0 === D || null === (c = D.social) || void 0 === c ? void 0 : c.length) > 1) && (0, o.jsx)("button", {
                                            className: "inline-flex items-center justify-center p-2 rounded-md focus:outline-none",
                                            style: {
                                                color: G
                                            },
                                            onClick: function() {
                                                return R(!0)
                                            },
                                            children: (0, o.jsx)(C.Z, {
                                                className: "block h-5 w-5",
                                                "aria-hidden": "true"
                                            })
                                        }), !(null === ll || void 0 === ll ? void 0 : ll.button) && 0 === (null === el || void 0 === el ? void 0 : el.length) && (null === ll || void 0 === ll ? void 0 : ll.showSocial) && Array.isArray(null === D || void 0 === D ? void 0 : D.social) && 1 === (null === D || void 0 === D || null === (z = D.social) || void 0 === z ? void 0 : z.length) && ol(null === ll || void 0 === ll ? void 0 : ll.style, !0)]
                                    })]
                                })]
                            }) : "full-center" === (null === ll || void 0 === ll ? void 0 : ll.style) ? (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)("div", {
                                    className: "w-9 lg:w-auto",
                                    children: (null === ll || void 0 === ll ? void 0 : ll.showSocial) && ol(null === ll || void 0 === ll ? void 0 : ll.style)
                                }), (0, o.jsxs)("div", {
                                    className: "flex-1 flex flex-col items-center gap-4",
                                    children: [(0, o.jsx)("div", {
                                        className: "flex justify-center w-full truncate",
                                        children: tl()
                                    }), sl(null === ll || void 0 === ll ? void 0 : ll.style)]
                                }), (0, o.jsxs)("div", {
                                    className: "flex justify-end",
                                    children: [(null === ll || void 0 === ll ? void 0 : ll.button) && nl(), (0, o.jsxs)("div", {
                                        className: "ml-auto lg:hidden",
                                        children: [((null === ll || void 0 === ll ? void 0 : ll.button) || (null === el || void 0 === el ? void 0 : el.length) > 0 || (null === ll || void 0 === ll ? void 0 : ll.showSocial) && Array.isArray(null === D || void 0 === D ? void 0 : D.social) && (null === D || void 0 === D || null === (M = D.social) || void 0 === M ? void 0 : M.length) > 1) && (0, o.jsx)("button", {
                                            className: "inline-flex items-center justify-center p-2 rounded-md focus:outline-none",
                                            style: {
                                                color: G
                                            },
                                            onClick: function() {
                                                return R(!0)
                                            },
                                            children: (0, o.jsx)(C.Z, {
                                                className: "block h-5 w-5",
                                                "aria-hidden": "true"
                                            })
                                        }), !(null === ll || void 0 === ll ? void 0 : ll.button) && 0 === (null === el || void 0 === el ? void 0 : el.length) && (null === ll || void 0 === ll ? void 0 : ll.showSocial) && Array.isArray(null === D || void 0 === D ? void 0 : D.social) && 1 === (null === D || void 0 === D || null === (P = D.social) || void 0 === P ? void 0 : P.length) && ol(null === ll || void 0 === ll ? void 0 : ll.style, !0)]
                                    })]
                                })]
                            }) : (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)("div", {
                                    className: "col-span-2 lg:col-span-1 truncate",
                                    children: tl()
                                }), (0, o.jsxs)("div", {
                                    className: "hidden lg:flex item-center justify-end gap-10 lg:col-span-2",
                                    children: [sl(null === ll || void 0 === ll ? void 0 : ll.style), (null === ll || void 0 === ll ? void 0 : ll.showSocial) && ol(null === ll || void 0 === ll ? void 0 : ll.style), (null === ll || void 0 === ll ? void 0 : ll.button) && nl()]
                                }), (0, o.jsxs)("div", {
                                    className: "ml-auto lg:hidden",
                                    children: [((null === ll || void 0 === ll ? void 0 : ll.button) || (null === el || void 0 === el ? void 0 : el.length) > 0 || (null === ll || void 0 === ll ? void 0 : ll.showSocial) && Array.isArray(null === D || void 0 === D ? void 0 : D.social) && (null === D || void 0 === D || null === (E = D.social) || void 0 === E ? void 0 : E.length) > 1) && (0, o.jsx)("button", {
                                        className: "inline-flex items-center justify-center p-2 rounded-md focus:outline-none",
                                        style: {
                                            color: G
                                        },
                                        onClick: function() {
                                            return R(!0)
                                        },
                                        children: (0, o.jsx)(C.Z, {
                                            className: "block h-5 w-5",
                                            "aria-hidden": "true"
                                        })
                                    }), !(null === ll || void 0 === ll ? void 0 : ll.button) && 0 === (null === el || void 0 === el ? void 0 : el.length) && (null === ll || void 0 === ll ? void 0 : ll.showSocial) && Array.isArray(null === D || void 0 === D ? void 0 : D.social) && 1 === (null === D || void 0 === D || null === (L = D.social) || void 0 === L ? void 0 : L.length) && ol(null === ll || void 0 === ll ? void 0 : ll.style, !0)]
                                })]
                            })
                        })
                    }), (0, o.jsx)(v.V, {
                        open: O,
                        onClose: function() {
                            return R(!1)
                        },
                        className: "relative z-[3000] h-full",
                        children: (0, o.jsx)(v.V.Panel, {
                            className: "fixed inset-0 flex flex-col h-full",
                            style: {
                                backgroundColor: V,
                                color: G
                            },
                            children: (0, o.jsxs)("div", {
                                className: "flex-1 flex flex-col h-full container mx-auto pb-6",
                                children: [(0, o.jsxs)("div", {
                                    className: (0, t.AK)("items-center gap-3 py-6", "left" !== (null === ll || void 0 === ll ? void 0 : ll.style) ? "grid" : "flex justify-between"),
                                    style: "left" !== (null === ll || void 0 === ll ? void 0 : ll.style) ? {
                                        gridTemplateColumns: "1fr auto 1fr"
                                    } : {},
                                    children: [("center" === (null === ll || void 0 === ll ? void 0 : ll.style) || "full-center" === (null === ll || void 0 === ll ? void 0 : ll.style)) && (0, o.jsx)("div", {}), tl(), (0, o.jsx)("div", {
                                        className: "ml-auto lg:hidden",
                                        children: (0, o.jsx)("button", {
                                            className: "inline-flex items-center justify-center p-2 rounded-md focus:outline-none",
                                            style: {
                                                color: G
                                            },
                                            onClick: function() {
                                                return R(!1)
                                            },
                                            children: (0, o.jsx)(Z.Z, {
                                                className: "block h-5 w-5",
                                                "aria-hidden": "true"
                                            })
                                        })
                                    })]
                                }), (null === el || void 0 === el ? void 0 : el.filter((function(l) {
                                    return "nested" !== l.type
                                })).length) > 0 && (0, o.jsxs)("ul", {
                                    className: (0, t.AK)("flex-1 flex flex-col justify-center gap-4 w-full py-6 overflow-auto", "center" === (null === ll || void 0 === ll ? void 0 : ll.style) || "full-center" === (null === ll || void 0 === ll ? void 0 : ll.style) ? "text-center" : ""),
                                    style: {
                                        color: G
                                    },
                                    children: [U && (0, o.jsx)("li", {
                                        className: "pb-6",
                                        children: (0, o.jsxs)("button", {
                                            className: "inline-flex items-center gap-2 text-xl",
                                            onClick: function() {
                                                return X(null)
                                            },
                                            children: [(0, o.jsx)(S.Z, {
                                                className: "w-4 h-4",
                                                "aria-hidden": "true"
                                            }), (0, o.jsx)("span", {
                                                children: "Back"
                                            })]
                                        })
                                    }), !U && (null === el || void 0 === el ? void 0 : el.filter((function(l) {
                                        return "nested" !== l.type
                                    })).map((function(l) {
                                        return (0, o.jsx)("li", {
                                            className: (0, t.AK)("font-light text-xl py-2 border-b-2"),
                                            style: {
                                                borderColor: l.current ? "".concat(G) : "transparent"
                                            },
                                            children: "parent" === l.type && l.nests.length > 0 ? (0, o.jsxs)("button", {
                                                className: "inline-flex items-center gap-2",
                                                onClick: function() {
                                                    return X(l.nests)
                                                },
                                                children: [(0, o.jsx)("span", {
                                                    children: l.name
                                                }), (0, o.jsx)(F.Z, {
                                                    className: "w-4 h-4",
                                                    "aria-hidden": "true"
                                                })]
                                            }) : (0, o.jsx)(d(), {
                                                href: l.href,
                                                children: (0, o.jsx)("a", {
                                                    className: "block w-full",
                                                    children: l.name
                                                })
                                            })
                                        }, "page-link-".concat(l.href))
                                    }))), null === U || void 0 === U ? void 0 : U.map((function(l) {
                                        return (0, o.jsx)("li", {
                                            className: (0, t.AK)("font-light text-xl py-2 border-b-2"),
                                            style: {
                                                borderColor: l.current ? "".concat(G) : "transparent"
                                            },
                                            children: (0, o.jsx)(d(), {
                                                href: l.href,
                                                children: (0, o.jsx)("a", {
                                                    className: "block w-full",
                                                    children: l.name
                                                })
                                            })
                                        }, "page-link-".concat(l.href))
                                    }))]
                                }), (0, o.jsxs)("div", {
                                    className: (0, t.AK)("flex flex-col max-w-[100vw]", "center" === (null === ll || void 0 === ll ? void 0 : ll.style) || "full-center" === (null === ll || void 0 === ll ? void 0 : ll.style) ? "items-center" : "", (null === el || void 0 === el ? void 0 : el.length) > 0 ? "" : "h-full justify-center"),
                                    children: [(null === ll || void 0 === ll ? void 0 : ll.showSocial) && (null === (T = D.social) || void 0 === T ? void 0 : T.length) > 0 && (0, o.jsx)("ul", {
                                        className: "flex items-center gap-x-4 gap-y-2 flex-wrap py-6",
                                        children: Array.isArray(D.social) && D.social.map((function(l, e) {
                                            var i = _.find((function(e) {
                                                    return e.id === l.type
                                                })),
                                                n = l.link;
                                            return "custom" !== l.type && (n = (n = l.link.replace(/[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\//gi, "").replace(/https?:/g, "").replace(/^\/\/?/g, "")).replace(null === i || void 0 === i ? void 0 : i.host, ""), n = "https://".concat(null === i || void 0 === i ? void 0 : i.host, "/").concat(n)), (0, o.jsx)("li", {
                                                children: (0, o.jsx)(d(), {
                                                    href: n,
                                                    children: (0, o.jsx)("a", {
                                                        target: "_blank",
                                                        children: il(l)
                                                    })
                                                })
                                            }, "social-icon-header-".concat(e))
                                        }))
                                    }), (null === ll || void 0 === ll ? void 0 : ll.button) && (0, o.jsx)("div", {
                                        className: "py-6",
                                        children: (0, o.jsx)(a.Z, {
                                            className: "xl !font-normal !py-1.5",
                                            button: ll.button,
                                            website: D
                                        })
                                    })]
                                })]
                            })
                        })
                    })]
                })
            }
        }
    }
]);