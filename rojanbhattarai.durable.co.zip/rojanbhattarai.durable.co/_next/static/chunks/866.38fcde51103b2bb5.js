"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [866], {
        50866: function(t, e, n) {
            n.r(e), n.d(e, {
                default: function() {
                    return c
                }
            });
            var l = n(85893),
                u = n(31996),
                a = n(67294);

            function c(t) {
                t.website;
                var e = t.block,
                    n = (0, a.useState)(null),
                    c = n[0],
                    s = n[1],
                    o = (0, a.useState)(null),
                    r = o[0],
                    i = o[1],
                    f = (0, a.useState)("#F3F4F6"),
                    m = f[0],
                    x = f[1],
                    d = (0, a.useState)("#111827"),
                    h = d[0],
                    k = d[1];
                return (0, a.useEffect)((function() {
                    e && (s(e.content), i(e.align), x(e.background))
                }), [e]), (0, a.useEffect)((function() {
                    m && k((0, u.$O)(m))
                }), [m]), (0, l.jsx)("section", {
                    className: "flex-shrink-0",
                    style: {
                        backgroundColor: m
                    },
                    children: (0, l.jsx)("div", {
                        className: (0, u.AK)("container mx-auto py-12 lg:py-14 xl:py-20"),
                        children: (0, l.jsx)("div", {
                            className: (0, u.AK)("rich-text-block max-w-5xl", "text-".concat(r), "left" === r ? "ml-0 mr-auto" : "right" === r ? "ml-auto mr-0" : "mx-auto"),
                            style: {
                                color: h
                            },
                            dangerouslySetInnerHTML: {
                                __html: c
                            }
                        })
                    })
                })
            }
        }
    }
]);