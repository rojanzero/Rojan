"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [376], {
        94179: function(d, l, n) {
            n.r(l), n.d(l, {
                default: function() {
                    return r
                }
            });
            var e = n(85893),
                o = n(31996);

            function r(d) {
                var l, n, r = d.block,
                    u = null === r || void 0 === r ? void 0 : r.background,
                    i = null !== (l = null === r || void 0 === r ? void 0 : r.profile) && void 0 !== l ? l : "durableteam",
                    s = null === r || void 0 === r ? void 0 : r.cornerRadius;
                return (0, e.jsx)("section", {
                    style: {
                        backgroundColor: u
                    },
                    children: (0, e.jsx)("div", {
                        className: "container py-12 lg:py-14 xl:py-20 mx-auto h-[504px] xs:h-[115vw] sm:h-[690px] md:h-[780px] lg:h-[960px] xl:h-[1200px] 2xl:h-[1360px]",
                        children: (0, e.jsx)("iframe", {
                            className: (0, o.AK)("w-full", (n = s, "small" === n ? "rounded-sm md:rounded-md lg:rounded-lg" : "medium" === n ? "rounded-lg md:rounded-xl lg:rounded-2xl" : "large" === n ? "rounded-2xl md:rounded-3xl lg:rounded-4xl" : "")),
                            height: "100%",
                            widht: "100%",
                            scrolling: "no",
                            src: "https://www.instagram.com/".concat(i, "/embed/")
                        })
                    })
                })
            }
        }
    }
]);