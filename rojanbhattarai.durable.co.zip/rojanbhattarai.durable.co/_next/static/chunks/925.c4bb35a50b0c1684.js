"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [925], {
        52077: function(e, l, a) {
            a.d(l, {
                Z: function() {
                    return i
                }
            });
            var n = a(85893),
                r = a(41664),
                s = a.n(r),
                o = a(16494),
                t = a(31996);

            function i(e) {
                var l, a, r, i, d, c, u = e.button,
                    v = e.type,
                    g = e.website,
                    m = e.action,
                    x = e.loading,
                    b = e.className,
                    y = (null === g || void 0 === g || null === (l = g.button) || void 0 === l ? void 0 : l.background) || (null === g || void 0 === g ? void 0 : g.secondaryColor),
                    f = {
                        background: "outline" === (null === g || void 0 === g || null === (a = g.button) || void 0 === a ? void 0 : a.style) ? "transparent" : y,
                        borderRadius: isNaN(null === g || void 0 === g || null === (r = g.button) || void 0 === r ? void 0 : r.cornerRadius) ? 8 : g.button.cornerRadius,
                        color: "outline" === (null === g || void 0 === g || null === (i = g.button) || void 0 === i ? void 0 : i.style) ? y : (0, t.$O)(y),
                        border: "2px solid ".concat(y)
                    };
                return m && "function" === typeof m || "submit" === v ? (0, n.jsx)("button", {
                    type: "submit" === v ? "submit" : "button",
                    onClick: m,
                    className: (0, t.AK)("button primary", b),
                    style: f,
                    disabled: x,
                    children: x ? (0, n.jsx)(o.Z, {}) : u.label
                }) : (0, n.jsx)(s(), {
                    href: function(e) {
                        if (e) {
                            if ("email" === e.type) return "mailto:" + e.link;
                            if ("phone" === e.type) return "tel:" + e.link;
                            if ("page" === e.type) {
                                var l, a, n, r = null === g || void 0 === g || null === (l = g.pages) || void 0 === l ? void 0 : l.find((function(l) {
                                        return l._id === e.page
                                    })),
                                    s = (null === r || void 0 === r ? void 0 : r.Parent) ? null === g || void 0 === g || null === (a = g.pages) || void 0 === a ? void 0 : a.find((function(e) {
                                        return e._id === (null === r || void 0 === r ? void 0 : r.Parent)
                                    })) : null,
                                    o = "";
                                return s && (o += "".concat(s.slug, "/")), o += null !== (n = null === r || void 0 === r ? void 0 : r.slug) && void 0 !== n ? n : "/"
                            }
                            var t, i = null === (t = e.link) || void 0 === t ? void 0 : t.replace(/https?:\/\//gi, "");
                            return i && "#" !== i ? "https://" + i : "#"
                        }
                        return "/"
                    }(u),
                    children: (0, n.jsx)("a", {
                        className: (0, t.AK)("button primary", b),
                        target: !0 === u.newPage ? "_blank" : (null === g || void 0 === g || null === (d = g.button) || void 0 === d ? void 0 : d.target) ? null === g || void 0 === g || null === (c = g.button) || void 0 === c ? void 0 : c.target : "_self",
                        style: f,
                        children: u.label
                    })
                })
            }
        },
        16494: function(e, l, a) {
            a.d(l, {
                Z: function() {
                    return s
                }
            });
            var n = a(85893),
                r = a(31996);

            function s(e) {
                var l = e.text,
                    a = e.className;
                switch (e.variant) {
                    case "form":
                        return (0, n.jsx)("div", {
                            className: "w-full max-w-screen-sm my-8",
                            children: (0, n.jsxs)("div", {
                                className: "animate-pulse flex space-y-8 flex-col",
                                children: [(0, n.jsxs)("div", {
                                    className: "space-y-3",
                                    children: [(0, n.jsx)("div", {
                                        className: "h-4 bg-gray-100 rounded w-1/2"
                                    }), (0, n.jsx)("div", {
                                        className: "h-9 bg-gray-100 rounded"
                                    }), (0, n.jsx)("div", {
                                        className: "h-2 bg-gray-100 rounded w-5/6"
                                    })]
                                }), (0, n.jsx)("hr", {}), (0, n.jsxs)("div", {
                                    className: "space-y-3",
                                    children: [(0, n.jsx)("div", {
                                        className: "h-4 bg-gray-100 rounded w-1/4"
                                    }), (0, n.jsx)("div", {
                                        className: "h-9 bg-gray-100 rounded"
                                    }), (0, n.jsx)("div", {
                                        className: "h-2 bg-gray-100 rounded w-1/2"
                                    })]
                                }), (0, n.jsx)("hr", {}), (0, n.jsxs)("div", {
                                    className: "space-y-3",
                                    children: [(0, n.jsx)("div", {
                                        className: "h-4 bg-gray-100 rounded w-1/4"
                                    }), (0, n.jsx)("div", {
                                        className: "h-9 bg-gray-100 rounded"
                                    }), (0, n.jsx)("div", {
                                        className: "h-2 bg-gray-100 rounded w-1/2"
                                    })]
                                }), (0, n.jsx)("hr", {}), (0, n.jsxs)("div", {
                                    className: "space-y-3",
                                    children: [(0, n.jsx)("div", {
                                        className: "h-4 bg-gray-100 rounded w-1/6"
                                    }), (0, n.jsx)("div", {
                                        className: "h-9 bg-gray-100 rounded"
                                    }), (0, n.jsx)("div", {
                                        className: "h-2 bg-gray-100 rounded w-3/4"
                                    })]
                                }), (0, n.jsx)("div", {
                                    className: "h-10 bg-gray-200 rounded w-1/4 ml-auto mt-4"
                                })]
                            })
                        });
                    case "table":
                        return (0, n.jsx)("div", {
                            className: "w-full my-8",
                            children: (0, n.jsxs)("div", {
                                className: "animate-pulse flex space-y-2 flex-col",
                                children: [(0, n.jsxs)("div", {
                                    className: "space-x-2 flex",
                                    children: [(0, n.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, n.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, n.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, n.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, n.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    }), (0, n.jsx)("div", {
                                        className: "h-9 bg-gray-200 rounded w-full"
                                    })]
                                }), [1, 2, 3, 4, 5, 6].map((function(e) {
                                    return (0, n.jsxs)("div", {
                                        className: "space-x-2 flex",
                                        children: [(0, n.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, n.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, n.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, n.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, n.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        }), (0, n.jsx)("div", {
                                            className: "h-9 bg-gray-100 rounded w-full"
                                        })]
                                    }, e)
                                }))]
                            })
                        });
                    default:
                        return (0, n.jsxs)("div", {
                            className: (0, r.AK)("inline-flex items-center", a),
                            children: [(0, n.jsxs)("svg", {
                                className: (0, r.AK)("animate-spin ml-1 mr-3 h-4 w-4", a && "text-indigo-600"),
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                children: [(0, n.jsx)("circle", {
                                    className: "opacity-25",
                                    cx: "12",
                                    cy: "12",
                                    r: "10",
                                    stroke: "currentColor",
                                    strokeWidth: "4"
                                }), (0, n.jsx)("path", {
                                    className: "opacity-75",
                                    fill: "currentColor",
                                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                })]
                            }), l || "" === l ? l : "Loading..."]
                        })
                }
            }
        },
        82258: function(e, l, a) {
            a.r(l), a.d(l, {
                default: function() {
                    return c
                }
            });
            var n = a(14251),
                r = a(52875),
                s = a(85893),
                o = a(31996),
                t = a(67294),
                i = a(52077),
                d = "#F3F4F6";

            function c(e) {
                var l, a = e.block,
                    c = e.website,
                    u = function(e) {
                        var l = e.replace(/\s/g, "").match(/^rgba?\((\d+),(\d+),(\d+),?([^,\s)]+)?/i),
                            a = l ? (256 | l[1]).toString(16).slice(1) + (256 | l[2]).toString(16).slice(1) + (256 | l[3]).toString(16).slice(1) : e;
                        return "#".concat(a)
                    },
                    v = (0, t.useState)(null),
                    g = v[0],
                    m = v[1],
                    x = (0, t.useState)(null),
                    b = x[0],
                    y = x[1],
                    f = (0, t.useState)(null),
                    h = f[0],
                    j = f[1],
                    p = (0, t.useState)(null),
                    N = p[0],
                    w = p[1],
                    k = (0, t.useState)(null),
                    O = k[0],
                    P = k[1],
                    S = (0, t.useState)("#111827"),
                    A = S[0],
                    C = S[1];
                return (0, t.useEffect)((function() {
                    var e, l;
                    if (a)
                        if (m(a.headline), y(a.content), j(a.button), w(a.align), "image" === (null === (e = a.background) || void 0 === e ? void 0 : e.type) && (null === (l = a.background) || void 0 === l ? void 0 : l.overlay)) {
                            var s = a.background.overlay.color.includes("rgba") ? u(a.background.overlay.color) : a.background.overlay.color;
                            P((0, r.Z)((0, n.Z)({}, a.background), {
                                overlay: {
                                    color: (0, o.mR)(s || "#000000", a.background.overlay.amount || 50),
                                    amount: a.background.overlay.amount || 50
                                }
                            }))
                        } else P(a.background)
                }), [a]), (0, t.useEffect)((function() {
                    var e;
                    "image" === (null === O || void 0 === O ? void 0 : O.type) ? C((0, o.$O)(u((null === (e = O.overlay) || void 0 === e ? void 0 : e.color) || (0, o.mR)(d)))): C((0, o.$O)((null === O || void 0 === O ? void 0 : O.color) || d))
                }), [O]), (0, s.jsxs)("section", {
                    className: "flex-shrink-0 relative flex items-center min-h-120",
                    style: "image" === (null === O || void 0 === O ? void 0 : O.type) ? {
                        backgroundImage: "url(".concat((null === (l = O.image) || void 0 === l ? void 0 : l.url) || O.image, ")"),
                        backgroundPosition: "".concat(O.imagePositionX || "center", " ").concat(O.imagePositionY || "center"),
                        backgroundSize: "cover"
                    } : {
                        backgroundColor: null === O || void 0 === O ? void 0 : O.color
                    },
                    children: ["image" === (null === O || void 0 === O ? void 0 : O.type) && (null === O || void 0 === O ? void 0 : O.overlay) && (0, s.jsx)("div", {
                        className: (0, o.AK)("absolute inset-0"),
                        style: {
                            backgroundColor: O.overlay.color
                        }
                    }), (0, s.jsx)("div", {
                        className: "relative container mx-auto px-6 z-10 py-12 lg:py-32 xl:py-40 text-8xl",
                        children: (0, s.jsxs)("div", {
                            className: (0, o.AK)("max-w-3xl", "text-".concat(N), "left" === N ? "ml-0 mr-auto" : "right" === N ? "ml-auto mr-0" : "mx-auto"),
                            children: [g && (0, s.jsx)("h2", {
                                className: (0, o.AK)("text-h1 xl:text-7xl xl:leading-tight mb-4", "text-".concat(N)),
                                style: (0, n.Z)({
                                    color: A
                                }, (0, o.j2)(c)),
                                children: g
                            }), b && (0, s.jsx)("p", {
                                className: (0, o.AK)("text-body md:text-body-lg xl:text-2xl"),
                                style: (0, n.Z)({
                                    color: A
                                }, (0, o.SV)(c)),
                                children: b
                            }), h && (0, s.jsx)(i.Z, {
                                button: h,
                                website: c,
                                className: "xl mt-6 lg:mt-8 w-full md:w-max"
                            })]
                        })
                    })]
                })
            }
        },
        52875: function(e, l, a) {
            function n(e, l) {
                return l = null != l ? l : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(l)) : function(e, l) {
                    var a = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var n = Object.getOwnPropertySymbols(e);
                        l && (n = n.filter((function(l) {
                            return Object.getOwnPropertyDescriptor(e, l).enumerable
                        }))), a.push.apply(a, n)
                    }
                    return a
                }(Object(l)).forEach((function(a) {
                    Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(l, a))
                })), e
            }
            a.d(l, {
                Z: function() {
                    return n
                }
            })
        }
    }
]);