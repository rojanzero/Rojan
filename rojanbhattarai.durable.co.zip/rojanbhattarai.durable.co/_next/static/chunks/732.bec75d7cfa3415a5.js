"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [732], {
        18732: function(e, t, n) {
            n.d(t, {
                V: function() {
                    return Re
                }
            });
            var r = n(67294),
                o = n.t(r, 2),
                l = n(32984),
                a = n(12351),
                u = n(23784),
                i = n(61363),
                c = n(64103),
                s = n(19946),
                d = n(82180),
                f = n(46045),
                p = n(84575),
                m = n(73781),
                v = n(3855);
            var g = (e => (e[e.Forwards = 0] = "Forwards", e[e.Backwards = 1] = "Backwards", e))(g || {});

            function h() {
                let e = (0, r.useRef)(0);
                return function(e, t, n) {
                    let o = (0, v.E)(t);
                    (0, r.useEffect)((() => {
                        function t(e) {
                            o.current(e)
                        }
                        return window.addEventListener(e, t, n), () => window.removeEventListener(e, t, n)
                    }), [e, n])
                }("keydown", (t => {
                    "Tab" === t.key && (e.current = t.shiftKey ? 1 : 0)
                }), !0), e
            }
            var E = n(14879),
                w = n(51074);

            function y(e, t, n, o) {
                let l = (0, v.E)(n);
                (0, r.useEffect)((() => {
                    function n(e) {
                        l.current(e)
                    }
                    return (e = null != e ? e : window).addEventListener(t, n, o), () => e.removeEventListener(t, n, o)
                }), [e, t, o])
            }
            var b = n(81021),
                T = n(96599),
                C = n(94192);

            function L(e) {
                if (!e) return new Set;
                if ("function" == typeof e) return new Set(e());
                let t = new Set;
                for (let n of e.current) n.current instanceof HTMLElement && t.add(n.current);
                return t
            }
            var P = (e => (e[e.None = 1] = "None", e[e.InitialFocus = 2] = "InitialFocus", e[e.TabLock = 4] = "TabLock", e[e.FocusLock = 8] = "FocusLock", e[e.RestoreFocus = 16] = "RestoreFocus", e[e.All = 30] = "All", e))(P || {});
            let S = (0, a.yV)((function(e, t) {
                    let n = (0, r.useRef)(null),
                        o = (0, u.T)(n, t),
                        {
                            initialFocus: i,
                            containers: c,
                            features: s = 30,
                            ...v
                        } = e;
                    (0, d.H)() || (s = 1);
                    let P = (0, w.i)(n);
                    ! function({
                        ownerDocument: e
                    }, t) {
                        let n = function(e = !0) {
                            let t = (0, r.useRef)(O.slice());
                            return (0, T.q)((([e], [n]) => {
                                !0 === n && !1 === e && (0, b.Y)((() => {
                                    t.current.splice(0)
                                })), !1 === n && !0 === e && (t.current = O.slice())
                            }), [e, O, t]), (0, m.z)((() => {
                                var e;
                                return null != (e = t.current.find((e => null != e && e.isConnected))) ? e : null
                            }))
                        }(t);
                        (0, T.q)((() => {
                            t || (null == e ? void 0 : e.activeElement) === (null == e ? void 0 : e.body) && (0, p.C5)(n())
                        }), [t]);
                        let o = (0, r.useRef)(!1);
                        (0, r.useEffect)((() => (o.current = !1, () => {
                            o.current = !0, (0, b.Y)((() => {
                                o.current && (0, p.C5)(n())
                            }))
                        })), [])
                    }({
                        ownerDocument: P
                    }, Boolean(16 & s));
                    let S = function({
                        ownerDocument: e,
                        container: t,
                        initialFocus: n
                    }, o) {
                        let l = (0, r.useRef)(null),
                            a = (0, E.t)();
                        return (0, T.q)((() => {
                            if (!o) return;
                            let r = t.current;
                            r && (0, b.Y)((() => {
                                if (!a.current) return;
                                let t = null == e ? void 0 : e.activeElement;
                                if (null != n && n.current) {
                                    if ((null == n ? void 0 : n.current) === t) return void(l.current = t)
                                } else if (r.contains(t)) return void(l.current = t);
                                null != n && n.current ? (0, p.C5)(n.current) : (0, p.jA)(r, p.TO.First) === p.fE.Error && console.warn("There are no focusable elements inside the <FocusTrap />"), l.current = null == e ? void 0 : e.activeElement
                            }))
                        }), [o]), l
                    }({
                        ownerDocument: P,
                        container: n,
                        initialFocus: i
                    }, Boolean(2 & s));
                    ! function({
                        ownerDocument: e,
                        container: t,
                        containers: n,
                        previousActiveElement: r
                    }, o) {
                        let l = (0, E.t)();
                        y(null == e ? void 0 : e.defaultView, "focus", (e => {
                            if (!o || !l.current) return;
                            let a = L(n);
                            t.current instanceof HTMLElement && a.add(t.current);
                            let u = r.current;
                            if (!u) return;
                            let i = e.target;
                            i && i instanceof HTMLElement ? R(a, i) ? (r.current = i, (0, p.C5)(i)) : (e.preventDefault(), e.stopPropagation(), (0, p.C5)(u)) : (0, p.C5)(r.current)
                        }), !0)
                    }({
                        ownerDocument: P,
                        container: n,
                        containers: c,
                        previousActiveElement: S
                    }, Boolean(8 & s));
                    let D = h(),
                        k = (0, m.z)((e => {
                            let t = n.current;
                            t && (0, l.E)(D.current, {
                                [g.Forwards]: () => {
                                    (0, p.jA)(t, p.TO.First, {
                                        skipElements: [e.relatedTarget]
                                    })
                                },
                                [g.Backwards]: () => {
                                    (0, p.jA)(t, p.TO.Last, {
                                        skipElements: [e.relatedTarget]
                                    })
                                }
                            })
                        })),
                        M = (0, C.G)(),
                        A = (0, r.useRef)(!1),
                        F = {
                            ref: o,
                            onKeyDown(e) {
                                "Tab" == e.key && (A.current = !0, M.requestAnimationFrame((() => {
                                    A.current = !1
                                })))
                            },
                            onBlur(e) {
                                let t = L(c);
                                n.current instanceof HTMLElement && t.add(n.current);
                                let r = e.relatedTarget;
                                r instanceof HTMLElement && "true" !== r.dataset.headlessuiFocusGuard && (R(t, r) || (A.current ? (0, p.jA)(n.current, (0, l.E)(D.current, {
                                    [g.Forwards]: () => p.TO.Next,
                                    [g.Backwards]: () => p.TO.Previous
                                }) | p.TO.WrapAround, {
                                    relativeTo: e.target
                                }) : e.target instanceof HTMLElement && (0, p.C5)(e.target)))
                            }
                        };
                    return r.createElement(r.Fragment, null, Boolean(4 & s) && r.createElement(f._, {
                        as: "button",
                        type: "button",
                        "data-headlessui-focus-guard": !0,
                        onFocus: k,
                        features: f.A.Focusable
                    }), (0, a.sY)({
                        ourProps: F,
                        theirProps: v,
                        defaultTag: "div",
                        name: "FocusTrap"
                    }), Boolean(4 & s) && r.createElement(f._, {
                        as: "button",
                        type: "button",
                        "data-headlessui-focus-guard": !0,
                        onFocus: k,
                        features: f.A.Focusable
                    }))
                })),
                D = Object.assign(S, {
                    features: P
                }),
                O = [];

            function R(e, t) {
                for (let n of e)
                    if (n.contains(t)) return !0;
                return !1
            }! function(e) {
                function t() {
                    "loading" !== document.readyState && (e(), document.removeEventListener("DOMContentLoaded", t))
                }
                "undefined" != typeof window && "undefined" != typeof document && (document.addEventListener("DOMContentLoaded", t), t())
            }((() => {
                function e(e) {
                    e.target instanceof HTMLElement && e.target !== document.body && O[0] !== e.target && (O.unshift(e.target), O = O.filter((e => null != e && e.isConnected)), O.splice(10))
                }
                window.addEventListener("click", e, {
                    capture: !0
                }), window.addEventListener("mousedown", e, {
                    capture: !0
                }), window.addEventListener("focus", e, {
                    capture: !0
                }), document.body.addEventListener("click", e, {
                    capture: !0
                }), document.body.addEventListener("mousedown", e, {
                    capture: !0
                }), document.body.addEventListener("focus", e, {
                    capture: !0
                })
            }));
            var k = n(73935),
                M = n(16723);
            let A = (0, r.createContext)(!1);

            function F() {
                return (0, r.useContext)(A)
            }

            function Y(e) {
                return r.createElement(A.Provider, {
                    value: e.force
                }, e.children)
            }
            var x = n(77896);
            let H = r.Fragment;
            let V = r.Fragment,
                B = (0, r.createContext)(null);
            let N = (0, a.yV)((function(e, t) {
                    let n = e,
                        o = (0, r.useRef)(null),
                        l = (0, u.T)((0, u.h)((e => {
                            o.current = e
                        })), t),
                        i = (0, w.i)(o),
                        c = function(e) {
                            let t = F(),
                                n = (0, r.useContext)(B),
                                o = (0, w.i)(e),
                                [l, a] = (0, r.useState)((() => {
                                    if (!t && null !== n || x.O.isServer) return null;
                                    let e = null == o ? void 0 : o.getElementById("headlessui-portal-root");
                                    if (e) return e;
                                    if (null === o) return null;
                                    let r = o.createElement("div");
                                    return r.setAttribute("id", "headlessui-portal-root"), o.body.appendChild(r)
                                }));
                            return (0, r.useEffect)((() => {
                                null !== l && (null != o && o.body.contains(l) || null == o || o.body.appendChild(l))
                            }), [l, o]), (0, r.useEffect)((() => {
                                t || null !== n && a(n.current)
                            }), [n, a, t]), l
                        }(o),
                        [s] = (0, r.useState)((() => {
                            var e;
                            return x.O.isServer ? null : null != (e = null == i ? void 0 : i.createElement("div")) ? e : null
                        })),
                        f = (0, d.H)(),
                        p = (0, r.useRef)(!1);
                    return (0, M.e)((() => {
                        if (p.current = !1, c && s) return c.contains(s) || (s.setAttribute("data-headlessui-portal", ""), c.appendChild(s)), () => {
                            p.current = !0, (0, b.Y)((() => {
                                var e;
                                p.current && (!c || !s || (s instanceof Node && c.contains(s) && c.removeChild(s), c.childNodes.length <= 0 && (null == (e = c.parentElement) || e.removeChild(c))))
                            }))
                        }
                    }), [c, s]), f && c && s ? (0, k.createPortal)((0, a.sY)({
                        ourProps: {
                            ref: l
                        },
                        theirProps: n,
                        defaultTag: H,
                        name: "Portal"
                    }), s) : null
                })),
                I = (0, a.yV)((function(e, t) {
                    let {
                        target: n,
                        ...o
                    } = e, l = {
                        ref: (0, u.T)(t)
                    };
                    return r.createElement(B.Provider, {
                        value: n
                    }, (0, a.sY)({
                        ourProps: l,
                        theirProps: o,
                        defaultTag: V,
                        name: "Popover.Group"
                    }))
                })),
                _ = Object.assign(N, {
                    Group: I
                }),
                j = (0, r.createContext)(null);

            function z() {
                let e = (0, r.useContext)(j);
                if (null === e) {
                    let e = new Error("You used a <Description /> component, but it is not inside a relevant parent.");
                    throw Error.captureStackTrace && Error.captureStackTrace(e, z), e
                }
                return e
            }

            function $() {
                let [e, t] = (0, r.useState)([]);
                return [e.length > 0 ? e.join(" ") : void 0, (0, r.useMemo)((() => function(e) {
                    let n = (0, m.z)((e => (t((t => [...t, e])), () => t((t => {
                            let n = t.slice(),
                                r = n.indexOf(e);
                            return -1 !== r && n.splice(r, 1), n
                        }))))),
                        o = (0, r.useMemo)((() => ({
                            register: n,
                            slot: e.slot,
                            name: e.name,
                            props: e.props
                        })), [n, e.slot, e.name, e.props]);
                    return r.createElement(j.Provider, {
                        value: o
                    }, e.children)
                }), [t])]
            }
            let W = (0, a.yV)((function(e, t) {
                    let n = (0, s.M)(),
                        {
                            id: r = `headlessui-description-${n}`,
                            ...o
                        } = e,
                        l = z(),
                        i = (0, u.T)(t);
                    (0, M.e)((() => l.register(r)), [r, l.register]);
                    let c = {
                        ref: i,
                        ...l.props,
                        id: r
                    };
                    return (0, a.sY)({
                        ourProps: c,
                        theirProps: o,
                        slot: l.slot || {},
                        defaultTag: "p",
                        name: l.name || "Description"
                    })
                })),
                q = Object.assign(W, {});
            var G = n(16567);
            let U = (0, r.createContext)((() => {}));
            U.displayName = "StackContext";
            var Z = (e => (e[e.Add = 0] = "Add", e[e.Remove = 1] = "Remove", e))(Z || {});

            function K({
                children: e,
                onUpdate: t,
                type: n,
                element: o,
                enabled: l
            }) {
                let a = (0, r.useContext)(U),
                    u = (0, m.z)(((...e) => {
                        null == t || t(...e), a(...e)
                    }));
                return (0, M.e)((() => {
                    let e = void 0 === l || !0 === l;
                    return e && u(0, n, o), () => {
                        e && u(1, n, o)
                    }
                }), [u, n, o, l]), r.createElement(U.Provider, {
                    value: u
                }, e)
            }
            var J = n(39650);
            const Q = "function" == typeof Object.is ? Object.is : function(e, t) {
                    return e === t && (0 !== e || 1 / e === 1 / t) || e !== e && t !== t
                },
                {
                    useState: X,
                    useEffect: ee,
                    useLayoutEffect: te,
                    useDebugValue: ne
                } = o;

            function re(e) {
                const t = e.getSnapshot,
                    n = e.value;
                try {
                    const e = t();
                    return !Q(n, e)
                } catch {
                    return !0
                }
            }
            const oe = !("undefined" != typeof window && "undefined" != typeof window.document && "undefined" != typeof window.document.createElement) ? function(e, t, n) {
                    return t()
                } : function(e, t, n) {
                    const r = t(),
                        [{
                            inst: o
                        }, l] = X({
                            inst: {
                                value: r,
                                getSnapshot: t
                            }
                        });
                    return te((() => {
                        o.value = r, o.getSnapshot = t, re(o) && l({
                            inst: o
                        })
                    }), [e, r, t]), ee((() => (re(o) && l({
                        inst: o
                    }), e((() => {
                        re(o) && l({
                            inst: o
                        })
                    })))), [e]), ne(r), r
                },
                le = oe;
            var ae = n(9362);

            function ue() {
                let e;
                return {
                    before({
                        doc: t
                    }) {
                        var n;
                        let r = t.documentElement;
                        e = (null != (n = t.defaultView) ? n : window).innerWidth - r.clientWidth
                    },
                    after({
                        doc: t,
                        d: n
                    }) {
                        let r = t.documentElement,
                            o = r.clientWidth - r.offsetWidth,
                            l = e - o;
                        n.style(r, "paddingRight", `${l}px`)
                    }
                }
            }
            var ie = n(78657);

            function ce() {
                if (!(0, ie.gn)()) return {};
                let e;
                return {
                    before() {
                        e = window.pageYOffset
                    },
                    after({
                        doc: t,
                        d: n,
                        meta: r
                    }) {
                        function o(e) {
                            return r.containers.flatMap((e => e())).some((t => t.contains(e)))
                        }
                        n.style(t.body, "marginTop", `-${e}px`), window.scrollTo(0, 0);
                        let l = null;
                        n.addEventListener(t, "click", (e => {
                            if (e.target instanceof HTMLElement) try {
                                let n = e.target.closest("a");
                                if (!n) return;
                                let {
                                    hash: r
                                } = new URL(n.href), a = t.querySelector(r);
                                a && !o(a) && (l = a)
                            } catch {}
                        }), !0), n.addEventListener(t, "touchmove", (e => {
                            e.target instanceof HTMLElement && !o(e.target) && e.preventDefault()
                        }), {
                            passive: !1
                        }), n.add((() => {
                            window.scrollTo(0, window.pageYOffset + e), l && l.isConnected && (l.scrollIntoView({
                                block: "nearest"
                            }), l = null)
                        }))
                    }
                }
            }

            function se(e) {
                let t = {};
                for (let n of e) Object.assign(t, n(t));
                return t
            }
            let de = function(e, t) {
                let n = e(),
                    r = new Set;
                return {
                    getSnapshot: () => n,
                    subscribe: e => (r.add(e), () => r.delete(e)),
                    dispatch(e, ...o) {
                        let l = t[e].call(n, ...o);
                        l && (n = l, r.forEach((e => e())))
                    }
                }
            }((() => new Map), {
                PUSH(e, t) {
                    var n;
                    let r = null != (n = this.get(e)) ? n : {
                        doc: e,
                        count: 0,
                        d: (0, ae.k)(),
                        meta: new Set
                    };
                    return r.count++, r.meta.add(t), this.set(e, r), this
                },
                POP(e, t) {
                    let n = this.get(e);
                    return n && (n.count--, n.meta.delete(t)), this
                },
                SCROLL_PREVENT({
                    doc: e,
                    d: t,
                    meta: n
                }) {
                    let r = {
                            doc: e,
                            d: t,
                            meta: se(n)
                        },
                        o = [ce(), ue(), {
                            before({
                                doc: e,
                                d: t
                            }) {
                                t.style(e.documentElement, "overflow", "hidden")
                            }
                        }];
                    o.forEach((({
                        before: e
                    }) => null == e ? void 0 : e(r))), o.forEach((({
                        after: e
                    }) => null == e ? void 0 : e(r)))
                },
                SCROLL_ALLOW({
                    d: e
                }) {
                    e.dispose()
                },
                TEARDOWN({
                    doc: e
                }) {
                    this.delete(e)
                }
            });

            function fe(e, t, n) {
                let r = function(e) {
                        return le(e.subscribe, e.getSnapshot, e.getSnapshot)
                    }(de),
                    o = e ? r.get(e) : void 0,
                    l = !!o && o.count > 0;
                return (0, M.e)((() => {
                    if (e && t) return de.dispatch("PUSH", e, n), () => de.dispatch("POP", e, n)
                }), [t, e]), l
            }
            de.subscribe((() => {
                let e = de.getSnapshot(),
                    t = new Map;
                for (let [n] of e) t.set(n, n.documentElement.style.overflow);
                for (let n of e.values()) {
                    let e = "hidden" === t.get(n.doc),
                        r = 0 !== n.count;
                    (r && !e || !r && e) && de.dispatch(n.count > 0 ? "SCROLL_PREVENT" : "SCROLL_ALLOW", n), 0 === n.count && de.dispatch("TEARDOWN", n)
                }
            }));
            let pe = new Map,
                me = new Map;

            function ve(e, t = !0) {
                (0, M.e)((() => {
                    var n;
                    if (!t) return;
                    let r = "function" == typeof e ? e() : e.current;
                    if (!r) return;
                    let o = null != (n = me.get(r)) ? n : 0;
                    return me.set(r, o + 1), 0 !== o || (pe.set(r, {
                            "aria-hidden": r.getAttribute("aria-hidden"),
                            inert: r.inert
                        }), r.setAttribute("aria-hidden", "true"), r.inert = !0),
                        function() {
                            var e;
                            if (!r) return;
                            let t = null != (e = me.get(r)) ? e : 1;
                            if (1 === t ? me.delete(r) : me.set(r, t - 1), 1 !== t) return;
                            let n = pe.get(r);
                            n && (null === n["aria-hidden"] ? r.removeAttribute("aria-hidden") : r.setAttribute("aria-hidden", n["aria-hidden"]), r.inert = n.inert, pe.delete(r))
                        }
                }), [e, t])
            }
            var ge, he = ((ge = he || {})[ge.Open = 0] = "Open", ge[ge.Closed = 1] = "Closed", ge),
                Ee = (e => (e[e.SetTitleId = 0] = "SetTitleId", e))(Ee || {});
            let we = {
                    0: (e, t) => e.titleId === t.id ? e : { ...e,
                        titleId: t.id
                    }
                },
                ye = (0, r.createContext)(null);

            function be(e) {
                let t = (0, r.useContext)(ye);
                if (null === t) {
                    let t = new Error(`<${e} /> is missing a parent <Dialog /> component.`);
                    throw Error.captureStackTrace && Error.captureStackTrace(t, be), t
                }
                return t
            }

            function Te(e, t) {
                return (0, l.E)(t.type, we, e, t)
            }
            ye.displayName = "DialogContext";
            let Ce = a.AN.RenderStrategy | a.AN.Static;
            let Le = (0, a.yV)((function(e, t) {
                    let n = (0, s.M)(),
                        {
                            id: o = `headlessui-dialog-${n}`,
                            open: c,
                            onClose: p,
                            initialFocus: v,
                            __demoMode: g = !1,
                            ...h
                        } = e,
                        [E, b] = (0, r.useState)(0),
                        T = (0, G.oJ)();
                    void 0 === c && null !== T && (c = (T & G.ZM.Open) === G.ZM.Open);
                    let C = (0, r.useRef)(null),
                        L = (0, u.T)(C, t),
                        P = (0, r.useRef)(null),
                        S = (0, w.i)(C),
                        O = e.hasOwnProperty("open") || null !== T,
                        R = e.hasOwnProperty("onClose");
                    if (!O && !R) throw new Error("You have to provide an `open` and an `onClose` prop to the `Dialog` component.");
                    if (!O) throw new Error("You provided an `onClose` prop to the `Dialog`, but forgot an `open` prop.");
                    if (!R) throw new Error("You provided an `open` prop to the `Dialog`, but forgot an `onClose` prop.");
                    if ("boolean" != typeof c) throw new Error(`You provided an \`open\` prop to the \`Dialog\`, but the value is not a boolean. Received: ${c}`);
                    if ("function" != typeof p) throw new Error(`You provided an \`onClose\` prop to the \`Dialog\`, but the value is not a function. Received: ${p}`);
                    let k = c ? 0 : 1,
                        [M, A] = (0, r.useReducer)(Te, {
                            titleId: null,
                            descriptionId: null,
                            panelRef: (0, r.createRef)()
                        }),
                        F = (0, m.z)((() => p(!1))),
                        x = (0, m.z)((e => A({
                            type: 0,
                            id: e
                        }))),
                        H = !!(0, d.H)() && (!g && 0 === k),
                        V = E > 1,
                        B = null !== (0, r.useContext)(ye),
                        N = V ? "parent" : "leaf",
                        I = null !== T && (T & G.ZM.Closing) === G.ZM.Closing,
                        j = !B && !I && H,
                        z = (0, r.useCallback)((() => {
                            var e, t;
                            return null != (t = Array.from(null != (e = null == S ? void 0 : S.querySelectorAll("body > *")) ? e : []).find((e => "headlessui-portal-root" !== e.id && (e.contains(P.current) && e instanceof HTMLElement)))) ? t : null
                        }), [P]);
                    ve(z, j);
                    let W = !!V || H,
                        q = (0, r.useCallback)((() => {
                            var e, t;
                            return null != (t = Array.from(null != (e = null == S ? void 0 : S.querySelectorAll("[data-headlessui-portal]")) ? e : []).find((e => e.contains(P.current) && e instanceof HTMLElement))) ? t : null
                        }), [P]);
                    ve(q, W);
                    let U = (0, m.z)((() => {
                            var e, t;
                            return [...Array.from(null != (e = null == S ? void 0 : S.querySelectorAll("html > *, body > *, [data-headlessui-portal]")) ? e : []).filter((e => !(e === document.body || e === document.head || !(e instanceof HTMLElement) || e.contains(P.current) || M.panelRef.current && e.contains(M.panelRef.current)))), null != (t = M.panelRef.current) ? t : C.current]
                        })),
                        Q = !(!H || V);
                    (0, J.O)((() => U()), F, Q);
                    let X = !(V || 0 !== k);
                    y(null == S ? void 0 : S.defaultView, "keydown", (e => {
                            X && (e.defaultPrevented || e.key === i.R.Escape && (e.preventDefault(), e.stopPropagation(), F()))
                        })),
                        function(e, t, n = (() => [document.body])) {
                            fe(e, t, (e => {
                                var t;
                                return {
                                    containers: [...null != (t = e.containers) ? t : [], n]
                                }
                            }))
                        }(S, !(I || 0 !== k || B), U), (0, r.useEffect)((() => {
                            if (0 !== k || !C.current) return;
                            let e = new ResizeObserver((e => {
                                for (let t of e) {
                                    let e = t.target.getBoundingClientRect();
                                    0 === e.x && 0 === e.y && 0 === e.width && 0 === e.height && F()
                                }
                            }));
                            return e.observe(C.current), () => e.disconnect()
                        }), [k, C, F]);
                    let [ee, te] = $(), ne = (0, r.useMemo)((() => [{
                        dialogState: k,
                        close: F,
                        setTitleId: x
                    }, M]), [k, M, F, x]), re = (0, r.useMemo)((() => ({
                        open: 0 === k
                    })), [k]), oe = {
                        ref: L,
                        id: o,
                        role: "dialog",
                        "aria-modal": 0 === k || void 0,
                        "aria-labelledby": M.titleId,
                        "aria-describedby": ee
                    };
                    return r.createElement(K, {
                        type: "Dialog",
                        enabled: 0 === k,
                        element: C,
                        onUpdate: (0, m.z)(((e, t) => {
                            "Dialog" === t && (0, l.E)(e, {
                                [Z.Add]: () => b((e => e + 1)),
                                [Z.Remove]: () => b((e => e - 1))
                            })
                        }))
                    }, r.createElement(Y, {
                        force: !0
                    }, r.createElement(_, null, r.createElement(ye.Provider, {
                        value: ne
                    }, r.createElement(_.Group, {
                        target: C
                    }, r.createElement(Y, {
                        force: !1
                    }, r.createElement(te, {
                        slot: re,
                        name: "Dialog.Description"
                    }, r.createElement(D, {
                        initialFocus: v,
                        containers: U,
                        features: H ? (0, l.E)(N, {
                            parent: D.features.RestoreFocus,
                            leaf: D.features.All & ~D.features.FocusLock
                        }) : D.features.None
                    }, (0, a.sY)({
                        ourProps: oe,
                        theirProps: h,
                        slot: re,
                        defaultTag: "div",
                        features: Ce,
                        visible: 0 === k,
                        name: "Dialog"
                    })))))))), r.createElement(f._, {
                        features: f.A.Hidden,
                        ref: P
                    }))
                })),
                Pe = (0, a.yV)((function(e, t) {
                    let n = (0, s.M)(),
                        {
                            id: o = `headlessui-dialog-backdrop-${n}`,
                            ...l
                        } = e,
                        [{
                            dialogState: i
                        }, c] = be("Dialog.Backdrop"),
                        d = (0, u.T)(t);
                    (0, r.useEffect)((() => {
                        if (null === c.panelRef.current) throw new Error("A <Dialog.Backdrop /> component is being used, but a <Dialog.Panel /> component is missing.")
                    }), [c.panelRef]);
                    let f = (0, r.useMemo)((() => ({
                        open: 0 === i
                    })), [i]);
                    return r.createElement(Y, {
                        force: !0
                    }, r.createElement(_, null, (0, a.sY)({
                        ourProps: {
                            ref: d,
                            id: o,
                            "aria-hidden": !0
                        },
                        theirProps: l,
                        slot: f,
                        defaultTag: "div",
                        name: "Dialog.Backdrop"
                    })))
                })),
                Se = (0, a.yV)((function(e, t) {
                    let n = (0, s.M)(),
                        {
                            id: o = `headlessui-dialog-panel-${n}`,
                            ...l
                        } = e,
                        [{
                            dialogState: i
                        }, c] = be("Dialog.Panel"),
                        d = (0, u.T)(t, c.panelRef),
                        f = (0, r.useMemo)((() => ({
                            open: 0 === i
                        })), [i]),
                        p = (0, m.z)((e => {
                            e.stopPropagation()
                        }));
                    return (0, a.sY)({
                        ourProps: {
                            ref: d,
                            id: o,
                            onClick: p
                        },
                        theirProps: l,
                        slot: f,
                        defaultTag: "div",
                        name: "Dialog.Panel"
                    })
                })),
                De = (0, a.yV)((function(e, t) {
                    let n = (0, s.M)(),
                        {
                            id: o = `headlessui-dialog-overlay-${n}`,
                            ...l
                        } = e,
                        [{
                            dialogState: i,
                            close: d
                        }] = be("Dialog.Overlay"),
                        f = (0, u.T)(t),
                        p = (0, m.z)((e => {
                            if (e.target === e.currentTarget) {
                                if ((0, c.P)(e.currentTarget)) return e.preventDefault();
                                e.preventDefault(), e.stopPropagation(), d()
                            }
                        })),
                        v = (0, r.useMemo)((() => ({
                            open: 0 === i
                        })), [i]);
                    return (0, a.sY)({
                        ourProps: {
                            ref: f,
                            id: o,
                            "aria-hidden": !0,
                            onClick: p
                        },
                        theirProps: l,
                        slot: v,
                        defaultTag: "div",
                        name: "Dialog.Overlay"
                    })
                })),
                Oe = (0, a.yV)((function(e, t) {
                    let n = (0, s.M)(),
                        {
                            id: o = `headlessui-dialog-title-${n}`,
                            ...l
                        } = e,
                        [{
                            dialogState: i,
                            setTitleId: c
                        }] = be("Dialog.Title"),
                        d = (0, u.T)(t);
                    (0, r.useEffect)((() => (c(o), () => c(null))), [o, c]);
                    let f = (0, r.useMemo)((() => ({
                        open: 0 === i
                    })), [i]);
                    return (0, a.sY)({
                        ourProps: {
                            ref: d,
                            id: o
                        },
                        theirProps: l,
                        slot: f,
                        defaultTag: "h2",
                        name: "Dialog.Title"
                    })
                })),
                Re = Object.assign(Le, {
                    Backdrop: Pe,
                    Panel: Se,
                    Overlay: De,
                    Title: Oe,
                    Description: q
                })
        },
        51074: function(e, t, n) {
            n.d(t, {
                i: function() {
                    return l
                }
            });
            var r = n(67294),
                o = n(15466);

            function l(...e) {
                return (0, r.useMemo)((() => (0, o.r)(...e)), [...e])
            }
        }
    }
]);