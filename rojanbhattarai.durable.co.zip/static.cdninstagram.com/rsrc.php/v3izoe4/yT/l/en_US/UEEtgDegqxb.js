; /*FB_PKG_DELIM*/

__d("SUISpinner.react", ["cx", "fbt", "invariant", "LoadingMarker.react", "joinClasses", "react", "withSUITheme"], (function(a, b, c, d, e, f, g, h, i, j) {
    "use strict";
    var k = d("react"),
        l = d("react").useRef,
        m = .75,
        n = 1.5;

    function a(a) {
        var b = a["data-testid"];
        b = a.arcSpread;
        b = b === void 0 ? m : b;
        var d = a.className,
            e = a.margin,
            f = a.animationDuration,
            g = a.background;
        g = g === void 0 ? "light" : g;
        var h = a.size;
        h = h === void 0 ? "large" : h;
        var n = a.style;
        a = a.theme;
        a || j(0, 20159);
        var p = a.SUISpinner;
        p = p.sizes[h];
        var q = p.border;
        p = p.diameter;
        p = p + q * 2;
        q = l(null);
        return k.jsx(c("LoadingMarker.react"), {
            nodeRef: q,
            children: k.jsx("span", {
                "aria-busy": !0,
                "aria-valuemax": 360,
                "aria-valuemin": 0,
                "aria-valuetext": i._("Loading..."),
                className: c("joinClasses")("_4cgy", d, e),
                "data-testid": void 0,
                ref: q,
                role: "progressbar",
                style: babelHelpers["extends"]({}, n, {
                    height: p,
                    width: p
                }),
                children: k.jsx(o, {
                    animationDuration: f,
                    arcSpread: b,
                    background: g,
                    frameSize: p,
                    size: h,
                    theme: a
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function o(a) {
        var b = a.animationDuration,
            c = a.arcSpread,
            d = a.background,
            e = a.frameSize,
            f = a.size;
        a = a.theme;
        a = a.SUISpinner;
        b = b !== void 0 ? {
            animationDuration: b + "ms"
        } : void 0;
        var g = d === "dark" ? a.darkActiveColor : a.activeColor;
        d = d === "dark" ? a.darkBackgroundColor : a.backgroundColor;
        a = a.sizes[f];
        f = a.border;
        a = a.diameter;
        var h = (e - a) / 2,
            i = a / 2,
            j = e / 2;
        return k.jsxs("svg", {
            className: "_1lid",
            height: e,
            style: b,
            viewBox: "0 0 " + e + " " + e,
            width: e,
            xmlns: "http://www.w3.org/2000/svg",
            children: [k.jsx("rect", {
                fill: "none",
                height: a,
                rx: i,
                strokeWidth: f,
                style: {
                    stroke: d
                },
                width: a,
                x: h,
                y: h
            }), k.jsx("path", {
                d: s(j, j, i, n * Math.PI, (n + c) % 2 * Math.PI),
                fill: "none",
                strokeWidth: f,
                style: {
                    stroke: g
                }
            })]
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";

    function p(a) {
        return a * Math.PI / 180
    }

    function q(a) {
        return a * 180 / Math.PI
    }

    function r(a, b, c, d) {
        d = p(d);
        return {
            x: a + c * Math.cos(d),
            y: b + c * Math.sin(d)
        }
    }

    function s(a, b, c, d, e) {
        d = q(d);
        e = q(e);
        var f = r(a, b, c, e);
        a = r(a, b, c, d);
        b = d - e > 180 ? "0" : "1";
        return ["M " + f.x + " " + f.y, "A " + c + " " + c + " " + 0 + " " + b + " " + 0 + " " + a.x + " " + a.y].join(" ")
    }
    b = c("withSUITheme")(a);
    g["default"] = b
}), 98);
__d("SUISpinnerUniform.bui", ["cssVar"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    a = {
        activeColor: "#1877F2",
        backgroundColor: "#CCD0D5",
        darkActiveColor: "#FFFFFF",
        darkBackgroundColor: "rgba(255, 255, 255, 0.3)",
        sizes: {
            large: {
                border: 2,
                diameter: 20
            },
            small: {
                border: 1.5,
                diameter: 13
            }
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("makeSUIFDSPrivateTheme", ["SUITheme"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return new(c("SUITheme"))({
            id: a,
            components: b
        })
    }
    g["default"] = a
}), 98);
__d("BUISpinner_DEPRECATED.react", ["cx", "BUIText.react", "SUISpinner.react", "SUISpinnerUniform.bui", "joinClasses", "makeBUIStandardComponent", "makeSUIFDSPrivateTheme", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = {
            maxWidth: "100%"
        },
        k = 1.25,
        l = c("makeSUIFDSPrivateTheme")("BUISpinner_DEPRECATED", {
            SUISpinner: c("SUISpinnerUniform.bui")
        });
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.$1 = function() {
            return this.props.center === void 0 ? Boolean(this.props.title) : this.props.center
        };
        d.render = function() {
            var a = this.props,
                b = a.shade === "light" ? "dark" : "light",
                d = Boolean(a.title),
                e = this.$1();
            if (!d && !e) return i.jsx(c("SUISpinner.react"), {
                animationDuration: 750,
                arcSpread: k,
                background: b,
                "data-testid": void 0,
                margin: a.margin,
                size: a.size,
                style: a.style,
                theme: l
            });
            var f = null;
            if (d) {
                d = b === "dark" ? ["white", "primary"] : ["primary", "secondary"];
                var g = d[0];
                d = d[1];
                f = i.jsxs("div", {
                    style: j,
                    children: [i.jsx(c("BUIText.react"), {
                        color: g,
                        display: "truncate",
                        margin: "_3-8y",
                        palette: b,
                        size: "header4",
                        textAlign: "center",
                        weight: "bold",
                        whiteSpace: "nowrap",
                        children: a.title
                    }), a.subtitle != null && i.jsx(c("BUIText.react"), {
                        color: d,
                        display: "truncate",
                        margin: "_3-8w",
                        palette: b,
                        size: "body2",
                        textAlign: "center",
                        whiteSpace: "nowrap",
                        children: a.subtitle
                    })]
                })
            }
            return i.jsxs("div", {
                className: c("joinClasses")("_aeqv" + (a.shade === "light" ? " _aeqw" : "") + (e ? " _aeqx" : ""), a.margin),
                "data-testid": void 0,
                style: a.style,
                children: [i.jsx(c("SUISpinner.react"), {
                    animationDuration: 750,
                    arcSpread: k,
                    background: b,
                    size: a.size,
                    theme: l
                }), f]
            })
        };
        return b
    }(i.PureComponent);
    a.defaultProps = {
        shade: "dark",
        size: "large"
    };
    b = c("makeBUIStandardComponent")("BUISpinner_DEPRECATED", a);
    g["default"] = b
}), 98);
__d("WheelEventContain.react", ["DOMEventListener", "react"], (function(a, b, c, d, e, f, g) {
    var h = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (b = c = a.call.apply(a, [this].concat(f)) || this, c.$1 = null, c.$2 = function(a) {
                a && !c.$1 ? c.$1 = d("DOMEventListener").add(a, "wheel", c.$3, {
                    passive: !0
                }) : !a && c.$1 && (c.$1.remove(), c.$1 = null)
            }, c.$3 = function(a) {
                a.stopPropagation()
            }, b) || babelHelpers.assertThisInitialized(c)
        }
        var c = b.prototype;
        c.render = function() {
            return h.jsx("div", babelHelpers["extends"]({}, this.props, {
                ref: this.$2
            }))
        };
        return b
    }(h.Component);
    g["default"] = a
}), 98);
__d("TidyArbiterMixin", ["Arbiter", "ArbiterMixin", "Run"], (function(a, b, c, d, e, f, g) {
    a = {};
    Object.assign(a, c("ArbiterMixin"), {
        _getArbiterInstance: function() {
            var a = this;
            this._arbiter || (this._arbiter = new(c("Arbiter"))(), d("Run").onLeave(function() {
                delete a._arbiter
            }));
            return this._arbiter
        }
    });
    b = a;
    g["default"] = b
}), 98);
__d("Currency", ["CurrencyConfig"], (function(a, b, c, d, e, f, g) {
    var h = {
        iso: "",
        format: "",
        symbol: "",
        offset: 1,
        name: ""
    };

    function i(a) {
        return a != null && c("CurrencyConfig").allCurrenciesByCode[a] ? c("CurrencyConfig").allCurrenciesByCode[a] : h
    }

    function a(a) {
        return i(a).format
    }

    function b(a) {
        return i(a).iso
    }

    function d(a) {
        return i(a).name
    }

    function e(a) {
        return i(a).offset
    }

    function g(a) {
        return i(a).symbol
    }
    f.exports = {
        getFormat: a,
        getISO: b,
        getName: d,
        getOffset: e,
        getSymbol: g
    }
}), 34);
__d("adsLibFormatNumber", ["intlNumUtils"], (function(a, b, c, d, e, f, g) {
    function a(a, b, c, e, f) {
        return a === "N/A" ? a : d("intlNumUtils").formatNumberRaw((a = a) != null ? a : 0, b, c, e, f)
    }
    g["default"] = a
}), 98);
__d("createIntlPercentFormatter", ["NumberFormatConfig", "adsLibFormatNumber"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        var e = b === !1 ? 1 : 100;
        return function(b) {
            return c("adsLibFormatNumber")(((b = b) != null ? b : 0) * e, a || 0, d("NumberFormatConfig").numberDelimiter, d("NumberFormatConfig").decimalSeparator) + "%"
        }
    }
    g["default"] = a
}), 98);
__d("ads-lib-formatters", ["fbt", "Currency", "NumberFormatConfig", "adsLibFormatNumber", "createIntlPercentFormatter", "intlNumUtils"], (function(a, b, c, d, e, f, g, h) {
    var i = "USD";

    function j(a, b, c) {
        a = (a = a) != null ? a : "";
        c = (c = c) != null ? c : "";
        b = b === 0 || b == null ? a.length : b;
        if (a.length <= b) return a;
        b = b - c.length;
        b && (/[\uD800-\uDFFF]/.test(a[b - 1]) && (b += 1));
        return a.substr(0, b) + c
    }

    function a(a, b) {
        b === void 0 && (b = "");
        return function(c) {
            return c == null ? b : j(c, a, "...")
        }
    }

    function k(a) {
        return function(b) {
            return c("adsLibFormatNumber")(b, (b = a) != null ? b : 0, ",", ".")
        }
    }

    function l(a) {
        return function(b) {
            return c("adsLibFormatNumber")(b, (b = a) != null ? b : 0, c("NumberFormatConfig").numberDelimiter, c("NumberFormatConfig").decimalSeparator, c("NumberFormatConfig").minDigitsForThousandsSeparator)
        }
    }

    function b(a) {
        return function(b) {
            return c("intlNumUtils").formatNumberRaw((b = b) != null ? b : "0", (b = a) != null ? b : 0, c("NumberFormatConfig").numberDelimiter, c("NumberFormatConfig").decimalSeparator, c("NumberFormatConfig").minDigitsForThousandsSeparator)
        }
    }

    function d(a, b) {
        return function(d) {
            return c("intlNumUtils").formatNumberWithLimitedSigFig(d, a, b)
        }
    }

    function e(a, b) {
        return b ? l(a) : function(b) {
            return c("adsLibFormatNumber")(b, a || 0, "", c("NumberFormatConfig").decimalSeparator, c("NumberFormatConfig").minDigitsForThousandsSeparator)
        }
    }

    function f(a, b) {
        var d = b === !1 ? 1 : 100;
        return function(b) {
            return c("adsLibFormatNumber")(b * d, a || 0, ",", ".") + "%"
        }
    }

    function m(a, b, d, e, f) {
        a === void 0 && (a = 2);
        b === void 0 && (b = i);
        d === void 0 && (d = !1);
        var g = e(a);
        e = b + "-" + a + "-" + d.toString();
        if (!f[e]) {
            var h = c("Currency").getFormat(b) || c("Currency").getFormat(i);
            a = c("Currency").getSymbol(b) || c("Currency").getSymbol(i);
            var j = c("Currency").getOffset(b) || c("Currency").getOffset(i);
            h = h.replace("{symbol}", a);
            f[e] = function(a) {
                a = (a = a) != null ? a : 0;
                d && (a /= j);
                return !(a + "").match(/^\-?[\d\.,]*$/) ? "N/A" : h.replace("{amount}", g(a))
            }
        }
        return f[e]
    }
    var n = {};

    function o(a, b, c) {
        return m((a = a) != null ? a : 0, b, c, k, n)
    }
    var p = {};

    function q(a, b, c) {
        return m(a, b, c, l, p)
    }

    function r(a, b, c, d) {
        return q(a, b, c)(d)
    }

    function s(a, b) {
        return b != null ? c("intlNumUtils").parseNumberRaw(a != null ? a + "" : "", b, c("NumberFormatConfig").numberDelimiter) : a != null ? c("intlNumUtils").parseNumber(a + "") : null
    }

    function t(a) {
        var b = [];
        a.countries && a.countries.length && b.push(a.countries);
        a.cities && a.cities.length && b.push(a.cities.map(function(a) {
            return a.name
        }));
        a.zips && a.zips.length && b.push(a.zips.map(function(a) {
            return a.name
        }));
        a.regions && a.regions.length && b.push(a.regions.map(function(a) {
            return a.name
        }));
        return b.join("; ").replace(/,/g, ", ")
    }

    function u(a, b) {
        if (a || b) {
            a = a || h._("All");
            b = b || h._("All");
            return a + "&ndash;" + b
        }
        return "Any"
    }

    function v(a) {
        a = a + "";
        if (a === "0") return h._("All");
        else if (a === "1") return h._("Men");
        return h._("Women")
    }
    g.geoLocation = t;
    g.age = u;
    g.sex = v;
    g.createTextTruncator = a;
    g.chopString = j;
    g.parseNumber = s;
    g.formatNumber = c("adsLibFormatNumber");
    g.createIntlNumberFormatter = l;
    g.createIntlLongNumberFormatter = b;
    g.createLimitedSigFigNumberFormatter = d;
    g.createMaybeDelimitedNumberFormatter = e;
    g.createIntlPercentFormatter = c("createIntlPercentFormatter");
    g.createIntlMoneyFormatter = q;
    g.formatIntlMoney = r;
    g.createNumberFormatter = k;
    g.createPercentFormatter = f;
    g.createMoneyFormatter = o
}), 34);
__d("isStringNullOrWhitespaceOnly", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a == null || a.trim() === ""
    }
    f["default"] = a
}), 66);
__d("cssLength", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    b = /^(auto|0)$|^[+-]?[0-9]+.?([0-9]+)?(px|em|ex|ch|rem|in|cm|mm|pc|pt|ex|vw|vh|vmin|vmax|%)$|^calc\(.+\)$/;

    function a(a) {
        return a
    }
    g["default"] = a
}), 98);
__d("range", [], (function(a, b, c, d, e, f) {
    function a(a, b, c) {
        c = c == null || c === 0 ? a < b ? 1 : -1 : c;
        var d = -1;
        b = Math.max(Math.ceil((b - a) / c), 0);
        var e = Array(b);
        a = a;
        while (b--) e[++d] = a, a += c;
        return e
    }
    f["default"] = a
}), 66);
__d("DateHelpers", ["range"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = a.getDayOfWeek();
        b === 0 && (b = 7);
        b = Math.floor((a.getDayOfYear() - b + 11) / 7);
        b < 1 ? b = h(a.subtractYears(1)) : b > h(a) && (b = 1);
        return b
    }

    function h(a) {
        var b = a.getYear();
        a = a.startOfYear();
        a = a.getDayOfWeek();
        return a === 4 || a === 3 && i(b) ? 53 : 52
    }

    function i(a) {
        return a % 4 === 0 && a % 100 !== 0 || a % 400 === 0
    }

    function b(a, b, d) {
        switch (b) {
            case 2:
                return i(d) ? c("range")(1, 30).includes(a) : c("range")(1, 29).includes(a);
            case 4:
            case 6:
            case 9:
            case 11:
                return c("range")(1, 31).includes(a);
            default:
                return c("range")(1, 32).includes(a)
        }
    }
    g.getISOWeekNumber = a;
    g.isLeapYear = i;
    g.isValidDate = b
}), 98);
__d("XDeveloperDocumentationController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/docs/{?path1}/{?path2}/{?path3}/{?path4}/{?path5}/{?path6}/", {
        version: {
            type: "String"
        },
        preview: {
            type: "Exists",
            defaultValue: !1
        },
        revisionid: {
            type: "Int"
        },
        translation: {
            type: "Exists",
            defaultValue: !1
        },
        source: {
            type: "String"
        },
        app_id: {
            type: "FBID"
        },
        path1: {
            type: "String"
        },
        path2: {
            type: "String"
        },
        path3: {
            type: "String"
        },
        path4: {
            type: "String"
        },
        path5: {
            type: "String"
        },
        path6: {
            type: "String"
        },
        prefill_href: {
            type: "String"
        }
    })
}), null);