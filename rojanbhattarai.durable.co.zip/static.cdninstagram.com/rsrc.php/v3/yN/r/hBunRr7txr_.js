; /*FB_PKG_DELIM*/

__d("CometDangerouslySuppressInteractiveElementsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("CSSUserAgentSupports", ["UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        webkitLineClamp: function() {
            return !(c("UserAgent").isBrowser("IE") || c("UserAgent").isBrowser("Edge < 17") || c("UserAgent").isBrowser("Firefox < 68"))
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("CometTextContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("TetraTextTypography", ["UserAgent", "cr:2011", "cr:4166"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b("cr:2011");
    var h = {
            apple: {
                MozOsxFontSmoothing: "xlh3980",
                WebkitFontSmoothing: "xvmahel",
                fontFamily: "x1n0sxbx",
                $$css: !0
            },
            "default": {
                fontFamily: "x10flsy6",
                $$css: !0
            },
            segoe: {
                fontFamily: "x1xmvt09",
                $$css: !0
            }
        },
        i = {
            body1: {
                fontFamily: h["default"],
                fontSize: 20,
                fontWeight: "normal",
                lineHeight: 24,
                offsets: [4, 5]
            },
            body2: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "normal",
                lineHeight: 20,
                offsets: [3, 5]
            },
            body3: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "normal",
                lineHeight: 20,
                offsets: [4, 5]
            },
            body4: {
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "normal",
                lineHeight: 16,
                offsets: [3, 4]
            },
            bodyLink1: {
                fontFamily: h["default"],
                fontSize: 20,
                fontWeight: "semibold",
                lineHeight: 24,
                offsets: [4, 5]
            },
            bodyLink2: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [3, 5]
            },
            bodyLink3: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            bodyLink4: {
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "semibold",
                lineHeight: 16,
                offsets: [3, 4]
            },
            button1: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [3, 5]
            },
            button2: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            entityHeaderHeadline1: {
                fontFamily: h["default"],
                fontSize: 32,
                fontWeight: "bold",
                lineHeight: 38,
                offsets: [7, 8]
            },
            entityHeaderHeadline2: {
                fontFamily: h["default"],
                fontSize: 28,
                fontWeight: "bold",
                lineHeight: 32,
                offsets: [5, 7]
            },
            entityHeaderMeta1: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "bold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            entityHeaderMeta2: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "bold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            headline3: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "medium",
                lineHeight: 20,
                offsets: [3, 5]
            },
            headline4: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "medium",
                lineHeight: 20,
                offsets: [4, 5]
            },
            headlineDeemphasized3: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "normal",
                lineHeight: 20,
                offsets: [3, 5]
            },
            headlineDeemphasized4: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "normal",
                lineHeight: 20,
                offsets: [4, 5]
            },
            headlineEmphasized1: {
                fontFamily: h["default"],
                fontSize: 24,
                fontWeight: "bold",
                lineHeight: 28,
                offsets: [5, 6]
            },
            headlineEmphasized2: {
                fontFamily: h["default"],
                fontSize: 20,
                fontWeight: "bold",
                lineHeight: 24,
                offsets: [4, 5]
            },
            headlineEmphasized3: {
                fontFamily: h["default"],
                fontSize: 17,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [3, 4]
            },
            headlineEmphasized4: {
                fontFamily: h["default"],
                fontSize: 15,
                fontWeight: "semibold",
                lineHeight: 20,
                offsets: [4, 5]
            },
            meta1: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "semibold",
                lineHeight: 16,
                offsets: [3, 4]
            },
            meta2: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "semibold",
                lineHeight: 16,
                offsets: [3, 4]
            },
            meta3: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 13,
                fontWeight: "normal",
                lineHeight: 16,
                offsets: [3, 4]
            },
            meta4: {
                defaultColor: "secondary",
                fontFamily: h["default"],
                fontSize: 12,
                fontWeight: "normal",
                lineHeight: 16,
                offsets: [3, 4]
            }
        },
        j = [
            ["body1", [5, 5]],
            ["body2", [4, 4]],
            ["body3", [4, 4]],
            ["body4", [4, 3]],
            ["bodyLink1", [5, 5]],
            ["bodyLink2", [4, 4]],
            ["bodyLink3", [4, 4]],
            ["bodyLink4", [4, 3]],
            ["button1", [4, 4]],
            ["button2", [4, 4]],
            ["entityHeaderHeadline1", [8, 7]],
            ["entityHeaderHeadline2", [6, 6]],
            ["entityHeaderMeta1", [4, 4]],
            ["entityHeaderMeta2", [4, 4]],
            ["headline3", [4, 4]],
            ["headline4", [4, 4]],
            ["headlineDeemphasized3", [4, 4]],
            ["headlineDeemphasized4", [4, 4]],
            ["headlineEmphasized1", [6, 5]],
            ["headlineEmphasized2", [5, 5]],
            ["headlineEmphasized3", [4, 4]],
            ["headlineEmphasized4", [4, 4]],
            ["meta1", [4, 3]],
            ["meta2", [4, 3]],
            ["meta3", [4, 3]],
            ["meta4", [3, 3]]
        ],
        k = [
            ["body1", [5, 5]],
            ["body2", [4, 4]],
            ["body3", [5, 4]],
            ["body4", [4, 3]],
            ["bodyLink1", [6, 4]],
            ["bodyLink2", [4, 3]],
            ["bodyLink3", [5, 4]],
            ["bodyLink4", [4, 3]],
            ["button1", [4, 3]],
            ["button2", [5, 4]],
            ["entityHeaderHeadline1", [8, 7]],
            ["entityHeaderHeadline2", [7, 5]],
            ["entityHeaderMeta1", [5, 4]],
            ["entityHeaderMeta2", [5, 4]],
            ["headline3", [5, 3]],
            ["headline4", [5, 4]],
            ["headlineDeemphasized3", [5, 3]],
            ["headlineDeemphasized4", [5, 4]],
            ["headlineEmphasized1", [6, 5]],
            ["headlineEmphasized2", [6, 4]],
            ["headlineEmphasized3", [4, 3]],
            ["headlineEmphasized4", [5, 4]],
            ["meta1", [4, 3]],
            ["meta2", [4, 3]],
            ["meta3", [4, 3]],
            ["meta4", [4, 3]]
        ],
        l = [
            ["body1", [6, 4, 1]],
            ["body2", [5, 3, 1]],
            ["body3", [5, 4]],
            ["body4", [4, 3, 1]],
            ["bodyLink1", [6, 4, 1]],
            ["bodyLink2", [5, 3, 1]],
            ["bodyLink3", [5, 4]],
            ["bodyLink4", [4, 3, 1]],
            ["button1", [5, 3, 1]],
            ["button2", [5, 4]],
            ["entityHeaderHeadline1", [10, 6, 2]],
            ["entityHeaderHeadline2", [8, 5, 3]],
            ["entityHeaderMeta1", [5, 4, 1]],
            ["entityHeaderMeta2", [5, 4, 1]],
            ["headline3", [5, 3, 1]],
            ["headline4", [5, 4]],
            ["headlineDeemphasized3", [5, 3, 1]],
            ["headlineDeemphasized4", [5, 4]],
            ["headlineEmphasized1", [7, 4, 2]],
            ["headlineEmphasized2", [6, 4, 2]],
            ["headlineEmphasized3", [5, 3, 1]],
            ["headlineEmphasized4", [5, 4]],
            ["meta1", [4, 3, 1]],
            ["meta2", [4, 3, 1]],
            ["meta3", [4, 3, 1]],
            ["meta4", [4, 3]]
        ];

    function m() {
        if (c("UserAgent").isPlatform("Windows >= 6")) return {
            fontFamily: h.segoe,
            offsets: l
        };
        return c("UserAgent").isPlatform("Mac OS X >= 10.11") && !c("UserAgent").isBrowser("Firefox < 55") || c("UserAgent").isPlatform("iOS >= 9") ? {
            fontFamily: h.apple,
            offsets: c("UserAgent").isEngine("Gecko") ? k : j
        } : null
    }

    function a() {
        var a = babelHelpers["extends"]({}, i),
            c = m();
        if (c != null) {
            var d = c.fontFamily;
            c = c.offsets;
            c = new Map(c);
            c.forEach(function(b, c) {
                a[c] = babelHelpers["extends"]({}, a[c], {
                    fontFamily: d,
                    offsets: b
                })
            })
        }
        b("cr:4166") && Object.keys(b("cr:4166")).forEach(function(c) {
            a[c] = b("cr:4166")[c]
        });
        return a
    }
    d = a();
    g["default"] = d
}), 98);
__d("CometTextTypography", ["TetraTextTypography"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("TetraTextTypography")
}), 98);
__d("CometLineClamp.react", ["CSSUserAgentSupports", "CometPlaceholder.react", "CometTextContext", "CometTextTypography", "JSResourceForInteraction", "cr:2099", "lazyLoadComponent", "react", "stylex", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useCallback,
        j = e.useContext,
        k = e.useRef,
        l = e.useState;
    e = (d = b("cr:2099")) != null ? d : {
        useTranslationKeyForTextParent: function() {}
    };
    var m = e.useTranslationKeyForTextParent,
        n = c("JSResourceForInteraction")("CometTooltip.react").__setRef("CometLineClamp.react"),
        o = c("lazyLoadComponent")(n),
        p = c("CSSUserAgentSupports").webkitLineClamp(),
        q = {
            ellipsis: {
                end: "xds687c",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x10l6tqk",
                $$css: !0
            },
            oneLine: {
                textOverflow: "xlyipyv",
                whiteSpace: "xuxw1ft",
                $$css: !0
            },
            root: {
                display: "x1lliihq",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x1n2onr6",
                $$css: !0
            }
        };

    function a(a, b) {
        var d = a.children,
            e = a.id,
            f = a.lines,
            g = a.testid,
            s = a.truncationTooltip;
        g = a.useAutomaticTextDirection;
        g = g === void 0 ? !1 : g;
        a = a.xstyle;
        var t = j(c("CometTextContext")),
            u = m(),
            v = l(!1),
            w = v[0],
            x = v[1],
            y = k(null);
        v = d;
        var z;
        if (f > 1)
            if (p) z = {
                WebkitBoxOrient: "vertical",
                WebkitLineClamp: f,
                display: "-webkit-box"
            };
            else {
                d = r(t == null ? void 0 : t.type);
                z = {
                    maxHeight: d * f + .1
                };
                t = {
                    maxHeight: "calc((100% - " + d * f + "px) * 999)",
                    top: d * (f - 1)
                };
                v = h.jsxs(h.Fragment, {
                    children: [v, h.jsx("span", {
                        "aria-hidden": !0,
                        className: "xds687c x6ikm8r x10wlt62 x10l6tqk",
                        style: t,
                        children: "\u2026"
                    })]
                })
            }
        d = function() {
            var a = y.current;
            if (a == null || f < 1) return;
            x(a.offsetWidth < a.scrollWidth || a.offsetHeight < a.scrollHeight)
        };
        t = i(function(a) {
            if (a == null || s == null) return;
            n.preload()
        }, [s]);
        b = c("useMergeRefs")(b, y, t);
        t = h.jsx("span", {
            className: c("stylex")(q.root, f === 1 && q.oneLine, a),
            "data-testid": void 0,
            dir: g ? "auto" : void 0,
            id: e,
            onMouseEnter: s != null ? d : void 0,
            ref: b,
            style: z,
            children: v
        }, u);
        return w ? h.jsx(c("CometPlaceholder.react"), {
            fallback: t,
            children: h.jsx(o, {
                tooltip: s,
                children: t
            })
        }) : t
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function r(a) {
        return a != null && a in c("CometTextTypography") ? c("CometTextTypography")[a].lineHeight : 16
    }
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("ReactEventHelpers", [], (function(a, b, c, d, e, f) {
    b = typeof window !== "undefined" && window.navigator != null ? /^Mac/.test(window.navigator.platform) : !1;
    c = typeof window !== "undefined" && window.PointerEvent != null;

    function a(a, b) {
        return b == null ? !1 : typeof a.containsNode === "function" ? a.containsNode(b) : a.contains(b)
    }
    f.isMac = b;
    f.hasPointerEvents = c;
    f.isRelatedTargetWithin = a
}), 66);
__d("ReactEventHookPropagation", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        a = a._stopEventHookPropagation;
        return a !== void 0 && a[b]
    }

    function b(a, b) {
        var c = a._stopEventHookPropagation;
        c || (c = a._stopEventHookPropagation = {});
        c[b] = !0
    }
    f.hasEventHookPropagationStopped = a;
    f.stopEventHookPropagation = b
}), 66);
__d("ReactUseEvent.react", ["ReactDOMComet", "gkx", "react", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useLayoutEffect;

    function a(a, b) {
        var e = c("useUnsafeRef_DEPRECATED")(null),
            f = e.current;
        c("gkx")("1703328") && (b && (b.passive = void 0));
        if (f === null) {
            var g = d("ReactDOMComet").unstable_createEventHandle(a, b),
                i = new Map();
            f = {
                setListener: function(a, b) {
                    var c = i.get(a);
                    c !== void 0 && c();
                    if (b === null) {
                        i["delete"](a);
                        return
                    }
                    c = g(a, b);
                    i.set(a, c)
                },
                clear: function() {
                    var a = Array.from(i.values());
                    for (var b = 0; b < a.length; b++) a[b]();
                    i.clear()
                }
            };
            e.current = f
        }
        h(function() {
            return function() {
                f !== null && f.clear(), e.current = null
            }
        }, [f]);
        return f
    }
    g["default"] = a
}), 98);
__d("checkPassiveEventsSupported", ["gkx"], (function(a, b, c, d, e, f, g) {
    a = !!(typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined");
    b = !1;
    if (a && !c("gkx")("1703328")) try {
        d = {};
        Object.defineProperty(d, "passive", {
            get: function() {
                b = !0
            }
        });
        window.addEventListener("test", d, d);
        window.removeEventListener("test", d, d)
    } catch (a) {
        b = !1
    }
    e = b;
    g["default"] = e
}), 98);
__d("ReactFocusEvent.react", ["ReactEventHelpers", "ReactEventHookPropagation", "ReactUseEvent.react", "checkPassiveEventsSupported", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = d("react");
    var h = e.useCallback,
        i = e.useEffect,
        j = e.useLayoutEffect,
        k = e.useMemo,
        l = e.useRef,
        m = d("ReactEventHelpers").hasPointerEvents ? ["keydown", "pointermove", "pointerdown", "pointerup"] : ["keydown", "mousedown", "mousemove", "mouseup", "touchmove", "touchstart", "touchend"],
        n = {
            passive: !0
        },
        o = !0,
        p = !1;

    function q() {
        m.forEach(function(a) {
            window.addEventListener(a, t, c("checkPassiveEventsSupported") ? {
                capture: !0,
                passive: !0
            } : !0)
        })
    }

    function r(a) {
        var b = a.metaKey,
            c = a.altKey;
        a = a.ctrlKey;
        return !(b || !d("ReactEventHelpers").isMac && c || a)
    }

    function s(a) {
        var b = a.key;
        a = a.target;
        if (b === "Tab" || b === "Escape") return !1;
        b = a.isContentEditable;
        a = a.tagName;
        return a === "INPUT" || a === "TEXTAREA" || b
    }

    function t(a) {
        if (a.type === "keydown") r(a) && (o = !0);
        else {
            a = a.target.nodeName;
            if (a === "HTML") return;
            o = !1
        }
    }

    function u(a, b) {
        if (a.type === "keydown") {
            a = a.nativeEvent;
            r(a) && !s(a) && b(!0)
        } else o = !1, b(!1)
    }

    function v(a, b, c) {
        a.forEach(function(a) {
            a.setListener(b, function(a) {
                return u(a, c)
            })
        })
    }

    function w() {
        var a = c("ReactUseEvent.react")("mousedown", n),
            b = c("ReactUseEvent.react")(d("ReactEventHelpers").hasPointerEvents ? "pointerdown" : "touchstart", n),
            e = c("ReactUseEvent.react")("keydown", n);
        return k(function() {
            return [a, b, e]
        }, [e, a, b])
    }

    function x() {
        i(function() {
            p || (p = !0, q())
        }, [])
    }

    function a(a, b) {
        var e = b.disabled,
            f = b.onBlur,
            g = b.onFocus,
            h = b.onFocusChange,
            k = b.onFocusVisibleChange,
            m = l({
                isFocused: !1,
                isFocusVisible: !1
            }),
            p = c("ReactUseEvent.react")("focusin", n),
            q = c("ReactUseEvent.react")("focusout", n),
            r = w();
        j(function() {
            var b = a.current,
                i = m.current;
            if (b !== null && b.nodeType === 1) {
                v(r, b, function(a) {
                    i.isFocused && i.isFocusVisible !== a && (i.isFocusVisible = a, k && k(a))
                });
                var j = function(a) {
                    i.isFocused && (i.isFocused = !1, f && f(a), h && h(!1), i.isFocusVisible && k && k(!1), i.isFocusVisible = o)
                };
                p.setListener(b, function(a) {
                    if (!c("gkx")("5403") && e === !0) return;
                    if (d("ReactEventHookPropagation").hasEventHookPropagationStopped(a, "useFocus")) return;
                    d("ReactEventHookPropagation").stopEventHookPropagation(a, "useFocus");
                    !i.isFocused && b === a.target && (i.isFocused = !0, i.isFocusVisible = o, g && g(a), h && h(!0), i.isFocusVisible && k && k(!0))
                });
                q.setListener(b, function(a) {
                    if (!c("gkx")("5403") && e === !0) return;
                    if (d("ReactEventHookPropagation").hasEventHookPropagationStopped(a, "useFocus")) return;
                    d("ReactEventHookPropagation").stopEventHookPropagation(a, "useFocus");
                    j(a)
                })
            }
        }, [q, e, p, a, r, f, g, h, k]);
        i(function() {
            var b = a.current,
                c = m.current;
            return function() {
                if (a.current === null && c.isFocused) {
                    c.isFocused = !1;
                    var d = new window.FocusEvent("blur");
                    Object.defineProperty(d, "target", {
                        value: b
                    });
                    f && f(d);
                    h && h(!1);
                    c.isFocusVisible && k && k(!1);
                    c.isFocusVisible = o
                }
            }
        });
        x()
    }

    function b(a, b) {
        var e = b.disabled,
            f = b.onAfterBlurWithin,
            g = b.onBeforeBlurWithin,
            i = b.onBlurWithin,
            j = b.onFocusWithin,
            k = b.onFocusWithinChange,
            m = b.onFocusWithinVisibleChange,
            p = l({
                isFocused: !1,
                isFocusVisible: !1
            }),
            q = c("ReactUseEvent.react")("focusin", n),
            r = c("ReactUseEvent.react")("focusout", n),
            s = c("ReactUseEvent.react")("afterblur", n),
            t = c("ReactUseEvent.react")("beforeblur", n),
            u = w();
        b = h(function(b) {
            typeof a === "function" ? a(b) : a.current = b;
            var h = p.current;
            b !== null && h !== null && (v(u, b, function(a) {
                h.isFocused && h.isFocusVisible !== a && (h.isFocusVisible = a, m && m(a))
            }), q.setListener(b, function(a) {
                if (!c("gkx")("5403") && e === !0) return;
                if (d("ReactEventHookPropagation").hasEventHookPropagationStopped(a, "useFocusWithin")) return;
                h.isFocused || (h.isFocused = !0, h.isFocusVisible = o, k && k(!0), h.isFocusVisible && m && m(!0));
                !h.isFocusVisible && o && (h.isFocusVisible = o, m && m(!0));
                j && j(a)
            }), r.setListener(b, function(a) {
                if (!c("gkx")("5403") && e === !0) return;
                var f = a.nativeEvent.relatedTarget;
                if (d("ReactEventHookPropagation").hasEventHookPropagationStopped(a, "useFocusWithin")) return;
                h.isFocused && !d("ReactEventHelpers").isRelatedTargetWithin(b, f) ? (h.isFocused = !1, k && k(!1), h.isFocusVisible && m && m(!1), i && i(a)) : d("ReactEventHookPropagation").stopEventHookPropagation(a, "useFocusWithin")
            }), t.setListener(b, function(a) {
                if (!c("gkx")("5403") && e === !0) return;
                g && (g(a), s.setListener(document, function(a) {
                    f && f(a), s.setListener(document, null)
                }))
            }))
        }, [s, t, r, e, q, u, a, f, g, i, j, k, m]);
        x();
        return b
    }
    g.useFocus = a;
    g.useFocusWithin = b
}), 98);
__d("FocusWithinHandler.react", ["ReactFocusEvent.react", "react"], (function(a, b, c, d, e, f, g) {
    var h = d("react");
    b = d("react");
    var i = b.useMemo,
        j = b.useRef,
        k = b.useState,
        l = h.unstable_Scope;

    function a(a) {
        var b, c = a.children,
            e = a.onFocusChange,
            f = a.onFocusVisibleChange,
            g = a.onFocusWithin,
            m = a.onBlurWithin;
        a = a.testOnly;
        var n = j(null);
        b = k((b = a && a.focus) != null ? b : !1);
        var o = b[0],
            p = b[1];
        a = k((b = a && a.focusVisible) != null ? b : !1);
        b = a[0];
        var q = a[1];
        a = d("ReactFocusEvent.react").useFocusWithin(n, i(function() {
            return {
                onFocusWithin: function(a) {
                    g && !o && g(a)
                },
                onBlurWithin: function(a) {
                    m && o && m(a)
                },
                onFocusWithinChange: e ? function(a) {
                    p(a), e(a)
                } : p,
                onFocusWithinVisibleChange: f ? function(a) {
                    q(a), f(a)
                } : q
            }
        }, [o, m, e, f, g]));
        return h.jsx(l, {
            ref: a,
            children: typeof c === "function" ? c(o, b) : c
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseFocusRing.react", ["FocusWithinHandler.react", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            focused: {
                outline: "x1i4iak8",
                "@media (-webkit-min-device-pixel-ratio: 0)_outline": "x1n22pj5",
                $$css: !0
            },
            newFocused: {
                boxShadow: "x90kdol",
                outline: "x1a2a7pz",
                $$css: !0
            },
            newFocusedInset: {
                boxShadow: "xsgs0p0",
                outline: "x1a2a7pz",
                $$css: !0
            },
            newFocusedLink: {
                outline: "x11312b7",
                $$css: !0
            },
            unfocused: {
                outline: "x1a2a7pz",
                $$css: !0
            }
        },
        j = {
            "default": i.newFocused,
            inset: i.newFocusedInset
        },
        k = c("gkx")("1721477") || c("gkx")("1459");

    function a(a) {
        var b = a.children,
            d = a.focusRingPosition;
        d = d === void 0 ? "default" : d;
        var e = a.mode,
            f = e === void 0 ? "focus-visible" : e;
        e = a.suppressFocusRing;
        var g = e === void 0 ? !1 : e;
        e = a.testOnly;
        var l = k ? j[d] : i.focused;
        return h.jsx(c("FocusWithinHandler.react"), {
            testOnly: e,
            children: function(a, c) {
                var d = !1;
                g || (a && c ? d = !0 : a && f === "focus" && (d = !0));
                return b(d ? l : i.unfocused)
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a.focusRingXStyle = k ? i.newFocused : i.focused;
    a.focusRingInsetXStyle = k ? i.newFocusedInset : i.focused;
    a.linkFocusRingXStyle = k ? i.newFocusedLink : i.focused;
    g["default"] = a
}), 98);
__d("CometPressableOverlay.react", ["BaseFocusRing.react", "CometCompositeItemFocusIndicator.react", "CometVisualCompletionAttributes", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useState,
        j = {
            circle: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                $$css: !0
            },
            defaultHoveredStyle: {
                backgroundColor: "x1wpzbip",
                $$css: !0
            },
            defaultPressedStyle: {
                backgroundColor: "x1iutvsz",
                $$css: !0
            },
            overlay: {
                borderTopStartRadius: "x1o1ewxj",
                borderTopEndRadius: "x3x9cwd",
                borderBottomEndRadius: "x1e5q0jg",
                borderBottomStartRadius: "x13rtm0m",
                bottom: "x1ey2m1c",
                end: "xds687c",
                opacity: "xg01cxk",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy",
                transitionDuration: "x1ebt8du",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "x1dhq9h",
                $$css: !0
            },
            overlayVisible: {
                opacity: "x1hc1fzr",
                transitionDuration: "x1mq3mr6",
                $$css: !0
            }
        };

    function a(a) {
        var b = a.focusVisible;
        b = b === void 0 ? !1 : b;
        var d = a.focusRingPosition;
        d = d === void 0 ? "default" : d;
        var e = a.hovered;
        e = e === void 0 ? !1 : e;
        var f = a.hoveredStyle;
        f = f === void 0 ? j.defaultHoveredStyle : f;
        var g = a.offset,
            k = a.pressed;
        k = k === void 0 ? !1 : k;
        var l = a.pressedStyle;
        l = l === void 0 ? j.defaultPressedStyle : l;
        var m = a.radius,
            n = a.focusVisibleStyle;
        n = n === void 0 ? f : n;
        var o = a.showGridSignifiers;
        o = o === void 0 ? !1 : o;
        a = a.showFocusRing;
        a = a === void 0 ? !1 : a;
        var p = i(),
            q = p[0];
        p = p[1];
        k ? q !== "pressed" && p("pressed") : b ? q !== "focused" && p("focused") : e && (q !== "hovered" && p("hovered"));
        var r, s, t, u;
        g != null && (typeof g === "number" ? (r = -g, s = -g, t = -g, u = -g) : (r = -g.bottom, s = -g.left, t = -g.right, u = -g.top));
        return h.jsx("div", babelHelpers["extends"]({
            className: c("stylex")(j.overlay, (k || b || e || o) && j.overlayVisible, q === "pressed" && l, q === "focused" && n, q === "hovered" && f, q === "focused" && a ? d === "default" ? c("BaseFocusRing.react").focusRingXStyle : c("BaseFocusRing.react").focusRingInsetXStyle : void 0, m === "50%" && j.circle)
        }, c("CometVisualCompletionAttributes").IGNORE, {
            style: q != null ? {
                borderRadius: typeof m === "number" ? m : void 0,
                bottom: r,
                left: s,
                right: t,
                top: u
            } : void 0,
            children: o ? h.jsx(c("CometCompositeItemFocusIndicator.react"), {}) : null
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometCompositeStructureContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        horizontal: !1,
        vertical: !1
    });
    g["default"] = b
}), 98);
__d("TintableIconSource", ["IconSource"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.$$typeof = "fb.tintableiconsource", b) || babelHelpers.assertThisInitialized(c)
        }
        return b
    }(c("IconSource"));
    g["default"] = a
}), 98);
__d("fbicon", ["TintableIconSource", "coerceImageishSprited", "memoizeWithArgs", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        throw c("unrecoverableViolation")("fbicon.filled" + ("(" + JSON.stringify(a) + ", " + b + "): ") + "Unexpected fbicon.filled reference.", "comet_ui")
    }

    function b(a, b) {
        throw c("unrecoverableViolation")("fbicon.outline" + ("(" + JSON.stringify(a) + ", " + b + "): ") + "Unexpected fbicon.outline reference.", "comet_ui")
    }
    d = c("memoizeWithArgs")(function(a, b) {
        return new(c("TintableIconSource"))("FB", a, b)
    }, function(a, b) {
        if (typeof a === "object") {
            var d = c("coerceImageishSprited")(a);
            if (d != null) return d.identifier + ":" + b;
            else if (typeof a.uri === "string") return a.uri + ":" + b
        } else if (typeof a === "string") return a + ":" + b;
        throw c("unrecoverableViolation")("fbicon._: Invalid icon provided.", "comet_ui")
    });
    g.filled = a;
    g.outline = b;
    g._ = d
}), 98);
__d("CometCompositeItemFocusIndicator.react", ["ix", "CometCompositeStructureContext", "CometIcon.react", "fbicon", "gkx", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = d("react").useContext,
        k = c("gkx")("1721477") || c("gkx")("1459");

    function a() {
        var a = j(c("CometCompositeStructureContext"));
        return !k || a.hideArrowSignifiers === !0 ? null : i.jsxs(i.Fragment, {
            children: [a.horizontal === !0 ? i.jsxs(i.Fragment, {
                children: [i.jsx("div", {
                    className: "x2bj2ny xn7ya7q x1su9jv1 xt02mhb xb4krs4 x1npaq5j x1c83p5e x1enjb0b x199158v xdk7pt x14ju556 x1nn3v0j xg83lxy xg8j3zb x1k2j06m x10l6tqk x1xc55vz x9otpla x67uiyb xwa60dl",
                    children: i.jsx(c("CometIcon.react"), {
                        color: "primary",
                        icon: d("fbicon")._(h("1739808"), 8)
                    })
                }), i.jsx("div", {
                    className: "x2bj2ny xn7ya7q x1su9jv1 xt02mhb xb4krs4 x1npaq5j x1c83p5e x1enjb0b x199158v xdk7pt x14ju556 x1nn3v0j xg83lxy xg8j3zb x1k2j06m x10l6tqk x1xc55vz x1wtad8d x9otpla xwa60dl",
                    children: i.jsx(c("CometIcon.react"), {
                        color: "primary",
                        icon: d("fbicon")._(h("897949"), 8)
                    })
                })]
            }) : null, a.vertical === !0 ? i.jsxs(i.Fragment, {
                children: [i.jsx("div", {
                    className: "x2bj2ny xn7ya7q x1su9jv1 xt02mhb xb4krs4 x1npaq5j x1c83p5e x1enjb0b x199158v xdk7pt x14ju556 x1nn3v0j xg83lxy xg8j3zb x1k2j06m x10l6tqk x1xc55vz x1orzsq4 xtzzx4i x1fur4o1",
                    children: i.jsx(c("CometIcon.react"), {
                        color: "primary",
                        icon: d("fbicon")._(h("702721"), 8)
                    })
                }), i.jsx("div", {
                    className: "x2bj2ny xn7ya7q x1su9jv1 xt02mhb xb4krs4 x1npaq5j x1c83p5e x1enjb0b x199158v xdk7pt x14ju556 x1nn3v0j xg83lxy xg8j3zb x1k2j06m x10l6tqk x1xc55vz xqd3l62 x1orzsq4 xtzzx4i",
                    children: i.jsx(c("CometIcon.react"), {
                        color: "primary",
                        icon: d("fbicon")._(h("701592"), 8)
                    })
                })]
            }) : null]
        })
    }
    g["default"] = a
}), 98);
__d("CometSSRPreloadImageCollection", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = new Set(),
        h = new Set();

    function a(a) {
        g.add(a)
    }

    function b() {
        g.clear()
    }

    function c() {
        if (!g || g.size === 0) return "";
        var a = [];
        g == null ? void 0 : g.forEach(function(b) {
            h.has(b) || (a.push('<link rel="preload" as="image" href="' + b + '" />'), h.add(b))
        });
        return a.join("\n")
    }
    f.addImage = a;
    f.clearImageCollection = b;
    f.imagesToHTMLLinkString = c
}), 66);
__d("CometSSRBackgroundImageUtils", ["CometSSRPreloadImageCollection", "ExecutionEnvironment"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b;
        if (a === null || c("ExecutionEnvironment").canUseDOM) return;
        b = (b = (b = a.spi) != null ? b : a._spi) != null ? b : a.uri;
        if (!b) return;
        d("CometSSRPreloadImageCollection").addImage(b)
    }
    g.processSpritedImagesForSSRPreload = a
}), 98);
__d("InteractionTracingMetricsCore", ["addAnnotations", "performanceNowSinceAppStart"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map(),
        i = new Map(),
        j = new Map(),
        k = {
            string: {},
            "int": {},
            "double": {},
            bool: {},
            string_array: {},
            int_array: {},
            double_array: {},
            bool_array: {}
        },
        l = {
            interactionCount: 0
        };
    a = function() {
        var a = new Map(j),
            b = function(b) {
                a.forEach(function(a) {
                    b(a)
                })
            },
            d = {
                addGlobalMetadata: function(a, b) {
                    if (typeof b === "number") {
                        var e;
                        c("addAnnotations")(k, {
                            "int": (e = {}, e[a] = b, e)
                        })
                    } else if (typeof b === "string") {
                        c("addAnnotations")(k, {
                            string: (e = {}, e[a] = b, e)
                        })
                    } else if (typeof b === "boolean") {
                        c("addAnnotations")(k, {
                            bool: (e = {}, e[a] = b, e)
                        })
                    }
                    d.addMetadata(a, b)
                },
                addMetadata: function(a, d) {
                    b(function(b) {
                        if (typeof d === "number") {
                            var e;
                            c("addAnnotations")(b.annotations, {
                                "int": (e = {}, e[a] = d, e)
                            })
                        } else if (typeof d === "string") {
                            c("addAnnotations")(b.annotations, {
                                string: (e = {}, e[a] = d, e)
                            })
                        } else if (typeof d === "boolean") {
                            c("addAnnotations")(b.annotations, {
                                bool: (e = {}, e[a] = d, e)
                            })
                        }
                    })
                },
                addRequireDeferred: function(a, c) {
                    var d = [];
                    b(function(b) {
                        if (b.requireDeferreds[a] != null) return;
                        b = b.requireDeferreds[a] = {
                            start: c
                        };
                        d.push(b)
                    });
                    return function(a, b) {
                        d.forEach(function(d) {
                            d.end = a, d.duration = a - c, b && (d.alreadyRequired = !0)
                        })
                    }
                },
                forEach: function(a) {
                    b(function(b) {
                        a(b)
                    })
                }
            };
        return d
    };
    var m = {
        addFactoryTiming: function(a, b) {
            a = i.get(a);
            if (!a) return;
            a.factoryTimings.push(b)
        },
        addGlobalMetadata: function(a, b, d) {
            if (typeof d === "number") {
                var e;
                c("addAnnotations")(k, {
                    "int": (e = {}, e[b] = d, e)
                });
                m.addAnnotationInt(a, b, d)
            } else if (typeof d === "string") {
                c("addAnnotations")(k, {
                    string: (e = {}, e[b] = d, e)
                });
                m.addAnnotation(a, b, d)
            } else if (typeof d === "boolean") {
                c("addAnnotations")(k, {
                    bool: (e = {}, e[b] = d, e)
                });
                m.addAnnotationBoolean(a, b, d)
            }
        },
        addHeroBootload: function(a, b) {
            a = i.get(a);
            if (!a) return;
            a.heroBootloads.push(b)
        },
        addHeroRelay: function(a, b) {
            a = i.get(a);
            if (!a) return;
            a.heroRelay.push(b)
        },
        addHiddenTiming: function(a, b) {
            a = i.get(a);
            if (!a) return;
            a.hiddenTimings = b
        },
        addImagePreloader: function(a, b, c) {
            a = i.get(a);
            if (!a) return;
            a.imagePreloaderTimings[b] = c
        },
        addMarkerPoint: function(a, b, d, e, f) {
            e === void 0 && (e = c("performanceNowSinceAppStart")());
            a = i.get(a);
            if (!a) return;
            e >= a.start && (a.markerPoints[b] = {
                timestamp: e,
                type: d
            }, f && (a.markerPoints[b].data = f))
        },
        addFirstMarkerPoint: function(a, b, c, d, e) {
            e === void 0 && (e = {});
            a = i.get(a);
            if (!a) return;
            var f = a.markerPoints[b];
            d >= a.start && (!f || f.timestamp > d) && (a.markerPoints[b] = {
                timestamp: d,
                type: c
            }, e && (a.markerPoints[b].data = e))
        },
        addMetadata: function(a, b, d) {
            a = i.get(a);
            if (!a) return;
            if (typeof d === "number") {
                var e;
                c("addAnnotations")(a.annotations, {
                    "int": (e = {}, e[b] = d, e)
                })
            } else if (typeof d === "string") {
                c("addAnnotations")(a.annotations, {
                    string: (e = {}, e[b] = d, e)
                })
            } else if (typeof d === "boolean") {
                c("addAnnotations")(a.annotations, {
                    bool: (e = {}, e[b] = d, e)
                })
            }
        },
        addAnnotation: function(a, b, d) {
            a = i.get(a);
            if (a) {
                c("addAnnotations")(a.annotations, {
                    string: (a = {}, a[b] = d, a)
                })
            }
        },
        addAnnotationInt: function(a, b, d) {
            a = i.get(a);
            if (a) {
                c("addAnnotations")(a.annotations, {
                    "int": (a = {}, a[b] = d, a)
                })
            }
        },
        addAnnotationDouble: function(a, b, d) {
            a = i.get(a);
            if (a) {
                c("addAnnotations")(a.annotations, {
                    "double": (a = {}, a[b] = d, a)
                })
            }
        },
        addAnnotationBoolean: function(a, b, d) {
            a = i.get(a);
            if (a) {
                c("addAnnotations")(a.annotations, {
                    bool: (a = {}, a[b] = d, a)
                })
            }
        },
        addAnnotationStringArray: function(a, b, d) {
            a = i.get(a);
            if (a) {
                c("addAnnotations")(a.annotations, {
                    string_array: (a = {}, a[b] = d, a)
                })
            }
        },
        addAnnotationIntArray: function(a, b, d) {
            a = i.get(a);
            if (a) {
                c("addAnnotations")(a.annotations, {
                    int_array: (a = {}, a[b] = d, a)
                })
            }
        },
        addAnnotationDoubleArray: function(a, b, d) {
            a = i.get(a);
            if (a) {
                c("addAnnotations")(a.annotations, {
                    double_array: (a = {}, a[b] = d, a)
                })
            }
        },
        addAnnotationBooleanArray: function(a, b, d) {
            a = i.get(a);
            if (a) {
                c("addAnnotations")(a.annotations, {
                    bool_array: (a = {}, a[b] = d, a)
                })
            }
        },
        addOfflineTiming: function(a, b) {
            a = i.get(a);
            if (!a) return;
            a.offlineTimings = b
        },
        addPayloadResource: function(a, b, c) {
            a = i.get(a);
            if (!a) return;
            a.payloadResources[b] = c
        },
        addPayloadTiming: function(a, b, c) {
            a = i.get(a);
            if (!a) return;
            a.payloadTimings[b] = c
        },
        addReactRender: function(a, b, c, d, e, f, g) {
            a = i.get(a);
            if (!a) return;
            e = {
                actualDuration: e,
                baseDuration: f,
                duration: d - c,
                end: d,
                phase: g,
                start: c
            };
            a.reactRender[b] ? a.reactRender[b].push(e) : a.reactRender[b] = [e];
            a.commitSet.add(d)
        },
        addSubspan: function(a, b, c, d, e, f) {
            a = i.get(a);
            if (!a) return;
            f = {
                data: f,
                end: e,
                start: d,
                type: c
            };
            a.subSpans[b] ? a.subSpans[b].push(f) : a.subSpans[b] = [f]
        },
        addMountPoint: function(a, b, c) {
            c = "Mount_" + c;
            m.addFirstMarkerPoint(a, c, "VisualCompletion", b)
        },
        addMountPointMetadata: function(a, b, c) {
            a = m.get(a);
            b = "Mount_" + b;
            a = a == null ? void 0 : a.markerPoints[b];
            if (a) {
                var d = a.data || {};
                a.data = d;
                Object.keys(c).forEach(function(a) {
                    d[a] = c[a]
                })
            }
        },
        addTag: function(a, b, c) {
            a = i.get(a);
            if (!a) return;
            a.tagSet[b] || (a.tagSet[b] = new Set());
            a.tagSet[b].add(c)
        },
        addTracedInteraction: function(a, b, c) {
            b = {
                annotations: {
                    string: {},
                    "int": {},
                    "double": {},
                    bool: {},
                    string_array: {},
                    int_array: {},
                    double_array: {},
                    bool_array: {}
                },
                commitSet: new Set(),
                factoryTimings: [],
                hasVcReport: !1,
                heroBootloads: [],
                heroRelay: [],
                hiddenTimings: [],
                imagePreloaderTimings: {},
                lateMutationIgnoreElements: new Set(),
                markerPoints: {},
                navigationTiming: {},
                offlineTimings: [],
                payloadResources: {},
                payloadTimings: {},
                reactRender: {},
                requireDeferreds: {},
                start: b,
                subSpans: {},
                tagSet: {},
                traceId: a,
                vcStateLog: null,
                wasCanceled: !1,
                wasOffline: !1
            };
            for (var d in k)
                for (var e in k[d]) b.annotations[d][e] = k[d][e];
            i.set(a, b);
            j.set(a, b);
            h.set(a, c);
            l.interactionCount++;
            return b
        },
        complete: function(a) {
            var b = i.get(a);
            if (b && b.completed == null) {
                c("addAnnotations")(b.annotations, {
                    "int": {
                        endedByHeroComplete: 1
                    }
                });
                b.completed = c("performanceNowSinceAppStart")();
                var d = h.get(a);
                d && d(b);
                h["delete"](a);
                j["delete"](a)
            }
        },
        currentInteractionLogger: a,
        dump: function() {
            var a = {};
            i.forEach(function(b, c) {
                a[c] = babelHelpers["extends"]({}, b, {
                    e2e: b.completed != null ? ((b.completed - b.start) / 1e3).toFixed(2) : "?"
                })
            });
            return a
        },
        get: function(a) {
            return i.get(a)
        },
        removeMarkerPoint: function(a, b) {
            a = i.get(a);
            a && delete a.markerPoints[b]
        },
        setInteractionClass: function(a, b) {
            a = i.get(a);
            a && (a.interactionClass = b)
        },
        setInteractionType: function(a, b, c, d) {
            a = i.get(a);
            a && (a.interactionClass = b, a.type = c, a.qplEvent = d)
        },
        "delete": function(a) {
            i["delete"](a)
        },
        getInteractionStat: function() {
            return l
        }
    };
    b = m;
    g["default"] = b
}), 98);
__d("interaction-tracing-metrics", ["InteractionTracingMetricsCore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g.InteractionTracingMetricsCore = c("InteractionTracingMetricsCore")
}), 98);
__d("InteractionTracingMetrics", ["interaction-tracing-metrics"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("interaction-tracing-metrics").InteractionTracingMetricsCore
}), 98);
__d("useHeroErrorMetadata", ["InteractionTracingMetrics", "QPLEvent", "fb-error", "hero-tracing-placeholder", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useContext;

    function a() {
        var a = i(d("hero-tracing-placeholder").HeroCurrentInteractionForLoggingContext),
            b = i(d("hero-tracing-placeholder").HeroInteractionContext.Context),
            e = b.pageletStack;
        return h(function(b) {
            var f;
            f = (f = b.metadata) != null ? f : new(c("fb-error").ErrorMetadata)();
            b.metadata = f;
            b = (b = a.current) == null ? void 0 : b.interactionUUID;
            if (b != null) {
                b = c("InteractionTracingMetrics").get(b);
                e != null && f.addEntry("COMET_INFRA", "INTERACTION_PAGELET_STACK", e.join(","));
                b != null && b.qplAction == null && (b.qplEvent != null && f.addEntry("COMET_INFRA", "INTERACTION_QPL_EVENT", String(d("QPLEvent").getMarkerId(b.qplEvent))), b.tracePolicy != null && f.addEntry("COMET_INFRA", "INTERACTION_TRACE_POLICY", b.tracePolicy))
            }
        }, [a, e])
    }
    g["default"] = a
}), 98);
__d("CometErrorBoundary.react", ["ErrorBoundary.react", "react", "useHeroErrorMetadata"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react").forwardRef;

    function a(a, b) {
        var d = c("useHeroErrorMetadata")();
        return h.jsx(c("ErrorBoundary.react"), babelHelpers["extends"]({}, a, {
            augmentError: d,
            fallback: a.fallback,
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = b(a);
    g["default"] = e
}), 98);
__d("RecoverableViolationWithComponentStack.react", ["CometErrorBoundary.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function i(a) {
        a = a.errorMessage;
        throw new Error(a)
    }

    function a(a) {
        var b = a.errorMessage,
            d = a.fallback;
        a = a.projectName;
        return h.jsx(c("CometErrorBoundary.react"), {
            context: {
                project: a,
                type: "error"
            },
            fallback: function() {
                var a;
                return (a = d) != null ? a : null
            },
            children: h.jsx(i, {
                errorMessage: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseImage_DEPRECATED.react", ["CometSSRBackgroundImageUtils", "CometVisualCompletionAttributes", "RecoverableViolationWithComponentStack.react", "coerceImageishSprited", "coerceImageishURL", "cr:2010754", "gkx", "joinClasses", "mergeRefs", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useEffect,
        j = e.useMemo,
        k = e.useRef,
        l = "2";

    function m(a) {
        return a != null && typeof a === "string" && a !== "" && a !== "[object Object]"
    }

    function a(a, e) {
        var f = a.alt,
            g = a.testid,
            n = babelHelpers.objectWithoutPropertiesLoose(a, ["alt", "testid"]),
            o = n.onLoad;
        g = n.src;
        var p = k(null);
        a = j(function() {
            return c("mergeRefs")(p, e)
        }, [p, e]);
        d("CometSSRBackgroundImageUtils").processSpritedImagesForSSRPreload(g);
        var q = c("coerceImageishSprited")(g),
            r = c("coerceImageishURL")(g);
        i(function() {
            var a;
            o != null && p.current instanceof HTMLImageElement && ((a = p.current) == null ? void 0 : a.complete) && o()
        }, [o, g]);
        if (r != null && r.uri != null) {
            return !m(r.uri) ? h.jsx(c("RecoverableViolationWithComponentStack.react"), {
                errorMessage: "Invalid src provided as imageish uri",
                projectName: "comet_ui"
            }) : h.jsx("img", babelHelpers["extends"]({}, n, {
                alt: (g = f) != null ? g : "",
                "data-testid": void 0,
                height: n.height != null ? n.height : r.height,
                ref: a,
                src: r.uri,
                width: n.width != null ? n.width : r.width
            }))
        } else if (q != null) {
            n.height;
            n.src;
            g = n.style;
            n.width;
            r = babelHelpers.objectWithoutPropertiesLoose(n, ["height", "src", "style", "width"]);
            return h.jsx("i", babelHelpers["extends"]({}, c("CometVisualCompletionAttributes").CSS_IMG, r, {
                "aria-label": f === "" ? null : f,
                className: c("joinClasses")(n.className, q.type === "css" ? q.className : void 0),
                "data-testid": void 0,
                ref: a,
                role: f === "" ? null : "img",
                style: q.type === "cssless" ? babelHelpers["extends"]({}, g, q.style) : g
            }))
        }
        if (!m(n.src)) return h.jsx(c("RecoverableViolationWithComponentStack.react"), {
            errorMessage: "Invalid src provided to image",
            projectName: "comet_ui"
        });
        r = c("gkx")("1690028") ? l : void 0;

        function s(a, c, d, e, f, g) {
            b("cr:2010754") && c === "mount" && p.current != null && b("cr:2010754").trackImagePerf(p.current, g, typeof n.src === "string" ? n.src : "", {
                mutationType: "reactCommit"
            })
        }
        g = h.jsx("img", babelHelpers["extends"]({}, n, {
            alt: (q = f) != null ? q : "",
            "data-testid": void 0,
            elementtiming: r,
            ref: a
        }));
        return c("gkx")("1690028") ? h.jsx(h.Profiler, {
            id: l,
            onRender: s,
            children: g
        }) : g
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("useCometUniqueID", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useId;

    function a() {
        return h()
    }
    g["default"] = a
}), 98);
__d("CometSVGIcon.react", ["react", "stylex", "useCometUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            icon: {
                display: "x1lliihq",
                transitionDuration: "x1k90msu",
                transitionProperty: "x2h7rmj",
                transitionTimingFunction: "x1qfuztq",
                $$css: !0
            },
            inline: {
                display: "x1rg5ohu",
                $$css: !0
            },
            shadow: {
                filter: "x1ssd25i",
                $$css: !0
            }
        },
        j = {
            8: {
                height: "xdk7pt",
                width: "x1xc55vz",
                $$css: !0
            },
            10: {
                height: "x170jfvy",
                width: "x1fsd2vl",
                $$css: !0
            },
            12: {
                height: "x1kpxq89",
                width: "xsmyaan",
                $$css: !0
            },
            16: {
                height: "xlup9mm",
                width: "x1kky2od",
                $$css: !0
            },
            18: {
                height: "xmix8c7",
                width: "x1xp8n7a",
                $$css: !0
            },
            20: {
                height: "x1qx5ct2",
                width: "xw4jnvo",
                $$css: !0
            },
            24: {
                height: "xxk0z11",
                width: "xvy4d1p",
                $$css: !0
            },
            28: {
                height: "x1fgtraw",
                width: "xgd8bvy",
                $$css: !0
            },
            30: {
                height: "x1gnnpzl",
                width: "x1849jeq",
                $$css: !0
            },
            32: {
                height: "x10w6t97",
                width: "x1td3qas",
                $$css: !0
            },
            36: {
                height: "xc9qbxq",
                width: "x14qfxbe",
                $$css: !0
            },
            40: {
                height: "x1vqgdyp",
                width: "x100vrsf",
                $$css: !0
            },
            48: {
                height: "xsdox4t",
                width: "x1useyqa",
                $$css: !0
            },
            52: {
                height: "xdd8jsf",
                width: "xvni27",
                $$css: !0
            },
            56: {
                height: "xnnlda6",
                width: "x15yg21f",
                $$css: !0
            },
            60: {
                height: "xng8ra",
                width: "x1247r65",
                $$css: !0
            },
            72: {
                height: "xy75621",
                width: "xni59qk",
                $$css: !0
            },
            112: {
                height: "x19swzb4",
                width: "xj35x94",
                $$css: !0
            },
            132: {
                height: "x1h5wmu3",
                width: "x16s0kzc",
                $$css: !0
            }
        },
        k = {
            "active-tab": {
                color: "x5e5rjt",
                $$css: !0
            },
            baseCherry: {
                color: "xmw33a7",
                $$css: !0
            },
            baseLemon: {
                color: "xedzdh8",
                $$css: !0
            },
            baseLime: {
                color: "xdb1l0v",
                $$css: !0
            },
            black: {
                color: "x1p6odiv",
                $$css: !0
            },
            blueLink: {
                color: "x1fey0fg",
                $$css: !0
            },
            disabled: {
                color: "x1eu2eya",
                $$css: !0
            },
            "fb-logo": {
                color: "xig6vdn",
                $$css: !0
            },
            highlight: {
                color: "x1qq9wsj",
                $$css: !0
            },
            "inactive-tab": {
                color: "xcza8v6",
                $$css: !0
            },
            negative: {
                color: "x1a1m0xk",
                $$css: !0
            },
            none: {
                color: "x19co3pv",
                $$css: !0
            },
            positive: {
                color: "x6u5lvz",
                $$css: !0
            },
            primary: {
                color: "x198g3q0",
                $$css: !0
            },
            "rating-star-active": {
                color: "x1n8qakd",
                $$css: !0
            },
            secondary: {
                color: "xcza8v6",
                $$css: !0
            },
            tertiary: {
                color: "xfuq9xy",
                $$css: !0
            },
            warning: {
                color: "xcly8g5",
                $$css: !0
            },
            white: {
                color: "x14ctfv",
                $$css: !0
            },
            "work-iris": {
                color: "xx4snyb",
                $$css: !0
            }
        };

    function a(a) {
        var b = c("useCometUniqueID")();
        if (a.viewBox === void 0) {
            var d = a.alt,
                e = a.color,
                f = a.component,
                g = a.inline;
            g = g === void 0 ? !1 : g;
            var l = a.shadow;
            l = l === void 0 ? !1 : l;
            var m = a.size;
            f = f;
            return h.jsx(f, {
                className: c("stylex")([i.icon, g && i.inline, l && i.shadow, k[e], j[m]]),
                title: d == null || d === "" ? void 0 : d
            })
        } else {
            f = a.children;
            g = a.color;
            l = a.inline;
            e = l === void 0 ? !1 : l;
            m = a.shadow;
            d = m === void 0 ? !1 : m;
            l = a.size;
            m = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "color", "inline", "shadow", "size"]);
            a = [];
            var n;
            g != null && typeof g !== "string" && h.isValidElement(g) && (a.push(h.cloneElement(g, {
                id: b,
                key: "1",
                suppressHydrationWarning: !0
            })), n = "url(#" + b + ")");
            return h.jsxs("svg", babelHelpers["extends"]({}, m, {
                className: c("stylex")([i.icon, e && i.inline, d && i.shadow, typeof g === "string" && k[g]]),
                fill: (b = n) != null ? b : "currentColor",
                height: l,
                suppressHydrationWarning: !0,
                width: l,
                children: [a.length > 0 ? h.jsx("defs", {
                    children: a
                }) : void 0, f]
            }))
        }
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTintedIcon.react", ["BaseImage_DEPRECATED.react", "TintableIconSource", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            image: {
                verticalAlign: "x1b0d499",
                $$css: !0
            }
        },
        j = {
            accent: {
                filter: "xi3auck",
                $$css: !0
            },
            blueLink: {
                filter: "x1vv9jnp",
                $$css: !0
            },
            disabled: {
                filter: "xmgbrsx",
                $$css: !0
            },
            negative: {
                filter: "x1d2xfc3",
                $$css: !0
            },
            placeholder: {
                filter: "xuo83w3",
                $$css: !0
            },
            positive: {
                filter: "x1hq76kk",
                $$css: !0
            },
            primary: {
                filter: "xep6ejk",
                $$css: !0
            },
            secondary: {
                filter: "x1d69dk1",
                $$css: !0
            },
            warning: {
                filter: "xgzi2j0",
                $$css: !0
            },
            white: {
                filter: "xaj1gnb",
                $$css: !0
            }
        };

    function a(a, b) {
        var d = a.alt;
        d = d === void 0 ? "" : d;
        var e = a.color;
        e = e === void 0 ? "black" : e;
        var f = a.draggable,
            g = a.icon,
            k = a.testid;
        k = a.xstyle;
        a = g instanceof c("TintableIconSource");
        return h.jsx(c("BaseImage_DEPRECATED.react"), {
            alt: d,
            className: c("stylex")(i.image, a && e !== "black" && j[e], k),
            draggable: f,
            ref: b,
            src: g.src,
            testid: void 0
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    b.name = "CometTintedIcon";
    e = b;
    g["default"] = e
}), 98);
__d("ImageIconSource", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a, b, c, d) {
        d === void 0 && (d = "cover"), this.$$typeof = "fb.imageiconsource", this.src = a, this.width = b, this.height = c, this.resizeStrategy = d
    };
    f["default"] = a
}), 66);
__d("FlightSerializableIcon", ["IconSource", "ImageIconSource", "TintableIconSource"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (typeof a === "object" && typeof a !== "function" && a != null && (a.flight_icon_type === "TintableIconSource" || a.$$typeof === "fb.tintableiconsource")) {
            var b = a;
            return new(c("TintableIconSource"))(b.domain, b.src, b.size)
        }
        if (typeof a === "object" && typeof a !== "function" && a != null && (a.flight_icon_type === "IconSource" || a.$$typeof === "fb.iconsource")) {
            b = a;
            return new(c("IconSource"))(b.domain, b.src, b.size)
        }
        if (typeof a === "object" && typeof a !== "function" && a != null && (a.flight_icon_type === "ImageIconSource" || a.$$typeof === "fb.imageiconsource")) {
            b = a;
            return new(c("ImageIconSource"))(b.src, b.width, b.height, b.resizeStrategy)
        }
        return a
    }
    g.parseFlightIcon = a
}), 98);
__d("SVGIcon", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = function(a) {
        this.component = a
    };

    function a(a) {
        return new g(a)
    }
    c = function(a) {
        this.codepoints = a
    };
    var h = function(a) {
        this.component = a
    };

    function b(a) {
        return new h(a)
    }
    f.SVGIcon = g;
    f.svgIcon = a;
    f.EmojiIcon = c;
    f.LegacySVGIcon = h;
    f.legacySVGIcon = b
}), 66);
__d("CometIcon.react", ["BaseImage_DEPRECATED.react", "CometPressable.react", "CometSVGIcon.react", "CometTintedIcon.react", "FlightSerializableIcon", "IconSource", "ImageIconSource", "SVGIcon", "TintableIconSource", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            button: {
                appearance: "xjyslct",
                backgroundColor: "xjbqb8w",
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                display: "x3nfvp2",
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                position: "x1n2onr6",
                verticalAlign: "x3ajldb",
                "::after_borderTopStartRadius": "x194ut8o",
                "::after_borderTopEndRadius": "x1vzenxt",
                "::after_borderBottomEndRadius": "xd7ygy7",
                "::after_borderBottomStartRadius": "xt298gk",
                "::after_bottom": "x1xhcax0",
                "::after_content": "x1s928wv",
                "::after_end": "x10pfhc2",
                "::after_position": "x1j6awrg",
                "::after_start": "x1v53gu8",
                "::after_top": "x1tfg27r",
                "::after_zIndex": "xitxdhh",
                $$css: !0
            },
            image: {
                verticalAlign: "x1b0d499",
                $$css: !0
            },
            imageContain: {
                objectFit: "xz74otr",
                $$css: !0
            },
            imageCover: {
                objectFit: "xl1xv1r",
                $$css: !0
            },
            pressed: {
                transform: "x1n5d1j9",
                $$css: !0
            }
        };

    function a(a, b) {
        var e = a.alt;
        e = e === void 0 ? "" : e;
        var f = a.color;
        f = f === void 0 ? "primary" : f;
        var g = a.disabled;
        g = g === void 0 ? !1 : g;
        var k = a.disableOverlay_DEPRECATED;
        k = k === void 0 ? !1 : k;
        a.draggable;
        var l = a.focusable,
            m = a.hideHoverOverlay;
        m = m === void 0 ? !1 : m;
        var n = a.icon,
            o = a.linkProps,
            p = a.onHoverIn,
            q = a.onHoverOut,
            r = a.onPress,
            s = a.onPressIn,
            t = a.onPressOut,
            u = a.size;
        u = u === void 0 ? 8 : u;
        var v = a.testid,
            w = a.testOnly_pressed;
        w = w === void 0 ? !1 : w;
        var x = a.xstyle,
            y = babelHelpers.objectWithoutPropertiesLoose(a, ["alt", "color", "disabled", "disableOverlay_DEPRECATED", "draggable", "focusable", "hideHoverOverlay", "icon", "linkProps", "onHoverIn", "onHoverOut", "onPress", "onPressIn", "onPressOut", "size", "testid", "testOnly_pressed", "xstyle"]);
        n = d("FlightSerializableIcon").parseFlightIcon(n);
        v = r == null ? v : void 0;
        f = a.disabled === !0 ? "disabled" : f;
        var z = r != null || o != null;
        e = !z && y["aria-label"] || e;
        var A = z ? void 0 : b;
        x = n instanceof c("TintableIconSource") ? h.jsx(c("CometTintedIcon.react"), {
            alt: e,
            color: j(f),
            draggable: a.draggable,
            icon: n,
            ref: A,
            testid: void 0,
            xstyle: x
        }) : n instanceof c("ImageIconSource") ? h.jsx(c("BaseImage_DEPRECATED.react"), {
            alt: e,
            className: c("stylex")(i.image, n.resizeStrategy === "contain" && i.imageContain, n.resizeStrategy === "cover" && i.imageCover, x),
            draggable: a.draggable,
            ref: A,
            src: n.src,
            style: {
                height: n.height,
                width: n.width
            },
            testid: void 0
        }) : n instanceof c("IconSource") ? h.jsx(c("BaseImage_DEPRECATED.react"), {
            alt: e,
            className: c("stylex")(i.image, x),
            draggable: a.draggable,
            height: n.size,
            ref: A,
            src: n.src,
            width: n.size
        }) : n instanceof d("SVGIcon").LegacySVGIcon ? h.createElement(n.component, {
            alt: e,
            color: f,
            "data-testid": v,
            size: u
        }) : n instanceof d("SVGIcon").SVGIcon ? h.jsx(c("CometSVGIcon.react"), {
            alt: e,
            color: f,
            component: n.component,
            "data-testid": void 0,
            size: u
        }) : h.jsx(c("CometSVGIcon.react"), {
            alt: e,
            color: f,
            component: n,
            "data-testid": void 0,
            size: u
        });
        return z ? h.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, y, {
            disabled: g,
            focusable: l,
            hideHoverOverlay: m,
            linkProps: o,
            onHoverIn: p,
            onHoverOut: q,
            onPress: r,
            onPressIn: s,
            onPressOut: t,
            overlayDisabled: k,
            overlayOffset: 8,
            overlayRadius: "50%",
            ref: b,
            testOnly_pressed: w,
            testid: void 0,
            xstyle: function(a) {
                a = a.pressed;
                return [i.button, a && i.pressed]
            },
            children: x
        })) : x
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function j(a) {
        switch (a) {
            case "positive":
                return "positive";
            case "negative":
                return "negative";
            case "disabled":
                return "disabled";
            case "highlight":
                return "accent";
            case "secondary":
                return "secondary";
            case "tertiary":
                return "placeholder";
            case "white":
                return "white";
            case "primary":
                return "primary";
            case "warning":
                return "warning";
            case "blueLink":
                return "blueLink";
            default:
                return "black"
        }
    }
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseButtonPopoverContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = null;
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("ReactContextMenuEvent.react", ["ReactEventHookPropagation", "ReactUseEvent.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useEffect;

    function a(a, b) {
        var e = b.disabled,
            f = b.onContextMenu,
            g = b.preventDefault,
            i = c("ReactUseEvent.react")("contextmenu");
        h(function() {
            var b = a.current;
            b !== null && i.setListener(b, function(a) {
                if (e === !0) return;
                if (d("ReactEventHookPropagation").hasEventHookPropagationStopped(a, "useContextMenu")) return;
                d("ReactEventHookPropagation").stopEventHookPropagation(a, "useContextMenu");
                g !== !1 && !a.nativeEvent.defaultPrevented && a.preventDefault();
                f && f(a)
            })
        }, [e, a, i, g, f])
    }
    g.useContextMenu = a
}), 98);
__d("ReactHoverEvent.react", ["ReactEventHelpers", "ReactEventHookPropagation", "ReactUseEvent.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef;

    function j(a, b, c) {
        return {
            clientX: b.clientX,
            clientY: b.clientY,
            pageX: b.pageX,
            pageY: b.pageY,
            screenX: b.screenX,
            screenY: b.screenY,
            target: c,
            timeStamp: b.timeStamp,
            type: a,
            x: b.clientX,
            y: b.clientY
        }
    }
    var k = {
        passive: !0
    };

    function l(a, b) {
        b = b;
        while (b != null) {
            if (b === a) return !0;
            if (b._hoverEventTarget) return !1;
            b = b.parentNode
        }
        return !1
    }

    function a(a, b) {
        var e = b.disabled,
            f = b.onHoverStart,
            g = b.onHoverMove,
            m = b.onHoverEnd,
            n = b.onHoverChange,
            o = c("ReactUseEvent.react")("touchstart", k),
            p = c("ReactUseEvent.react")("mouseover", k),
            q = c("ReactUseEvent.react")("mouseout", k),
            r = c("ReactUseEvent.react")("mousemove", k),
            s = c("ReactUseEvent.react")("pointerover", k),
            t = c("ReactUseEvent.react")("pointerout", k),
            u = c("ReactUseEvent.react")("pointermove", k),
            v = c("ReactUseEvent.react")("pointercancel", k),
            w = i({
                isHovered: !1,
                isTouched: !1
            });
        h(function() {
            var b = a.current,
                c = w.current;
            if (b !== null && c !== null) {
                b._hoverEventTarget = !0;
                var h = document,
                    i = function(a) {
                        if (e === !0) {
                            y(a);
                            return
                        }
                        if (d("ReactEventHookPropagation").hasEventHookPropagationStopped(a, "useHover")) return;
                        d("ReactEventHookPropagation").stopEventHookPropagation(a, "useHover");
                        !c.isHovered && !l(b, a.relatedTarget) && (c.isHovered = !0, f && f(j("hoverstart", a, b)), n && n(!0), d("ReactEventHelpers").hasPointerEvents ? (u.setListener(h, x), v.setListener(h, y), t.setListener(h, k)) : q.setListener(h, k))
                    },
                    k = function(a) {
                        c.isHovered && !l(b, a.relatedTarget) && (c.isHovered = !1, m && m(j("hoverend", a, b)), n && n(!1), y(a))
                    },
                    x = function(a) {
                        c.isTouched = !1;
                        if (e === !0) {
                            y(a);
                            return
                        }
                        c.isHovered && (g && g(j("hovermove", a, b)))
                    },
                    y = function(a) {
                        c.isTouched = !1, d("ReactEventHelpers").hasPointerEvents ? (u.setListener(h, null), v.setListener(h, null), t.setListener(h, null)) : q.setListener(h, null), k(a)
                    };
                d("ReactEventHelpers").hasPointerEvents ? s.setListener(b, function(a) {
                    a.pointerType !== "touch" && i(a)
                }) : (p.setListener(b, function(a) {
                    c.isTouched || i(a)
                }), o.setListener(b, function() {
                    c.isTouched = !0
                }), r.setListener(h, x));
                c.isHovered && (d("ReactEventHelpers").hasPointerEvents ? (u.setListener(h, x), v.setListener(h, y), t.setListener(h, k)) : q.setListener(h, k))
            }
        }, [e, n, m, g, f, v, u, t, s, r, q, p, a, o])
    }
    g.useHover = a
}), 98);
__d("ReactPressEvent.react", ["ReactEventHelpers", "ReactEventHookPropagation", "ReactUseEvent.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef,
        j = {
            passive: !0
        };

    function k(a, b, c, d, e) {
        var f = {
            altKey: d.altKey,
            buttons: b,
            clientX: d.clientX,
            clientY: d.clientY,
            ctrlKey: d.ctrlKey,
            defaultPrevented: d.defaultPrevented,
            metaKey: d.metaKey,
            pageX: d.pageX,
            pageY: d.pageY,
            pointerType: c,
            screenX: d.screenX,
            screenY: d.screenY,
            shiftKey: d.shiftKey,
            target: e,
            timeStamp: d.timeStamp,
            type: a,
            x: d.clientX,
            y: d.clientY,
            preventDefault: function() {
                f.defaultPrevented = !0, d.preventDefault()
            },
            stopPropagation: function() {
                d.stopPropagation()
            }
        };
        return f
    }

    function a(a, b) {
        var e = b.disabled,
            f = b.onPressStart,
            g = b.onPressMove,
            l = b.onPressEnd,
            m = b.onPressChange,
            n = i({
                isPressed: !1,
                isPressActive: !1,
                pointerId: null,
                bounds: null,
                pointerType: "",
                buttons: 0,
                activationEvent: null
            }),
            o = c("ReactUseEvent.react")("pointerdown"),
            p = c("ReactUseEvent.react")("pointermove", j),
            q = c("ReactUseEvent.react")("pointerup", j),
            r = c("ReactUseEvent.react")("pointercancel", j),
            s = c("ReactUseEvent.react")("mousedown"),
            t = c("ReactUseEvent.react")("mouseup", j),
            u = c("ReactUseEvent.react")("mousemove", j),
            v = c("ReactUseEvent.react")("dragstart", j),
            w = c("ReactUseEvent.react")("focusout", j);
        h(function() {
            var b = a.current,
                c = n.current;
            if (b !== null) {
                var h = document,
                    i = function(a) {
                        if (e === !0) {
                            y(a);
                            return
                        }
                        if (d("ReactEventHookPropagation").hasEventHookPropagationStopped(a, "usePress")) return;
                        d("ReactEventHookPropagation").stopEventHookPropagation(a, "usePress");
                        if (a.buttons === 2 || a.buttons > 4 || d("ReactEventHelpers").isMac && a.pointerType === "mouse" && a.ctrlKey) return;
                        c.buttons = a.buttons;
                        a.button === 1 && (c.buttons = 4);
                        j(a)
                    },
                    j = function(a) {
                        if (!c.isPressed) {
                            var e = a,
                                g = e.pointerId;
                            e = e.pointerType || "mouse";
                            c.isPressed = !0;
                            c.isPressActive = !0;
                            c.pointerId = g !== void 0 ? g : null;
                            c.pointerType = e;
                            c.activationEvent = a;
                            e !== "mouse" && (c.bounds = b.getBoundingClientRect());
                            f && f(k("pressstart", c.buttons, e, a, b));
                            m && m(!0);
                            d("ReactEventHelpers").hasPointerEvents ? (q.setListener(h, y), p.setListener(h, z), r.setListener(h, y)) : (u.setListener(h, z), t.setListener(h, y), v.setListener(h, y))
                        }
                    },
                    x = function(a) {
                        c.isPressed && (c.isPressed = !1, l && l(k("pressend", c.buttons, c.pointerType, a, b)), m && m(!1))
                    },
                    y = function(a) {
                        c.isPressActive = !1, c.bounds = null, c.activationEvent = null, x(a), d("ReactEventHelpers").hasPointerEvents ? (q.setListener(h, null), p.setListener(h, null), r.setListener(h, null)) : (u.setListener(h, null), t.setListener(h, null), v.setListener(h, null))
                    },
                    z = function(a) {
                        if (e === !0) {
                            y(a);
                            return
                        }
                        if (!c.isPressActive) return;
                        var d = c.pointerType,
                            f = c.isPressed,
                            h = !1;
                        if (d === "mouse") {
                            var i = a.target;
                            h = b.contains(i)
                        } else {
                            i = a;
                            i = i.pointerId;
                            var l = c.bounds;
                            if (i !== c.pointerId || l === null) return;
                            i = a.clientX;
                            var m = a.clientY,
                                n = l.top,
                                o = l.left,
                                p = l.right;
                            l = l.bottom;
                            i >= o && i <= p && m >= n && m <= l && (h = !0)
                        }
                        h ? f ? g && g(k("pressmove", c.buttons, d, a, b)) : j(a) : f && x(a)
                    };
                d("ReactEventHelpers").hasPointerEvents ? o.setListener(b, i) : s.setListener(b, i);
                w.setListener(b, function(a) {
                    var d = c.activationEvent;
                    a.target === b && d !== null && y(d)
                });
                c.isPressActive && (d("ReactEventHelpers").hasPointerEvents ? (q.setListener(h, y), p.setListener(h, z), r.setListener(h, y)) : (u.setListener(h, z), t.setListener(h, y), v.setListener(h, y)));
                return function() {
                    var b = c.activationEvent;
                    a.current === null && b !== null && y(b)
                }
            }
        }, [e, v, w, s, u, t, m, l, g, f, r, o, p, q, a])
    }
    g.usePress = a
}), 98);
__d("Pressability", ["ReactContextMenuEvent.react", "ReactFocusEvent.react", "ReactHoverEvent.react", "ReactPressEvent.react"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var c = b.disabled,
            e = b.onBlur,
            f = b.onContextMenu,
            g = b.onFocus,
            h = b.onFocusChange,
            i = b.onFocusVisibleChange,
            j = b.onHoverChange,
            k = b.onHoverEnd,
            l = b.onHoverMove,
            m = b.onHoverStart,
            n = b.onPressChange,
            o = b.onPressEnd,
            p = b.onPressMove,
            q = b.onPressStart;
        b = b.preventContextMenu;
        d("ReactHoverEvent.react").useHover(a, {
            disabled: c,
            onHoverChange: j,
            onHoverEnd: k,
            onHoverMove: l,
            onHoverStart: m
        });
        d("ReactPressEvent.react").usePress(a, {
            disabled: c,
            onPressChange: n,
            onPressEnd: o,
            onPressMove: p,
            onPressStart: q
        });
        d("ReactFocusEvent.react").useFocus(a, {
            disabled: c,
            onBlur: e,
            onFocus: g,
            onFocusChange: h,
            onFocusVisibleChange: i
        });
        d("ReactContextMenuEvent.react").useContextMenu(a, {
            disabled: c,
            onContextMenu: f,
            preventDefault: b || !1
        })
    }
    g.usePressability = a
}), 98);
__d("PressableGroupContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(void 0);
    g["default"] = b
}), 98);
__d("Pressable.react", ["Pressability", "PressableGroupContext", "UserAgent", "gkx", "joinClasses", "justknobx", "passiveEventListenerUtil", "react", "recoverableViolation", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useEffect,
        l = b.useRef,
        m = b.useState,
        n = c("UserAgent").isBrowser("Safari") || c("UserAgent").isBrowser("Mobile Safari"),
        o = ["menuitem", "tab", "none"],
        p = {
            article: "article",
            banner: "header",
            complementary: "aside",
            contentinfo: "footer",
            figure: "figure",
            form: "form",
            heading: "h1",
            label: "label",
            link: "a",
            list: "ul",
            listitem: "li",
            main: "main",
            navigation: "nav",
            none: "div",
            region: "section"
        };

    function q(a, b) {
        var c = "div";
        if (o.includes(a) && b != null && b.url != null) c = "a";
        else if (a != null) {
            b = p[a];
            b != null && (c = b)
        }
        return c
    }

    function r(a) {
        switch (a) {
            case "none":
                return "presentation";
            case "label":
                return void 0;
            default:
                return a
        }
    }
    var s = function(a) {
        var b = a.target,
            c = b.tagName;
        c = b.isContentEditable || c === "A" && b.href != null || c === "BUTTON" || c === "INPUT" || c === "SELECT" || c === "TEXTAREA";
        if (b.tabIndex === 0 && !c) {
            c = a.key;
            if (c === "Enter") return !0;
            a = b.getAttribute("role");
            if ((c === " " || c === "Spacebar") && (a === "button" || a === "checkbox" || a === "combobox" || a === "menuitem" || a === "menuitemcheckbox" || a === "menuitemradio" || a === "option" || a === "radio" || a === "switch" || a === "tab")) return !0
        }
        return !1
    };

    function t(a) {
        return typeof document !== "undefined" && typeof document.contains === "function" ? document.contains(a) : !1
    }

    function u(a) {
        a = a;
        while (a != null) {
            if (a.tagName === "A" && a.href != null) return !0;
            a = a.parentNode
        }
        return !1
    }

    function v(a, b) {
        var d = a.altKey,
            e = a.ctrlKey,
            f = a.currentTarget,
            g = a.metaKey,
            h = a.shiftKey;
        a = a.target;
        var i = a;
        c("justknobx")._("450") && (i = t(a) ? a : f);
        a = u(i);
        f = d || e || g || h;
        return b !== !1 && a && !f
    }

    function a(a) {
        var b = l(null),
            e = m(!1),
            f = e[0];
        e = e[1];
        var g = m(!1),
            o = g[0];
        g = g[1];
        var p = m(!1),
            u = p[0];
        p = p[1];
        var y = m(!1),
            z = y[0];
        y = y[1];
        var A = j(c("PressableGroupContext")),
            B = a.accessibilityLabel,
            C = a.accessibilityRelationship,
            D = a.accessibilityRole,
            E = a.accessibilityState,
            F = a.accessibilityValue,
            G = a.allowClickEventPropagation,
            H = G === void 0 ? !1 : G;
        G = a.children;
        var I = a.className_DEPRECATED,
            J = a.disabled,
            K = a.forwardedRef,
            L = a.link,
            M = a.nativeID,
            N = a.onBlur,
            O = a.onContextMenu,
            aa = a.onFocus,
            ba = a.onFocusChange,
            ca = a.onFocusVisibleChange,
            da = a.onHoverChange,
            ea = a.onHoverEnd,
            fa = a.onHoverMove,
            ga = a.onHoverStart,
            P = a.onKeyDown,
            Q = a.onPress,
            ha = a.onPressChange,
            ia = a.onPressEnd,
            ja = a.onPressMove,
            ka = a.onPressStart,
            la = a.preventContextMenu,
            R = a.preventDefault,
            S = a.style,
            T = a.suppressFocusRing;
        T = T === void 0 ? !1 : T;
        var U = a.tabbable,
            V = a.testID;
        V = a.testOnly_state;
        var W = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["accessibilityLabel", "accessibilityRelationship", "accessibilityRole", "accessibilityState", "accessibilityValue", "allowClickEventPropagation", "children", "className_DEPRECATED", "disabled", "forwardedRef", "link", "nativeID", "onBlur", "onContextMenu", "onFocus", "onFocusChange", "onFocusVisibleChange", "onHoverChange", "onHoverEnd", "onHoverMove", "onHoverStart", "onKeyDown", "onPress", "onPressChange", "onPressEnd", "onPressMove", "onPressStart", "preventContextMenu", "preventDefault", "style", "suppressFocusRing", "tabbable", "testID", "testOnly_state", "xstyle"]);
        var X = q(D, L);
        J = J === !0 || (E == null ? void 0 : E.disabled) === !0;
        var Y = E == null ? void 0 : E.hidden,
            Z = X === "a" && J !== !0;
        o = {
            disabled: J === !0 || (V == null ? void 0 : V.disabled) === !0 || !1,
            focusVisible: o || (V == null ? void 0 : V.focusVisible) === !0,
            focused: f || (V == null ? void 0 : V.focused) === !0,
            hovered: u || (V == null ? void 0 : V.hovered) === !0,
            pressed: z || (V == null ? void 0 : V.pressed) === !0
        };
        f = typeof G === "function" ? G(o) : G;
        u = typeof I === "function" ? I(o) : I;
        z = typeof S === "function" ? S(o) : S;
        V = typeof W === "function" ? W(o) : W;
        d("Pressability").usePressability(b, {
            disabled: J,
            onBlur: N,
            onContextMenu: O,
            onFocus: aa,
            onFocusChange: w(e, ba),
            onFocusVisibleChange: w(g, ca),
            onHoverChange: w(p, da),
            onHoverEnd: ea,
            onHoverMove: fa,
            onHoverStart: ga,
            onPressChange: w(y, ha),
            onPressEnd: ia,
            onPressMove: ja,
            onPressStart: ka,
            preventContextMenu: la,
            preventDefault: R == null ? !0 : R
        });
        var $ = i(function(a) {
            Q && Q(a), (Q || L != null) && (H !== !0 && a.stopPropagation()), v(a, R) && a.nativeEvent.preventDefault()
        }, [L, Q, R]);
        G = i(function(a) {
            P && P(a);
            if (s(a)) {
                var b = a.key;
                (b === " " || b === "Spacebar") && a.preventDefault();
                Q && (Q(a), a.stopPropagation())
            }
        }, [P, Q]);
        I = i(function(a) {
            b.current = a, typeof K === "function" ? K(a) : K != null && (K.current = a)
        }, [K]);
        k(function() {
            var a = b.current;
            if (!a || !a.addEventListener || !t(a)) return;
            if (!A && !n) return;
            A && A.register(a, $);
            var c = function(a) {
                    A && (a.preventDefault(), A.onTouchStart());
                    if (!n) return;
                    var b = (a = window) == null ? void 0 : (a = a.document) == null ? void 0 : a.body;
                    if (b == null) return;
                    b.style.WebkitUserSelect = "none";
                    var c = d("passiveEventListenerUtil").makeEventOptions({
                        passive: !0
                    });
                    a = function a() {
                        b.style.WebkitUserSelect = null, document.removeEventListener("touchend", a, c)
                    };
                    document.addEventListener("touchend", a, c)
                },
                e = d("passiveEventListenerUtil").makeEventOptions({
                    passive: !A
                });
            a.addEventListener("touchstart", c, e);
            return function() {
                A && A.unRegister(a), a.removeEventListener("touchstart", c, e)
            }
        }, [A, $]);
        S = -1;
        c("gkx")("5403") ? Y !== !0 && (U !== !1 && (S = 0)) : J !== !0 && Y !== !0 && (U !== !1 && (S = 0));
        W = L == null ? void 0 : L.download;
        N = (W === !0 || typeof W === "string") && Z;
        return h.jsx(X, babelHelpers["extends"]({}, a, {
            "aria-activedescendant": C == null ? void 0 : C.activedescendant,
            "aria-busy": E == null ? void 0 : E.busy,
            "aria-checked": E == null ? void 0 : E.checked,
            "aria-controls": C == null ? void 0 : C.controls,
            "aria-current": C == null ? void 0 : C.current,
            "aria-describedby": C == null ? void 0 : C.describedby,
            "aria-details": C == null ? void 0 : C.details,
            "aria-disabled": J === !0 ? J : void 0,
            "aria-errormessage": C == null ? void 0 : C.errormessage,
            "aria-expanded": E == null ? void 0 : E.expanded,
            "aria-haspopup": C == null ? void 0 : C.haspopup,
            "aria-hidden": Y,
            "aria-invalid": E == null ? void 0 : E.invalid,
            "aria-label": B,
            "aria-labelledby": C == null ? void 0 : C.labelledby,
            "aria-modal": E == null ? void 0 : E.modal,
            "aria-orientation": E == null ? void 0 : E.orientation,
            "aria-owns": C == null ? void 0 : C.owns,
            "aria-pressed": E == null ? void 0 : E.pressed,
            "aria-readonly": E == null ? void 0 : E.readonly,
            "aria-required": E == null ? void 0 : E.required,
            "aria-selected": E == null ? void 0 : E.selected,
            "aria-valuemax": F == null ? void 0 : F.max,
            "aria-valuemin": F == null ? void 0 : F.min,
            "aria-valuenow": F == null ? void 0 : F.now,
            "aria-valuetext": F == null ? void 0 : F.text,
            children: f,
            className: c("joinClasses")(c("stylex")(x.root, o.disabled && x.disabled, (!o.focusVisible || T === !0) && x.focusNotVisible, V, A && x.rootInGroup), u),
            "data-testid": void 0,
            download: N ? W : void 0,
            href: Z ? L == null ? void 0 : L.url : void 0,
            id: M,
            onClick: J ? void 0 : $,
            onKeyDown: J ? void 0 : G,
            ref: I,
            rel: Z ? L == null ? void 0 : L.rel : void 0,
            role: r(D),
            style: z,
            tabIndex: S,
            target: Z ? L == null ? void 0 : L.target : void 0
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function w(a, b) {
        return i(function(c) {
            a(c), b && b(c)
        }, [b, a])
    }
    var x = {
        disabled: {
            cursor: "x1h6gzvc",
            $$css: !0
        },
        focusNotVisible: {
            outlineStyle: "x1t137rt",
            $$css: !0
        },
        root: {
            WebkitTapHighlightColor: "x1i10hfl",
            alignItems: "x1qjc9v5",
            backgroundColor: "xjbqb8w",
            borderTopColor: "xjqpnuy",
            borderEndColor: "xa49m3k",
            borderBottomColor: "xqeqjp1",
            borderStartColor: "x2hbi6w",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "x972fbf",
            borderEndWidth: "xcfux6l",
            borderBottomWidth: "x1qhh985",
            borderStartWidth: "xm0m39n",
            boxSizing: "x9f619",
            cursor: "x1ypdohk",
            display: "x78zum5",
            flexBasis: "xdl72j9",
            flexDirection: "xdt5ytf",
            flexShrink: "x2lah0s",
            listStyle: "xe8uvvx",
            marginTop: "xdj266r",
            marginEnd: "x11i5rnm",
            marginBottom: "xat24cr",
            marginStart: "x1mh8g0r",
            minHeight: "x2lwn1j",
            minWidth: "xeuugli",
            paddingTop: "xexx8yu",
            paddingEnd: "x4uap5",
            paddingBottom: "x18d9i69",
            paddingStart: "xkhd6sd",
            position: "x1n2onr6",
            textAlign: "x16tdsg8",
            textDecoration: "x1hl2dhg",
            touchAction: "xggy1nq",
            zIndex: "x1ja2u2z",
            $$css: !0
        },
        rootInGroup: {
            touchAction: "x5ve5x3",
            $$css: !0
        }
    };
    g["default"] = a
}), 98);
__d("CometErrorProjectContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useCometErrorProject", ["CometErrorProjectContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometErrorProjectContext"))
    }
    g["default"] = a
}), 98);
__d("PressableText.react", ["BaseFocusRing.react", "Pressability", "PressableGroupContext", "RecoverableViolationWithComponentStack.react", "UserAgent", "gkx", "joinClasses", "justknobx", "passiveEventListenerUtil", "react", "stylex", "useCometErrorProject", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useEffect,
        l = b.useRef,
        m = b.useState,
        n = c("UserAgent").isBrowser("Safari") || c("UserAgent").isBrowser("Mobile Safari"),
        o = ["menuitem", "tab", "none"],
        p = {
            article: "article",
            banner: "header",
            complementary: "aside",
            contentinfo: "footer",
            figure: "figure",
            form: "form",
            heading: "h1",
            label: "label",
            link: "a",
            list: "ul",
            listitem: "li",
            main: "main",
            navigation: "nav",
            none: "div",
            region: "section"
        };

    function q(a, b) {
        var c = "div";
        if ((b == null ? void 0 : b.url) != null && (b == null ? void 0 : b.url) !== "#" || o.includes(a) && (b == null ? void 0 : b.url) != null) c = "a";
        else if (a != null) {
            b = p[a];
            b != null && (c = b)
        }
        return c
    }
    var r = function(a) {
        var b = a.target,
            c = b.tagName;
        c = b.isContentEditable || c === "A" && b.href != null || c === "BUTTON" || c === "INPUT" || c === "SELECT" || c === "TEXTAREA";
        if (b.tabIndex === 0 && !c) {
            c = a.key;
            if (c === "Enter") return !0;
            a = b.getAttribute("role");
            if ((c === " " || c === "Spacebar") && (a === "button" || a === "combobox" || a === "menuitem" || a === "menuitemradio" || a === "option")) return !0
        }
        return !1
    };

    function s(a) {
        a = a;
        while (a != null) {
            if (a.tagName === "A" && a.href != null) return !0;
            a = a.parentNode
        }
        return !1
    }

    function t(a, b) {
        var d = a.altKey,
            e = a.ctrlKey,
            f = a.currentTarget,
            g = a.metaKey,
            h = a.shiftKey;
        a = a.target;
        var i = a;
        c("justknobx")._("450") && (i = document.contains(a) ? a : f);
        a = s(i);
        f = d || e || g || h;
        return b !== !1 && a && !f
    }

    function a(a) {
        var b = l(null),
            e = m(!1),
            f = e[0];
        e = e[1];
        var g = m(!1),
            o = g[0];
        g = g[1];
        var p = m(!1),
            s = p[0];
        p = p[1];
        var w = m(!1),
            x = w[0];
        w = w[1];
        var y = j(c("PressableGroupContext")),
            z = a.accessibilityLabel,
            A = a.accessibilityRelationship,
            B = a.accessibilityRole,
            C = a.accessibilityState,
            D = a.children,
            E = a.className_DEPRECATED,
            F = a.direction,
            G = a.disabled,
            H = a.focusable,
            I = a.forwardedRef,
            J = a.link,
            K = a.nativeID,
            L = a.onBlur,
            M = a.onContextMenu,
            N = a.onFocus,
            O = a.onFocusChange,
            aa = a.onFocusVisibleChange,
            ba = a.onHoverChange,
            ca = a.onHoverEnd,
            da = a.onHoverMove,
            ea = a.onHoverStart,
            P = a.onPress,
            fa = a.onPressChange,
            ga = a.onPressEnd,
            ha = a.onPressMove,
            ia = a.onPressStart,
            ja = a.preventContextMenu,
            Q = a.preventDefault,
            ka = a.selectable,
            R = a.style,
            S = a.suppressFocusRing,
            T = a.testID;
        T = a.testOnly_state;
        var U = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["accessibilityLabel", "accessibilityRelationship", "accessibilityRole", "accessibilityState", "children", "className_DEPRECATED", "direction", "disabled", "focusable", "forwardedRef", "link", "nativeID", "onBlur", "onContextMenu", "onFocus", "onFocusChange", "onFocusVisibleChange", "onHoverChange", "onHoverEnd", "onHoverMove", "onHoverStart", "onPress", "onPressChange", "onPressEnd", "onPressMove", "onPressStart", "preventContextMenu", "preventDefault", "selectable", "style", "suppressFocusRing", "testID", "testOnly_state", "xstyle"]);
        var V = q(B, J);
        G = G === !0 || (C == null ? void 0 : C.disabled) === !0;
        var W = C == null ? void 0 : C.hidden,
            X = V === "a" && G !== !0;
        f = {
            disabled: G === !0 || (T == null ? void 0 : T.disabled) === !0 || !1,
            focused: f || (T == null ? void 0 : T.focused) === !0,
            focusVisible: o && S !== !0 || (T == null ? void 0 : T.focusVisible) === !0,
            hovered: s || (T == null ? void 0 : T.hovered) === !0,
            pressed: x || (T == null ? void 0 : T.pressed) === !0
        };
        o = typeof D === "function" ? D(f) : D;
        S = typeof E === "function" ? E(f) : E;
        s = typeof R === "function" ? R(f) : R;
        x = typeof U === "function" ? U(f) : U;
        d("Pressability").usePressability(b, {
            disabled: G,
            onBlur: L,
            onContextMenu: M,
            onFocus: N,
            onFocusChange: u(e, O),
            onFocusVisibleChange: u(g, aa),
            onHoverChange: u(p, ba),
            onHoverEnd: ca,
            onHoverMove: da,
            onHoverStart: ea,
            onPressChange: u(w, fa),
            onPressEnd: ga,
            onPressMove: ha,
            onPressStart: ia,
            preventContextMenu: ja,
            preventDefault: Q == null ? !0 : Q
        });
        var Y = i(function(a) {
            P && P(a), (P || J != null) && a.stopPropagation(), t(a, Q) && a.nativeEvent.preventDefault()
        }, [J, P, Q]);
        T = i(function(a) {
            if (r(a)) {
                var b = a.key;
                (b === " " || b === "Spacebar") && a.preventDefault();
                P && (P(a), a.stopPropagation())
            }
        }, [P]);
        var la, Z;
        switch (F) {
            case "none":
                break;
            default:
                F != null && (Z = F);
                break
        }
        D = c("useMergeRefs")(b, I);
        k(function() {
            var a, c = b.current,
                e = (a = window) == null ? void 0 : (a = a.document) == null ? void 0 : a.body;
            if (e == null || c == null || !e.contains(c) || c.addEventListener == null) return;
            y && y.register(c, Y);
            var f = function(a) {
                    y && (a.preventDefault(), y.onTouchStart());
                    if (!n) return;
                    if (e == null) return;
                    e.style.WebkitUserSelect = "none";
                    var b = d("passiveEventListenerUtil").makeEventOptions({
                        passive: !0
                    });
                    a = function a() {
                        e.style.WebkitUserSelect = null, document.removeEventListener("touchend", a, b)
                    };
                    document.addEventListener("touchend", a, b)
                },
                g = d("passiveEventListenerUtil").makeEventOptions({
                    passive: !y
                });
            c.addEventListener("touchstart", f, g);
            return function() {
                y && y.unRegister(c), c.removeEventListener("touchstart", f, g)
            }
        }, [y, Y]);
        var $;
        E = V === "a" || B === "button";
        E ? W === !0 || H === !1 || !c("gkx")("5403") && G === !0 ? $ = -1 : $ = 0 : c("gkx")("5403") ? W !== !0 && H !== !1 && B !== "none" && ($ = 0) : G !== !0 && W !== !0 && H !== !1 && B !== "none" && ($ = 0);
        R = J == null ? void 0 : J.download;
        U = (R === !0 || typeof R === "string") && X;
        L = B === "none" ? "presentation" : B;
        M = h.jsx(V, babelHelpers["extends"]({}, a, {
            "aria-activedescendant": A == null ? void 0 : A.activedescendant,
            "aria-busy": C == null ? void 0 : C.busy,
            "aria-checked": C == null ? void 0 : C.checked,
            "aria-controls": A == null ? void 0 : A.controls,
            "aria-current": A == null ? void 0 : A.current,
            "aria-describedby": A == null ? void 0 : A.describedby,
            "aria-details": A == null ? void 0 : A.details,
            "aria-disabled": G === !0 && L !== "presentation" ? G : void 0,
            "aria-expanded": C == null ? void 0 : C.expanded,
            "aria-haspopup": A == null ? void 0 : A.haspopup,
            "aria-hidden": W,
            "aria-invalid": C == null ? void 0 : C.invalid,
            "aria-label": z,
            "aria-labelledby": A == null ? void 0 : A.labelledby,
            "aria-owns": A == null ? void 0 : A.owns,
            "aria-pressed": C == null ? void 0 : C.pressed,
            "aria-readonly": C == null ? void 0 : C.readonly,
            "aria-required": C == null ? void 0 : C.required,
            "aria-selected": C == null ? void 0 : C.selected,
            children: o,
            className: c("joinClasses")(c("stylex")(v.root, ka === !1 && v.notSelectable, f.disabled && v.disabled, !f.focusVisible && v.focusNotVisible, f.focusVisible && E && c("BaseFocusRing.react").linkFocusRingXStyle, x, y && v.rootInGroup), S),
            "data-testid": void 0,
            dir: Z,
            download: U ? R : void 0,
            href: X ? J == null ? void 0 : J.url : void 0,
            id: K,
            onClick: G ? void 0 : Y,
            onKeyDown: G ? void 0 : T,
            ref: D,
            rel: X ? J == null ? void 0 : J.rel : void 0,
            role: L,
            style: s,
            tabIndex: $,
            target: X ? J == null ? void 0 : J.target : void 0
        }));
        return M
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function u(a, b) {
        return i(function(c) {
            a(c), b && b(c)
        }, [b, a])
    }
    var v = {
        disabled: {
            cursor: "x1h6gzvc",
            $$css: !0
        },
        focusNotVisible: {
            outline: "x1a2a7pz",
            $$css: !0
        },
        notSelectable: {
            userSelect: "x87ps6o",
            $$css: !0
        },
        root: {
            WebkitTapHighlightColor: "x1i10hfl",
            backgroundColor: "xjbqb8w",
            borderTop: "x6umtig",
            borderEnd: "x1b1mbwd",
            borderBottom: "xaqea5y",
            borderStart: "xav7gou",
            boxSizing: "x9f619",
            cursor: "x1ypdohk",
            display: "xt0psk2",
            listStyle: "xe8uvvx",
            marginTop: "xdj266r",
            marginEnd: "x11i5rnm",
            marginBottom: "xat24cr",
            marginStart: "x1mh8g0r",
            paddingTop: "xexx8yu",
            paddingEnd: "x4uap5",
            paddingBottom: "x18d9i69",
            paddingStart: "xkhd6sd",
            textAlign: "x16tdsg8",
            textDecoration: "x1hl2dhg",
            touchAction: "xggy1nq",
            $$css: !0
        },
        rootInGroup: {
            touchAction: "x5ve5x3",
            $$css: !0
        }
    };
    g["default"] = a
}), 98);
__d("CometFeedClickEventsLoggerContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(c("emptyFunction"));
    g["default"] = b
}), 98);
__d("CometFeedLoggingExtraFieldsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({});
    g["default"] = b
}), 98);
__d("CometTrackingCodeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        click_tracking_linkshim_cb: [],
        encrypted_click_tracking: [],
        encrypted_tracking: []
    });
    g["default"] = b
}), 98);
__d("CometTrackingNodesContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext([]);
    g["default"] = b
}), 98);
__d("DataUrlUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = /^data:.*/;

    function a(a) {
        return a == null ? !1 : g.test(a)
    }
    f.isDataUrl = a
}), 66);
__d("MailLinkUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = new RegExp("mailto:.*@.*");

    function a(a) {
        return a == null ? !1 : g.test(a)
    }
    f.isMailToLink = a
}), 66);
__d("getAbsoluteUrl", ["ConstUriUtils", "FBLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a == null || a.trim() === "#") return a;
        a = (a = d("ConstUriUtils").getUri(a)) == null ? void 0 : (a = a.getQualifiedUri()) == null ? void 0 : a.toString();
        a == null && c("FBLogger")("comet_infra").blameToPreviousFrame().mustfix("must pass a valid href to getAbsoluteUrl");
        return a
    }
    g["default"] = a
}), 98);
__d("useStoryClickEventLogger", ["CometFeedClickEventsLoggerContext", "CometFeedLoggingExtraFieldsContext", "CometTrackingCodeContext", "CometTrackingNodesContext", "DataUrlUtils", "MailLinkUtils", "getAbsoluteUrl", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useContext;

    function a() {
        var a = i(c("CometFeedClickEventsLoggerContext")),
            b = i(c("CometTrackingNodesContext")),
            e = i(c("CometTrackingCodeContext")),
            f = e.encrypted_tracking[0],
            g = i(c("CometFeedLoggingExtraFieldsContext"));
        return h(function(e, h, i, j) {
            var k = i;
            !d("MailLinkUtils").isMailToLink(i) && !d("DataUrlUtils").isDataUrl(i) && (k = c("getAbsoluteUrl")(i));
            a(e, b, f, h, k, g, j)
        }, [a, b, f, g])
    }
    g["default"] = a
}), 98);
__d("useFeedPressEventHandler", ["FBLogger", "cr:11054", "emptyFunction", "react", "useStoryClickEventLogger", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useCallback,
        i = (e = b("cr:11054")) != null ? e : function() {
            return c("emptyFunction")
        };

    function a(a, b) {
        var d = c("useStoryClickEventLogger")(),
            e = i();
        return h(function(f) {
            try {
                e(f)
            } catch (a) {
                c("FBLogger")("voyage").catching(a).mustfix("Voyage press logger threw")
            }
            a && a(f);
            var g = f.buttons,
                h = f.timeStamp;
            f = f.type;
            if (f === "click" || f === "press" || f === "contextmenu" || f === "pressstart" && g === 4) {
                f = f === "contextmenu" ? 2 : g === 4 ? 1 : 0;
                g = c("uuid")();
                d(h, f, b, g)
            }
        }, [a, d, b, e])
    }
    g["default"] = a
}), 98);
__d("BaseButton.react", ["BaseButtonPopoverContext", "Pressable.react", "PressableText.react", "react", "useFeedPressEventHandler"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function a(a, b) {
        var d = a.allowClickEventPropagation,
            e = a["aria-activedescendant"],
            f = a["aria-checked"],
            g = a["aria-controls"],
            j = a["aria-current"],
            k = a["aria-describedby"],
            l = a["aria-expanded"],
            m = a["aria-haspopup"],
            n = a["aria-hidden"],
            o = a["aria-invalid"],
            p = a["aria-label"],
            q = a["aria-labelledby"],
            r = a["aria-pressed"],
            s = a["aria-selected"],
            t = a.children,
            u = a.className_DEPRECATED,
            v = a.disabled;
        v = v === void 0 ? !1 : v;
        var w = a.display;
        w = w === void 0 ? "inline" : w;
        var x = a.focusable,
            y = a.id,
            z = a.label,
            A = a.onBlur,
            B = a.onClick,
            C = a.onContextMenu,
            D = a.onFocus,
            E = a.onFocusChange,
            F = a.onFocusVisibleChange,
            G = a.onHoverChange,
            H = a.onHoverEnd,
            I = a.onHoverStart,
            J = a.onPressChange,
            K = a.onPressEnd,
            L = a.onPressStart,
            M = a.preventContextMenu,
            N = a.role,
            O = a.style,
            P = a.suppressFocusRing,
            Q = a.suppressHydrationWarning,
            R = a.testid,
            S = a.testOnly_pressed;
        S = S === void 0 ? !1 : S;
        a = a.xstyle;
        N = N === "presentation" ? "none" : N;
        p = N !== "none" ? (p = p) != null ? p : z : void 0;
        z = b;
        b = B;
        var T = L,
            U = C;
        b = c("useFeedPressEventHandler")(B);
        T = c("useFeedPressEventHandler")(L);
        U = c("useFeedPressEventHandler")(C);
        B = i(c("BaseButtonPopoverContext"));
        L = {
            accessibilityLabel: p,
            accessibilityRelationship: {
                activedescendant: e,
                controls: g,
                current: j,
                describedby: k,
                haspopup: B != null && m == null ? B.haspopup : m,
                labelledby: q
            },
            accessibilityState: {
                checked: f,
                disabled: v,
                expanded: B != null && l == null ? B.expanded : l,
                hidden: n,
                invalid: o,
                pressed: r,
                selected: s
            },
            className_DEPRECATED: u,
            disabled: v,
            forwardedRef: z,
            nativeID: y,
            onBlur: A,
            onContextMenu: U,
            onFocus: D,
            onFocusChange: E,
            onFocusVisibleChange: F,
            onHoverChange: G,
            onHoverEnd: H,
            onHoverStart: I,
            onPress: b,
            onPressChange: J,
            onPressEnd: K,
            onPressStart: T,
            preventContextMenu: M,
            style: O,
            suppressHydrationWarning: Q,
            testID: R,
            testOnly_state: {
                disabled: !1,
                focused: !1,
                focusVisible: !1,
                hovered: !1,
                pressed: S
            },
            xstyle: a
        };
        if (w === "block") {
            C = N === "menuitem" || N === "none" || N === "gridcell" || N === "switch" || N === "combobox" || N === "checkbox" || N === "tab" || N === "radio" || N === "option" ? N : "button";
            return h.jsx(c("Pressable.react"), babelHelpers["extends"]({}, L, {
                accessibilityRole: C,
                allowClickEventPropagation: d,
                suppressFocusRing: P,
                tabbable: x,
                children: t
            }))
        } else {
            p = N === "combobox" || N === "menuitem" || N === "menuitemcheckbox" || N === "menuitemradio" || N === "option" || N === "none" || N === "tab" ? N : "button";
            return h.jsx(c("PressableText.react"), babelHelpers["extends"]({
                focusable: x
            }, L, {
                accessibilityRole: p,
                direction: "none",
                suppressFocusRing: P,
                children: t
            }))
        }
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseLinkDefaultTargetContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("BaseLinkEndpointModifierContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext([]);
    g["default"] = b
}), 98);
__d("BaseLinkNestedPressableContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("BaseNestedPressableHack_DO_NOT_USE.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useEffect,
        j = b.useState;

    function a(a) {
        a = a.children;
        var b = j(!1),
            c = b[0],
            d = b[1];
        i(function() {
            return d(!0)
        }, []);
        b = c ? null : {
            height: 0,
            width: 0
        };
        return h.jsx("object", babelHelpers["extends"]({}, b, {
            type: "nested/pressable",
            children: a
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometClickIDParameterUtils", ["ConstUriUtils", "isCdnURI", "isClickIDBlacklistSVDomainURI", "isFacebookSVDomainURI", "isFacebookURI", "isFbDotComURI"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "fbclid";
    b = "doubleclick.net";
    var i = (e = {}, e[b] = [{
        extractor: function(a) {
            a = a.getQueryString();
            return a != null && a.startsWith("http") ? d("ConstUriUtils").getUri(a) : null
        },
        injector: function(a, b, c) {
            b = b.addQueryParam(h, c);
            if (b != null) {
                c = new Map();
                c.set(b.toString(), null);
                b = a.replaceQueryParams(c);
                if (b != null) return b
            }
            return a
        }
    }], e);

    function j(a) {
        return a.getOrigin() !== "://"
    }

    function k(a) {
        var b = Object.keys(i).filter(function(b) {
            return a.getDomain().endsWith(b)
        });
        b = b[0] || null;
        b = b != null ? i[b] : null;
        if (b == null) return null;
        b = b.map(function(b) {
            var c = b.extractor(a);
            return c == null ? null : {
                injector: b.injector,
                uri: c
            }
        }).filter(function(a) {
            return a != null
        });
        return b[0] || null
    }

    function l(a) {
        var b = c("isClickIDBlacklistSVDomainURI")(a);
        if (b) return !0;
        b = k(a);
        return b != null ? l(b.uri) : !1
    }

    function m(a) {
        return !c("isFacebookURI")(a) && !c("isFacebookSVDomainURI")(a) && !c("isCdnURI")(a) && !c("isFbDotComURI")(a) && j(a) && ["http", "https"].includes(a.getProtocol()) && !l(a)
    }

    function n(a, b) {
        var c = k(a);
        if (c != null) return c.injector(a, c.uri, b);
        c = a.addQueryParam(h, b);
        return c != null ? c : a
    }

    function a(a, b) {
        return m(a) ? n(a, b) : a
    }
    g.appendClickIDQueryParam = a
}), 98);
__d("CometLynxGeneration", ["ConstUriUtils", "LinkshimHandlerConfig", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = c("LinkshimHandlerConfig").current_domain === "oculus.com";
    var h = "c",
        i = c("gkx")("1902661") || b ? "e" : "h",
        j = "u",
        k = "__tn__";
    e = "/l.php";
    c("gkx")("1902661") && (e = "");
    b && (e = "/lynx/");
    var l = d("ConstUriUtils").getUri(e);
    l != null && (l = l.setDomain(c("LinkshimHandlerConfig").linkshim_host));

    function m(a) {
        return c("LinkshimHandlerConfig").always_use_https ? "https" : a.getProtocol() === "http" ? "http" : "https"
    }

    function n() {
        return l
    }

    function a(a, b, c, d) {
        var e = m(a),
            f = n();
        f != null && (f = f.addQueryParams(new Map([
            [j, d === !0 ? a.toStringPreserveQuery() : a.toString()],
            [i, b]
        ])));
        f != null && (f = f.setProtocol(e));
        d = c == null ? void 0 : c.trackingNodes;
        b = c == null ? void 0 : c.callbacks;
        d && d.length && f != null && (f = f.addQueryParam(k, d.join("")));
        b && b.length && f != null && (f = f.addQueryParam(h, b));
        return f != null ? f : a
    }
    g.getLynxURIProtocol = m;
    g.getShimURI = n;
    g.getShimmedHref = a
}), 98);
__d("CometLinkShimUtils", ["CometClickIDParameterUtils", "CometLynxGeneration", "ConstUriUtils", "LinkshimHandlerConfig", "Random", "gkx", "isLinkshimURI", "isRelativeURL", "isTrustedDestination", "killswitch"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        if (c("isRelativeURL")(a.toString())) return !1;
        var b = a.getProtocol();
        return b !== "http" && b !== "https" ? !1 : !c("isTrustedDestination")(a)
    }
    var i = new RegExp("^(l|lm|h)\\..*$", "i");

    function j(a) {
        if (c("killswitch")("LINK_UPGRADE_UNSHIMMED_JS")) return null;
        if (a.getProtocol() !== "http") return null;
        if (!c("isTrustedDestination")(a)) return null;
        return i.test(a.getDomain()) ? null : a.setProtocol("https")
    }

    function k(a) {
        a = a.getQueryParams();
        a = a.get("enc");
        return String(a) !== "1" ? !1 : c("gkx")("5945")
    }
    var l = {
        href: "#",
        shimmed: !1
    };

    function a(a, b, e, f, g, i) {
        if (a == null || a === "#") return l;
        var m = d("ConstUriUtils").getUri(a);
        if (m == null) return l;
        a = k(m);
        var n = c("LinkshimHandlerConfig").link_react_default_hash;
        if (c("isLinkshimURI")(m) && !a) {
            var o = m.getQueryParams(),
                p = o.get("u");
            o = o.get("h");
            p = d("ConstUriUtils").getUri(String(p));
            p != null && (m = p, n = String(o))
        }
        if (a) {
            p = m.removeQueryParam("enc");
            p != null && (m = p)
        }
        o = c("LinkshimHandlerConfig").click_ids;
        p = !1;
        if (!c("killswitch")("LINKSHIM_ADD_CLICK_ID_PARAM") && o != null && o.length > 0) {
            var q = null;
            if (c("gkx")("1616314") && f != null) q = f;
            else {
                f = Math.floor(c("Random").random() * o.length);
                q = o[f]
            }
            m = d("CometClickIDParameterUtils").appendClickIDQueryParam(m, q);
            p = !0
        }
        o = j(m);
        o != null && (m = o);
        if (h(m) && g !== !0 && !a) {
            f = d("CometLynxGeneration").getShimmedHref(m, n, {
                callbacks: b,
                trackingNodes: e
            }, i);
            q = c("LinkshimHandlerConfig").blocklisted_domains.some(function(a) {
                var b;
                return (b = m) == null ? void 0 : b.toString().includes(a)
            });
            return q ? {
                clickIDAppended: p,
                href: f.toString(),
                shimmed: !0,
                unshimmedHref: f.toString()
            } : {
                clickIDAppended: p,
                ghlEncrypted: a,
                href: f.toString(),
                shimmed: !0,
                unshimmedHref: i === !0 ? m.toStringPreserveQuery() : m.toString()
            }
        } else return {
            clickIDAppended: p,
            ghlEncrypted: a,
            href: i === !0 ? m.toStringPreserveQuery() : m.toString(),
            shimmed: !1
        }
    }
    g.getLinkShimInfo = a;
    g.use_rel_no_opener = c("LinkshimHandlerConfig").use_rel_no_opener
}), 98);
__d("CometLinkTrackingUtils", ["cr:1522191"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g.decorateHrefWithTrackingInfo = b("cr:1522191").decorateHrefWithTrackingInfo
}), 98);
__d("CometProductAttributionContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = null;
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("appendPersistQueryParamsToUrl", ["CometPersistQueryParams", "ConstUriUtils", "isRelativeURL"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        var c;
        return (b = (c = d("ConstUriUtils").getUri(a)) == null ? void 0 : (c = c.addQueryParams(new Map(Object.entries(b)))) == null ? void 0 : c.toString()) != null ? b : a
    }

    function a(a) {
        var b = d("ConstUriUtils").getUri(a);
        if (b == null) return a;
        if (c("isRelativeURL")(a) || b.getDomain() === "") return h(a, c("CometPersistQueryParams").relative);
        b = b.getDomain().split(".").slice(-2).join(".");
        return c("CometPersistQueryParams").domain[b] != null ? h(a, c("CometPersistQueryParams").domain[b]) : a
    }
    g["default"] = a
}), 98);
__d("isCometRouterUrl", ["ConstUriUtils", "Env", "isFacebookURI", "isLinkshimURI", "memoizeStringOnly", "uriIsRelativePath"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a) {
            return a === "/l.php" || a.startsWith("/si/ajax/l/") || a.startsWith("/l/") || a.startsWith("l/")
        },
        i = function(a) {
            var b = a.getDomain();
            return b == null ? !1 : c("isFacebookURI")(a) && b.startsWith("www")
        },
        j = /^(\/\w)/;
    a = c("memoizeStringOnly")(function(a) {
        if (a == null || a.startsWith("#") || !d("ConstUriUtils").isValidUri(a)) return !1;
        var b = null,
            e = !1;
        b = d("ConstUriUtils").getUri(a);
        if (b != null) {
            if (!h(b.getPath()) && j.test(a)) return !0;
            a = d("ConstUriUtils").getUri(window.location.href);
            e = a ? b.isSameOrigin(a) || c("uriIsRelativePath")(b) : !1
        }
        return b != null ? !c("isLinkshimURI")(b) && (e || Boolean(c("Env").isCometSubdomain) && i(b) || Boolean(c("Env").isStoryGallery) && i(b) || Boolean(c("Env").isAdsPreviewTool) && i(b)) : !1
    });
    g["default"] = a
}), 98);
__d("CometRouterDispatcherContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useCometRouterDispatcher", ["CometRouterDispatcherContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometRouterDispatcherContext"))
    }
    g["default"] = a
}), 98);
__d("useCometRouterLinkQueryPrefetcher", ["ODS", "react", "useCometRouterDispatcher"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.startTransition,
        i = b.useCallback,
        j = b.useRef;

    function a(a) {
        var b = a.dispatcherExtras,
            e = a.href,
            f = a.preloadTriggerType,
            g = a.routeHandledByCometRouter,
            k = c("useCometRouterDispatcher")(),
            l = j(null);
        a = i(function() {
            var a = l.current;
            a && (h(function() {
                a.cancel()
            }), l.current = null)
        }, []);
        var m = i(function() {
                var a = l.current;
                l.current = null;
                a != null && d("ODS").bumpEntityKey(2994, "comet_preloading", "prefetch_route_queries." + f + ".used");
                return a
            }, [f]),
            n = i(function() {
                if (k != null && e != null && g && l.current == null) {
                    var a;
                    l.current = k.prefetchRouteQueries(e, (a = b) != null ? a : {});
                    d("ODS").bumpEntityKey(2994, "comet_preloading", "prefetch_route_queries." + f + ".preloaded")
                }
            }, [k, e, g, b, f]);
        return {
            cancelPrefetchRouteQueries: a,
            getPrefetchedQueryContainerAndMarkAsUsed: m,
            prefetchRouteQueries: n
        }
    }
    g["default"] = a
}), 98);
__d("useCometRouterLinkEventHandlers", ["JSScheduler", "gkx", "react", "useCometPreloader", "useCometRouterDispatcher", "useCometRouterLinkQueryPrefetcher"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useEffect,
        j = b.useMemo,
        k = b.useRef,
        l = /async(?:-post)?|dialog(?:-post)?|theater|toggle/;

    function a(a) {
        var b = a.dispatcherExtras,
            e = a.href,
            f = a.isRouterLink,
            g = a.onHoverEnd,
            m = a.onHoverStart,
            n = a.onPress,
            o = a.onPressStart,
            p = a.prefetchQueriesOnHover,
            q = a.preloadCodeOnMount,
            r = a.preventLocalNavigation,
            s = a.rel,
            t = a.target;
        a = p === !0 ? "button_aggressive" : "button";
        var u = c("useCometRouterDispatcher")(),
            v = k(null),
            w = j(function() {
                var a = t == null || t === "_self",
                    b = !c("gkx")("708253") && s != null && s.match(l) != null;
                return f && r !== !0 && a && !b
            }, [f, r, t, s]);
        p = (p = b) != null ? p : {};
        p.onNavigate;
        p = babelHelpers.objectWithoutPropertiesLoose(p, ["onNavigate"]);
        p = c("useCometRouterLinkQueryPrefetcher")({
            dispatcherExtras: p,
            href: e,
            preloadTriggerType: a,
            routeHandledByCometRouter: w
        });
        var x = p.cancelPrefetchRouteQueries,
            y = p.getPrefetchedQueryContainerAndMarkAsUsed;
        p = p.prefetchRouteQueries;
        var z = function(a) {
                n && n(a);
                var c = !(a.metaKey || a.altKey || a.ctrlKey || a.shiftKey);
                if (c && w && (u && e != null)) {
                    c = y();
                    u.go(e, babelHelpers["extends"]({
                        eventTimestamp: a.timeStamp,
                        prefetcher: c
                    }, b))
                }
            },
            A = b == null ? void 0 : b.target,
            B = h(function() {
                e != null && v.current !== e && w && d("JSScheduler").scheduleSpeculativeCallback(function() {
                    u != null && v.current !== e && (v.current = e, u.preloadRouteCode(e, A))
                })
            }, [u, e, A, w]);
        i(function() {
            e != null && w && (q === !0 ? B() : d("JSScheduler").scheduleSpeculativeCallback(function() {
                u == null ? void 0 : u.prefetchRouteDefinition(e)
            }))
        }, [B, q, u, w, e]);
        a = c("useCometPreloader")(a, B, p, x);
        var C = a[0],
            D = a[1],
            E = a[2];
        p = function(a) {
            o && o(a), E(a)
        };
        x = function(a) {
            m && m(a);
            if (!f) return;
            C(a)
        };
        a = function(a) {
            g && g(a), D()
        };
        return {
            onHoverEnd: a,
            onHoverStart: x,
            onPress: z,
            onPressStart: p
        }
    }
    g["default"] = a
}), 98);
__d("CometGHLRenderingContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = !1;
    c = a.createContext(b);
    e = c;
    g["default"] = e
}), 98);
__d("useCometRouterLinkShimEventHandlers", ["CometGHLRenderingContext", "ReactDOMComet", "gkx", "react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useContext,
        i = b.useState,
        j = c("requireDeferred")("LynxAsyncCallbackFalcoEvent").__setRef("useCometRouterLinkShimEventHandlers");

    function a(a) {
        var b = a.href,
            e = a.lynxMode,
            f = a.onContextMenu,
            g = a.onHoverStart,
            k = a.onPress,
            l = a.shimmed,
            m = a.unshimmedHref;
        a = h(c("CometGHLRenderingContext"));
        a = i(a);
        var n = a[0],
            o = a[1];

        function p(a) {
            f && f(a), n && d("ReactDOMComet").flushSync(function() {
                o(!1)
            })
        }

        function q(a) {
            k && k(a), l === !0 && e === "ASYNCLAZY" && b != null && m != null && c("gkx")("1642984") ? (n || d("ReactDOMComet").flushSync(function() {
                o(!0)
            }), j.onReadyImmediately(function(a) {
                a.log(function() {
                    return {
                        lynx_uri: b,
                        next_uri: m
                    }
                })
            })) : n && d("ReactDOMComet").flushSync(function() {
                o(!1)
            })
        }

        function r(a) {
            g && g(a), l === !0 && o(!0)
        }
        return {
            onContextMenu: p,
            onHoverStart: r,
            onPress: q,
            useOrigHref: n
        }
    }
    g["default"] = a
}), 98);
__d("CometRouterRouteContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("useCurrentRoute", ["CometRouterRouteContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometRouterRouteContext"))
    }
    g["default"] = a
}), 98);
__d("BaseLinkUriBaseContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("useTransformRelativeUri", ["BaseLinkUriBaseContext", "ConstUriUtils", "isRelativeURL", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useContext,
        i = b.useMemo;

    function j(a, b) {
        if (c("isRelativeURL")(b)) {
            var e = d("ConstUriUtils").getUri(b);
            if (e != null) {
                e = (a = a.addQueryParams(e.getQueryParams())) == null ? void 0 : (a = a.setPath(e.getPath())) == null ? void 0 : (a = a.setFragment(e.getFragment())) == null ? void 0 : a.toString();
                if (e != null) return e
            }
        }
        return b
    }

    function a(a) {
        var b = h(c("BaseLinkUriBaseContext"));
        return i(function() {
            return b == null || a == null ? a : j(b, a)
        }, [b, a])
    }
    g["default"] = a
}), 98);
__d("BaseLink.react", ["BaseLinkDefaultTargetContext", "BaseLinkEndpointModifierContext", "BaseLinkNestedPressableContext", "BaseNestedPressableHack_DO_NOT_USE.react", "CometLinkShimUtils", "CometLinkTrackingUtils", "CometProductAttributionContext", "CometTrackingCodeContext", "CometTrackingNodesContext", "Pressable.react", "PressableText.react", "RecoverableViolationWithComponentStack.react", "appendPersistQueryParamsToUrl", "isCometRouterUrl", "justknobx", "mergeRefs", "react", "recoverableViolation", "useCometErrorProject", "useCometRouterDispatcher", "useCometRouterLinkEventHandlers", "useCometRouterLinkShimEventHandlers", "useCurrentRoute", "useFeedPressEventHandler", "useTransformRelativeUri"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useMemo,
        aa = b.useRef;

    function ba(a, b) {
        return b == null ? null : a.reduce(function(a, b) {
            b = b(a);
            if (!c("isCometRouterUrl")(b)) {
                c("recoverableViolation")("Endpoint modifier returned a non-router URL, ignoring.", "comet_infra");
                return a
            }
            return b
        }, b)
    }

    function l(a) {
        a = a.children;
        return h.jsx(c("BaseLinkNestedPressableContext").Provider, {
            value: !0,
            children: a
        })
    }
    l.displayName = l.name + " [from " + f.id + "]";

    function a(a, b) {
        var e = a["aria-activedescendant"],
            f = a["aria-checked"],
            g = a["aria-controls"],
            ca = a["aria-current"],
            da = a["aria-describedby"],
            ea = a["aria-expanded"],
            fa = a["aria-haspopup"],
            ga = a["aria-hidden"],
            ha = a["aria-invalid"],
            n = a["aria-label"],
            ia = a["aria-labelledby"],
            ja = a["aria-owns"],
            ka = a["aria-selected"],
            o = a.children,
            la = a.className_DEPRECATED,
            p = a.disabled,
            q = a.disableLinkShimAndTracking_DO_NOT_USE_OR_SEE_YOU_AT_THE_PRIVACY_SEV,
            r = a.disableLinkShimForFollowLinkButton_DO_NOT_USE_OR_SEE_YOU_AT_THE_PRIVACY_SEV,
            s = a.display;
        s = s === void 0 ? "inline" : s;
        var t = a.download,
            u = a.fbclid,
            v = a.focusable,
            w = a.href,
            ma = a.id,
            x = a.label,
            y = a.lynxMode,
            na = a.onBlur,
            z = a.onClick,
            A = a.onContextMenu,
            oa = a.onFocus,
            pa = a.onFocusChange,
            qa = a.onFocusVisibleChange,
            ra = a.onHoverChange,
            B = a.onHoverEnd,
            C = a.onHoverStart,
            D = a.onNavigate,
            sa = a.onPressChange,
            ta = a.onPressEnd,
            E = a.onPressStart,
            F = a.passthroughProps,
            G = a.prefetchQueriesOnHover,
            H = a.preloadCodeOnMount,
            I = a.preserveQueryInShim,
            ua = a.preventContextMenu,
            J = a.preventLocalNavigation,
            va = a.productAttribution,
            K = a.rel,
            wa = a.replace,
            L = a.role,
            M = a.routeTarget,
            xa = a.style,
            ya = a.suppressFocusRing,
            za = a.suppressHydrationWarning,
            N = a.target,
            Aa = a.testid,
            O = a.testOnly_pressed;
        O = O === void 0 ? !1 : O;
        var Ba = a.traceParams;
        a = a.xstyle;
        var Ca = c("useCometRouterDispatcher")(),
            P = aa(null),
            Da = j(c("BaseLinkEndpointModifierContext")),
            Q = j(c("BaseLinkDefaultTargetContext")),
            R = j(c("CometTrackingNodesContext")),
            S = j(c("CometTrackingCodeContext")),
            Ea = S.click_tracking_linkshim_cb,
            Fa = S.encrypted_click_tracking,
            Ga = j(c("CometProductAttributionContext")),
            T = i(function(a) {
                return d("CometLinkTrackingUtils").decorateHrefWithTrackingInfo(a, R, Fa)
            }, [Fa, R]),
            Ha = i(function(a) {
                return ba(Da, a)
            }, [Da]),
            Ia = t === !0 || typeof t === "string";
        S = k(function() {
            var a, b = w != null && c("justknobx")._("144") ? c("appendPersistQueryParamsToUrl")(w) : w;
            if (Ia || q === !0) return {
                clickIDAppended: !1,
                ghlEncrypted: !1,
                href: b,
                isRouterLink: !1,
                shimmed: !1,
                unshimmedHref: null
            };
            if (b != null && c("isCometRouterUrl")(b)) {
                var e = T(Ha(b));
                return {
                    clickIDAppended: !1,
                    ghlEncrypted: !1,
                    href: e,
                    isRouterLink: !0,
                    shimmed: !1,
                    unshimmedHref: null
                }
            }
            e = d("CometLinkShimUtils").getLinkShimInfo(b, Ea, R, u, r, I);
            b = e.shimmed ? e.href : T(e.href);
            return {
                clickIDAppended: e.clickIDAppended,
                ghlEncrypted: (a = e.ghlEncrypted) != null ? a : !1,
                href: b,
                isRouterLink: !1,
                shimmed: e.shimmed,
                unshimmedHref: e.shimmed ? e.unshimmedHref : null
            }
        }, [Ea, r, q, u, Ia, w, I, R, T, Ha]);
        var Ja = S.clickIDAppended,
            U = S.ghlEncrypted,
            V = S.href,
            W = S.isRouterLink,
            X = S.shimmed;
        S = S.unshimmedHref;
        var Y = !1,
            Z = !1;
        N = N;
        if (Q) {
            var $;
            N = ($ = N) != null ? $ : Q
        }
        if (X || U) {
            Y = !0;
            N = ($ = N) != null ? $ : "_blank";
            Z = !!d("CometLinkShimUtils").use_rel_no_opener && N === "_blank"
        }
        Q = Array.isArray(K) ? K.join(" ") : K;
        Y && (Q == null || Q.indexOf("nofollow") < 0) && (Q = Q != null ? Q + " nofollow" : "nofollow");
        Z && (Q == null || Q.indexOf("noopener") < 0) && (Q = Q != null ? Q + " noopener" : "noopener");
        U = j(c("BaseLinkNestedPressableContext"));
        $ = L === "presentation" ? "none" : L;
        K = x != null && $ !== "none" ? x : n;
        var Ka = b;
        Y = z;
        Z = E;
        L = A;
        Y = c("useFeedPressEventHandler")(z, V);
        Z = c("useFeedPressEventHandler")(E, V);
        L = c("useFeedPressEventHandler")(A, V);
        x = k(function() {
            return c("mergeRefs")(Ka, P)
        }, [Ka, P]);
        n = c("useCometRouterLinkShimEventHandlers")({
            href: V,
            lynxMode: y,
            onContextMenu: L,
            onHoverStart: C,
            onPress: Y,
            shimmed: X,
            unshimmedHref: S
        });
        b = n.onContextMenu;
        z = n.onHoverStart;
        E = n.onPress;
        A = n.useOrigHref;
        y = k(function() {
            return {
                linkRef: P,
                onNavigate: D,
                passthroughProps: F,
                productAttributionUpdateProps: {
                    fromLink: va,
                    linkContext: Ga,
                    trackingNodes: R
                },
                replace: wa,
                target: M,
                traceParams: Ba
            }
        }, [P, va, Ga, R, D, wa, M, Ba, F]);
        L = c("useCometRouterLinkEventHandlers")({
            dispatcherExtras: y,
            href: V,
            isRouterLink: W,
            onHoverEnd: B,
            onHoverStart: z,
            onPress: E,
            onPressStart: Z,
            prefetchQueriesOnHover: G,
            preloadCodeOnMount: H,
            preventLocalNavigation: J,
            rel: Q,
            target: N
        });
        C = L.onHoverEnd;
        Y = L.onHoverStart;
        n = L.onPress;
        y = L.onPressStart;
        B = A && X ? S : V;
        z = W && N !== "_blank" && Ca != null || B == null || B === "#" || J === !0;
        Z = (E = c("useTransformRelativeUri")(A && X ? S : V)) != null ? E : "#";
        G = {
            accessibilityLabel: K,
            accessibilityRelationship: {
                activedescendant: e,
                controls: g,
                current: ca,
                describedby: da,
                haspopup: fa,
                labelledby: ia,
                owns: ja
            },
            accessibilityState: {
                checked: f,
                disabled: p,
                expanded: ea,
                hidden: ga,
                invalid: ha,
                selected: ka
            },
            className_DEPRECATED: la,
            disabled: p,
            forwardedRef: x,
            link: {
                download: t,
                rel: Q,
                target: N,
                url: Z
            },
            nativeID: ma,
            onBlur: na,
            onContextMenu: b,
            onFocus: oa,
            onFocusChange: pa,
            onFocusVisibleChange: qa,
            onHoverChange: ra,
            onHoverEnd: C,
            onHoverStart: Y,
            onPress: n,
            onPressChange: sa,
            onPressEnd: ta,
            onPressStart: y,
            preventContextMenu: ua,
            preventDefault: z,
            style: xa,
            suppressHydrationWarning: za === !0 || Ja === !0 ? !0 : void 0,
            testID: Aa,
            testOnly_state: {
                disabled: !1,
                focused: !1,
                focusVisible: !1,
                hovered: !1,
                pressed: O
            },
            xstyle: a
        };
        if (s === "block") {
            H = $ === "button" || $ === "menuitem" || $ === "none" || $ === "switch" || $ === "checkbox" || $ === "article" || $ === "radio" || $ === "tab" ? $ : "link";
            L = h.jsx(c("Pressable.react"), babelHelpers["extends"]({}, G, {
                accessibilityRole: H,
                suppressFocusRing: ya,
                tabbable: v,
                children: h.jsx(l, {
                    children: o
                })
            }))
        } else {
            W = $ === "button" || $ === "menuitem" || $ === "menuitemradio" || $ === "menuitemcheckbox" || $ === "none" || $ === "tab" ? $ : "link";
            L = h.jsx(c("PressableText.react"), babelHelpers["extends"]({}, G, {
                accessibilityRole: W,
                direction: "none",
                focusable: v,
                suppressFocusRing: ya,
                children: h.jsx(l, {
                    children: o
                })
            }))
        }
        return h.jsxs(h.Fragment, {
            children: [M === "content" && h.jsx(m, {}), U ? h.jsx(c("BaseNestedPressableHack_DO_NOT_USE.react"), {
                children: L
            }) : L]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function m() {
        var a = c("useCurrentRoute")(),
            b = c("useCometErrorProject")();
        return a != null && a.isCometRootContainer !== !0 && h.jsx(c("RecoverableViolationWithComponentStack.react"), {
            errorMessage: "A link with target=content was rendered in a non-tab-container",
            projectName: (a = b) != null ? a : "comet_infra"
        })
    }
    m.displayName = m.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometContainerPressableContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometPressable.react", ["BaseButton.react", "BaseFocusRing.react", "BaseLink.react", "CometContainerPressableContext", "CometDangerouslySuppressInteractiveElementsContext", "CometPressableOverlay.react", "gkx", "react", "stylex", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useEffect,
        l = b.useRef,
        m = b.useState,
        n = c("gkx")("1721477") || c("gkx")("1459"),
        o = {
            defaultCursor: {
                cursor: "xt0e3qv",
                $$css: !0
            },
            expanding: {
                display: "x78zum5",
                $$css: !0
            },
            hideOutline: {
                outline: "x1a2a7pz",
                $$css: !0
            },
            linkBase: {
                display: "x1rg5ohu",
                $$css: !0
            },
            root: {
                borderTopStartRadius: "x1o1ewxj",
                borderTopEndRadius: "x3x9cwd",
                borderBottomEndRadius: "x1e5q0jg",
                borderBottomStartRadius: "x13rtm0m",
                display: "x3nfvp2",
                flexDirection: "x1q0g3np",
                userSelect: "x87ps6o",
                ":hover_textDecoration": "x1lku1pv",
                $$css: !0
            },
            root_DEPRECATED: {
                borderTopStartRadius: "x1o1ewxj",
                borderTopEndRadius: "x3x9cwd",
                borderBottomEndRadius: "x1e5q0jg",
                borderBottomStartRadius: "x13rtm0m",
                position: "x1n2onr6",
                userSelect: "x87ps6o",
                ":hover_textDecoration": "x1lku1pv",
                $$css: !0
            },
            zIndex: {
                zIndex: "x1vjfegm",
                $$css: !0
            }
        };

    function a(a, b) {
        var d = a.allowClickEventPropagation,
            e = a.children,
            f = a.className_DEPRECATED,
            g = a.cursorDisabled;
        g = g === void 0 ? !1 : g;
        var p = a.xstyle,
            q = a.disabled;
        q = q === void 0 ? !1 : q;
        var r = a.display,
            s = a.expanding;
        s = s === void 0 ? r === "block" : s;
        var t = a.hideFocusOverlay;
        t = t === void 0 ? !1 : t;
        var u = a.hideHoverOverlay;
        u = u === void 0 ? !1 : u;
        var v = a.isContainerTarget,
            w = v === void 0 ? !1 : v,
            x = a.linkProps,
            y = a.onFocusChange;
        v = a.onFocusIn;
        var z = a.onFocusOut,
            A = a.onFocusVisibleChange,
            B = a.onHoverChange,
            C = a.onHoverIn,
            D = a.onHoverOut,
            E = a.onPress,
            F = a.onPressChange,
            G = a.onPressIn,
            H = a.onPressOut,
            I = a.preventContextMenu,
            J = a.overlayDisabled;
        J = J === void 0 ? !1 : J;
        var K = a.overlayOffset,
            L = a.overlayFocusRingPosition,
            M = a.overlayFocusVisibleStyle,
            N = a.overlayHoveredStyle,
            O = a.overlayPressedStyle,
            P = a.overlayRadius,
            Q = a.suppressFocusRing;
        Q = Q === void 0 ? !1 : Q;
        var R = a.testOnly_pressed,
            S = R === void 0 ? !1 : R;
        R = a.testid;
        R = babelHelpers.objectWithoutPropertiesLoose(a, ["allowClickEventPropagation", "children", "className_DEPRECATED", "cursorDisabled", "xstyle", "disabled", "display", "expanding", "hideFocusOverlay", "hideHoverOverlay", "isContainerTarget", "linkProps", "onFocusChange", "onFocusIn", "onFocusOut", "onFocusVisibleChange", "onHoverChange", "onHoverIn", "onHoverOut", "onPress", "onPressChange", "onPressIn", "onPressOut", "preventContextMenu", "overlayDisabled", "overlayOffset", "overlayFocusRingPosition", "overlayFocusVisibleStyle", "overlayHoveredStyle", "overlayPressedStyle", "overlayRadius", "suppressFocusRing", "testOnly_pressed", "testid"]);
        a = m(S);
        var T = a[0],
            U = a[1];
        a = m(!1);
        var V = a[0],
            aa = a[1];
        a = m(!1);
        var W = a[0],
            ba = a[1];
        a = m(!1);
        var X = a[0],
            ca = a[1];
        a = i(function(a) {
            U(a || S), F && F(a)
        }, [F, S]);
        var da = i(function(a) {
                aa(a), y && y(a)
            }, [y]),
            ea = i(function(a) {
                ba(a), A && A(a)
            }, [A]),
            fa = i(function(a) {
                ca(a), B && B(a)
            }, [B]);
        M = J ? null : h.jsx(c("CometPressableOverlay.react"), {
            focusRingPosition: L,
            focusVisible: !t && W,
            focusVisibleStyle: M,
            hovered: !u && X,
            hoveredStyle: N,
            offset: K,
            pressed: T,
            pressedStyle: O,
            radius: P,
            showFocusRing: !0
        });
        u = typeof e === "function" ? e({
            disabled: q,
            focused: V,
            focusVisible: W,
            hovered: X,
            overlay: M,
            pressed: T
        }) : h.jsxs(h.Fragment, {
            children: [e, M]
        });
        N = typeof p === "function" ? p({
            disabled: q,
            focused: V,
            focusVisible: W,
            hovered: X,
            pressed: T
        }) : p;
        var Y = j(c("CometContainerPressableContext"));
        K = j(c("CometDangerouslySuppressInteractiveElementsContext"));
        O = W && (t || J) && !Q;
        P = [r === "inline" ? o.root_DEPRECATED : o.root, g === !0 && o.defaultCursor, s && o.expanding, x != null && o.linkBase, !W && o.hideOutline, N, O && (L === "inset" ? c("BaseFocusRing.react").focusRingInsetXStyle : c("BaseFocusRing.react").focusRingXStyle), Y != null && o.zIndex];
        e = {
            onBlur: z,
            onClick: E,
            onFocus: v,
            onFocusChange: da,
            onFocusVisibleChange: ea,
            onHoverChange: fa,
            onHoverEnd: D,
            onHoverStart: C,
            onPressChange: a,
            onPressEnd: H,
            onPressStart: G
        };
        var ga = l(null),
            Z = l(null),
            $ = R.onContextMenu;
        k(function() {
            w && Y && Y.onMount({
                onContextMenu: function(a) {
                    I === !0 && a.preventDefault(), $ != null && $(a)
                },
                onPress: function(a) {
                    a = Z.current;
                    a && a.click()
                },
                target: x == null ? void 0 : x.target,
                url: x == null ? void 0 : x.url
            }, ga)
        }, [Y, w, R, $, I, x == null ? void 0 : x.url, x == null ? void 0 : x.target]);
        M = c("useMergeRefs")(b, Z);
        if (K) {
            V = r === "inline" ? "span" : "div";
            return h.jsx(V, babelHelpers["extends"]({
                className_DEPRECATED: f,
                display: r === "inline" ? r : "block",
                preventContextMenu: I
            }, R, {
                className: c("stylex")(P),
                "data-testid": void 0,
                ref: M,
                children: u
            }))
        }
        if (x != null) {
            X = x.url;
            T = babelHelpers.objectWithoutPropertiesLoose(x, ["url"]);
            p = babelHelpers["extends"]({}, T, {
                href: X
            });
            return h.jsx(c("BaseLink.react"), babelHelpers["extends"]({}, e, R, p, {
                className_DEPRECATED: f,
                disabled: q,
                display: r === "inline" ? r : "block",
                preventContextMenu: I,
                ref: M,
                suppressFocusRing: !O || n,
                testid: void 0,
                xstyle: P,
                children: u
            }))
        }
        return h.jsx(c("BaseButton.react"), babelHelpers["extends"]({}, e, R, {
            allowClickEventPropagation: d,
            className_DEPRECATED: f,
            disabled: q,
            display: r === "inline" ? r : "block",
            preventContextMenu: I,
            ref: M,
            suppressFocusRing: !O || n,
            testid: void 0,
            xstyle: P,
            children: u
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometTextLangContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(void 0);
    g["default"] = b
}), 98);
__d("BaseContextualLayerAnchorRootContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        current: document.body
    });
    g["default"] = b
}), 98);
__d("BaseDOMContainer.react", ["react", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useLayoutEffect,
        j = b.useRef;

    function a(a, b) {
        var d = a.node,
            e = j(null);
        i(function() {
            var a = e.current;
            if (d != null && a != null) {
                a.appendChild(d);
                return function() {
                    a.removeChild(d)
                }
            }
        }, [d]);
        a = c("useMergeRefs")(b, e);
        return h.jsx("div", {
            ref: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.memo(h.forwardRef(a));
    g["default"] = e
}), 98);
__d("BaseContextualLayerAnchorRoot.react", ["BaseContextualLayerAnchorRootContext", "BaseDOMContainer.react", "ExecutionEnvironment", "react", "useStable", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        a = a.children;
        var b = c("useStable")(function() {
                return c("ExecutionEnvironment").canUseDOM ? document.createElement("div") : null
            }),
            d = c("useUnsafeRef_DEPRECATED")(b);
        return h.jsxs(h.Fragment, {
            children: [h.jsx(c("BaseContextualLayerAnchorRootContext").Provider, {
                value: d,
                children: a
            }), h.jsx(c("BaseDOMContainer.react"), {
                node: b
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseHeadingContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(1);
    g["default"] = b
}), 98);
__d("BaseTextContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    c = d("react");
    var i = c.useContext,
        j = c.useMemo,
        k = h.createContext(null);

    function a(a) {
        var b = a.children,
            c = a.nested;
        a = j(function() {
            return {
                nested: c
            }
        }, [c]);
        return h.jsx(k.Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return i(k)
    }
    g.BaseTextContextProvider = a;
    g.useBaseTextContext = b
}), 98);
__d("BaseHeading.react", ["BaseHeadingContext", "BaseTextContext", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = {
            root: {
                color: "x1heor9g",
                fontSize: "x1qlqyl8",
                fontWeight: "x1pd3egz",
                outline: "x1a2a7pz",
                $$css: !0
            }
        };

    function a(a, b) {
        var e = a.children,
            f = a.isPrimaryHeading,
            g = f === void 0 ? !1 : f;
        f = a.testid;
        f = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "isPrimaryHeading", "testid", "xstyle"]);
        var l = i(c("BaseHeadingContext")),
            m = j(function() {
                return g ? "h1" : "h" + Math.max(Math.min(l, 6), 2)
            }, [g, l]),
            n = d("BaseTextContext").useBaseTextContext();
        n = (n == null ? void 0 : n.nested) === !0;
        return h.jsx(m, babelHelpers["extends"]({}, a, {
            className: c("stylex")(k.root, f),
            "data-testid": void 0,
            dir: n ? void 0 : "auto",
            ref: b,
            children: e
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("BasePortalTargetContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(document.body);
    g["default"] = b
}), 98);
__d("BaseThemeConfigContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = {
        darkClassName: null,
        darkVariables: {},
        lightClassName: null,
        lightVariables: {}
    };
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("BaseThemeDisplayModeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("useCurrentDisplayMode", ["BaseThemeDisplayModeContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext,
        i = "light";

    function a() {
        var a;
        return (a = h(c("BaseThemeDisplayModeContext"))) != null ? a : i
    }
    g["default"] = a
}), 98);
__d("BaseThemeProvider.react", ["BaseThemeConfigContext", "BaseThemeDisplayModeContext", "react", "useCurrentDisplayMode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo;

    function a(a) {
        var b = a.children,
            d = a.config;
        a = a.displayMode;
        var e = i(c("BaseThemeConfigContext")),
            f = c("useCurrentDisplayMode")(),
            g = (a = a) != null ? a : f;
        a = j(function() {
            var a;
            d != null && d.type === "CLASSNAMES" ? a = g === "dark" ? d.dark : d.light : a = g === "dark" ? e.darkClassName : e.lightClassName;
            return a != null ? {
                $$css: !0,
                theme: a
            } : null
        }, [d, e.darkClassName, e.lightClassName, g]);
        f = a;
        a = j(function() {
            if (d != null)
                if (d.type === "VARIABLES") return babelHelpers["extends"]({}, e, {
                    darkVariables: babelHelpers["extends"]({}, e.darkVariables, d.dark),
                    lightVariables: babelHelpers["extends"]({}, e.lightVariables, d.light)
                });
                else if (d.type === "CLASSNAMES") return babelHelpers["extends"]({}, e, {
                darkClassName: d.dark,
                lightClassName: d.light
            });
            return e
        }, [d, e]);
        var l = k(g === "dark" ? a.darkVariables : a.lightVariables);
        return h.jsx(c("BaseThemeConfigContext").Provider, {
            value: a,
            children: h.jsx(c("BaseThemeDisplayModeContext").Provider, {
                value: g,
                children: b(f, l)
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function k(a) {
        var b = {};
        Object.keys(a).forEach(function(c) {
            b["--" + c] = a[c]
        });
        return b
    }
    g["default"] = a
}), 98);
__d("CometSSRClientRender", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = "CometSSRClientRenderError",
        h = function(a) {
            this.message = g + ": " + a, this.name = "CometSSRClientRenderError"
        };

    function a(a) {
        throw new h(a)
    }
    f.CometSSRClientRenderError = g;
    f.ClientRenderSentinel = h;
    f.CometSSRClientRender = a
}), 66);
__d("CometSSRReactFizzEnvironment", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        window.__isReactFizzContext = a
    }

    function b() {
        var a;
        return !!((a = window) == null ? void 0 : a.__isReactFizzContext)
    }
    f.setReactFizzEnvironment = a;
    f.isReactFizzEnvironment = b
}), 66);
__d("BasePortal.react", ["BaseDOMContainer.react", "BasePortalTargetContext", "BaseThemeProvider.react", "CometSSRClientRender", "CometSSRReactFizzEnvironment", "ExecutionEnvironment", "Promise", "ReactDOMComet", "react", "stylex", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function a(a) {
        var e = a.children,
            f = a.hidden,
            g = f === void 0 ? !1 : f;
        f = a.target;
        var j = a.xstyle;
        a = i(c("BasePortalTargetContext"));
        f = f || a;
        var k = c("useStable")(function() {
            return c("ExecutionEnvironment").canUseDOM ? document.createElement("div") : null
        });
        if (!c("ExecutionEnvironment").canUseDOM)
            if (d("CometSSRReactFizzEnvironment").isReactFizzEnvironment()) throw d("CometSSRClientRender").CometSSRClientRender("BasePortal: Portals are not currently supported by the server renderer.");
            else throw b("Promise").reject();
        return f != null ? d("ReactDOMComet").createPortal(h.jsx(c("BaseThemeProvider.react"), {
            children: function(a, b) {
                return h.jsxs("div", babelHelpers["extends"]({}, g && {
                    hidden: !0
                }, {
                    className: c("stylex")(a, j) || void 0,
                    style: b,
                    children: [h.jsx(c("BasePortalTargetContext").Provider, {
                        value: k,
                        children: e
                    }), h.jsx(c("BaseDOMContainer.react"), {
                        node: k
                    })]
                }))
            }
        }), f) : null
    }
    g["default"] = a
}), 98);
__d("BaseRowContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        columns: 1,
        wrap: "none"
    });
    g["default"] = b
}), 98);
__d("BaseView.react", ["LegacyHidden", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            hidden: {
                display: "x1s85apg",
                $$css: !0
            },
            root: {
                boxSizing: "x9f619",
                position: "x1n2onr6",
                zIndex: "x1ja2u2z",
                $$css: !0
            }
        };

    function a(a, b) {
        var d = a.children,
            e = a.suppressHydrationWarning,
            f = a.testid,
            g = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "suppressHydrationWarning", "testid", "xstyle"]);
        var j = a.hidden === !0;
        return h.jsx(c("LegacyHidden"), {
            htmlAttributes: babelHelpers["extends"]({}, a, c("testID")(f), {
                className: c("stylex")(i.root, g, j && i.hidden)
            }),
            mode: j ? "hidden" : "visible",
            ref: b,
            suppressHydrationWarning: e,
            children: d
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseRow.react", ["BaseRowContext", "BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo,
        j = {
            expanding: {
                flexBasis: "x1r8uery",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                minWidth: "xeuugli",
                $$css: !0
            },
            row: {
                display: "x78zum5",
                flexShrink: "x2lah0s",
                $$css: !0
            }
        },
        k = {
            center: {
                justifyContent: "xl56j7k",
                $$css: !0
            },
            end: {
                justifyContent: "x13a6bvl",
                $$css: !0
            },
            justify: {
                justifyContent: "x1qughib",
                $$css: !0
            },
            start: {
                justifyContent: "x1nhvcw1",
                $$css: !0
            }
        },
        l = {
            bottom: {
                alignItems: "xuk3077",
                $$css: !0
            },
            center: {
                alignItems: "x6s0dn4",
                $$css: !0
            },
            stretch: {
                alignItems: "x1qjc9v5",
                $$css: !0
            },
            top: {
                alignItems: "x1cy8zhl",
                $$css: !0
            }
        },
        m = {
            backward: {
                flexDirection: "x15zctf7",
                $$css: !0
            },
            forward: {
                flexDirection: "x1q0g3np",
                $$css: !0
            }
        },
        n = {
            backward: {
                flexWrap: "x8hhl5t",
                $$css: !0
            },
            forward: {
                flexWrap: "x1a02dak",
                $$css: !0
            },
            none: {
                flexWrap: "xozqiw3",
                $$css: !0
            }
        },
        o = {
            end: "start",
            start: "end"
        };

    function a(a, b) {
        var d = a.align;
        d = d === void 0 ? "justify" : d;
        var e = a.children,
            f = a.columns,
            g = f === void 0 ? 0 : f;
        f = a.direction;
        f = f === void 0 ? "forward" : f;
        var p = a.expanding;
        p = p === void 0 ? !1 : p;
        var q = a.verticalAlign;
        q = q === void 0 ? "stretch" : q;
        var r = a.wrap,
            s = r === void 0 ? "none" : r;
        r = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["align", "children", "columns", "direction", "expanding", "verticalAlign", "wrap", "xstyle"]);
        var t = i(function() {
            return {
                columns: g,
                wrap: s
            }
        }, [g, s]);
        return h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            ref: b,
            xstyle: [j.row, p && j.expanding, k[f === "backward" && (d === "start" || d === "end") ? o[d] : d], l[q], n[s], m[f], r],
            children: h.jsx(c("BaseRowContext").Provider, {
                value: t,
                children: e
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseRowItem.react", ["BaseRowContext", "BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            expanding: {
                flexBasis: "x1r8uery",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                $$css: !0
            },
            expandingWithWrap: {
                flexBasis: "x1l7klhg",
                $$css: !0
            },
            item: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexShrink: "x2lah0s",
                maxWidth: "x193iq5w",
                minWidth: "xeuugli",
                $$css: !0
            },
            item_DEPRECATED: {
                maxWidth: "x193iq5w",
                minWidth: "xeuugli",
                $$css: !0
            }
        },
        k = {
            1: {
                flexBasis: "x1l7klhg",
                $$css: !0
            },
            2: {
                flexBasis: "x4pfjvb",
                $$css: !0
            },
            3: {
                flexBasis: "x1upgvki",
                $$css: !0
            },
            4: {
                flexBasis: "xhnlq4v",
                $$css: !0
            },
            5: {
                flexBasis: "x15foiic",
                $$css: !0
            },
            6: {
                flexBasis: "xd8mu38",
                $$css: !0
            },
            7: {
                flexBasis: "xjtu8lc",
                $$css: !0
            },
            8: {
                flexBasis: "xvuwby9",
                $$css: !0
            },
            9: {
                flexBasis: "x1m2iiog",
                $$css: !0
            },
            10: {
                flexBasis: "x3cfelu",
                $$css: !0
            }
        },
        l = {
            bottom: {
                alignSelf: "xpvyfi4",
                $$css: !0
            },
            center: {
                alignSelf: "xamitd3",
                $$css: !0
            },
            stretch: {
                alignSelf: "xkh2ocl",
                $$css: !0
            },
            top: {
                alignSelf: "xqcrz7y",
                $$css: !0
            }
        };

    function a(a, b) {
        var d = a.expanding;
        d = d === void 0 ? !1 : d;
        var e = a.useDeprecatedStyles;
        e = e === void 0 ? !1 : e;
        var f = a.verticalAlign,
            g = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["expanding", "useDeprecatedStyles", "verticalAlign", "xstyle"]);
        var m = i(c("BaseRowContext")),
            n = m.columns;
        m = m.wrap;
        return h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            ref: b,
            xstyle: [e ? j.item_DEPRECATED : j.item, d && j.expanding, d && m !== "none" && j.expandingWithWrap, n > 0 && k[n], f != null && l[f], g]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseScrollableAreaContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext([]);
    g["default"] = b
}), 98);
__d("BaseTheme.react", ["BaseThemeProvider.react", "BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var d = a.config,
            e = a.displayMode,
            f = a.style,
            g = a.xstyle,
            i = babelHelpers.objectWithoutPropertiesLoose(a, ["config", "displayMode", "style", "xstyle"]);
        return h.jsx(c("BaseThemeProvider.react"), {
            config: d,
            displayMode: e,
            children: function(a, d) {
                return h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, i, {
                    ref: b,
                    style: babelHelpers["extends"]({}, d, f),
                    xstyle: [a, g]
                }))
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseViewportMarginsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        bottom: 0,
        left: 0,
        right: 0,
        top: 0
    });
    g["default"] = b
}), 98);
__d("LayoutAnimationBoundaryContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("useDoubleEffectHack_DO_NOT_USE_THIS_IS_TRACKED", ["clearTimeout", "err", "react", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef;

    function a(a, b) {
        var d = i(null),
            e = i();
        h(function() {
            var b = d.current;
            b !== null ? (c("clearTimeout")(b), d.current = null) : e.current = a();
            return function() {
                function a() {
                    d.current = null;
                    var a = e.current;
                    a && a()
                }
                d.current = c("setTimeout")(a, 0)
            }
        }, [])
    }
    e = h;
    f = e;
    g["default"] = f
}), 98);
__d("useFadeEffect", ["clearTimeout", "react", "setTimeout", "useDoubleEffectHack_DO_NOT_USE_THIS_IS_TRACKED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useLayoutEffect,
        j = b.useReducer,
        k = b.useRef,
        l = 1e3;

    function m(a, b) {
        switch (b.type) {
            case "start":
                return {
                    isTransitioning: !0,
                    shouldBeVisible: b.shouldBeVisible
                };
            case "finish":
                return {
                    isTransitioning: !1,
                    shouldBeVisible: a.shouldBeVisible
                };
            default:
                return a
        }
    }

    function a(a) {
        var b = k(null),
            d = j(m, {
                isTransitioning: !1,
                shouldBeVisible: !1
            }),
            e = d[0],
            f = e.isTransitioning;
        e = e.shouldBeVisible;
        var g = d[1],
            n = k(null),
            o = k(null);
        c("useDoubleEffectHack_DO_NOT_USE_THIS_IS_TRACKED")(function() {
            return function() {
                n.current != null && c("clearTimeout")(n.current), o.current != null && window.cancelAnimationFrame(o.current)
            }
        }, []);
        var p = h(function() {
                g({
                    type: "finish"
                }), n.current != null && c("clearTimeout")(n.current), n.current = null
            }, []),
            q = h(function(a) {
                o.current != null && window.cancelAnimationFrame(o.current), o.current = window.requestAnimationFrame(function() {
                    g({
                        shouldBeVisible: a,
                        type: "start"
                    }), o.current = null, n.current != null && c("clearTimeout")(n.current), n.current = c("setTimeout")(p, l)
                })
            }, [p]),
            r = k(!1);
        i(function() {
            r.current !== a && (!a || b.current != null) && q(a), r.current = a
        }, [a, q]);
        d = h(function(a) {
            var c = b.current;
            b.current = a;
            a != null ? (a.addEventListener != null && (a.addEventListener("transitionend", p), a.addEventListener("webkitTransitionEnd", p)), r.current === !0 && q(!0)) : c != null && c.removeEventListener != null && (c.removeEventListener("transitionend", p), c.removeEventListener("webkitTransitionEnd", p))
        }, [p, q]);
        f = f || e || a;
        return [f, e, d]
    }
    g["default"] = a
}), 98);
__d("CometContextualLayerAnchorRoot.react", ["BaseContextualLayerAnchorRoot.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx(c("BaseContextualLayerAnchorRoot.react"), babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDensityModeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = !1;
    c = a.createContext([b, function() {}]);
    e = c;
    g["default"] = e
}), 98);
__d("TetraText.react", ["BaseHeading.react", "BaseTextContext", "CometDensityModeContext", "CometLineClamp.react", "CometTextContext", "CometTextLangContext", "CometTextTypography", "cr:2099", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useContext,
        j = e.useMemo;
    b = (e = b("cr:2099")) != null ? e : {
        useTranslationKeyForTextParent: function() {}
    };
    var k = b.useTranslationKeyForTextParent,
        l = {
            base: {
                maxWidth: "x193iq5w",
                minWidth: "xeuugli",
                wordBreak: "x13faqbe",
                wordWrap: "x1vvkbs",
                $$css: !0
            },
            block: {
                display: "x1lliihq",
                "::after_content": "x1s928wv",
                "::after_display": "xhkezso",
                "::after_height": "x1gmr53x",
                "::before_content": "x1cpjm7i",
                "::before_display": "x1fgarty",
                "::before_height": "x1943h6x",
                $$css: !0
            },
            heading: {
                maxWidth: "x193iq5w",
                minWidth: "xeuugli",
                $$css: !0
            },
            preserveNewLines: {
                whiteSpace: "x1fj9vlw",
                $$css: !0
            }
        },
        m = {
            center: {
                textAlign: "x2b8uid",
                $$css: !0
            },
            end: {
                textAlign: "xp4054r",
                $$css: !0
            },
            start: {
                textAlign: "x1yc453h",
                $$css: !0
            }
        },
        n = {
            blueLink: {
                color: "x1fey0fg",
                $$css: !0
            },
            disabled: {
                color: "x1dntmbh",
                $$css: !0
            },
            disabledButton: {
                color: "x1x80s81",
                $$css: !0
            },
            highlight: {
                color: "x1qq9wsj",
                $$css: !0
            },
            negative: {
                color: "x1a1m0xk",
                $$css: !0
            },
            placeholder: {
                color: "x12scifz",
                $$css: !0
            },
            positive: {
                color: "x6u5lvz",
                $$css: !0
            },
            primary: {
                color: "xzsf02u",
                $$css: !0
            },
            primaryButton: {
                color: "xtk6v10",
                $$css: !0
            },
            primaryDeemphasizedButton: {
                color: "x1mvi0mv",
                $$css: !0
            },
            primaryOnMedia: {
                color: "x17z8epw",
                $$css: !0
            },
            secondary: {
                color: "xi81zsa",
                $$css: !0
            },
            secondaryButton: {
                color: "x1dem4cn",
                $$css: !0
            },
            secondaryOnMedia: {
                color: "xkxfvhb",
                $$css: !0
            },
            tertiary: {
                color: "x12scifz",
                $$css: !0
            },
            white: {
                color: "x14ctfv",
                $$css: !0
            }
        },
        o = {
            12: {
                fontSize: "x1pg5gke",
                lineHeight: "xvq8zen",
                $$css: !0
            },
            13: {
                fontSize: "x1nxh6w3",
                lineHeight: "x1sibtaa",
                $$css: !0
            },
            14: {
                fontSize: "x1f6kntn",
                lineHeight: "x1ruc54x",
                $$css: !0
            },
            15: {
                fontSize: "x6prxxf",
                lineHeight: "xvq8zen",
                $$css: !0
            },
            16: {
                fontSize: "x1jchvi3",
                lineHeight: "x132q4wb",
                $$css: !0
            },
            17: {
                fontSize: "x1lkfr7t",
                lineHeight: "x1lbecb7",
                $$css: !0
            },
            20: {
                fontSize: "x1603h9y",
                lineHeight: "x1u7k74",
                $$css: !0
            },
            24: {
                fontSize: "xngnso2",
                lineHeight: "x1qb5hxa",
                $$css: !0
            },
            28: {
                fontSize: "x1q74xe4",
                lineHeight: "xyesn5m",
                $$css: !0
            },
            32: {
                fontSize: "x579bpy",
                lineHeight: "xjkpybl",
                $$css: !0
            }
        },
        p = {
            12: {
                fontSize: "x1pg5gke",
                lineHeight: "xvq8zen",
                $$css: !0
            },
            13: {
                fontSize: "x1pg5gke",
                lineHeight: "x1sibtaa",
                $$css: !0
            },
            15: {
                fontSize: "x1f6kntn",
                lineHeight: "xvq8zen",
                $$css: !0
            },
            17: {
                fontSize: "x1jchvi3",
                lineHeight: "x1lbecb7",
                $$css: !0
            },
            20: {
                fontSize: "x1603h9y",
                lineHeight: "x1u7k74",
                $$css: !0
            },
            24: {
                fontSize: "xngnso2",
                lineHeight: "x1qb5hxa",
                $$css: !0
            },
            28: {
                fontSize: "x1q74xe4",
                lineHeight: "xyesn5m",
                $$css: !0
            },
            32: {
                fontSize: "x579bpy",
                lineHeight: "xjkpybl",
                $$css: !0
            }
        },
        q = {
            bold: {
                fontWeight: "x1xlr1w8",
                $$css: !0
            },
            medium: {
                fontWeight: "xk50ysn",
                $$css: !0
            },
            normal: {
                fontWeight: "xo1l8bm",
                $$css: !0
            },
            semibold: {
                fontWeight: "x1s688f",
                $$css: !0
            }
        },
        r = {
            1: {
                "::before_marginTop": "x1ckan80",
                $$css: !0
            },
            2: {
                "::before_marginTop": "x1s3etm8",
                $$css: !0
            },
            3: {
                "::before_marginTop": "x1tu3fi",
                $$css: !0
            },
            4: {
                "::before_marginTop": "x4zkp8e",
                $$css: !0
            },
            5: {
                "::before_marginTop": "xudqn12",
                $$css: !0
            },
            6: {
                "::before_marginTop": "xtoi2st",
                $$css: !0
            },
            7: {
                "::before_marginTop": "x14z4hjw",
                $$css: !0
            },
            8: {
                "::before_marginTop": "x1ill7wo",
                $$css: !0
            },
            9: {
                "::before_marginTop": "xhau9xz",
                $$css: !0
            },
            10: {
                "::before_marginTop": "x14qwyeo",
                $$css: !0
            }
        },
        s = {
            1: {
                "::after_marginBottom": "xo8pqpo",
                $$css: !0
            },
            2: {
                "::after_marginBottom": "xlf94lp",
                $$css: !0
            },
            3: {
                "::after_marginBottom": "x676frb",
                $$css: !0
            },
            4: {
                "::after_marginBottom": "x3x7a5m",
                $$css: !0
            },
            5: {
                "::after_marginBottom": "x41vudc",
                $$css: !0
            },
            6: {
                "::after_marginBottom": "xw06pyt",
                $$css: !0
            },
            7: {
                "::after_marginBottom": "x1g2y4wz",
                $$css: !0
            },
            8: {
                "::after_marginBottom": "x1x48ksl",
                $$css: !0
            },
            9: {
                "::after_marginBottom": "x1guzi96",
                $$css: !0
            },
            10: {
                "::after_marginBottom": "x1y9wsrc",
                $$css: !0
            }
        },
        t = {
            1: {
                paddingBottom: "x1j85h84",
                $$css: !0
            },
            2: {
                paddingBottom: "x1120s5i",
                $$css: !0
            },
            3: {
                paddingBottom: "xg8j3zb",
                $$css: !0
            }
        },
        u = {
            disabled: "disabledButton",
            highlight: "primaryDeemphasizedButton",
            secondary: "secondaryButton",
            white: "primaryButton"
        };

    function v(a, b) {
        return b ? (b = u[a]) != null ? b : a : a
    }

    function a(a, b) {
        var e = a.align;
        e = e === void 0 ? "auto" : e;
        var f = a.children,
            g = a.color,
            u = a.dir;
        u = u === void 0 ? "auto" : u;
        var w = a.id,
            x = a.isPrimaryHeading;
        x = x === void 0 ? !1 : x;
        var y = a.isSemanticHeading;
        y = y === void 0 ? !1 : y;
        var z = a.numberOfLines,
            A = a.preserveNewLines;
        A = A === void 0 ? !1 : A;
        var B = a.suppressHydrationWarning,
            C = a.testid;
        C = a.truncationTooltip;
        var D = a.type;
        a = i(c("CometDensityModeContext"));
        a = a[0];
        var E = i(c("CometTextLangContext")),
            F = c("CometTextTypography")[D],
            G = F.defaultColor;
        G = G === void 0 ? "primary" : G;
        var H = F.fontFamily,
            I = F.fontSize,
            J = F.fontWeight;
        J = J === void 0 ? "normal" : J;
        F = F.offsets;
        F = F === void 0 ? [0, 0] : F;
        var K = F.length === 3 ? F[2] : 0,
            L = v((g = g) != null ? g : G, D === "button1" || D === "button2");
        g = j(function() {
            return {
                color: L,
                type: D
            }
        }, [L, D]);
        G = d("BaseTextContext").useBaseTextContext();
        G = (G == null ? void 0 : G.nested) === !0;
        var M = k();
        g = h.jsx(d("BaseTextContext").BaseTextContextProvider, {
            nested: !0,
            children: h.jsx(c("CometTextContext").Provider, {
                value: g,
                children: h.jsx("span", {
                    className: c("stylex")(l.base, H, !G && l.block, !G && r[F[0]], !G && s[z != null ? F[1] + K : F[1]], a ? p[I] : o[I], q[J], n[L], e !== "auto" && m[e], A && l.preserveNewLines),
                    "data-testid": void 0,
                    dir: G ? void 0 : u,
                    id: w,
                    lang: E,
                    ref: b,
                    suppressHydrationWarning: B,
                    children: z != null ? h.jsx(c("CometLineClamp.react"), {
                        lines: z,
                        truncationTooltip: C,
                        xstyle: K !== 0 && t[K],
                        children: f
                    }) : f
                }, M)
            })
        });
        return y ? h.jsx(c("BaseHeading.react"), {
            isPrimaryHeading: x,
            xstyle: l.heading,
            children: g
        }) : g
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    e.displayName = "TetraText";
    b = e;
    g["default"] = b
}), 98);
__d("ActiveFocusRegionUtilsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    c = b;
    g["default"] = c
}), 98);
__d("getTabbableNodes", [], (function(a, b, c, d, e, f) {
    function a(a, b) {
        var c = document.activeElement,
            d = function(b, d, e) {
                return e === c ? !0 : a(b, d, e) && e.offsetWidth > 0 && e.offsetHeight > 0 && e.tabIndex !== -1 && window.getComputedStyle(e).visibility !== "hidden"
            };
        b = c ? b.DO_NOT_USE_queryAllNodes(d) : null;
        if (b === null) return [null, null, null, 0, null];
        d = {};
        for (var e = b, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var h;
            if (f) {
                if (g >= e.length) break;
                h = e[g++]
            } else {
                g = e.next();
                if (g.done) break;
                h = g.value
            }
            h = h;
            if (h instanceof HTMLInputElement && h.tagName === "INPUT" && h.type === "radio" && h.name != null) {
                var i;
                d[h.name] = [].concat((i = d[h.name]) != null ? i : [], [h])
            }
        }
        var j = Object.values(d).map(function(a) {
            if (a.find(function(a) {
                    return a.checked
                })) return a.filter(function(a) {
                return !a.checked
            });
            a[0];
            a = a.slice(1);
            return a
        }).flat();
        b = b.filter(function(a) {
            return !j.includes(a)
        });
        i = b[0];
        h = b[b.length - 1];
        g = b.indexOf(c);
        f = null;
        g !== -1 && (f = b[g]);
        return [b, i, h, g, f]
    }
    f["default"] = a
}), 66);
__d("FocusManager", ["getTabbableNodes"], (function(a, b, c, d, e, f, g) {
    var h = !1,
        i = !1,
        j = !1,
        k = 500;

    function l() {
        try {
            var a = document.createElement("div");
            a.addEventListener("focus", function(a) {
                a.preventDefault(), a.stopPropagation()
            }, !0);
            a.focus(Object.defineProperty({}, "preventScroll", {
                get: function() {
                    i = !0
                }
            }))
        } catch (a) {}
    }

    function m(a) {
        a = a.parentElement;
        var b = [],
            c = document.scrollingElement || document.documentElement;
        while (a && a !== c) {
            var d = a,
                e = d.offsetHeight;
            d = d.offsetWidth;
            (e < a.scrollHeight || d < a.scrollWidth) && b.push([a, a.scrollTop, a.scrollLeft]);
            a = a.parentElement
        }
        c && b.push([c, c.scrollTop, c.scrollLeft]);
        return b
    }

    function n(a) {
        for (var b = 0; b < a.length; b++) {
            var c = a[b],
                d = c[0],
                e = c[1];
            c = c[2];
            d.scrollTop = e;
            d.scrollLeft = c
        }
    }

    function a(a, b) {
        a = Array.isArray(a) ? a : [a];
        for (var c = 0; c < a.length; c++) {
            var d = b.DO_NOT_USE_queryAllNodes(a[c]);
            if (d) return d
        }
        return null
    }

    function o(a, b) {
        a = Array.isArray(a) ? a : [a];
        for (var c = 0; c < a.length; c++) {
            var d = b.DO_NOT_USE_queryFirstNode(a[c]);
            if (d) return d
        }
        return null
    }

    function b(a, b, c) {
        c = c || {};
        var d = c.preventScroll,
            e = c.focusWithoutUserIntent;
        c = c.focusWithAutoFocus;
        a = o(a, b);
        a != null && p(a, {
            preventScroll: d,
            focusWithoutUserIntent: e,
            focusWithAutoFocus: c
        })
    }

    function d() {
        return h
    }

    function e(a) {
        return a._focusWithAutoFocus === !0
    }

    function p(a, b) {
        b = b || {};
        var c = b.preventScroll,
            d = b.focusWithoutUserIntent;
        b = b.focusWithAutoFocus;
        if (a !== null) {
            j || (j = !0, l());
            var e = a._tabIndexState;
            if (e && e.canTab === !1) return;
            e = e ? e.value : a.tabIndex;
            a.tabIndex = -1;
            var f = h;
            c = c || !1;
            b === !0 && (a._focusWithAutoFocus = !0, window.setTimeout(function() {
                a._focusWithAutoFocus = !1
            }, k));
            try {
                h = d || !1;
                b = a.__lexicalEditor;
                if (b !== void 0) b.focus();
                else if (!c) t(a);
                else if (i) t(a, {
                    preventScroll: !0
                });
                else {
                    d = m(a);
                    t(a);
                    n(d)
                }
            } catch (a) {} finally {
                h = f
            }
            a.tabIndex = e
        }
    }

    function f(a, b, d) {
        a = c("getTabbableNodes")(a, b);
        b = a[0];
        var e = a[2],
            f = a[3];
        a = a[4];
        a !== null && a !== e && b && p(b[f + 1], {
            preventScroll: d
        })
    }

    function q(a, b, d) {
        a = c("getTabbableNodes")(a, b);
        b = a[0];
        var e = a[1],
            f = a[3];
        a = a[4];
        a !== null && a !== e && b && p(b[f - 1], {
            preventScroll: d
        })
    }

    function r(a, b, d, e, f) {
        a = c("getTabbableNodes")(a, b);
        b = a[0];
        var g = a[1],
            h = a[2],
            i = a[3];
        a = a[4];
        if (a === null || b === null) return;
        a === h ? f != null ? f() : e === !0 && (p(g), d.preventDefault(), d.stopPropagation()) : (p(b[i + 1]), d.preventDefault(), d.stopPropagation())
    }

    function s(a, b, d, e, f) {
        a = c("getTabbableNodes")(a, b);
        b = a[0];
        var g = a[1],
            h = a[2],
            i = a[3];
        a = a[4];
        if (a === null || b === null) return;
        a === g ? f != null ? f() : e === !0 && (p(h), d.preventDefault(), d.stopPropagation()) : (p(b[i - 1]), d.preventDefault(), d.stopPropagation())
    }
    var t = function(a, b) {
        (a.focus || HTMLElement.prototype.focus).call(a, b)
    };
    g.getAllNodesFromOneOrManyQueries = a;
    g.getFirstNodeFromOneOrManyQueries = o;
    g.focusFirst = b;
    g.isFocusingWithoutUserIntent = d;
    g.wasElementAutoFocused = e;
    g.focusElement = p;
    g.focusNext = f;
    g.focusPrevious = q;
    g.focusNextContained = r;
    g.focusPreviousContained = s
}), 98);
__d("FocusRegionType", ["$InternalEnum", "react"], (function(a, b, c, d, e, f, g) {
    d("react");
    a = b("$InternalEnum").Mirrored(["Nearest", "First"]);
    g.RecoverFocusStrategy = a
}), 98);
__d("ReactKeyboardEvent.react", ["ReactUseEvent.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useEffect,
        i = {
            passive: !0
        };

    function a(a, b) {
        var d = b.disabled,
            e = d === void 0 ? !1 : d,
            f = b.onKeyDown,
            g = b.onKeyUp,
            j = c("ReactUseEvent.react")("keydown"),
            k = c("ReactUseEvent.react")("keyup", i);
        h(function() {
            var b = a.current;
            b !== null && (j.setListener(b, !e && f || null), k.setListener(b, !e && g || null))
        }, [e, f, j, k, a, g])
    }
    g.useKeyboard = a
}), 98);
__d("setElementCanTab", [], (function(a, b, c, d, e, f) {
    c = Object.getOwnPropertyDescriptor(HTMLElement.prototype, "tabIndex");
    d = Object.getOwnPropertyDescriptor(SVGElement.prototype, "tabIndex");
    e = function(a) {
        return a
    };
    var g = c ? c.set : e,
        h = d ? d.set : e;

    function i(a) {
        return a instanceof SVGElement ? h : g
    }

    function a(a, b, c) {
        c === void 0 && (c = !1);
        var d = a._tabIndexState,
            e = i(a);
        if (!d) {
            b && c && a.tabIndex < 0 && (a.tabIndex = 0);
            var f = {
                value: a.tabIndex,
                canTab: b
            };
            a._tabIndexState = f;
            b || (a.tabIndex = -1);
            Object.defineProperty(a, "tabIndex", {
                enumerable: !1,
                configurable: !0,
                get: function() {
                    return f.canTab ? f.value : -1
                },
                set: function(a) {
                    f.canTab && typeof e === "function" && e.call(this, a), f.value = a
                }
            })
        } else d.canTab !== b && typeof e === "function" && (e.call(a, b ? d.value : -1), d.canTab = b)
    }

    function b(a) {
        var b = a._tabIndexState;
        if (!b) return a.tabIndex > 0;
        else return b.canTab
    }
    f.setElementCanTab = a;
    f.canElementTab = b
}), 66);
__d("FocusRegion.react", ["ActiveFocusRegionUtilsContext", "FocusManager", "FocusRegionType", "ReactEventHookPropagation", "ReactFocusEvent.react", "ReactKeyboardEvent.react", "react", "setElementCanTab", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    var h = d("react");
    e = d("react");
    var i = e.useCallback,
        j = e.useContext,
        k = e.useEffect,
        l = e.useLayoutEffect,
        m = e.useMemo,
        n = e.useRef;

    function o(a, b, c) {
        var e = document.activeElement;
        window.requestAnimationFrame(function() {
            document.activeElement === e && d("FocusManager").focusElement(a, {
                preventScroll: b,
                focusWithoutUserIntent: c
            })
        })
    }

    function p(a) {
        return a.offsetWidth === 0 && a.offsetHeight === 0
    }
    var q = h.unstable_Scope,
        r = new Map();

    function a(a) {
        var b = a.autoRestoreFocus,
            e = a.autoFocusQuery,
            f = a.children,
            g = a.containFocusQuery,
            s = a.forwardRef,
            t = a.id,
            u = a.onEscapeFocusRegion,
            v = a.recoverFocusStrategy,
            w = v === void 0 ? d("FocusRegionType").RecoverFocusStrategy.Nearest : v,
            x = a.recoverFocusQuery;
        v = a.stopOnFocusWithinPropagation;
        var y = v === void 0 ? !0 : v,
            z = n(null),
            A = n(null),
            B = j(c("ActiveFocusRegionUtilsContext"));
        a = B === null && (b === !0 || u != null) ? document.activeElement : null;
        var C = c("useUnsafeRef_DEPRECATED")(a),
            D = (v = C.current) != null ? v : a,
            E = m(function() {
                return {
                    lastFocused: null,
                    scope: null,
                    restorationFocusRegionItem: null,
                    triggeredFocusRegionItems: new Set()
                }
            }, []),
            F = i(function() {
                if (B != null) {
                    var a = B.getActiveFocusRegion();
                    if (a !== E) {
                        if (E.restorationFocusRegionItem !== a) {
                            var b;
                            if ((a == null ? void 0 : a.lastFocused) != null && !((b = z.current) == null ? void 0 : b.containsNode(a.lastFocused))) a != null && a.triggeredFocusRegionItems.add(E), E.restorationFocusRegionItem = a;
                            else if (E.restorationFocusRegionItem == null) {
                                b = a == null ? void 0 : a.restorationFocusRegionItem;
                                E.restorationFocusRegionItem = b;
                                a != null && (b == null ? void 0 : b.triggeredFocusRegionItems["delete"](a));
                                b == null ? void 0 : b.triggeredFocusRegionItems.add(E);
                                B.setActiveFocusRegion(E);
                                return
                            }
                        }(a === null || a != null && E != null && a.lastFocused !== E.lastFocused) && B.setActiveFocusRegion(E)
                    }
                }
            }, [B, E]),
            G = n(null);
        v = i(function(a) {
            z.current = a;
            E.scope = a;
            var b = G.current;
            s && (s.current = a);
            b !== null && b !== t && r.get(b) === null && r["delete"](b);
            t != null && (a !== null ? (G.current = t, r.set(t, a)) : r.get(t) === null && r["delete"](t))
        }, [s, t, E]);
        v = d("ReactFocusEvent.react").useFocusWithin(v, m(function() {
            return {
                onBeforeBlurWithin: function(a) {
                    var b = z.current;
                    if (b !== null && x !== void 0) {
                        a.stopPropagation();
                        if (x === null) return;
                        a = a.target;
                        b = d("FocusManager").getAllNodesFromOneOrManyQueries(x, b);
                        if (b === null) return;
                        var c = b.indexOf(a);
                        a = a._tabIndexState;
                        A.current = {
                            detachedCanTab: a != null && a.canTab,
                            recoveryIndex: c,
                            recovery: b
                        }
                    }
                },
                onAfterBlurWithin: function() {
                    var a = z.current,
                        b = A.current;
                    A.current = null;
                    var c = document.activeElement;
                    if (a !== null && x != null && b !== null && (c == null || c === document.body || !a.containsNode(c))) {
                        c = !0;
                        var e = !0,
                            f = b.recovery,
                            g = b.recoveryIndex,
                            h = d("FocusManager").getAllNodesFromOneOrManyQueries(x, a);
                        if (h !== null && f !== null) {
                            var i = new Set(h),
                                j = new Set(f);
                            for (var k = g - 1; k >= 0; k--) {
                                var l = f[k];
                                if (i.has(l)) {
                                    var m = h.indexOf(l);
                                    m = m + 1;
                                    if (m < h.length) {
                                        m = h[m];
                                        if (!j.has(m)) {
                                            b.detachedCanTab && d("setElementCanTab").setElementCanTab(m, !0);
                                            o(m, c, e);
                                            return
                                        }
                                    }
                                    b.detachedCanTab && d("setElementCanTab").setElementCanTab(l, !0);
                                    o(l, c, e);
                                    return
                                }
                            }
                            if (w === d("FocusRegionType").RecoverFocusStrategy.Nearest)
                                for (m = g + 1; m < f.length; m++) {
                                    l = f[m];
                                    if (i.has(l)) {
                                        j = h.indexOf(l);
                                        k = j - 1;
                                        if (k >= 0) {
                                            g = h[k];
                                            b.detachedCanTab && d("setElementCanTab").setElementCanTab(g, !0);
                                            o(g, c, e);
                                            return
                                        }
                                    }
                                }
                            l = d("FocusManager").getFirstNodeFromOneOrManyQueries(x, a);
                            l && (b.detachedCanTab && d("setElementCanTab").setElementCanTab(l, !0), o(l, c, e))
                        }
                    }
                },
                onFocusWithin: function(a) {
                    y && d("ReactEventHookPropagation").stopEventHookPropagation(a, "useFocusWithin"), E.lastFocused = a.target, F()
                }
            }
        }, [x, w, y, E, F]));
        a = i(function() {
            var a = z.current,
                b = document.activeElement;
            if (e != null && a !== null && (!b || !a.containsNode(b))) {
                b = E.lastFocused;
                b != null && a.containsNode(b) && !p(b) ? d("FocusManager").focusElement(b, {
                    focusWithAutoFocus: !0,
                    focusWithoutUserIntent: !0,
                    preventScroll: !0
                }) : d("FocusManager").focusFirst(e, a, {
                    focusWithAutoFocus: !0,
                    focusWithoutUserIntent: !0,
                    preventScroll: !0
                })
            }
        }, [e, E]);
        l(a, [a]);
        k(a, [a]);
        var H = i(function(a, c) {
                c === void 0 && (c = !1);
                var e = z.current,
                    f = document.activeElement,
                    g = C.current;
                C.current = null;
                var h = a == null ? void 0 : a.triggeredFocusRegionItems,
                    i = a == null ? void 0 : a.restorationFocusRegionItem;
                (h == null ? void 0 : h.size) && h.forEach(function(a) {
                    return a.restorationFocusRegionItem = i
                });
                a != null && i != null && (i.triggeredFocusRegionItems["delete"](a), (h == null ? void 0 : h.size) && h.forEach(function(a) {
                    i.triggeredFocusRegionItems.add(a)
                }));
                E.lastFocused = null;
                h = B == null ? void 0 : B.getActiveFocusRegion();
                var j = h != null ? h.restorationFocusRegionItem : {
                    lastFocused: g
                };
                h === a && (B == null ? void 0 : B.setActiveFocusRegion(i));
                g = e !== null && f !== null && e.containsNode(f) || f == null || f === document.body;
                if ((b === !0 || u != null) && g) {
                    var k = function(a) {
                        a === void 0 && (a = !1);
                        if ((j == null ? void 0 : j.lastFocused) != null) {
                            var b = !0,
                                c = !0,
                                e = document.activeElement;
                            (a || e === null || e === document.body) && d("FocusManager").focusElement(j.lastFocused, {
                                preventScroll: b,
                                focusWithoutUserIntent: c
                            })
                        }
                    };
                    c ? k(c) : window.requestAnimationFrame(function() {
                        return k()
                    })
                }
            }, [B, b, u, E]),
            I = i(function() {
                H(E, !0), u && u()
            }, [H, u, E]);
        d("ReactKeyboardEvent.react").useKeyboard(z, m(function() {
            return {
                onKeyDown: function(a) {
                    if (g == null || a.key !== "Tab" || a.isDefaultPrevented()) return;
                    var b = z.current;
                    b !== null && (a.shiftKey ? d("FocusManager").focusPreviousContained(g, b, a, !0, u != null ? I : void 0) : d("FocusManager").focusNextContained(g, b, a, !0, u != null ? I : void 0))
                }
            }
        }, [g, I, u]));
        l(function() {
            C.current = D;
            var a = E;
            return function() {
                H(a)
            }
        }, [B, b, H, E, D]);
        return h.jsx(q, {
            ref: v,
            id: t,
            children: f
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a, b, c) {
        a = r.get(a);
        if (a) {
            a = a.DO_NOT_USE_queryFirstNode(b);
            if (a !== null) {
                d("FocusManager").focusElement(a, {
                    preventScroll: c
                });
                return a
            }
        }
        return null
    }
    g.FocusRegion = a;
    g.focusRegionById = b
}), 98);
__d("focusScopeQueries", [], (function(a, b, c, d, e, f) {
    function g(a, b) {
        return a === "h1" || a === "h2" || a === "h3" || b.role === "heading" && (b["aria-level"] === 1 || b["aria-level"] === 2 || b["aria-level"] === 3) || b["aria-busy"] === !0 || b.role === "progressbar" ? !0 : !1
    }

    function a(a, b) {
        return b.tabIndex === -1 && !(b.disabled === !0 || b.type === "hidden" || b["aria-disabled"] === !0 || b["aria-hidden"] === !0) ? !0 : i(a, b)
    }

    function h(a) {
        return a.type !== "hidden" && a.type !== "file"
    }

    function b(a, b) {
        return a === "input" && h(b)
    }

    function i(a, b) {
        if (b.tabIndex === -1 || b.disabled === !0) return !1;
        if (b.tabIndex === 0 || b.contentEditable === !0) return !0;
        if (a === "a" || a === "area") return b.href != null && b.href !== "" && b.rel !== "ignore";
        return a === "input" ? h(b) : a === "button" || a === "textarea" || a === "select" || a === "iframe" || a === "embed"
    }
    b = [b, i];

    function j(a) {
        return a.offsetWidth === 0 && a.offsetHeight === 0
    }

    function c(a, b, c) {
        return !j(c) && i(a, b)
    }

    function k(a, b) {
        return a === "td" || a === "th" || b.role === "gridcell" || b.role === "columnheader" || b.role === "rowheader" ? !0 : !1
    }

    function d(a, b) {
        return !k(a, b) && i(a, b)
    }
    var l = [g, i];

    function e(a, b) {
        return g(a, b) || i(a, b)
    }
    var m = function(a, b) {
        return b["data-focus-target"] === !0 && (b["aria-busy"] === !0 || b.role === "progressbar") ? !0 : !1
    };
    f.headerAndSpinnerFocusScopeQuery = g;
    f.focusableScopeQuery = a;
    f.tabbableScopeQuery = i;
    f.inputFirstTabbbableScopeQuery = b;
    f.displayedTabbableScopeQuery = c;
    f.tableCellScopeQuery = k;
    f.tableCellTabbableContentScopeQuery = d;
    f.headerFirstTabbableSecondScopeQuery = l;
    f.headerOrTabbableScopeQuery = e;
    f.topLoadingScopeQuery = m
}), 66);