; /*FB_PKG_DELIM*/

__d("IconSource", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a, b, c) {
        this.$$typeof = "fb.iconsource", this.src = b, this.size = c
    };
    f["default"] = a
}), 66);