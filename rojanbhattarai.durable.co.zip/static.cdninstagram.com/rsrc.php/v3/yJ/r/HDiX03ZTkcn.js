; /*FB_PKG_DELIM*/

__d("react-dom", ["react-dom-0.0.0"], (function(a, b, c, d, e, f) {
    e.exports = b("react-dom-0.0.0")()
}), null);