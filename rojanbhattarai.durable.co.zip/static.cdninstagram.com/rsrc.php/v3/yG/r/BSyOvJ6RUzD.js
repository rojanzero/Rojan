; /*FB_PKG_DELIM*/

__d("EventListenerImplForBlue", ["Event", "TimeSlice", "emptyFunction", "setImmediateAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    function h(a, b, d, e) {
        var f = c("TimeSlice").guard(d, "EventListener capture " + b);
        if (a.addEventListener) {
            a.addEventListener(b, f, e);
            return {
                remove: function() {
                    a.removeEventListener(b, f, e)
                }
            }
        } else return {
            remove: c("emptyFunction")
        }
    }
    a = {
        listen: function(a, b, d) {
            return c("Event").listen(a, b, d)
        },
        capture: function(a, b, c) {
            return h(a, b, c, !0)
        },
        captureWithPassiveFlag: function(a, b, c, d) {
            return h(a, b, c, {
                passive: d,
                capture: !0
            })
        },
        bubbleWithPassiveFlag: function(a, b, c, d) {
            return h(a, b, c, {
                passive: d,
                capture: !1
            })
        },
        registerDefault: function(a, b) {
            var d, e = c("Event").listen(document.documentElement, a, f, c("Event").Priority._BUBBLE);

            function f() {
                g(), d = c("Event").listen(document, a, b), c("setImmediateAcrossTransitions")(g)
            }

            function g() {
                d && d.remove(), d = null
            }
            return {
                remove: function() {
                    g(), e && e.remove(), e = null
                }
            }
        },
        suppress: function(a) {
            c("Event").kill(a)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("BasicVector", [], (function(a, b, c, d, e, f) {
    a = function() {
        function a(a, b) {
            this.x = a, this.y = b
        }
        var b = a.prototype;
        b.derive = function(b, c) {
            return new a(b, c)
        };
        b.toString = function() {
            return "(" + this.x + ", " + this.y + ")"
        };
        b.add = function(a, b) {
            b === void 0 && (b = a.y, a = a.x);
            a = parseFloat(a);
            b = parseFloat(b);
            return this.derive(this.x + a, this.y + b)
        };
        b.mul = function(a, b) {
            b === void 0 && (b = a);
            return this.derive(this.x * a, this.y * b)
        };
        b.div = function(a, b) {
            b === void 0 && (b = a);
            return this.derive(this.x * 1 / a, this.y * 1 / b)
        };
        b.sub = function(a, b) {
            if (arguments.length === 1) return this.add(a.mul(-1));
            else return this.add(-a, -b)
        };
        b.distanceTo = function(a) {
            return this.sub(a).magnitude()
        };
        b.magnitude = function() {
            return Math.sqrt(this.x * this.x + this.y * this.y)
        };
        b.rotate = function(a) {
            return this.derive(this.x * Math.cos(a) - this.y * Math.sin(a), this.x * Math.sin(a) + this.y * Math.cos(a))
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("getUnboundedScrollPosition", ["Scroll"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a === window) {
            var c;
            return {
                x: (c = window.pageXOffset) != null ? c : b("Scroll").getLeft(document.documentElement),
                y: (c = window.pageYOffset) != null ? c : b("Scroll").getTop(document.documentElement)
            }
        }
        return {
            x: b("Scroll").getLeft(a),
            y: b("Scroll").getTop(a)
        }
    }
    e.exports = a
}), null);
__d("getViewportDimensions", ["UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function() {
        var a = null;
        return function() {
            var b = document.body;
            if (b == null) return null;
            (a == null || !b.contains(a)) && (a = document.createElement("div"), a.style.left = Number.MAX_SAFE_INTEGER + "px", a.style.width = "100%", a.style.height = "100%", a.style.position = "fixed", b.appendChild(a));
            return a
        }
    }();

    function i() {
        var a;
        document.documentElement && (a = document.documentElement.clientWidth);
        a == null && document.body && (a = document.body.clientWidth);
        return a || 0
    }

    function j() {
        var a;
        document.documentElement && (a = document.documentElement.clientHeight);
        a == null && document.body && (a = document.body.clientHeight);
        return a || 0
    }

    function k() {
        return {
            width: window.innerWidth || i(),
            height: window.innerHeight || j()
        }
    }
    k.withoutScrollbars = function() {
        return c("UserAgent").isPlatform("Android") ? k() : {
            width: i(),
            height: j()
        }
    };
    k.layout = function() {
        var a, b = h();
        return {
            width: (a = b == null ? void 0 : b.clientWidth) != null ? a : i(),
            height: (a = b == null ? void 0 : b.clientHeight) != null ? a : j()
        }
    };
    g["default"] = k
}), 98);
__d("DOMVector", ["BasicVector", "getDocumentScrollElement", "getElementPosition", "getUnboundedScrollPosition", "getViewportDimensions"], (function(a, b, c, d, e, f, g) {
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c, d) {
            b = a.call(this, b, c) || this;
            b.domain = d || "pure";
            return b
        }
        var d = b.prototype;
        d.derive = function(a, c, d) {
            return new b(a, c, d || this.domain)
        };
        d.add = function(c, d) {
            c instanceof b && c.getDomain() !== "pure" && (c = c.convertTo(this.domain));
            return a.prototype.add.call(this, c, d)
        };
        d.convertTo = function(a) {
            if (a != "pure" && a != "viewport" && a != "document") return this.derive(0, 0);
            if (a == this.domain) return this.derive(this.x, this.y, this.domain);
            if (a == "pure") return this.derive(this.x, this.y);
            if (this.domain == "pure") return this.derive(0, 0);
            var c = b.getScrollPosition("document"),
                d = this.x,
                e = this.y;
            this.domain == "document" ? (d -= c.x, e -= c.y) : (d += c.x, e += c.y);
            return this.derive(d, e, a)
        };
        d.getDomain = function() {
            return this.domain
        };
        b.from = function(a, c, d) {
            return new b(a, c, d)
        };
        b.getScrollPosition = function(a) {
            a = a || "document";
            var b = c("getUnboundedScrollPosition")(window);
            return this.from(b.x, b.y, "document").convertTo(a)
        };
        b.getElementPosition = function(a, b) {
            b = b || "document";
            a = c("getElementPosition")(a);
            return this.from(a.x, a.y, "viewport").convertTo(b)
        };
        b.getElementDimensions = function(a) {
            return this.from(a.offsetWidth || 0, a.offsetHeight || 0)
        };
        b.getViewportDimensions = function() {
            var a = c("getViewportDimensions")();
            return this.from(a.width, a.height, "viewport")
        };
        b.getLayoutViewportDimensions = function() {
            var a = c("getViewportDimensions").layout();
            return this.from(a.width, a.height, "viewport")
        };
        b.getViewportWithoutScrollbarDimensions = function() {
            var a = c("getViewportDimensions").withoutScrollbars();
            return this.from(a.width, a.height, "viewport")
        };
        b.getDocumentDimensions = function(a) {
            a = c("getDocumentScrollElement")(a);
            return this.from(a.scrollWidth, a.scrollHeight, "document")
        };
        return b
    }(c("BasicVector"));
    g["default"] = a
}), 98);
__d("Vector", ["DOMVector", "Event", "Scroll"], (function(a, b, c, d, e, f, g) {
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c, d) {
            return a.call(this, parseFloat(b), parseFloat(c), d) || this
        }
        var e = b.prototype;
        e.derive = function(a, c, d) {
            return new b(a, c, d || this.domain)
        };
        e.setElementPosition = function(a) {
            var b = this.convertTo("document");
            a.style.left = parseInt(b.x, 10) + "px";
            a.style.top = parseInt(b.y, 10) + "px";
            return this
        };
        e.setElementDimensions = function(a) {
            return this.setElementWidth(a).setElementHeight(a)
        };
        e.setElementWidth = function(a) {
            a.style.width = parseInt(this.x, 10) + "px";
            return this
        };
        e.setElementHeight = function(a) {
            a.style.height = parseInt(this.y, 10) + "px";
            return this
        };
        e.scrollElementBy = function(a) {
            a == document.body ? window.scrollBy(this.x, this.y) : (d("Scroll").setLeft(a, d("Scroll").getLeft(a) + this.x), d("Scroll").setTop(a, d("Scroll").getTop(a) + this.y));
            return this
        };
        b.from = function(a, c, d) {
            return new b(a, c, d)
        };
        b.getEventPosition = function(a, b) {
            b === void 0 && (b = "document");
            a = c("Event").getPosition(a);
            a = this.from(a.x, a.y, "document");
            return a.convertTo(b)
        };
        b.getTouchEventPosition = function(a, b) {
            b === void 0 && (b = "document");
            a = a.touches[0];
            a = this.from(a.pageX, a.pageY, "document");
            return a.convertTo(b)
        };
        b.deserialize = function(a) {
            a = a.split(",");
            return this.from(a[0], a[1])
        };
        return b
    }(c("DOMVector"));
    g["default"] = a
}), 98);
__d("SchedulerFeatureFlags", ["gkx"], (function(a, b, c, d, e, f, g) {
    a = !0;
    b = c("gkx")("1099893");
    d = !0;
    e = !0;
    f = 5;
    c = 10;
    var h = 10;
    g.enableSchedulerDebugging = a;
    g.enableProfiling = b;
    g.enableIsInputPending = d;
    g.enableIsInputPendingContinuous = e;
    g.frameYieldMs = f;
    g.continuousYieldMs = c;
    g.maxYieldMs = h
}), 98);
__d("Scheduler-dev.classic", ["SchedulerFeatureFlags"], (function(a, b, c, d, e, f) {
    "use strict"
}), null);
__d("Scheduler-profiling.classic", ["SchedulerFeatureFlags"], (function(b, c, d, e, f, g) {
    "use strict";
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart === "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
    var h = c("SchedulerFeatureFlags").enableIsInputPending,
        i = c("SchedulerFeatureFlags").enableSchedulerDebugging,
        j = c("SchedulerFeatureFlags").enableProfiling;
    d = c("SchedulerFeatureFlags").enableIsInputPendingContinuous;
    var k = c("SchedulerFeatureFlags").frameYieldMs,
        l = c("SchedulerFeatureFlags").continuousYieldMs,
        m = c("SchedulerFeatureFlags").maxYieldMs;

    function n(b, c) {
        var d = b.length;
        b.push(c);
        a: for (; 0 < d;) {
            var e = d - 1 >>> 1,
                f = b[e];
            if (0 < q(f, c)) b[e] = c, b[d] = f, d = e;
            else break a
        }
    }

    function o(b) {
        return 0 === b.length ? null : b[0]
    }

    function p(b) {
        if (0 === b.length) return null;
        var c = b[0],
            d = b.pop();
        if (d !== c) {
            b[0] = d;
            a: for (var e = 0, f = b.length, g = f >>> 1; e < g;) {
                var h = 2 * (e + 1) - 1,
                    i = b[h],
                    j = h + 1,
                    k = b[j];
                if (0 > q(i, d)) j < f && 0 > q(k, i) ? (b[e] = k, b[j] = d, e = j) : (b[e] = i, b[h] = d, e = h);
                else if (j < f && 0 > q(k, d)) b[e] = k, b[j] = d, e = j;
                else break a
            }
        }
        return c
    }

    function q(b, c) {
        var d = b.sortIndex - c.sortIndex;
        return 0 !== d ? d : b.id - c.id
    }
    var r = 0,
        s = 0,
        t = 0,
        u = null,
        v = null,
        w = 0;

    function x(b) {
        if (null !== v) {
            var c = w;
            w += b.length;
            if (w + 1 > t) {
                t *= 2;
                if (524288 < t) {
                    y();
                    return
                }
                var d = new Int32Array(4 * t);
                d.set(v);
                u = d.buffer;
                v = d
            }
            v.set(b, c)
        }
    }

    function b() {
        t = 131072, u = new ArrayBuffer(4 * t), v = new Int32Array(u), w = 0
    }

    function y() {
        var b = u;
        t = 0;
        v = u = null;
        w = 0;
        return b
    }
    g.unstable_now = void 0;
    if ("object" === typeof performance && "function" === typeof performance.now) {
        var z = performance;
        g.unstable_now = function() {
            return z.now()
        }
    } else {
        var A = Date,
            ba = A.now();
        g.unstable_now = function() {
            return A.now() - ba
        }
    }
    var B = [],
        C = [],
        ca = 1,
        D = !1,
        E = null,
        F = 3,
        G = !1,
        H = !1,
        I = !1,
        J = "function" === typeof setTimeout ? setTimeout : null,
        K = "function" === typeof clearTimeout ? clearTimeout : null,
        L = "undefined" !== typeof setImmediate ? setImmediate : null,
        M = "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending ? navigator.scheduling.isInputPending.bind(navigator.scheduling) : null,
        da = {
            includeContinuous: d
        };

    function N(b) {
        for (var c = o(C); null !== c;) {
            if (null === c.callback) p(C);
            else if (c.startTime <= b) p(C), c.sortIndex = c.expirationTime, n(B, c), j && (j && null !== v && x([1, 1e3 * b, c.id, c.priorityLevel]), c.isQueued = !0);
            else break;
            c = o(C)
        }
    }

    function O(b) {
        I = !1;
        N(b);
        if (!H)
            if (null !== o(B)) H = !0, $(P);
            else {
                var c = o(C);
                null !== c && aa(O, c.startTime - b)
            }
    }

    function P(c, b) {
        j && j && null !== v && x([8, 1e3 * b, s]);
        H = !1;
        I && (I = !1, K(T), T = -1);
        G = !0;
        var d = F;
        try {
            if (j) try {
                return Q(c, b)
            } catch (b) {
                if (null !== E) {
                    var e = g.unstable_now();
                    j && null !== v && x([3, 1e3 * e, E.id]);
                    E.isQueued = !1
                }
                throw b
            } else return Q(c, b)
        } finally {
            E = null, F = d, G = !1, j && (c = g.unstable_now(), j && (s++, null !== v && x([7, 1e3 * c, s])))
        }
    }

    function Q(c, b) {
        N(b);
        for (E = o(B); !(null === E || i && D || E.expirationTime > b && (!c || X()));) {
            var d = E.callback;
            if ("function" === typeof d) {
                E.callback = null;
                F = E.priorityLevel;
                var e = E.expirationTime <= b;
                if (j) {
                    var f = E;
                    j && (r++, null !== v && x([5, 1e3 * b, f.id, r]))
                }
                d = d(e);
                b = g.unstable_now();
                if ("function" === typeof d) return E.callback = d, j && j && null !== v && x([6, 1e3 * b, E.id, r]), N(b), !0;
                j && (j && null !== v && x([2, 1e3 * b, E.id]), E.isQueued = !1);
                E === o(B) && p(B);
                N(b)
            } else p(B);
            E = o(B)
        }
        if (null !== E) return !0;
        c = o(C);
        null !== c && aa(O, c.startTime - b);
        return !1
    }
    var R = !1,
        S = null,
        T = -1,
        U = k,
        V = -1,
        W = !1;

    function X() {
        var b = g.unstable_now() - V;
        if (b < U) return !1;
        if (h) {
            if (W) return !0;
            if (b < l) {
                if (null !== M) return M()
            } else if (b < m && null !== M) return M(da)
        }
        return !0
    }

    function Y() {
        if (null !== S) {
            var b = g.unstable_now();
            V = b;
            var c = !0;
            try {
                c = S(!0, b)
            } finally {
                c ? Z() : (R = !1, S = null)
            }
        } else R = !1;
        W = !1
    }
    var Z;
    if ("function" === typeof L) Z = function() {
        L(Y)
    };
    else if ("undefined" !== typeof MessageChannel) {
        e = new MessageChannel();
        var ea = e.port2;
        e.port1.onmessage = Y;
        Z = function() {
            ea.postMessage(null)
        }
    } else Z = function() {
        J(Y, 0)
    };

    function $(b) {
        S = b, R || (R = !0, Z())
    }

    function aa(b, c) {
        T = J(function() {
            b(g.unstable_now())
        }, c)
    }
    f = j ? {
        startLoggingProfilingEvents: b,
        stopLoggingProfilingEvents: y
    } : null;
    g.unstable_IdlePriority = 5;
    g.unstable_ImmediatePriority = 1;
    g.unstable_LowPriority = 4;
    g.unstable_NormalPriority = 3;
    g.unstable_Profiling = f;
    g.unstable_UserBlockingPriority = 2;
    g.unstable_cancelCallback = function(b) {
        if (j && b.isQueued) {
            var c = g.unstable_now();
            j && null !== v && x([4, 1e3 * c, b.id]);
            b.isQueued = !1
        }
        b.callback = null
    };
    g.unstable_continueExecution = function() {
        D = !1, H || G || (H = !0, $(P))
    };
    g.unstable_forceFrameRate = function(b) {
        0 > b || 125 < b ? !1 : U = 0 < b ? Math.floor(1e3 / b) : k
    };
    g.unstable_getCurrentPriorityLevel = function() {
        return F
    };
    g.unstable_getFirstCallbackNode = function() {
        return o(B)
    };
    g.unstable_next = function(b) {
        switch (F) {
            case 1:
            case 2:
            case 3:
                var c = 3;
                break;
            default:
                c = F
        }
        var d = F;
        F = c;
        try {
            return b()
        } finally {
            F = d
        }
    };
    g.unstable_pauseExecution = function() {
        D = !0
    };
    g.unstable_requestPaint = function() {
        h && void 0 !== navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && (W = !0)
    };
    g.unstable_runWithPriority = function(b, c) {
        switch (b) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                b = 3
        }
        var d = F;
        F = b;
        try {
            return c()
        } finally {
            F = d
        }
    };
    g.unstable_scheduleCallback = function(b, c, d) {
        var e = g.unstable_now();
        "object" === typeof d && null !== d ? (d = d.delay, d = "number" === typeof d && 0 < d ? e + d : e) : d = e;
        switch (b) {
            case 1:
                var f = -1;
                break;
            case 2:
                f = 250;
                break;
            case 5:
                f = 1073741823;
                break;
            case 4:
                f = 1e4;
                break;
            default:
                f = 5e3
        }
        f = d + f;
        b = {
            id: ca++,
            callback: c,
            priorityLevel: b,
            startTime: d,
            expirationTime: f,
            sortIndex: -1
        };
        j && (b.isQueued = !1);
        d > e ? (b.sortIndex = d, n(C, b), null === o(B) && b === o(C) && (I ? (K(T), T = -1) : I = !0, aa(O, d - e))) : (b.sortIndex = f, n(B, b), j && (j && null !== v && x([1, 1e3 * e, b.id, b.priorityLevel]), b.isQueued = !0), H || G || (H = !0, $(P)));
        return b
    };
    g.unstable_shouldYield = X;
    g.unstable_wrapCallback = function(b) {
        var c = F;
        return function() {
            var d = F;
            F = c;
            try {
                return b.apply(this, arguments)
            } finally {
                F = d
            }
        }
    };
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop === "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error())
}), null);
__d("SchedulerFb-Internals_DO_NOT_USE", ["Scheduler-dev.classic", "Scheduler-profiling.classic", "ifRequireable", "requestAnimationFramePolyfill"], (function(a, b, c, d, e, f) {
    "use strict";
    a.requestAnimationFrame === void 0 && (a.requestAnimationFrame = b("requestAnimationFramePolyfill"));
    var g;
    g = b("Scheduler-profiling.classic");
    e.exports = {
        unstable_ImmediatePriority: g.unstable_ImmediatePriority,
        unstable_UserBlockingPriority: g.unstable_UserBlockingPriority,
        unstable_NormalPriority: g.unstable_NormalPriority,
        unstable_LowPriority: g.unstable_LowPriority,
        unstable_IdlePriority: g.unstable_IdlePriority,
        unstable_getCurrentPriorityLevel: g.unstable_getCurrentPriorityLevel,
        unstable_runWithPriority: g.unstable_runWithPriority,
        unstable_now: g.unstable_now,
        unstable_scheduleCallback: function(a, c, d) {
            var e = b("ifRequireable")("TimeSlice", function(a) {
                return a.guard(c, "unstable_scheduleCallback", {
                    propagationType: a.PropagationType.CONTINUATION,
                    registerCallStack: !0
                })
            }, function() {
                return c
            });
            return g.unstable_scheduleCallback(a, e, d)
        },
        unstable_cancelCallback: function(a) {
            return g.unstable_cancelCallback(a)
        },
        unstable_wrapCallback: function(a) {
            var c = b("ifRequireable")("TimeSlice", function(b) {
                return b.guard(a, "unstable_wrapCallback", {
                    propagationType: b.PropagationType.CONTINUATION,
                    registerCallStack: !0
                })
            }, function() {
                return a
            });
            return g.unstable_wrapCallback(c)
        },
        unstable_pauseExecution: function() {
            return g.unstable_pauseExecution()
        },
        unstable_continueExecution: function() {
            return g.unstable_continueExecution()
        },
        unstable_shouldYield: g.unstable_shouldYield,
        unstable_requestPaint: g.unstable_requestPaint,
        unstable_forceFrameRate: g.unstable_forceFrameRate,
        unstable_Profiling: g.unstable_Profiling
    }
}), null);
__d("JSScheduler", ["SchedulerFb-Internals_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {
            unstable_Immediate: (c = b("SchedulerFb-Internals_DO_NOT_USE")).unstable_ImmediatePriority,
            unstable_UserBlocking: c.unstable_UserBlockingPriority,
            unstable_Normal: c.unstable_NormalPriority,
            unstable_Low: c.unstable_LowPriority,
            unstable_Idle: c.unstable_IdlePriority
        },
        h = !1,
        i = c.unstable_scheduleCallback,
        j = c.unstable_cancelCallback,
        k = {
            priorities: g,
            shouldYield: c.unstable_shouldYield,
            getCurrentPriorityLevel: c.unstable_getCurrentPriorityLevel,
            runWithPriority: c.unstable_runWithPriority,
            runWithPriority_DO_NOT_USE: c.unstable_runWithPriority,
            defer: function(a) {
                var b = k.getCurrentPriorityLevel();
                return i(b, a)
            },
            getCallbackScheduler: function() {
                var a = k.getCurrentPriorityLevel();
                return function(b) {
                    return i(a, b)
                }
            },
            getUserBlockingRunAtCurrentPriCallbackScheduler_DO_NOT_USE: function() {
                var a = k.getCurrentPriorityLevel();
                return function(c) {
                    return i(g.unstable_UserBlocking, function() {
                        b("SchedulerFb-Internals_DO_NOT_USE").unstable_runWithPriority(a, c)
                    })
                }
            },
            deferUserBlockingRunAtCurrentPri_DO_NOT_USE: function(a) {
                var c = k.getCurrentPriorityLevel();
                return i(g.unstable_UserBlocking, function() {
                    b("SchedulerFb-Internals_DO_NOT_USE").unstable_runWithPriority(c, a)
                })
            },
            scheduleImmediatePriCallback: function(a) {
                return i(g.unstable_Immediate, a)
            },
            scheduleUserBlockingPriCallback: function(a) {
                return i(g.unstable_UserBlocking, a)
            },
            scheduleNormalPriCallback: function(a) {
                return i(g.unstable_Normal, a)
            },
            scheduleLoggingPriCallback: function(a) {
                return i(g.unstable_Low, a)
            },
            scheduleSpeculativeCallback: function(a) {
                return i(g.unstable_Idle, a)
            },
            cancelCallback: function(a) {
                j(a)
            },
            scheduleDelayedCallback_DO_NOT_USE: function(a, b, c) {
                a = i(a, c, {
                    delay: b
                });
                return a
            },
            cancelDelayedCallback_DO_NOT_USE: function(a) {
                a = a;
                return j(a)
            },
            startEventProfiling: function() {
                var a;
                a = (a = b("SchedulerFb-Internals_DO_NOT_USE").unstable_Profiling) == null ? void 0 : a.startLoggingProfilingEvents;
                typeof a == "function" && a()
            },
            stopEventProfiling: function() {
                var a;
                a = (a = b("SchedulerFb-Internals_DO_NOT_USE").unstable_Profiling) == null ? void 0 : a.stopLoggingProfilingEvents;
                return typeof a == "function" ? a() : null
            },
            makeSchedulerGlobalEntry: function(c, d) {
                c === void 0 && (c = null), d === void 0 && (d = !1), c !== null && c !== void 0 && b("SchedulerFb-Internals_DO_NOT_USE").unstable_forceFrameRate(c), d && k.startEventProfiling(), a.ScheduleJSWork = function(a) {
                    return function() {
                        for (var b = arguments.length, c = new Array(b), d = 0; d < b; d++) c[d] = arguments[d];
                        h ? a.apply(void 0, c) : k.deferUserBlockingRunAtCurrentPri_DO_NOT_USE(function() {
                            h = !0;
                            try {
                                a.apply(void 0, c)
                            } finally {
                                h = !1
                            }
                        })
                    }
                }
            }
        };
    e.exports = k
}), null);
__d("keyMirror", ["unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = {};
        if (!(a instanceof Object && !Array.isArray(a))) throw c("unrecoverableViolation")("keyMirror(...): Argument must be an object.", "comet_infra");
        for (var d in a) {
            if (!Object.prototype.hasOwnProperty.call(a, d)) continue;
            b[d] = d
        }
        return b
    }
    g["default"] = a
}), 98);