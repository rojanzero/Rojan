; /*FB_PKG_DELIM*/

__d("pageID", ["WebSession"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WebSession").getPageId_DO_NOT_USE();
    g["default"] = a
}), 98);
__d("FBJSON", [], (function(a, b, c, d, e, f) {
    a = JSON.parse;
    b = JSON.stringify;
    f.parse = a;
    f.stringify = b
}), 66);
__d("OdsWebBatchFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1838142");
    b = d("FalcoLoggerInternal").create("ods_web_batch", a);
    e = b;
    g["default"] = e
}), 98);
__d("FalcoConsentChecker", [], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a, b, c, d) {
        var e;
        switch (typeof d) {
            case "string":
                e = a[String(d)];
                return !e ? !1 : e <= b;
            case "number":
                return g(a, b, c, c[Number(d)]);
            default:
                e = !1;
                if (Array.isArray(d)) {
                    var f = d[0];
                    for (var h = 1; h < d.length; h++) {
                        e = g(a, b, c, d[h]);
                        if (e) {
                            if (f === "or") return !0
                        } else if (f === "and") return !1
                    }
                }
                return e
        }
    }
    f["default"] = g
}), 66);
__d("FalcoUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a) {
            var b = a.fbIdentity,
                c = a.appScopedIdentity;
            a = a.claim;
            var d = "";
            if (b) {
                var e = b.accountId;
                b = b.actorId;
                d = e + "^#" + b + "^#"
            } else c !== void 0 && (d = "^#^#" + c);
            return d + "^#" + a
        }
        return ""
    }
    f.identityToString = a
}), 66);
__d("WebStorageMutex", ["WebStorage", "clearTimeout", "pageID", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null,
        i = !1,
        j = c("pageID");

    function k() {
        i || (i = !0, h = c("WebStorage").getLocalStorage());
        return h
    }
    a = function() {
        function a(a) {
            this.name = a
        }
        a.testSetPageID = function(a) {
            j = a
        };
        var b = a.prototype;
        b.$2 = function() {
            var a, b = k();
            if (!b) return j;
            b = b.getItem("mutex_" + this.name);
            b = ((a = b) != null ? a : "").split(":");
            return b && parseInt(b[1], 10) >= Date.now() ? b[0] : null
        };
        b.$3 = function(a) {
            var b = k();
            if (!b) return;
            a = a == null ? 1e3 : a;
            a = Date.now() + a;
            c("WebStorage").setItemGuarded(b, "mutex_" + this.name, j + ":" + a)
        };
        b.hasLock = function() {
            return this.$2() === j
        };
        b.lock = function(a, b, d) {
            var e = this;
            this.$1 && c("clearTimeout")(this.$1);
            j === (this.$2() || j) && this.$3(d);
            this.$1 = c("setTimeout")(function() {
                e.$1 = null;
                var c = e.hasLock() ? a : b;
                c && c(e)
            }, 0)
        };
        b.unlock = function() {
            this.$1 && c("clearTimeout")(this.$1);
            var a = k();
            a && this.hasLock() && a.removeItem("mutex_" + this.name)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("guid", [], (function(a, b, c, d, e, f) {
    function a() {
        return "f" + (Math.random() * (1 << 30)).toString(16).replace(".", "")
    }
    f["default"] = a
}), 66);
__d("requestAnimationFrame", ["TimeSlice", "TimerStorage", "requestAnimationFrameAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        function b(b) {
            c("TimerStorage").unset(c("TimerStorage").ANIMATION_FRAME, d), a(b)
        }
        c("TimeSlice").copyGuardForWrapper(a, b);
        b.__originalCallback = a;
        var d = c("requestAnimationFrameAcrossTransitions")(b);
        c("TimerStorage").set(c("TimerStorage").ANIMATION_FRAME, d);
        return d
    }
    g["default"] = a
}), 98);
__d("PersistedQueue", ["AnalyticsCoreData", "BaseEventEmitter", "ExecutionEnvironment", "FBJSON", "Run", "WebStorage", "WebStorageMutex", "err", "guid", "nullthrows", "performanceAbsoluteNow", "requestAnimationFrame"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 24 * 60 * 60 * 1e3,
        i = 30 * 1e3,
        j = new(c("BaseEventEmitter"))(),
        k;

    function l(a) {
        a === void 0 && (a = !1);
        if (k === void 0) {
            var b;
            if (((b = c("AnalyticsCoreData").queue_activation_experiment) != null ? b : !1) && a) try {
                return c("WebStorage").getLocalStorageForRead()
            } catch (a) {
                return null
            }
            b = "check_quota";
            try {
                a = c("WebStorage").getLocalStorage();
                a ? (a.setItem(b, b), a.removeItem(b), k = a) : k = null
            } catch (a) {
                k = null
            }
        }
        return k
    }

    function m(a) {
        var b = a.prev,
            c = a.next;
        c && (c.prev = b);
        b && (b.next = c);
        a.next = null;
        a.prev = null
    }

    function n(a) {
        return {
            item: a,
            next: null,
            prev: null
        }
    }

    function o(a, b) {
        return a + "^$" + ((a = b == null ? void 0 : b.queueNameSuffix) != null ? a : "")
    }
    var p = {},
        q = {},
        r = {},
        s = !1;
    a = function() {
        function a(a, b) {
            var d, e = this;
            this.$7 = 0;
            this.$3 = a;
            this.$5 = (d = b == null ? void 0 : b.queueNameSuffix) != null ? d : "";
            this.$4 = o(a, b);
            this.$11 = this.$4 + "^$" + c("guid")();
            this.$13 = !1;
            if (b) {
                this.$8 = (d = b.max_age_in_ms) != null ? d : h;
                this.$12 = b.migrate
            } else this.$8 = h;
            this.$9 = [j.addListener("active", function() {
                (e.$10 != null || !e.$13) && (e.$13 = !0, e.$10 = null, e.$14())
            }), j.addListener("inactive", function() {
                e.$10 == null && (e.$10 = Date.now(), e.$15())
            })];
            (c("ExecutionEnvironment").canUseDOM || c("ExecutionEnvironment").isInWorker) && c("requestAnimationFrame")(function() {
                return e.$14()
            })
        }
        var b = a.prototype;
        b.isActive = function() {
            var a = this.$10;
            if (a == null) return !0;
            if (Date.now() - a > i) {
                this.$10 = null;
                j.emit("active", null);
                return !0
            }
            return !1
        };
        b.$14 = function() {
            this.$16(), this.$17()
        };
        b.$15 = function() {
            this.$18()
        };
        b.getFullName = function() {
            return this.$4
        };
        b.getQueueNameSuffix = function() {
            return this.$5
        };
        a.isQueueActivateExperiment = function() {
            return s
        };
        a.setOnQueueActivateExperiment = function() {
            s = !0
        };
        a.create = function(b, d) {
            var e = o(b, d);
            if (e in p) throw c("err")("Duplicate queue created: " + b);
            d = new a(b, d);
            p[e] = d;
            r[b] ? r[b].push(d) : r[b] = [d];
            e = q[b];
            e && d.setHandler(e);
            return d
        };
        a.setHandler = function(a, b) {
            if (r[a]) {
                var c = r[a];
                for (var c = c, d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (d) {
                        if (e >= c.length) break;
                        f = c[e++]
                    } else {
                        e = c.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    f.setHandler(b)
                }
            }
            q[a] = b
        };
        b.destroy = function() {
            this.$9.forEach(function(a) {
                return a.remove()
            })
        };
        a.destroy = function(a, b) {
            a = o(a, b);
            p[a].destroy();
            delete p[a]
        };
        b.setHandler = function(a) {
            this.$6 = a;
            this.$17();
            return this
        };
        b.$17 = function() {
            this.$7 > 0 && this.$6 && this.$6(this)
        };
        b.length = function() {
            return this.$7
        };
        b.enumeratedLength = function() {
            return this.$19().length
        };
        a.isPersistenceAllowed = function() {
            var a = l();
            return !a ? !1 : !0
        };
        a.getSuffixesForKey = function(a) {
            var b = [];
            try {
                var c = l(!0);
                if (!c) return b;
                a = a + "^$";
                for (var d = 0; d < c.length; d++) {
                    var e = c.key(d);
                    if (typeof e === "string" && e.startsWith(a)) {
                        e = e.split("^$");
                        if (e.length > 2) {
                            e = e[1];
                            b.push(e)
                        } else b.push("")
                    }
                }
            } catch (a) {}
            return b
        };
        b.$16 = function() {
            var b = this;
            if (this.$5 === "") {
                this.$20();
                return
            }
            var a = l(!0);
            if (!a) return;
            var e = this.$4 + "^$",
                f = new(c("WebStorageMutex"))(e),
                g = this.$12;
            f.lock(function(f) {
                var h = Date.now() - b.$8;
                try {
                    for (var i = 0; i < a.length; i++) {
                        var j = a.key(i);
                        if (typeof j === "string" && j.startsWith(e)) {
                            var k = a.getItem(j);
                            a.removeItem(j);
                            if (k != null && k.startsWith("{")) {
                                j = d("FBJSON").parse(c("nullthrows")(k));
                                if (j.ts > h) try {
                                    for (var k = j.items, j = Array.isArray(k), l = 0, k = j ? k : k[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                        var m;
                                        if (j) {
                                            if (l >= k.length) break;
                                            m = k[l++]
                                        } else {
                                            l = k.next();
                                            if (l.done) break;
                                            m = l.value
                                        }
                                        m = m;
                                        m = g != null ? g(m) : m;
                                        b.$21(m)
                                    }
                                } catch (a) {}
                            }
                        }
                    }
                } catch (a) {}
                f.unlock()
            })
        };
        b.$20 = function() {
            var b = this,
                a = l(!0);
            if (!a) return;
            var e = this.$4,
                f = new(c("WebStorageMutex"))(e),
                g = this.$12;
            f.lock(function(f) {
                var h = Date.now() - b.$8;
                try {
                    for (var i = 0; i < a.length; i++) {
                        var j = a.key(i);
                        if (typeof j === "string" && j.startsWith(e)) {
                            var k = j.split("^$");
                            if (k.length <= 2 || k[1] === "") {
                                k = a.getItem(j);
                                a.removeItem(j);
                                if (k != null && k.startsWith("{")) {
                                    j = d("FBJSON").parse(c("nullthrows")(k));
                                    if (j.ts > h) try {
                                        for (var k = j.items, j = Array.isArray(k), l = 0, k = j ? k : k[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                            var m;
                                            if (j) {
                                                if (l >= k.length) break;
                                                m = k[l++]
                                            } else {
                                                l = k.next();
                                                if (l.done) break;
                                                m = l.value
                                            }
                                            m = m;
                                            m = g != null ? g(m) : m;
                                            b.$21(m)
                                        }
                                    } catch (a) {}
                                }
                            }
                        }
                    }
                } catch (a) {}
                f.unlock()
            })
        };
        b.$18 = function() {
            var a = l();
            if (!a) return;
            var b = this.$19();
            if (b.length === 0) {
                a.getItem(this.$11) != null && a.removeItem(this.$11);
                return
            }
            c("WebStorage").setItemGuarded(a, this.$11, d("FBJSON").stringify({
                items: b.map(function(a) {
                    return a
                }),
                ts: c("performanceAbsoluteNow")()
            }))
        };
        b.$19 = function() {
            var a = this.$1,
                b = [];
            if (!a) return b;
            do b.push(a.item); while (a = a.prev);
            return b.reverse()
        };
        b.markItemAsCompleted = function(a) {
            var b = a.prev;
            m(a);
            this.$1 === a && (this.$1 = b);
            this.$7--;
            this.isActive() || this.$18()
        };
        b.markItemAsFailed = function(a) {
            m(a);
            var b = this.$2;
            if (b) {
                var c = b.prev;
                c && (c.next = a, a.prev = c);
                a.next = b;
                b.prev = a
            }
            this.$2 = a;
            this.isActive() && this.$17()
        };
        b.markItem = function(a, b) {
            b ? this.markItemAsCompleted(a) : this.markItemAsFailed(a)
        };
        b.$21 = function(a) {
            a = n(a);
            var b = this.$1;
            b && (b.next = a, a.prev = b);
            this.$1 = a;
            this.$2 || (this.$2 = a);
            this.$7++
        };
        b.wrapAndEnqueueItem = function(a) {
            this.$21(a), this.isActive() ? this.$17() : this.$18()
        };
        b.dequeueItem = function() {
            if (this.$10 != null) return null;
            var a = this.$2;
            if (!a) return null;
            this.$2 = a.next;
            return a
        };
        return a
    }();
    a.eventEmitter = j;
    if (c("ExecutionEnvironment").canUseDOM) {
        var t = d("Run").maybeOnBeforeUnload(function() {
            j.emit("inactive", null), t == null ? void 0 : t.remove()
        }, !1);
        if (!t) var u = d("Run").onUnload(function() {
            j.emit("inactive", null), u.remove()
        })
    }
    g["default"] = a
}), 98);
__d("ServerTime", ["ServerTimeData"], (function(a, b, c, d, e, f, g) {
    var h, i = 0;
    f = 0;
    var j = null;
    h = (h = (typeof window !== "undefined" ? window : self).performance) == null ? void 0 : h.timing;
    if (h) {
        var k = h.requestStart;
        h = h.domLoading;
        if (k && h) {
            var l = c("ServerTimeData").timeOfResponseStart - c("ServerTimeData").timeOfRequestStart;
            k = h - k - l;
            f = k / 2;
            l = h - c("ServerTimeData").timeOfResponseStart - f;
            h = Math.max(50, k * .8);
            Math.abs(l) > h && (i = l, j = Date.now())
        }
    } else d(c("ServerTimeData").serverTime);

    function a() {
        return Date.now() - i
    }

    function b() {
        return i
    }

    function d(a) {
        a = Date.now() - a;
        Math.abs(i - a) > 6e4 && (i = a, j = Date.now())
    }

    function e() {
        return j === null ? null : Date.now() - j
    }
    f = a;
    k = b;
    g.getMillis = a;
    g.getOffsetMillis = b;
    g.update = d;
    g.getMillisSinceLastUpdate = e;
    g.get = f;
    g.getSkew = k
}), 98);
__d("FalcoLoggerInternal", ["AnalyticsCoreData", "BaseEventEmitter", "FBLogger", "FalcoConsentChecker", "FalcoUtils", "ODS", "PersistedQueue", "Promise", "Random", "ServerTime", "nullthrows", "performanceAbsoluteNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 500 * 1024 * .6,
        i = "ods_web_batch",
        j = new Map();

    function k(a) {
        "rate" in a && (a.policy = {
            r: a.rate
        });
        var b = a.extra;
        typeof b !== "string" && (a.extra = JSON.stringify(b));
        return a
    }

    function a(a, b) {
        var d;
        d = (d = c("PersistedQueue").getSuffixesForKey(a)) != null ? d : [];
        d.push(b);
        for (var d = d, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var g;
            if (e) {
                if (f >= d.length) break;
                g = d[f++]
            } else {
                f = d.next();
                if (f.done) break;
                g = f.value
            }
            g = g;
            var h = a + "^$" + g;
            if (j.has(h)) continue;
            g = c("PersistedQueue").create(a, {
                migrate: k,
                queueNameSuffix: g
            });
            j.set(h, g)
        }
        return c("nullthrows")(j.get(a + "^$" + b))
    }
    f = d("FalcoUtils").identityToString(c("AnalyticsCoreData").identity);
    var l = a("falco_queue_log", f),
        m = a("falco_queue_immediately", f),
        n = a("falco_queue_critical", f),
        o = new(c("BaseEventEmitter"))();

    function p(a, b) {
        d("ODS").bumpEntityKey(1344, "falco.fabric.www." + c("AnalyticsCoreData").push_phase, a, b)
    }

    function q(a, b, c, e) {
        if (a === i) return;
        d("ODS").bumpEntityKey(1344, "falco.event." + a, b, c);
        e && p(b, c)
    }
    var r = {};

    function s(a, b) {
        var d = c("Random").coinflip(b.r);
        b = b.c;
        b != null && c("AnalyticsCoreData").consents != null && (d = d && t(b, c("AnalyticsCoreData").consents, a));
        return d
    }

    function t(a, b, d) {
        var e = r[a];
        e == null && (e = r[a] = JSON.parse(a));
        return c("FalcoConsentChecker")(b, d, e, e[0])
    }

    function u() {
        return c("performanceAbsoluteNow")() - d("ServerTime").getOffsetMillis()
    }

    function v(a, b, d, e, f, g) {
        if (c("AnalyticsCoreData").enable_observer) {
            a = babelHelpers["extends"]({
                name: a,
                time: b,
                sampled: d,
                getData: f,
                policy: e
            }, g && {
                getPrivacyContext: g
            });
            o.emit("event", a)
        }
    }

    function w(a, b, d, e, f, g) {
        f = JSON.stringify(f);
        if (f.length > h) {
            q(a, "js.drop.oversized_message", 1, !0);
            c("FBLogger")("falco", "oversized_message:" + a).warn('Dropping event "%s" due to exceeding the max size %s at %s', a, h, f.length);
            return
        }
        g.wrapAndEnqueueItem({
            name: a,
            policy: b,
            time: d,
            extra: f,
            privacyContext: e
        });
        q(a, "js.event.write_to_queue", 1, !0)
    }

    function x(a, b, c, d, e) {
        try {
            var f = u(),
                g = s(f, b);
            if (g) {
                var h = d(),
                    i = c && c();
                w(a, b, f, i, h, e)
            }
            v(a, f, g, b, d, c)
        } catch (a) {
            z(a)
        }
    }

    function y(a, c, d, e, f) {
        try {
            var g = u(),
                h = s(g, c);
            if (h) {
                var i = e(),
                    j = b("Promise").resolve(d && d());
                return b("Promise").all([i, j]).then(function(b) {
                    var d = b[0],
                        e = b[1];
                    w(a, c, g, e, d, f);
                    v(a, g, h, c, function() {
                        return d
                    }, e && function() {
                        return e
                    })
                })
            } else {
                v(a, g, h, c, e, d);
                return b("Promise").resolve()
            }
        } catch (a) {
            return b("Promise").reject(a)
        }
    }

    function z(a) {
        var b = c("FBLogger")("falco");
        a instanceof Error ? b.catching(a).warn("Error while attempting to log to Falco") : b.warn("Caught non-error while attempting to log to Falco: %s", JSON.stringify(a))
    }

    function e(a, b) {
        return {
            log: function(c, d) {
                x(a, b, d, c, l)
            },
            logAsync: function(c, d) {
                y(a, b, d, c, l)["catch"](z)
            },
            logImmediately: function(c, d) {
                x(a, b, d, c, m)
            },
            logCritical: function(c, d) {
                x(a, b, d, c, n)
            },
            logRealtimeEvent: function(c, d) {
                x(a, b, d, c, n)
            }
        }
    }
    g.observable = o;
    g.create = e
}), 98);
__d("ODS", ["ExecutionEnvironment", "OdsWebBatchFalcoEvent", "Random", "Run", "clearTimeout", "gkx", "setTimeout", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    var h, i = c("ExecutionEnvironment").canUseDOM || c("ExecutionEnvironment").isInWorker,
        j = {};

    function k(a, b, c, d, e) {
        var f;
        d === void 0 && (d = 1);
        e === void 0 && (e = 1);
        var g = (f = j[b]) != null ? f : null;
        if (g != null && g <= 0) return;
        h = h || {};
        var i = h[a] || (h[a] = {}),
            k = i[b] || (i[b] = {}),
            l = k[c] || (k[c] = [0, null]),
            n = Number(d),
            o = Number(e);
        g > 0 && (n /= g, o /= g);
        if (!isFinite(n) || !isFinite(o)) return;
        l[0] += n;
        if (arguments.length >= 5) {
            var p = l[1];
            p == null && (p = 0);
            l[1] = p + o
        }
        m()
    }
    var l;

    function m() {
        if (l != null) return;
        l = c("setTimeout")(function() {
            n()
        }, c("gkx")("708253") ? 13e3 / 2 : 5e3)
    }

    function a(a, b) {
        if (!i) return;
        j[a] = d("Random").random() < b ? b : 0
    }

    function b(a, b, c, d) {
        d === void 0 && (d = 1);
        if (!i) return;
        k(a, b, c, d)
    }

    function e(a, b, c, d, e) {
        d === void 0 && (d = 1);
        e === void 0 && (e = 1);
        if (!i) return;
        k(a, b, c, d, e)
    }

    function n(a) {
        a === void 0 && (a = "normal");
        if (!i) return;
        c("clearTimeout")(l);
        l = null;
        if (h == null) return;
        var b = h;
        h = null;

        function d() {
            return {
                batch: b
            }
        }
        a === "critical" ? c("OdsWebBatchFalcoEvent").logCritical(d) : c("OdsWebBatchFalcoEvent").log(d)
    }
    i && d("Run").onUnload(function() {
        n("critical")
    });
    g.setEntitySample = a;
    g.bumpEntityKey = b;
    g.bumpFraction = e;
    g.flush = n
}), 98);
__d("uuid", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        var a;
        a = (a = self) == null ? void 0 : (a = a.crypto) == null ? void 0 : a.randomUUID;
        return typeof a === "function" ? self.crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = Math.random() * 16 | 0;
            a = a === "x" ? b : b & 3 | 8;
            return a.toString(16)
        })
    }
    f["default"] = a
}), 66);