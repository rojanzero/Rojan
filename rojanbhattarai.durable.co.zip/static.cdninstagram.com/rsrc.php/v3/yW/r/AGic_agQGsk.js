; /*FB_PKG_DELIM*/

__d("React", ["cr:1108857", "cr:1294158", "gkx"], (function(a, b, c, d, e, f) {
    c = b("cr:1294158");
    var g = c.useSyncExternalStore;

    function a(a, b, c) {
        return g(b, c)
    }
    b("gkx")("4166") && (c.useMutableSource = a, c.unstable_useMutableSource = a);
    e.exports = c
}), null);