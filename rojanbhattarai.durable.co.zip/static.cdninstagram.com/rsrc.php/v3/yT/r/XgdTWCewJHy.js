; /*FB_PKG_DELIM*/

__d("CometEventListener", ["unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, d, e) {
        if (a.addEventListener) {
            a.addEventListener(b, d, e);
            return {
                remove: function() {
                    a.removeEventListener(b, d, e)
                }
            }
        } else throw c("unrecoverableViolation")('Attempted to listen to eventType "' + b + '" on a target that does not have addEventListener.', "comet_ui")
    }
    a = {
        bubbleWithPassiveFlag: function(a, b, c, d) {
            return h(a, b, c, {
                capture: !1,
                passive: d
            })
        },
        capture: function(a, b, c) {
            return h(a, b, c, !0)
        },
        captureWithPassiveFlag: function(a, b, c, d) {
            return h(a, b, c, {
                capture: !0,
                passive: d
            })
        },
        listen: function(a, b, c) {
            return h(a, b, c, !1)
        },
        registerDefault: function(a, b) {
            throw c("unrecoverableViolation")("EventListener.registerDefault is not implemented.", "comet_ui")
        },
        suppress: function(a) {
            a.preventDefault(), a.stopPropagation()
        }
    };
    g["default"] = a
}), 98);
__d("LogHistory", [], (function(a, b, c, d, e, f) {
    var g = 500,
        h = {},
        i = [];

    function j(a, b, c, d) {
        var e = d[0];
        if (typeof e !== "string" || d.length !== 1) return;
        i.push({
            date: Date.now(),
            level: a,
            category: b,
            event: c,
            args: e
        });
        i.length > g && i.shift()
    }
    var k = function() {
        function a(a) {
            this.category = a
        }
        var b = a.prototype;
        b.debug = function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            j("debug", this.category, a, c);
            return this
        };
        b.log = function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            j("log", this.category, a, c);
            return this
        };
        b.warn = function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            j("warn", this.category, a, c);
            return this
        };
        b.error = function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            j("error", this.category, a, c);
            return this
        };
        return a
    }();

    function a(a) {
        h[a] || (h[a] = new k(a));
        return h[a]
    }

    function b() {
        return i
    }

    function c() {
        i.length = 0
    }

    function d(a) {
        return a.map(function(a) {
            var b = new Date(a.date).toISOString();
            return [b, a.level, a.category, a.event, a.args].join(" | ")
        }).join("\n")
    }
    f.getInstance = a;
    f.getEntries = b;
    f.clearEntries = c;
    f.formatEntries = d
}), 66);
__d("forEachObject", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = Object.prototype.hasOwnProperty;

    function a(a, b, c) {
        for (var d in a) {
            var e = d;
            g.call(a, e) && b.call(c, a[e], e, a)
        }
    }
    f["default"] = a
}), 66);
__d("joinClasses", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a || "",
            c = arguments.length <= 1 ? 0 : arguments.length - 1;
        for (var d = 0; d < c; d++) {
            var e = d + 1 < 1 || arguments.length <= d + 1 ? void 0 : arguments[d + 1];
            e != null && e !== "" && (b = (b ? b + " " : "") + e)
        }
        return b
    }
    f["default"] = a
}), 66);
__d("requireDeferredForDisplay", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("requireDeferred").call(null, a)
    }
    g["default"] = a
}), 98);
__d("cssVar", [], (function(a, b, c, d, e, f) {
    function a(a) {
        throw new Error('cssVar("' + a + '"): Unexpected class transformation.')
    }
    f["default"] = a
}), 66);