; /*FB_PKG_DELIM*/

__d("CometVisualCompletionConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = "data-visualcompletion";
    b = "HeroTracing";
    c = "InteractionTracing";
    d = "ignore";
    e = "ignore-dynamic";
    var g = "ignore-late-mutation",
        h = "loading-state",
        i = "media-vc-image",
        j = "css-img";
    f.ATTRIBUTE_NAME = a;
    f.HERO_TRACING_HOLD = b;
    f.INTERACTION_TRACING_HOLD = c;
    f.IGNORE = d;
    f.IGNORE_DYNAMIC = e;
    f.IGNORE_LATE_MUTATION = g;
    f.LOADING_STATE = h;
    f.MEDIA_VC_IMAGE = i;
    f.CSS_IMG = j
}), 66);
__d("CometVisualCompletionAttributes", ["CometVisualCompletionConstants"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = {
        CSS_IMG: (a = {}, a[d("CometVisualCompletionConstants").ATTRIBUTE_NAME] = d("CometVisualCompletionConstants").CSS_IMG, a),
        IGNORE: (b = {}, b[d("CometVisualCompletionConstants").ATTRIBUTE_NAME] = d("CometVisualCompletionConstants").IGNORE, b),
        IGNORE_DYNAMIC: (c = {}, c[d("CometVisualCompletionConstants").ATTRIBUTE_NAME] = d("CometVisualCompletionConstants").IGNORE_DYNAMIC, c),
        IGNORE_LATE_MUTATION: (e = {}, e[d("CometVisualCompletionConstants").ATTRIBUTE_NAME] = d("CometVisualCompletionConstants").IGNORE_LATE_MUTATION, e),
        LOADING_STATE: (f = {}, f[d("CometVisualCompletionConstants").ATTRIBUTE_NAME] = d("CometVisualCompletionConstants").LOADING_STATE, f),
        MEDIA_VC_IMAGE: (a = {}, a[d("CometVisualCompletionConstants").ATTRIBUTE_NAME] = d("CometVisualCompletionConstants").MEDIA_VC_IMAGE, a)
    };
    g["default"] = b
}), 98);
__d("warning", ["WebDriverConfig", "cr:1105154", "cr:11202", "cr:2682"], (function(a, b, c, d, e, f, g) {
    a = b("cr:2682");
    c = a;
    g["default"] = c
}), 98);
__d("react-relay/relay-hooks/ProfilerContext", ["react"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;
    a = g || b("react");
    c = a.createContext({
        wrapPrepareQueryResource: function(a) {
            return a()
        }
    });
    e.exports = c
}), null);
__d("RelayProfilerContext", ["react-relay/relay-hooks/ProfilerContext"], (function(a, b, c, d, e, f, g) {
    g["default"] = c("react-relay/relay-hooks/ProfilerContext")
}), 98);
__d("clamp", [], (function(a, b, c, d, e, f) {
    function a(a, b, c) {
        if (a < b) return b;
        return a > c ? c : a
    }
    f["default"] = a
}), 66);
__d("isRelativeURL", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = /^(#|\/\w)/;

    function a(a) {
        return g.test(a)
    }
    f["default"] = a
}), 66);
__d("usePrevious", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef;

    function a(a) {
        var b = i(null);
        h(function() {
            b.current = a
        });
        return b.current
    }
    g["default"] = a
}), 98);
__d("isClickIDBlacklistSVDomainURI", ["ClickIDDomainBlacklistSVConfig"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = ["http", "https"];

    function a(a) {
        return !g.includes(a.getProtocol()) ? !1 : b("ClickIDDomainBlacklistSVConfig").domains.some(function(b) {
            if (a.isSubdomainOfDomain(b)) return !0;
            if (!b.includes(".")) {
                var c = a.getDomain().split(".");
                return c.includes(b)
            }
            return !1
        })
    }
    e.exports = a
}), null);
__d("isEnterpriseURI", [], (function(a, b, c, d, e, f) {
    function a(a) {
        if (a.isEmpty() && a.toString() !== "#") return !1;
        if (!a.getDomain() && !a.getProtocol()) return !1;
        return a.getProtocol() !== "https" ? !1 : a.getDomain().includes("facebookenterprise.com") || a.getDomain().includes("metaenterprise.com")
    }
    f["default"] = a
}), 66);
__d("isFacebookSVDomainURI", ["FBDomainsSVConfig"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = ["http", "https"];

    function a(a) {
        if (g.indexOf(a.getProtocol()) === -1) return !1;
        a = b("FBDomainsSVConfig").domains.get(a.getDomain());
        return a != null
    }
    e.exports = a
}), null);
__d("isFbDotComURI", [], (function(a, b, c, d, e, f) {
    var g = new RegExp("(^|\\.)fb\\.com?$", "i"),
        h = ["http", "https"];

    function a(a) {
        if (a.isEmpty() && a.toString() !== "#") return !1;
        return !a.getDomain() && !a.getProtocol() ? !1 : h.indexOf(a.getProtocol()) !== -1 && g.test(a.getDomain())
    }
    f["default"] = a
}), 66);
__d("isInstagramURI", [], (function(a, b, c, d, e, f) {
    var g = null;

    function a(a) {
        if (a.isEmpty() && a.toString() !== "#") return !1;
        if (!a.getDomain() && !a.getProtocol()) return !1;
        if (a.getProtocol() !== "https") return !1;
        g || (g = new RegExp("(^|\\.)instagram\\.com$", "i"));
        return g.test(a.getDomain())
    }
    f["default"] = a
}), 66);
__d("isRoomsURI", [], (function(a, b, c, d, e, f) {
    var g = new RegExp("(^|\\.)msngr\\.com$", "i"),
        h = new RegExp("(^|\\.)fbaud\\.io$", "i"),
        i = new RegExp("(^|\\.)fb\\.audio$", "i"),
        j = ["https"];

    function a(a) {
        if (a.isEmpty() && a.toString() !== "#") return !1;
        return !a.getDomain() && !a.getProtocol() ? !1 : j.indexOf(a.getProtocol()) !== -1 && (g.test(a.getDomain()) || h.test(a.getDomain()) || i.test(a.getDomain()))
    }
    f["default"] = a
}), 66);
__d("isTrustedCMSContentURI", [], (function(a, b, c, d, e, f) {
    function a(a) {
        return !0
    }
    f["default"] = a
}), 66);
__d("isWhatsAppURI", [], (function(a, b, c, d, e, f) {
    var g = new RegExp("(^|\\.)whatsapp\\.com$", "i");

    function a(a) {
        if (a.isEmpty() && a.toString() !== "#") return !1;
        if (!a.getDomain() && !a.getProtocol()) return !1;
        return a.getProtocol() !== "https" ? !1 : g.test(a.getDomain())
    }
    f["default"] = a
}), 66);
__d("isWorkAccountsURI", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = /(work|work-test)\.facebook\.com|(^|\.)work\.meta\.com$/i;

    function a(a) {
        return a.getProtocol() === "https" && h(a.getDomain())
    }

    function h(a) {
        return g.test(a)
    }
    f.isWorkAccountsURI = a;
    f.isWorkAccountsDomain = h
}), 66);
__d("isTrustedDestination", ["LinkshimHandlerConfig", "isBulletinDotComURI", "isEnterpriseURI", "isFacebookURI", "isInstagramURI", "isInternalFBURI", "isOculusDotComURI", "isRoomsURI", "isTrustedCMSContentURI", "isWhatsAppURI", "isWorkAccountsURI", "isWorkplaceDotComURI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        return /(^|\.)oculus\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function i() {
        return /(^|\.)workplace\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function j() {
        return d("isWorkAccountsURI").isWorkAccountsDomain(c("LinkshimHandlerConfig").current_domain)
    }

    function k() {
        return /(^|\.)accountscenter\.meta\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function l() {
        return /(^|\.)(facebook|meta)enterprise\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function m() {
        return /(^|\.)bulletin\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function n() {
        return /(^|\.)www\.meta\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function o() {
        return /^store(\..+)?\.facebook\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function p() {
        return /(^|\.)about\.meta\.com$|^about(\..+)?\.facebook\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function q() {
        return /(^|\.)internalfb\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function r() {
        return /(^|\.)instagram\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function s() {
        return /(^|\.)whatsapp\.com$/.test(c("LinkshimHandlerConfig").current_domain)
    }

    function t(a) {
        return c("isFacebookURI")(a)
    }

    function u(a) {
        return c("isWorkplaceDotComURI")(a)
    }

    function a(a) {
        if (c("isRoomsURI")(a) && c("LinkshimHandlerConfig").is_mobile_device === !0) return !0;
        if (i()) return u(a);
        if (q()) return c("isInternalFBURI")(a) || t(a);
        if (h()) return c("isOculusDotComURI")(a);
        if (r()) return c("isInstagramURI")(a);
        if (s()) return c("isWhatsAppURI")(a);
        if (j()) return d("isWorkAccountsURI").isWorkAccountsURI(a) || t(a);
        if (k()) return t(a) || c("isInstagramURI")(a);
        if (l()) return c("isEnterpriseURI")(a);
        if (m()) return c("isBulletinDotComURI")(a);
        return o() || n() || p() ? c("isTrustedCMSContentURI")(a) : t(a)
    }
    g["default"] = a
}), 98);
__d("HeroInteractionContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = function() {};
    c = {
        consumeBootload: b,
        hold: function() {
            return ""
        },
        logHeroRender: b,
        logMetadata: b,
        logPageletVC: b,
        logReactCommit: b,
        logReactPostCommit: b,
        logReactRender: b,
        pageletStack: [],
        registerPlaceholder: b,
        removePlaceholder: b,
        suspenseCallback: b,
        unhold: b
    };
    e = a.createContext(c);
    g.DEFAULT_CONTEXT_VALUE = c;
    g.Context = e
}), 98);
__d("HeroInteractionIDContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("HeroComponent.react", ["HeroInteractionContext", "HeroInteractionIDContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    e = d("react");
    var h = e.useContext,
        i = e.useLayoutEffect;

    function a(a) {
        var b = a.description,
            e = h(d("HeroInteractionContext").Context),
            f = h(c("HeroInteractionIDContext"));
        i(function() {
            f != null && e.logHeroRender(f, b, e.pageletStack)
        }, [b, e, f]);
        return null
    }
    a.displayName = "HeroComponent";
    f = b.memo(a);
    g["default"] = f
}), 98);
__d("HeroCurrentInteractionForLoggingContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        current: null
    });
    g["default"] = b
}), 98);
__d("HeroFallbackTracker.react", ["HeroInteractionContext", "HeroInteractionIDContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useContext,
        i = b.useLayoutEffect;

    function a(a) {
        var b = a.uuid,
            e = h(d("HeroInteractionContext").Context),
            f = h(c("HeroInteractionIDContext"));
        i(function() {
            if (f != null) {
                e.registerPlaceholder(f, b, e.pageletStack);
                return function() {
                    e.removePlaceholder(f, b)
                }
            }
        }, [e, f, b]);
        return null
    }
    a.displayName = "HeroFallbackTracker";
    g["default"] = a
}), 98);
__d("HeroHoldTrigger.react", ["HeroInteractionContext", "HeroInteractionIDContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    b = d("react");
    var h = b.useContext,
        i = b.useLayoutEffect;

    function a(a) {
        var b = a.description,
            e = a.hold,
            f = h(d("HeroInteractionContext").Context),
            g = h(c("HeroInteractionIDContext"));
        i(function() {
            if (e && g != null) {
                var a = f.hold(g, f.pageletStack, b);
                return function() {
                    f.unhold(g, a)
                }
            }
        }, [b, f, g, e]);
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a.displayName = "HeroHoldTrigger";
    g["default"] = a
}), 98);
__d("HeroInteractionContextPassthrough.react", ["HeroCurrentInteractionForLoggingContext", "HeroInteractionContext", "HeroInteractionIDContext", "RelayProfilerContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            current: null
        },
        j = {
            consumeBootload: function() {},
            retainQuery: function() {},
            wrapPrepareQueryResource: function(a) {
                return a()
            }
        };

    function a(a) {
        var b = a.children;
        a = a.clear;
        a = a === void 0 ? !0 : a;
        return !a ? b : h.jsx(d("HeroInteractionContext").Context.Provider, {
            value: d("HeroInteractionContext").DEFAULT_CONTEXT_VALUE,
            children: h.jsx(c("HeroCurrentInteractionForLoggingContext").Provider, {
                value: i,
                children: h.jsx(c("HeroInteractionIDContext").Provider, {
                    value: null,
                    children: h.jsx(c("RelayProfilerContext").Provider, {
                        value: j,
                        children: b
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a.displayName = "HeroInteractionContextPassthrough";
    g["default"] = a
}), 98);
__d("HeroPendingPlaceholderTracker", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = new Map();

    function a(a) {
        g.has(a) || g.set(a, new Map())
    }

    function b(a, b, c) {
        a = g.get(a);
        a && a.set(b, c)
    }

    function c(a) {
        a = g.get(a);
        var b = [];
        a && a.forEach(function(a) {
            return b.push(a)
        });
        return b
    }

    function d(a) {
        g["delete"](a)
    }

    function e(a, b) {
        a = g.get(a);
        a && a["delete"](b)
    }

    function h(a) {
        return g.has(a)
    }
    f.addInteraction = a;
    f.addPlaceholder = b;
    f.dump = c;
    f.removeInteraction = d;
    f.removePlaceholder = e;
    f.isInteractionActive = h
}), 66);
__d("HeroPlaceholderUtils", ["PromiseAnnotate"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 0;

    function a() {
        return String(h++)
    }

    function b(a) {
        if (a != null && a.size > 0) return Array.from(a).map(function(a) {
            a = d("PromiseAnnotate").getDisplayName(a);
            if (a != null) return a;
            else return "Promise"
        }).join(",");
        else return null
    }
    g.getSimpleUUID = a;
    g.createThenableDescription = b
}), 98);
__d("useStable", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useRef;

    function a(a) {
        var b = h(null),
            c = b.current;
        if (c === null) {
            a = a();
            b.current = {
                value: a
            };
            return a
        } else return c.value
    }
    g["default"] = a
}), 98);
__d("HeroPlaceholder.react", ["HeroFallbackTracker.react", "HeroInteractionContext", "HeroInteractionIDContext", "HeroPlaceholderUtils", "react", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useLayoutEffect,
        l = b.useRef;
    e = function(a) {
        a = a.children;
        return a
    };

    function m(a) {
        var b = a.cb,
            c = l(!1);
        k(function() {
            c.current || (b(), c.current = !0)
        });
        return null
    }

    function a(a) {
        var b = a.children,
            e = a.fallback,
            f = a.name,
            g = a.unstable_avoidThisFallback,
            n = a.unstable_onSuspense,
            o = j(d("HeroInteractionContext").Context),
            p = j(c("HeroInteractionIDContext")),
            q = c("useStable")(d("HeroPlaceholderUtils").getSimpleUUID),
            r = c("useStable")(d("HeroPlaceholderUtils").getSimpleUUID),
            s = l(!1);
        a = b;
        b = i(function(a) {
            p != null && o.suspenseCallback(p, q, o.pageletStack, a, f);
            if (n) {
                a = (a = d("HeroPlaceholderUtils").createThenableDescription(a)) != null ? a : "";
                n(a)
            }
        }, [o, p, f, q, n]);
        k(function() {
            if (s.current === !1 && p != null && p != null) {
                o.hold(p, o.pageletStack, "Hydration", r, f);
                return function() {
                    return o.unhold(p, r)
                }
            }
        }, [o, p, f, r]);
        var t = function() {
            s.current = !0, p != null && o.unhold(p, r)
        };
        return h.jsxs(h.Suspense, {
            fallback: h.jsxs(h.Fragment, {
                children: [e, h.jsx(m, {
                    cb: t
                }), h.jsx(c("HeroFallbackTracker.react"), {
                    uuid: q
                })]
            }),
            suspenseCallback: b,
            unstable_avoidThisFallback: g,
            children: [h.jsx(m, {
                cb: t
            }), a]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a.displayName = "HeroPlaceholder";
    g["default"] = a
}), 98);
__d("hero-tracing-placeholder", ["HeroComponent.react", "HeroCurrentInteractionForLoggingContext", "HeroHoldTrigger.react", "HeroInteractionContext", "HeroInteractionContextPassthrough.react", "HeroInteractionIDContext", "HeroPendingPlaceholderTracker", "HeroPlaceholder.react", "HeroPlaceholderUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g.HeroComponent = c("HeroComponent.react"), g.HeroHoldTrigger = c("HeroHoldTrigger.react"), g.HeroInteractionContext = d("HeroInteractionContext"), g.HeroInteractionContextPassthrough = c("HeroInteractionContextPassthrough.react"), g.HeroInteractionIDContext = c("HeroInteractionIDContext"), g.HeroCurrentInteractionForLoggingContext = c("HeroCurrentInteractionForLoggingContext"), g.HeroPendingPlaceholderTracker = d("HeroPendingPlaceholderTracker"), g.HeroPlaceholder = c("HeroPlaceholder.react"), g.HeroPlaceholderUtils = d("HeroPlaceholderUtils")
}), 98);
__d("ActorURIConfig", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        PARAMETER_ACTOR: "av",
        ENCRYPTED_PARAMETER_ACTOR: "eav"
    });
    f["default"] = a
}), 66);
__d("JSResource", ["JSResourceReferenceImpl"], (function(a, b, c, d, e, f, g) {
    var h = {};

    function i(a, b) {
        h[a] = b
    }

    function j(a) {
        return h[a]
    }

    function a(a) {
        a = a;
        var b = j(a);
        if (b) return b;
        b = new(c("JSResourceReferenceImpl"))(a);
        i(a, b);
        return b
    }
    a.loadAll = c("JSResourceReferenceImpl").loadAll;
    g["default"] = a
}), 98);
__d("JSResourceForInteraction", ["JSResource"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return c("JSResource").call(null, a)
    }
    b = a;
    g["default"] = b
}), 98);
__d("TrackingNodeConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = 58;
    b = 126;
    c = 69;
    d = 42;
    e = 47;
    var g = 6,
        h = 100,
        i = 33,
        j = 38,
        k = (g + 1) * c,
        l = "__tn__";
    f.BASE_CODE_START = a;
    f.BASE_CODE_END = b;
    f.BASE_CODE_SIZE = c;
    f.PREFIX_CODE_START = d;
    f.PREFIX_CODE_END = e;
    f.PREFIX_CODE_SIZE = g;
    f.ENCODE_NUMBER_MAX = h;
    f.ENCODED_STRING_WITH_TWO_SYMBOLS_PREFIX_CODE = i;
    f.ENCODED_STRING_WITH_THREE_SYMBOLS_PREFIX_CODE = j;
    f.TOTAL_IDS_SUPPORTED_BY_LEGACY_ENCODING = k;
    f.TN_URL_PARAM = l
}), 66);
__d("decodeTrackingNode", ["TrackingNodeConstants"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a.length === 0) return [0];
        var b = function(a, b, e) {
                var c = 0;
                for (var f = b; f < e + b; f += 1) {
                    if (!(f < a.length && a.charCodeAt(f) >= d("TrackingNodeConstants").BASE_CODE_START && a.charCodeAt(f) <= d("TrackingNodeConstants").BASE_CODE_END)) return null;
                    c = c * d("TrackingNodeConstants").BASE_CODE_SIZE + (a.charCodeAt(f) - d("TrackingNodeConstants").BASE_CODE_START)
                }
                return c
            },
            c = function(a, c) {
                if (c >= a.length) return [null, c];
                var e = c,
                    f = null,
                    g = 0;
                switch (a.charCodeAt(0)) {
                    case d("TrackingNodeConstants").ENCODED_STRING_WITH_TWO_SYMBOLS_PREFIX_CODE:
                        f = b(a, c, 2);
                        g = d("TrackingNodeConstants").TOTAL_IDS_SUPPORTED_BY_LEGACY_ENCODING;
                        e += 2;
                        break;
                    case d("TrackingNodeConstants").ENCODED_STRING_WITH_THREE_SYMBOLS_PREFIX_CODE:
                        f = b(a, c, 3);
                        g = d("TrackingNodeConstants").TOTAL_IDS_SUPPORTED_BY_LEGACY_ENCODING + Math.pow(d("TrackingNodeConstants").BASE_CODE_SIZE, 2);
                        e += 3;
                        break;
                    default:
                        return [null, c]
                }
                return f === null ? [null, c] : [g + ((a = f) != null ? a : 0) + 1, e]
            },
            e = a.charCodeAt(0),
            f = 1,
            g = 0,
            h = 0,
            i = 0;
        if ([d("TrackingNodeConstants").ENCODED_STRING_WITH_TWO_SYMBOLS_PREFIX_CODE, d("TrackingNodeConstants").ENCODED_STRING_WITH_THREE_SYMBOLS_PREFIX_CODE].includes(e)) {
            var j;
            c = c(a, f);
            if (c[0] === null) return [0];
            i = (j = c[0]) != null ? j : -1;
            f = c[1]
        } else {
            if (e >= d("TrackingNodeConstants").PREFIX_CODE_START && e <= d("TrackingNodeConstants").PREFIX_CODE_END) {
                if (a.length === 1) return [0];
                h = e - d("TrackingNodeConstants").PREFIX_CODE_START + 1;
                g = a.charCodeAt(1);
                f = 2
            } else h = 0, g = e;
            if (g < d("TrackingNodeConstants").BASE_CODE_START || g > d("TrackingNodeConstants").BASE_CODE_END) return [0];
            i = h * d("TrackingNodeConstants").BASE_CODE_SIZE + (g - d("TrackingNodeConstants").BASE_CODE_START) + 1
        }
        if (a.length > f + 2 && a.charAt(f) === "#" && a.charAt(f + 1) >= "0" && a.charAt(f + 1) <= "9" && a.charAt(f + 2) >= "0" && a.charAt(f + 2) <= "9") return [f + 3, [i, parseInt(a.charAt(f + 1) + a.charAt(f + 2), 10) + 1]];
        return a.length > f && a.charAt(f) >= "0" && a.charAt(f) <= "9" ? [f + 1, [i, parseInt(a.charAt(f), 10) + 1]] : [f, [i]]
    }
    g["default"] = a
}), 98);
__d("encodeTrackingNode", ["TrackingNodeConstants"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var c = function(a) {
                return Math.pow(d("TrackingNodeConstants").BASE_CODE_SIZE, a)
            },
            e = function(a, b) {
                var c = "";
                a = a;
                b = b;
                while (b > 0) {
                    var e = a % d("TrackingNodeConstants").BASE_CODE_SIZE;
                    c = String.fromCharCode(d("TrackingNodeConstants").BASE_CODE_START + e) + c;
                    a = parseInt(a / d("TrackingNodeConstants").BASE_CODE_SIZE, 10);
                    b -= 1
                }
                return c
            },
            f = function(a) {
                a = a - d("TrackingNodeConstants").TOTAL_IDS_SUPPORTED_BY_LEGACY_ENCODING - 1;
                if (a < c(2)) return String.fromCharCode(d("TrackingNodeConstants").ENCODED_STRING_WITH_TWO_SYMBOLS_PREFIX_CODE) + e(a, 2);
                a -= c(2);
                return String.fromCharCode(d("TrackingNodeConstants").ENCODED_STRING_WITH_THREE_SYMBOLS_PREFIX_CODE) + e(a, 3)
            },
            g = (a - 1) % d("TrackingNodeConstants").BASE_CODE_SIZE,
            h = parseInt((a - 1) / d("TrackingNodeConstants").BASE_CODE_SIZE, 10);
        if (a < 1 || a > (d("TrackingNodeConstants").PREFIX_CODE_SIZE + 1) * d("TrackingNodeConstants").BASE_CODE_SIZE + Math.pow(d("TrackingNodeConstants").BASE_CODE_SIZE, 2) + Math.pow(d("TrackingNodeConstants").BASE_CODE_SIZE, 3)) throw Error("Invalid tracking node: " + a);
        var i = "";
        h > d("TrackingNodeConstants").PREFIX_CODE_SIZE ? i += f(a) : (h > 0 && (i += String.fromCharCode(h - 1 + d("TrackingNodeConstants").PREFIX_CODE_START)), i += String.fromCharCode(g + d("TrackingNodeConstants").BASE_CODE_START));
        b !== void 0 && b > 0 && (b > 10 && (i += "#"), i += parseInt(Math.min(b, d("TrackingNodeConstants").ENCODE_NUMBER_MAX) - 1, 10));
        return i
    }
    g["default"] = a
}), 98);
__d("mergeRefs", ["recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        for (var a = arguments.length, b = new Array(a), d = 0; d < a; d++) b[d] = arguments[d];
        return function(a) {
            b.forEach(function(b) {
                if (b == null) return;
                if (typeof b === "function") {
                    b(a);
                    return
                }
                if (typeof b === "object") {
                    b.current = a;
                    return
                }
                c("recoverableViolation")("mergeRefs cannot handle Refs of type boolean, number or string, received ref " + String(b), "comet_ui")
            })
        }
    }
    g["default"] = a
}), 98);