; /*FB_PKG_DELIM*/

__d("addAnnotations", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        Object.keys(b).forEach(function(c) {
            var d;
            a[c] = Object.assign((d = a[c]) != null ? d : {}, b[c])
        })
    }
    f["default"] = a
}), 66);