; /*FB_PKG_DELIM*/

__d("CometLinkTrackingUtils.facebook", ["ConstUriUtils", "isFacebookURI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e) {
        if (a != null && a !== "#" && (e.length || b.length)) {
            var f = d("ConstUriUtils").getUri(a);
            if (f != null) {
                if (!c("isFacebookURI")(f)) return a;
                e.length && (f = f.addQueryParam("__cft__", e));
                b.length && f != null && (f = f.addQueryParam("__tn__", b.join("")));
                return f != null ? f.toString() : a
            }
        }
        return a
    }
    g.decorateHrefWithTrackingInfo = a
}), 98);
__d("ReactFlightDOMRelayClientIntegration", ["RelayFBModuleLoader"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return d("RelayFBModuleLoader").getModuleReference(a)
    }

    function b(a) {
        a.preload()
    }

    function c(a) {
        return d("RelayFBModuleLoader").read(a)
    }
    g.resolveModuleReference = a;
    g.preloadModule = b;
    g.requireModule = c
}), 98);
__d("ReactFlightDOMRelayClient-prod.modern", ["Promise", "ReactFlightDOMRelayClientIntegration", "react", "react-dom"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = g || b("react");

    function i(a) {
        for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++) b += "&args[]=" + encodeURIComponent(arguments[c]);
        return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }
    var j = Array.isArray;

    function k(a, b, c, d) {
        if ("string" === typeof d) return H(a, b, c, d);
        if ("object" === typeof d && null !== d) {
            if (j(d)) {
                c = [];
                for (b = 0; b < d.length; b++) c[b] = k(a, d, "" + b, d[b]);
                a = c[0] === o ? {
                    $$typeof: o,
                    type: c[1],
                    key: c[2],
                    ref: null,
                    props: c[3],
                    _owner: null
                } : c;
                return a
            }
            b = {};
            for (c in d) b[c] = k(a, d, c, d[c]);
            return b
        }
        return d
    }
    var l = {},
        m = b("react-dom").__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.Dispatcher,
        n = new WeakMap(),
        o = Symbol["for"]("react.element"),
        p = Symbol["for"]("react.lazy"),
        q = Symbol["for"]("react.default_value"),
        r = h.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ContextRegistry;

    function s(a, b, c, d) {
        this.status = a, this.value = b, this.reason = c, this._response = d
    }
    s.prototype = Object.create(b("Promise").prototype);
    s.prototype.then = function(a, b) {
        switch (this.status) {
            case "resolved_model":
                A(this);
                break;
            case "resolved_module":
                B(this)
        }
        switch (this.status) {
            case "fulfilled":
                a(this.value);
                break;
            case "pending":
            case "blocked":
                a && (null === this.value && (this.value = []), this.value.push(a));
                b && (null === this.reason && (this.reason = []), this.reason.push(b));
                break;
            default:
                b(this.reason)
        }
    };

    function t(a) {
        switch (a.status) {
            case "resolved_model":
                A(a);
                break;
            case "resolved_module":
                B(a)
        }
        switch (a.status) {
            case "fulfilled":
                return a.value;
            case "pending":
            case "blocked":
                throw a;
            default:
                throw a.reason
        }
    }

    function u(a, b) {
        for (var c = 0; c < a.length; c++) a[c](b)
    }

    function v(a, b, c) {
        switch (a.status) {
            case "fulfilled":
                u(b, a.value);
                break;
            case "pending":
            case "blocked":
                a.value = b;
                a.reason = c;
                break;
            case "rejected":
                c && u(c, a.reason)
        }
    }

    function w(a, b) {
        if ("pending" === a.status || "blocked" === a.status) {
            var c = a.reason;
            a.status = "rejected";
            a.reason = b;
            null !== c && u(c, b)
        }
    }

    function x(a, b) {
        if ("pending" === a.status || "blocked" === a.status) {
            var c = a.value,
                d = a.reason;
            a.status = "resolved_module";
            a.value = b;
            null !== c && (B(a), v(a, c, d))
        }
    }
    var y = null,
        z = null;

    function A(a) {
        var b = y,
            c = z;
        y = a;
        z = null;
        try {
            var d = k(a._response, l, "", a.value);
            null !== z && 0 < z.deps ? (z.value = d, a.status = "blocked", a.value = null, a.reason = null) : (a.status = "fulfilled", a.value = d)
        } catch (b) {
            a.status = "rejected", a.reason = b
        } finally {
            y = b, z = c
        }
    }

    function B(a) {
        try {
            var c = b("ReactFlightDOMRelayClientIntegration").requireModule(a.value);
            a.status = "fulfilled";
            a.value = c
        } catch (b) {
            a.status = "rejected", a.reason = b
        }
    }

    function C(a, b) {
        a._chunks.forEach(function(a) {
            "pending" === a.status && w(a, b)
        })
    }

    function D(a, b) {
        var c = a._chunks,
            d = c.get(b);
        d || (d = new s("pending", null, null, a), c.set(b, d));
        return d
    }

    function E(a, b, c) {
        if (z) {
            var d = z;
            d.deps++
        } else d = z = {
            deps: 1,
            value: null
        };
        return function(e) {
            b[c] = e, d.deps--, 0 === d.deps && "blocked" === a.status && (e = a.value, a.status = "fulfilled", a.value = d.value, null !== e && u(e, d.value))
        }
    }

    function F(a) {
        return function(b) {
            return w(a, b)
        }
    }

    function G(a, c) {
        function d() {
            var a = Array.prototype.slice.call(arguments),
                d = c.bound;
            return d ? "fulfilled" === d.status ? e(c.id, d.value.concat(a)) : b("Promise").resolve(d).then(function(b) {
                return e(c.id, b.concat(a))
            }) : e(c.id, a)
        }
        var e = a._callServer;
        n.set(d, c);
        return d
    }

    function H(a, b, c, d) {
        if ("$" === d[0]) {
            if ("$" === d) return o;
            switch (d[1]) {
                case "$":
                    return d.slice(1);
                case "L":
                    return b = parseInt(d.slice(2), 16), a = D(a, b), {
                        $$typeof: p,
                        _payload: a,
                        _init: t
                    };
                case "@":
                    return b = parseInt(d.slice(2), 16), D(a, b);
                case "S":
                    return Symbol["for"](d.slice(2));
                case "P":
                    return a = d.slice(2), r[a] || (r[a] = h.createServerContext(a, q)), r[a].Provider;
                case "F":
                    b = parseInt(d.slice(2), 16);
                    b = D(a, b);
                    switch (b.status) {
                        case "resolved_model":
                            A(b)
                    }
                    switch (b.status) {
                        case "fulfilled":
                            return G(a, b.value);
                        default:
                            throw b.reason
                    }
                case "I":
                    return Infinity;
                case "-":
                    return "$-0" === d ? -0 : -Infinity;
                case "N":
                    return NaN;
                case "u":
                    return;
                case "D":
                    return new Date(Date.parse(d.slice(2)));
                case "n":
                    return BigInt(d.slice(2));
                default:
                    d = parseInt(d.slice(1), 16);
                    a = D(a, d);
                    switch (a.status) {
                        case "resolved_model":
                            A(a);
                            break;
                        case "resolved_module":
                            B(a)
                    }
                    switch (a.status) {
                        case "fulfilled":
                            return a.value;
                        case "pending":
                        case "blocked":
                            return d = y, a.then(E(d, b, c), F(d)), null;
                        default:
                            throw a.reason
                    }
            }
        }
        return d
    }

    function I() {
        throw Error(i(466))
    }

    function J(a, c, d) {
        var e = a._chunks,
            f = e.get(c);
        d = k(a, l, "", d);
        var g = b("ReactFlightDOMRelayClientIntegration").resolveClientReference(d);
        if (d = b("ReactFlightDOMRelayClientIntegration").preloadModule(g)) {
            if (f) {
                var h = f;
                h.status = "blocked"
            } else h = new s("blocked", null, null, a), e.set(c, h);
            d.then(function() {
                return x(h, g)
            }, function(a) {
                return w(h, a)
            })
        } else f ? x(f, g) : e.set(c, new s("resolved_module", g, null, a))
    }
    f.close = function(a) {
        C(a, Error(i(412)))
    };
    f.createResponse = function(a, b) {
        var c = new Map();
        return {
            _bundlerConfig: a,
            _callServer: void 0 !== b ? b : I,
            _chunks: c
        }
    };
    f.getRoot = function(a) {
        return D(a, 0)
    };
    f.resolveRow = function(a, b) {
        if ("O" === b[0]) {
            var c = b[1],
                d = b[2];
            b = a._chunks;
            var e = b.get(c);
            e ? "pending" === e.status && (a = e.value, b = e.reason, e.status = "resolved_model", e.value = d, null !== a && (A(e), v(e, a, b))) : b.set(c, new s("resolved_model", d, null, a))
        } else if ("I" === b[0]) J(a, b[1], b[2]);
        else if ("H" === b[0]) {
            if (d = b[1], a = k(a, l, "", b[2]), b = m.current) switch ("string" === typeof a ? c = a : (c = a[0], e = a[1]), d) {
                case "D":
                    b.prefetchDNS(c, e);
                    break;
                case "C":
                    b.preconnect(c, e);
                    break;
                case "L":
                    b.preload(c, e);
                    break;
                case "I":
                    b.preinit(c, e)
            }
        } else d = b[1], b = b[2].digest, e = Error(i(441)), e.stack = "Error: " + e.message, e.digest = b, b = a._chunks, (c = b.get(d)) ? w(c, e) : b.set(d, new s("rejected", null, e, a))
    }
}), null);
__d("CometMouseActivity", ["clearTimeout", "removeFromArray", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 50,
        i = [],
        j = [],
        k = null;

    function l() {
        i.length > 0 && i.forEach(function(a) {
            return a()
        }), j.length > 0 && (j.forEach(function(a) {
            return a()
        }), j = []), k = null
    }

    function m() {
        c("clearTimeout")(k), k = c("setTimeout")(function() {
            l()
        }, h)
    }
    var n = !1;

    function o() {
        n || (window.addEventListener("mousemove", m), n = !0);
        return function() {
            window.removeEventListener("mousemove", m)
        }
    }

    function a(a) {
        n || o();
        i.push(a);
        return function() {
            c("removeFromArray")(i, a)
        }
    }

    function b(a) {
        n || o();
        j.push(a);
        return function() {
            c("removeFromArray")(j, a)
        }
    }
    d = {
        addOnMouseStopCallback: a,
        addOnMouseStopCallbackOnce: b,
        init: o
    };
    e = d;
    g["default"] = e
}), 98);
__d("useCometPreloaderImpl", ["Bootloader", "CometMouseActivity", "JSScheduler", "clearTimeout", "ifRequired", "react", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useEffect,
        j = b.useRef;

    function k(a) {
        return a.pointerType === "mouse"
    }

    function l(a) {
        a && (typeof a === "function" ? a() : a.preload())
    }
    var m = 50;

    function a(a, b, d, e) {
        var f = j(null),
            g = j(null),
            n = j(null),
            o = function(a) {
                c("ifRequired")("setTimeoutCometInternals", function(b) {
                    f.current = b.setTimeoutAtPriority_DO_NOT_USE(c("JSScheduler").priorities.unstable_UserBlocking, a, m)
                }, function() {
                    f.current = c("setTimeout")(a, m)
                })
            },
            p = h(function(e, f, g) {
                if (a === "tooltip" || (a === "button" || a === "button_aggressive") && b != null) {
                    e = function() {
                        a === "tooltip" ? (l(d), l(b), c("Bootloader").forceFlush()) : (a === "button" || a === "button_aggressive") && (l(b), c("Bootloader").forceFlush()), f && f()
                    };
                    o(e)
                }
                if (a === "button_aggressive") {
                    e = function() {
                        l(d), g && g()
                    };
                    n.current != null && (n.current(), n.current = null);
                    n.current = c("CometMouseActivity").addOnMouseStopCallbackOnce(e)
                }
            }, [d, b, a]),
            q = h(function() {
                c("clearTimeout")(f.current), f.current = null, e && e(), g.current != null && g.current(), n.current != null && n.current()
            }, [e]),
            r = h(function(b) {
                if (!k(b)) return;
                (a === "button" || a === "button_aggressive") && (l(d), c("Bootloader").forceFlush())
            }, [d, a]),
            s = h(function(a) {
                c("JSScheduler").scheduleSpeculativeCallback(function() {
                    a === !0 && (l(d), l(b), c("Bootloader").forceFlush())
                })
            }, [d, b]);
        i(function() {
            return function() {
                g.current != null && g.current(), n.current != null && n.current(), c("clearTimeout")(f.current)
            }
        }, []);
        return [p, q, r, s]
    }
    g["default"] = a
}), 98);
__d("useCometPrerendererImpl", ["emptyFunction", "react", "useCometPreloader"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    var h = a.useCallback,
        i = a.useState;
    b = function(a, b, d, e, f) {
        var g = i(!1),
            j = g[0],
            k = g[1];
        g = i(!1);
        var l = g[0],
            m = g[1];
        g = c("useCometPreloader")(a, d, e, f);
        var n = g[0],
            o = g[1],
            p = g[2],
            q = g[3];
        d = h(function(b) {
            var c = function() {
                    a === "tooltip" && k(!0)
                },
                d = function() {
                    a === "button_aggressive" && k(!0)
                };
            n(b, c, d)
        }, [n, a]);
        e = h(function() {
            o(), k(!1)
        }, [o]);
        f = h(function(b) {
            p(b), (a === "button" || a === "button_aggressive") && k(!0)
        }, [p, a]);
        g = h(function(a) {
            q(a), m(a)
        }, [q]);
        if (a == null) return [{
            isVisible: b,
            shouldPrerender: !1
        }, c("emptyFunction"), c("emptyFunction"), c("emptyFunction"), c("emptyFunction")];
        b = {
            isVisible: b,
            shouldPrerender: j || l
        };
        return [b, d, e, f, g]
    };
    e = b;
    g["default"] = e
}), 98);