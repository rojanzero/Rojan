; /*FB_PKG_DELIM*/

__d("CometRootInitServerFlag", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = !1;

    function a() {
        g = !0
    }

    function b() {
        return g
    }
    f.enableServerEnvironment = a;
    f.isServerEnvironment = b
}), 66);
__d("CometKeyCommandContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometKeyCommandSettingsContext", ["CometCustomKeyCommands", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    var h = c("CometCustomKeyCommands").areSingleKeysDisabled === null && !c("gkx")("1707273") ? !1 : c("CometCustomKeyCommands").areSingleKeysDisabled;
    b = a.createContext({
        addCustomCommand: function(a) {},
        checkForKeyCommandConflict: function(a) {
            return []
        },
        disableCustomCommand: function(a) {},
        getAreSingleKeysDisabled: function() {
            return h
        },
        getCustomCommandsMap: function() {
            return new Map()
        },
        getCustomKeyCombination: function(a) {},
        getModifiedKeyboardShortcutsPreference: function(a) {
            return 4
        },
        isViewerShowing: !1,
        resetAllCustomCommands: function(a) {},
        resetCustomCommand: function(a) {},
        setAreSingleKeysDisabled: function(a) {},
        setModifiedKeyboardShortcutsPreference: function(a) {},
        setViewerInfo: function(a) {},
        viewerType: "see_all"
    });
    g["default"] = b
}), 98);
__d("CometKeyCommandUtilsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometKeyCommandsTypedLoggerLite", ["generateLiteTypedLogger"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = b("generateLiteTypedLogger")("logger:CometKeyCommandsLoggerConfig")
}), null);
__d("areKeyCombinationsEqual", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a == null || b == null ? a === b : a.key !== "" && b.key !== "" && a.key === b.key && a.alt === !0 === (b.alt === !0) && a.command === !0 === (b.command === !0) && a.shift === !0 === (b.shift === !0)
    }
    f["default"] = a
}), 66);
__d("createKeyCommand", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = ["alt", "command", "shift"];

    function a(a) {
        return g.filter(function(b) {
            return (a == null ? void 0 : a[b]) === !0
        }).concat(a == null ? void 0 : a.key).join(" ")
    }
    f["default"] = a
}), 66);
__d("isSingleCharKey", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = /^[a-z0-9/]$/;

    function a(a) {
        return a != null ? g.test(a) : !1
    }
    f["default"] = a
}), 66);
__d("createKeyCommandWrapper", ["CometKeyCommandContext", "CometKeyCommandSettingsContext", "CometKeyCommandUtilsContext", "CometKeyCommandsTypedLoggerLite", "areKeyCombinationsEqual", "createKeyCommand", "gkx", "isSingleCharKey", "react", "recoverableViolation", "stylex", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useMemo,
        l = b.useRef,
        m = {
            wrapperFocusable: {
                ":focus_outline": "x1uvtmcs",
                $$css: !0
            }
        };

    function n(a) {
        if (a instanceof HTMLInputElement) return a.type !== "hidden" && a.type !== "file" && !a.disabled;
        return a instanceof HTMLSelectElement || a instanceof HTMLTextAreaElement ? !a.disabled : a instanceof HTMLElement && a.isContentEditable
    }

    function o(a) {
        return a instanceof HTMLElement && a.getAttribute("role") === "listbox" ? !a.getAttribute("aria-disabled") : !1
    }

    function p(a, b, c) {
        for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var g;
            if (e) {
                if (f >= d.length) break;
                g = d[f++]
            } else {
                f = d.next();
                if (f.done) break;
                g = f.value
            }
            g = g;
            var h = g[0];
            g = g[1];
            if (g.groupID === b && g.commandID === c) return a.get(h)
        }
    }

    function q(a, b) {
        return c("gkx")("3598") && b.triggerFromInputs === !0 && n(a) && ((a = b.command) == null ? void 0 : a.alt) === !0
    }
    var r = function(a, b) {
            c("recoverableViolation")("Tried to call showSingleCharacterKeyCommandWrapperDialogRef, but it was never set", "comet_ax")
        },
        s = function(a, b) {
            c("recoverableViolation")("Tried to call showModifiedKeyCommandWrapperDialogRef, but it was never set", "comet_ax")
        };

    function a(a, b) {
        return function(d) {
            var e = j(c("CometKeyCommandContext")),
                f = j(c("CometKeyCommandUtilsContext")),
                g = j(c("CometKeyCommandSettingsContext")),
                t = f && f.setActiveWrapper,
                u = l(r),
                v = l(s),
                w = c("useStable")(function() {
                    return new Map()
                }),
                x = i(function(a) {
                    var b, d = w.get(a);
                    if (((b = d) == null ? void 0 : b.groupID) != null && ((b = d) == null ? void 0 : b.commandID) != null) {
                        b = g.getCustomKeyCombination(d.groupID, d.commandID);
                        if (b == null || c("areKeyCombinationsEqual")(b, (b = d) == null ? void 0 : b.command)) return d;
                        else d = null
                    }
                    b = g.getCustomCommandsMap().get(a);
                    if (b != null && b.groupID != null && b.commandID != null) {
                        a = p(w, b.groupID, b.commandID);
                        a != null && (d = a)
                    }
                    return d
                }, [g, w]),
                y = k(function() {
                    return {
                        addCommands: function(a) {
                            a.forEach(function(a) {
                                var b = a.command;
                                if (b != null) {
                                    b = c("createKeyCommand")(b);
                                    w.set(b, a);
                                    f && f.notifyCommandUpdate()
                                }
                            });
                            return function() {
                                a.forEach(function(a) {
                                    var b = a.command;
                                    b = c("createKeyCommand")(b);
                                    var d = w.get(b);
                                    d === a && w["delete"](b)
                                }), f && f.notifyCommandUpdate()
                            }
                        },
                        applyCommand: function(a, b) {
                            var e, f = x(a);
                            if (f == null) return !1;
                            var h = /^[a-z0-9]$/;
                            if (c("gkx")("3598") && ((e = f.command) == null ? void 0 : e.alt) === !0 && g.getModifiedKeyboardShortcutsPreference() === 1) return !0;
                            if (!f.triggerFromInputs && n(b.target) || o(b.target) && h.test(a)) return !1;
                            if (b.type === "keyup" && f.triggerOnKeyUp !== !0 && f.triggerOnKeyUpAndKeyDown !== !0) return !1;
                            if (b.type === "keydown" && f.triggerOnKeyUp === !0) return !1;
                            if (f.shouldPreventDefault !== !1) {
                                if (q(b.target, f) && g.getModifiedKeyboardShortcutsPreference() === 3) return !0;
                                b.preventDefault()
                            }
                            if (f.triggerOnRepeats === !1 && b.repeat === !0) return !1;
                            e = f.handler;
                            if (e != null) {
                                if (f.command != null && q(b.target, f) && g.getModifiedKeyboardShortcutsPreference() === 4) {
                                    v.current(f.command, f.singleCharDescription);
                                    return !0
                                }
                                h = g && g.getAreSingleKeysDisabled();
                                b = c("isSingleCharKey")(a);
                                if (h === !0 && b) return !0;
                                if (h === null && b) {
                                    u.current(a, f.singleCharDescription);
                                    return !0
                                }
                                e();
                                h = f.description;
                                c("CometKeyCommandsTypedLoggerLite").log({
                                    key_combo: a,
                                    key_context: d.debugName,
                                    key_description: h
                                });
                                return f.shouldStopPropagation !== !1
                            }
                            return !1
                        },
                        debugName: d.debugName,
                        getCommandMap: function() {
                            return w
                        },
                        getParent: function() {
                            return e
                        },
                        removeCommand: function(a) {
                            w["delete"](a), f && f.notifyCommandUpdate()
                        },
                        setShowModifiedKeyCommandWrapperDialogRef: function(a) {
                            v.current = a;
                            return function() {
                                v.current = s
                            }
                        },
                        setShowSingleCharacterKeyCommandWrapperDialogRef: function(a) {
                            u.current = a;
                            return function() {
                                u.current = r
                            }
                        }
                    }
                }, [g, f, w, e, d.debugName, v, u, x]),
                z = i(function() {
                    if (!t) {
                        c("recoverableViolation")("setActiveWrapper is undefined in " + (d.debugName != null ? d.debugName : "unknown"), "comet_ax");
                        return
                    }
                    t(y)
                }, [t, y, d.debugName]);
            if (a || d.elementType !== void 0) {
                var A;
                A = (A = d.elementType) != null ? A : "div";
                A = h.jsx(A, {
                    className: c("stylex")(d.isWrapperFocusable ? m.wrapperFocusable : void 0, d.xstyle),
                    "data-testid": void 0,
                    onFocusCapture: a ? z : void 0,
                    tabIndex: d.isWrapperFocusable ? -1 : void 0,
                    children: d.children
                })
            } else A = d.children;
            b && (A = h.jsx(b.Provider, {
                value: y,
                children: A
            }));
            return h.jsx(c("CometKeyCommandContext").Provider, {
                value: y,
                children: A
            })
        }
    }
    g["default"] = a
}), 98);
__d("createKeyCommandWidget", ["createKeyCommandWrapper", "react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useEffect;

    function a(a) {
        a === void 0 && (a = !0);
        var b = h.createContext();
        a = c("createKeyCommandWrapper")(a, b);

        function d(a, d) {
            d === void 0 && (d = !1);
            var e = i(b);
            j(function() {
                if (!e) {
                    d || c("recoverableViolation")("Attempting to register a key command outside of its widget scope. Calls to useKeyCommand must be within its widget's wrapper.", "comet_ax");
                    return
                }
                if (a) return e.addCommands(a)
            }, [e, a, d])
        }
        return {
            Context: b,
            Wrapper: a,
            useKeyCommands: d
        }
    }
    g["default"] = a
}), 98);
__d("CometKeyCommandWidget", ["createKeyCommandWidget"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("createKeyCommandWidget")();
    g["default"] = a
}), 98);
__d("CometKeyCommandWrapper.react", ["CometKeyCommandWidget", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.children;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children"]);
        return h.jsx(c("CometKeyCommandWidget").Wrapper, babelHelpers["extends"]({}, a, {
            children: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useKeyCommands", ["CometKeyCommandWidget"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("CometKeyCommandWidget").useKeyCommands
}), 98);
__d("CometComponentWithKeyCommands.react", ["CometKeyCommandWrapper.react", "react", "useKeyCommands"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            displayInherit: {
                display: "x1jfb8zj",
                $$css: !0
            },
            inherit: {
                alignContent: "x4k7w5x",
                alignItems: "x1h91t0o",
                flexDirection: "x1beo9mf",
                flexGrow: "xaigb6o",
                flexShrink: "x12ejxvf",
                height: "x3igimt",
                justifyContent: "xarpa2k",
                maxHeight: "xedcshv",
                maxWidth: "x1lytzrv",
                minHeight: "x1t2pt76",
                minWidth: "x7ja8zs",
                position: "x1n2onr6",
                width: "x1qrby5j",
                $$css: !0
            }
        };

    function j(a) {
        c("useKeyCommands")(a.commandConfigs);
        return null
    }

    function a(a) {
        var b = a.children,
            d = a.commandConfigs,
            e = a.elementType,
            f = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "commandConfigs", "elementType", "xstyle"]);
        var g = e === "span" ? i.inherit : [i.inherit, i.displayInherit];
        return h.jsxs(c("CometKeyCommandWrapper.react"), babelHelpers["extends"]({
            elementType: e,
            xstyle: f != null ? f : g
        }, a, {
            children: [h.jsx(j, {
                commandConfigs: d
            }), b]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometKeys", ["Locale"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = Object.freeze({
        AREA_NAV: "f6",
        COMMA: ",",
        DEL: "delete",
        DELETE: "backspace",
        DOWN: "arrowdown",
        END: "end",
        ENTER: "enter",
        EQUAL: "=",
        ESCAPE: "escape",
        HOME: "home",
        LEFT: d("Locale").isRTL() ? "arrowright" : "arrowleft",
        LEFT_SQUARE_BRACKET: "[",
        MINUS: "-",
        NEXT: d("Locale").isRTL() ? "arrowleft" : "arrowright",
        PAGE_DOWN: "pagedown",
        PAGE_UP: "pageup",
        PREVIOUS: d("Locale").isRTL() ? "arrowright" : "arrowleft",
        QUESTION: "?",
        RIGHT: d("Locale").isRTL() ? "arrowleft" : "arrowright",
        RIGHT_SQUARE_BRACKET: "]",
        SEMI_COLON: ";",
        SLASH: "/",
        SPACE: " ",
        TAB: "tab",
        UP: "arrowup",
        F1: "f1",
        F2: "f2",
        F3: "f3",
        F4: "f4",
        F5: "f5",
        F6: "f6",
        F7: "f7",
        F8: "f8",
        F9: "f9",
        F10: "f10",
        F11: "f11",
        F12: "f12",
        ONE: "1",
        TWO: "2",
        THREE: "3",
        FOUR: "4",
        FIVE: "5",
        SIX: "6",
        SEVEN: "7",
        EIGHT: "8",
        NINE: "9",
        ZERO: "0",
        A: "a",
        B: "b",
        C: "c",
        D: "d",
        E: "e",
        F: "f",
        G: "g",
        H: "h",
        I: "i",
        J: "j",
        K: "k",
        L: "l",
        M: "m",
        N: "n",
        O: "o",
        P: "p",
        Q: "q",
        R: "r",
        S: "s",
        T: "t",
        U: "u",
        V: "v",
        W: "w",
        X: "x",
        Y: "y",
        Z: "z"
    });
    b = a;
    g["default"] = b
}), 98);
__d("CometHideLayerOnEscape.react", ["fbt", "CometComponentWithKeyCommands.react", "CometKeys", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = d("react").useMemo;

    function a(a) {
        var b = a.children,
            d = a.debugName;
        d = d === void 0 ? "ModalLayer" : d;
        var e = a.onHide;
        a = j(function() {
            return [{
                command: {
                    key: c("CometKeys").ESCAPE
                },
                description: h._("Close"),
                handler: e,
                triggerFromInputs: !0,
                triggerOnRepeats: !1
            }]
        }, [e]);
        return i.jsx(c("CometComponentWithKeyCommands.react"), {
            commandConfigs: a,
            debugName: d,
            isWrapperFocusable: !0,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometBase.react", ["BaseView.react"], (function(a, b, c, d, e, f) {
    "use strict";
    f["default"] = b("BaseView.react")
}), 66);
__d("getItemRoleFromCompositeRole", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (a) {
            case "grid":
                return "row";
            case "listbox":
                return "option";
            case "list":
                return "listitem";
            case "radiogroup":
                return "radio";
            case "row":
                return "gridcell";
            case "tablist":
                return "tab"
        }
        return null
    }
    f["default"] = a
}), 66);
__d("pointerEventDistance", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = 1,
        h = 5;

    function i(a, b, c, d) {
        return Math.sqrt(Math.pow(d - b, 2) + Math.pow(c - a, 2))
    }

    function j(a, b) {
        return i(a.clientX, a.clientY, b.clientX, b.clientY)
    }

    function a(a, b) {
        var c = b.pointerType === "touch" || b.pointerType === "pen" ? h : g;
        a = j(a, b);
        return a <= c
    }
    f.isWithinThreshold = a
}), 66);
__d("BaseDialog.react", ["BaseThemeProvider.react", "BaseView.react", "CometHideLayerOnEscape.react", "pointerEventDistance", "react", "stylex", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useEffect,
        j = b.useRef,
        k = {
            anchor: {
                alignItems: "x1cy8zhl",
                boxSizing: "x9f619",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                minHeight: "x2lwn1j",
                minWidth: "xeuugli",
                pointerEvents: "x47corl",
                $$css: !0
            },
            dialog: {
                boxSizing: "x1afcbsf",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                outline: "x1a2a7pz",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                pointerEvents: "x71s49j",
                $$css: !0
            },
            root: {
                alignItems: "x1qjc9v5",
                boxSizing: "x9f619",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                justifyContent: "xl56j7k",
                $$css: !0
            },
            rootWithDeprecatedStyles: {
                flexGrow: "x1c4vz4f",
                minHeight: "xg6iff7",
                $$css: !0
            }
        };

    function a(a, b) {
        var e = a.anchorXStyle,
            f = a.children,
            g = a.disableClosingWithMask,
            l = g === void 0 ? !1 : g,
            m = a.onClose,
            n = a.rootXStyle;
        g = a.testid;
        g = a.themeConfig;
        var o = a.withDeprecatedStyles,
            p = o === void 0 ? !1 : o,
            q = a.xstyle,
            r = babelHelpers.objectWithoutPropertiesLoose(a, ["anchorXStyle", "children", "disableClosingWithMask", "onClose", "rootXStyle", "testid", "themeConfig", "withDeprecatedStyles", "xstyle"]),
            s = j(null),
            t = j(null),
            u = j(null);
        i(function() {
            var a = s.current,
                b = t.current;
            if (a == null || b == null || l) return;

            function c(c) {
                return c instanceof Node && !b.contains(c) && a.contains(c)
            }
            var e = "PointerEvent" in window;
            if (!e) {
                var f = function(a) {
                    c(a.target) && m()
                };
                a.addEventListener("click", f);
                return function() {
                    a.removeEventListener("click", f)
                }
            }
            var g = !1;

            function h(a) {
                if (a.isPrimary) {
                    var b = c(a.target);
                    g = b;
                    u.current = a
                }
            }

            function i(a) {
                var b = c(a.target);
                if (g && b && u.current != null && a.isPrimary) {
                    b = d("pointerEventDistance").isWithinThreshold(u.current, a);
                    b && m()
                }
                g = !1;
                u.current = null
            }
            a.addEventListener("pointerup", i);
            a.addEventListener("pointerdown", h);
            return function() {
                a.removeEventListener("pointerup", i), a.removeEventListener("pointerdown", h)
            }
        }, [l, m]);
        var v = c("useMergeRefs")(t, b);
        return h.jsx(c("CometHideLayerOnEscape.react"), {
            onHide: m,
            children: h.jsx(c("BaseThemeProvider.react"), {
                config: g,
                children: function(a, b) {
                    return h.jsx("div", {
                        className: c("stylex")([a, k.root, p && k.rootWithDeprecatedStyles, n]),
                        ref: s,
                        style: b,
                        children: h.jsx("div", {
                            className: c("stylex")(k.anchor, e),
                            children: h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, r, {
                                ref: v,
                                role: "dialog",
                                testid: void 0,
                                xstyle: [k.dialog, q],
                                children: f
                            }))
                        })
                    })
                }
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("BaseModal.react", ["cr:1824473", "cr:994756", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    a = b("cr:1824473") != null ? b("cr:1824473") : b("cr:994756");
    g["default"] = a
}), 98);
__d("XPlatReactToasterStateManager", ["clearTimeout", "removeFromArray", "setTimeout", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {};

    function i(a) {
        var b = !1;
        return function() {
            b || (a(), b = !0)
        }
    }
    a = function() {
        function a(a) {
            var b = a.callbackScheduler;
            a = a.maxQueuedToasts;
            this.$1 = 0;
            this.$2 = new Map();
            this.$3 = [];
            this.$4 = [];
            this.$5 = null;
            this.$7 = b;
            this.$6 = a
        }
        var b = a.prototype;
        b.push = function(a, b) {
            var c = "toast-" + this.$1++;
            b = {
                duration: b,
                expired: !1,
                id: c,
                shown: !1,
                timer: null,
                value: a
            };
            this.$8({
                node: b,
                type: "PUSH"
            });
            return c
        };
        b.replace = function(a, b) {
            this.$8({
                id: a,
                type: "REPLACE",
                value: b
            })
        };
        b.shown = function(a) {
            this.$8({
                id: a,
                type: "SHOWN"
            })
        };
        b["delete"] = function(a) {
            this.$8({
                id: a,
                type: "DELETE"
            })
        };
        b.expire = function(a) {
            this.$8({
                id: a,
                type: "EXPIRE"
            })
        };
        b.hidden = function(a) {
            this.$8({
                id: a,
                type: "HIDDEN"
            })
        };
        b.stopTimer = function(a) {
            this.$8({
                id: a,
                type: "STOP_TIMER"
            })
        };
        b.resetTimer = function(a) {
            this.$8({
                id: a,
                type: "RESET_TIMER"
            })
        };
        b.getState = function() {
            return Object.fromEntries(this.$2)
        };
        b.getEmptyState = function() {
            return h
        };
        b.addListener = function(a) {
            var b = this;
            this.$3.push(a);
            return {
                remove: i(function() {
                    c("removeFromArray")(b.$3, a)
                })
            }
        };
        b.$9 = function(a) {
            (this.$5 == null || a.priority > this.$5.priority) && (this.$5 = a)
        };
        b.registerView = function(a, b) {
            var d = this;
            b === void 0 && (b = 1);
            var e = {
                handler: a,
                priority: b
            };
            this.$4.push(e);
            this.$9(e);
            this.$10();
            return {
                remove: i(function() {
                    c("removeFromArray")(d.$4, e), d.$5 === e && (d.$5 = null, d.$4.forEach(function(a) {
                        return d.$9(a)
                    }))
                })
            }
        };
        b.$8 = function(a) {
            var b = this.$2;
            switch (a.type) {
                case "PUSH":
                    var c = a.node;
                    this.$2 = new Map([].concat(Array.from(this.$2), [
                        [c.id, c]
                    ]));
                    if (this.$6 !== 0) {
                        c = Array.from(this.$2.values()).filter(function(a) {
                            return !a.shown && !a.expired
                        });
                        if (c.length > this.$6) {
                            c = c[0];
                            this["delete"](c.id)
                        }
                    }
                    break;
                case "SHOWN":
                    if (this.$2.has(a.id) && !this.$11(a.id).shown) {
                        c = babelHelpers["extends"]({}, this.$11(a.id), {
                            shown: !0
                        });
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, this.$12(c)]
                        ]))
                    }
                    break;
                case "EXPIRE":
                    if (this.$2.has(a.id)) {
                        c = babelHelpers["extends"]({}, this.$11(a.id), {
                            expired: !0
                        });
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, this.$13(c)]
                        ]));
                        this.$14(c)
                    }
                    break;
                case "HIDDEN":
                    if (this.$2.has(a.id)) {
                        c = this.$11(a.id);
                        (c.shown || c.expired) && (this.$2 = new Map(this.$2), this.$2["delete"](a.id), this.$13(c))
                    }
                    break;
                case "DELETE":
                    if (this.$2.has(a.id)) {
                        c = this.$11(a.id);
                        this.$2 = new Map(this.$2);
                        this.$2["delete"](a.id);
                        this.$13(c)
                    }
                    break;
                case "REPLACE":
                    if (this.$2.has(a.id)) {
                        c = this.$11(a.id);
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, babelHelpers["extends"]({}, c, {
                                value: a.value
                            })]
                        ]))
                    }
                    break;
                case "STOP_TIMER":
                    if (this.$2.has(a.id) && this.$15(this.$11(a.id))) {
                        c = babelHelpers["extends"]({}, this.$11(a.id));
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, this.$13(c)]
                        ]))
                    }
                    break;
                case "RESET_TIMER":
                    if (this.$2.has(a.id) && !this.$15(this.$11(a.id))) {
                        c = babelHelpers["extends"]({}, this.$11(a.id));
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, this.$12(c)]
                        ]))
                    }
                    break;
                default:
                    a.type
            }
            b !== this.$2 && this.$10()
        };
        b.$10 = function() {
            var a = this;
            this.$3.forEach(function(b) {
                return a.$7(function() {
                    b()
                })
            });
            this.$4.forEach(function(b) {
                return a.$7(function() {
                    b.handler(b === a.$5 ? a.getState() : a.getEmptyState())
                })
            })
        };
        b.$12 = function(a) {
            var b = this;
            a.duration !== null && a.timer == null && (a.timer = c("setTimeout")(function() {
                b.expire(a.id)
            }, a.duration));
            return a
        };
        b.$13 = function(a) {
            a.timer != null && (c("clearTimeout")(a.timer), a.timer = null);
            return a
        };
        b.$14 = function(a) {
            var b = this;
            this.$13(a);
            var d = a.id;
            c("setTimeout")(function() {
                b["delete"](d)
            }, 1e3)
        };
        b.$15 = function(a) {
            return a.timer != null
        };
        b.$11 = function(a) {
            a = this.$2.get(a);
            if (a == null) throw c("unrecoverableViolation")("Toast with given identifier was not found", "comet_ui");
            return a
        };
        a.getInstance = function(b) {
            a.$16 == null && (a.$16 = new a(b));
            return a.$16
        };
        a.resetInstance_DO_NOT_USE = function() {
            a.$16 = null
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("BaseToasterStateManager", ["CometMaxEnqueuedToastsSitevarConfig", "JSScheduler", "XPlatReactToasterStateManager", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");

    function h(a) {
        d("JSScheduler").scheduleNormalPriCallback(function() {
            a()
        })
    }
    a = {
        getInstance: function() {
            return c("XPlatReactToasterStateManager").getInstance({
                callbackScheduler: h,
                maxQueuedToasts: c("CometMaxEnqueuedToastsSitevarConfig").max
            })
        },
        resetInstance_DO_NOT_USE: function() {
            c("XPlatReactToasterStateManager").resetInstance_DO_NOT_USE()
        }
    };
    g["default"] = a
}), 98);
__d("BaseToasterStateManagerContext.react", ["BaseToasterStateManager", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(c("BaseToasterStateManager").getInstance());
    g["default"] = b
}), 98);
__d("useToasterStateManager", ["BaseToasterStateManagerContext.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("BaseToasterStateManagerContext.react"))
    }
    g["default"] = a
}), 98);
__d("CometColumn.react", ["BaseView.react", "CometColumnContext", "CometColumnItem.react", "UserAgent", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = {
            expanding: {
                flexBasis: "x1l7klhg",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                minHeight: "x2lwn1j",
                $$css: !0
            },
            expandingIE11: {
                flexBasis: "xdl72j9",
                $$css: !0
            },
            inner: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                minHeight: "x2lwn1j",
                $$css: !0
            },
            root: {
                boxSizing: "x9f619",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexShrink: "x2lah0s",
                maxWidth: "x193iq5w",
                $$css: !0
            }
        },
        l = {
            0: {
                paddingTop: "xexx8yu",
                $$css: !0
            },
            4: {
                paddingTop: "x1iorvi4",
                $$css: !0
            },
            8: {
                paddingTop: "x1y1aw1k",
                $$css: !0
            },
            12: {
                paddingTop: "xz9dl7a",
                $$css: !0
            },
            16: {
                paddingTop: "xyamay9",
                $$css: !0
            },
            20: {
                paddingTop: "x1cnzs8",
                $$css: !0
            }
        },
        m = {
            4: {
                paddingTop: "x1iorvi4",
                paddingBottom: "xjkvuk6",
                $$css: !0
            },
            8: {
                paddingTop: "x1y1aw1k",
                paddingBottom: "xwib8y2",
                $$css: !0
            },
            12: {
                paddingTop: "xz9dl7a",
                paddingBottom: "xsag5q8",
                $$css: !0
            },
            16: {
                paddingTop: "xyamay9",
                paddingBottom: "x1l90r2v",
                $$css: !0
            },
            20: {
                paddingTop: "x1cnzs8",
                paddingBottom: "xx6bls6",
                $$css: !0
            }
        },
        n = {
            bottom: {
                justifyContent: "x13a6bvl",
                $$css: !0
            },
            center: {
                justifyContent: "xl56j7k",
                $$css: !0
            },
            "space-between": {
                justifyContent: "x1qughib",
                $$css: !0
            }
        },
        o = c("UserAgent").isBrowser("IE >= 11");

    function a(a, b) {
        var d = a.align,
            e = d === void 0 ? null : d;
        d = a.children;
        var f = a.expanding;
        f = f === void 0 ? !1 : f;
        var g = a.hasDividers,
            p = g === void 0 ? !1 : g;
        g = a.paddingHorizontal;
        var q = g === void 0 ? null : g;
        g = a.paddingTop;
        var r = a.paddingVertical;
        r = r === void 0 ? 0 : r;
        var s = a.spacing,
            t = s === void 0 ? null : s;
        s = a.verticalAlign;
        s = s === void 0 ? "top" : s;
        var u = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["align", "children", "expanding", "hasDividers", "paddingHorizontal", "paddingTop", "paddingVertical", "spacing", "verticalAlign", "xstyle"]);
        var v = i(c("CometColumnContext")),
            w = j(function() {
                return {
                    align: e,
                    hasDividers: p,
                    paddingHorizontal: q,
                    spacing: t
                }
            }, [e, p, q, t]);
        a = h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            ref: b,
            xstyle: [k.root, f === !0 && [k.expanding, o && k.expandingIE11], m[r], g != null && l[g], u],
            children: h.jsx(c("BaseView.react"), {
                xstyle: [k.inner, s !== "top" && n[s]],
                children: h.jsx(c("CometColumnContext").Provider, {
                    value: w,
                    children: d
                })
            })
        }));
        if (v != null) {
            return h.jsx(c("CometColumnItem.react"), {
                expanding: (b = f) != null ? b : void 0,
                children: a
            })
        }
        return a
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    d = e;
    g["default"] = d
}), 98);
__d("CometSection.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var c = a.children,
            d = a.className,
            e = a.name,
            f = a.role;
        a = a.testid;
        return h.jsx("div", {
            "aria-label": e,
            className: d,
            "data-testid": void 0,
            ref: b,
            role: f,
            children: c
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("cometPushToast", ["ix", "BaseToasterStateManager", "CometIcon.react", "deferredLoadComponent", "fbicon", "react", "requireDeferred"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = c("BaseToasterStateManager").getInstance(),
        k = c("deferredLoadComponent")(c("requireDeferred")("CometToast.react").__setRef("cometPushToast"));

    function l(a, b, c) {
        b === void 0 && (b = 2750);
        var d = (c = c) != null ? c : j,
            e = d.push(i.jsx(k, babelHelpers["extends"]({}, a, {
                loadImmediately: !0,
                onDismiss: function() {
                    return d.expire(e)
                }
            })), b);
        return e
    }

    function a(a, b) {
        return l({
            message: a
        }, b)
    }

    function b(a, b, e) {
        b === void 0 && (b = 2750);
        return l(babelHelpers["extends"]({}, a, {
            icon: i.jsx(c("CometIcon.react"), {
                color: "warning",
                icon: d("fbicon")._(h("502062"), 20)
            })
        }), b, e)
    }
    g.cometPushToast = l;
    g.cometPushSimpleToast = a;
    g.cometPushErrorToast = b
}), 98);
__d("useIsCalledDuringRender", ["FBLogger", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = d("react").useCallback;

    function a() {
        var a;
        return h(function() {
            c("FBLogger")("comet_ui").blameToPreviousFrame().warn("useIsCalledDuringRender should only be used for development purpose. It is implemented in a way that will not work correctly in production.");
            return !1
        }, [a])
    }
    g["default"] = a
}), 98);
__d("SilenceableErrorMessageUtils", ["killswitch"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return c("killswitch")("COMET_HIDE_SILENT_ERROR_MESSAGE") ? !1 : a.is_silent === !0
    }

    function i(a) {
        if (typeof a === "object" && a instanceof Error) {
            var b = a.description,
                c = a.message,
                d = a.source;
            return {
                code: d == null ? void 0 : d.code,
                is_silent: d == null ? void 0 : d.is_silent,
                message: (d = b) != null ? d : c,
                timestamp: Date.now()
            }
        }
        return {
            is_silent: (b = a.source) == null ? void 0 : b.is_silent,
            message: a.description
        }
    }

    function a(a, b) {
        var c, d = a.description,
            e = a.message,
            f = a.source;
        c = (f = (c = (c = f == null ? void 0 : (c = f.exception) == null ? void 0 : c.message) != null ? c : f == null ? void 0 : f.description) != null ? c : d) != null ? f : e;
        h(i(a)) && b(c)
    }
    g.shouldHideErrorMessage = h;
    g.getMetadataFromError = i;
    g.handleSilentError = a
}), 98);
__d("RunComet", ["ExecutionEnvironment", "FBLogger", "createCancelableFunction", "emptyFunction", "recoverableViolation", "setTimeout", "unexpectedUseInComet"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {},
        i = !1,
        j = !1,
        k = {
            remove: c("emptyFunction")
        };

    function l(a, b) {
        h.unload == null && (h.unload = [], h.afterunload = [], c("ExecutionEnvironment").canUseEventListeners && window.addEventListener("unload", function() {
            o("unload"), o("afterunload")
        })), h[a] == null ? (c("recoverableViolation")("EVENT_LISTENERS." + a + " wasn't initialized but should have been!", "comet_infra"), h[a] = [b]) : h[a].push(b)
    }

    function m(a) {
        a || c("recoverableViolation")("Undefined event listener handler is not allowed", "comet_infra");
        return c("createCancelableFunction")((a = a) != null ? a : c("emptyFunction"))
    }

    function n(a) {
        return {
            remove: function() {
                a.cancel()
            }
        }
    }

    function o(a) {
        var b = h[a] || [];
        for (var d = 0; d < b.length; d++) {
            var e = b[d];
            try {
                e()
            } catch (b) {
                c("FBLogger")("comet_infra").catching(b).mustfix("Hit an error while executing '" + a + "' event listeners.")
            }
        }
        h[a] = []
    }

    function p(a) {
        if (i) {
            a();
            return n(m(c("emptyFunction")))
        }
        a = m(a);
        h.domcontentloaded == null ? (h.domcontentloaded = [a], c("ExecutionEnvironment").canUseEventListeners && window.addEventListener("DOMContentLoaded", function() {
            o("domcontentloaded")
        }, !0)) : h.domcontentloaded.push(a);
        return n(a)
    }

    function a(a) {
        a = m(a);
        l("afterunload", a);
        return n(a)
    }

    function b(a) {
        a = m(a);
        h.load == null ? (h.load = [a], c("ExecutionEnvironment").canUseEventListeners && window.addEventListener("load", function() {
            o("domcontentloaded"), o("load")
        })) : h.load.push(a);
        j && c("setTimeout")(function() {
            o("domcontentloaded"), o("load")
        }, 0);
        return n(a)
    }

    function d(a) {
        a = m(a);
        l("unload", a);
        return n(a)
    }

    function e(a, b) {
        if (b !== !1) {
            b = "Run.onBeforeUnload was called with include_quickling_events as true or undefined, but this is not valid in Comet.";
            c("FBLogger")("comet_infra").blameToPreviousFrame().mustfix(b)
        }
        b = m(a);
        h.beforeunload == null && (h.beforeunload = [], c("ExecutionEnvironment").canUseEventListeners && window.addEventListener("beforeunload", function(a) {
            var b = h.beforeunload || [];
            for (var b = b, d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= b.length) break;
                    f = b[e++]
                } else {
                    e = b.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                var g = void 0;
                try {
                    g = f()
                } catch (a) {
                    c("FBLogger")("comet_infra").catching(a).mustfix("Hit an error while executing onBeforeUnload event listeners.")
                }
                if (g !== void 0) {
                    g != null && g.body != null && (g = g.body);
                    a.preventDefault();
                    a.returnValue = g;
                    return g
                }
            }
        }));
        h.beforeunload.push(b);
        return n(b)
    }
    var q = e;

    function f(a) {
        c("unexpectedUseInComet")("Run.onLeave");
        return k
    }

    function r(a, b) {
        c("unexpectedUseInComet")("Run.onCleanupOrLeave");
        return k
    }

    function s(a) {
        c("unexpectedUseInComet")("Run.removeHook")
    }

    function t() {
        document.readyState === "loading" ? p(function() {
            i = !0
        }) : i = !0;
        if (document.readyState === "complete") j = !0;
        else {
            var a = window.onload;
            window.onload = function() {
                a && a(), j = !0
            }
        }
    }
    c("ExecutionEnvironment").canUseDOM && t();
    t = null;
    var u = null;
    g.onLoad = p;
    g.onAfterUnload = a;
    g.onAfterLoad = b;
    g.onUnload = d;
    g.onBeforeUnload = e;
    g.maybeOnBeforeUnload = q;
    g.onLeave = f;
    g.onCleanupOrLeave = r;
    g.__removeHook = s;
    g.__domContentCallback = t;
    g.__onloadCallback = u
}), 98);
__d("CometInteractionTracingConfig", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        defaultTracePolicy: "comet.app",
        getMetadata: function() {
            return {}
        },
        navigationCancelsInteractions: !0
    };
    f.tracingConfig = a
}), 66);
__d("CometInteractionTracingQPLConfigContext", ["qpl", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    d = d("react");
    var i = d.useContext,
        j = d.useMemo;
    d = {
        dialogTraceQPLEvent: c("qpl")._(30605361, "6204"),
        popoverTraceQPLEvent: c("qpl")._(30605361, "6204")
    };
    var k = h.createContext(d);

    function a() {
        return i(k).dialogTraceQPLEvent
    }

    function b() {
        return i(k).popoverTraceQPLEvent
    }

    function e(a) {
        var b = a.children,
            c = a.dialogTraceQPLEvent,
            d = a.popoverTraceQPLEvent;
        return h.jsx(k.Provider, {
            value: j(function() {
                return {
                    dialogTraceQPLEvent: c,
                    popoverTraceQPLEvent: d
                }
            }, [c, d]),
            children: b
        })
    }
    e.displayName = e.name + " [from " + f.id + "]";
    g.defaultInteractionQPLEvents = d;
    g.useDialogTraceQPLEvent = a;
    g.usePopoverTraceQPLEvent = b;
    g.CometInteractionTracingQPLConfigContextProvider = e
}), 98);
__d("OneTraceQPLLogger", ["QuickPerformanceLogger", "gkx", "performanceNavigationStart", "performanceNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
            CANCEL: 4,
            ERROR: 87,
            FAIL: 3,
            OFFLINE: 160,
            START: 1,
            SUCCESS: 2,
            TIMEOUT: 113
        },
        i = c("gkx")("6196") ? 0 : c("performanceNavigationStart")();

    function a(a, b) {
        if (a == null) return;
        c("QuickPerformanceLogger").markerStart(a, b.instanceKey, b.startTime + i)
    }

    function b(a, b) {
        if (a == null) return;
        c("QuickPerformanceLogger").markerAnnotate(a, b.annotations, {
            instanceKey: b.instanceKey
        });
        for (var d in b.markerPoints) c("QuickPerformanceLogger").markerPoint(a, d, {
            data: b.markerPoints[d].data,
            instanceKey: b.instanceKey,
            timestamp: b.markerPoints[d].timeSinceStart + i
        });
        d = h[b.status];
        c("QuickPerformanceLogger").markerEnd(a, d, b.instanceKey, ((a = b.endTime) != null ? a : c("performanceNow")()) + i)
    }
    g.qplActionMap = h;
    g.initQPL = a;
    g.logQPL = b
}), 98);
__d("InteractionTracingConfigDefault", ["OneTraceQPLLogger", "SiteData", "gkx", "performanceNavigationStart"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = 6e4;
    b = new Set(["AppTiming", "TierFlush", "NavigationTiming", "VisualCompletion", "TestMetrics", "ServerTimings"]);
    e = {
        appStart: c("gkx")("6196") ? 0 : c("performanceNavigationStart")(),
        defaultTracePolicy: "default",
        enableMemoryLogging: c("gkx")("1475"),
        logLateMutationReactStack: c("gkx")("1914427"),
        logVCReactStack: c("gkx")("1778371"),
        heroLatePlaceholderDetection: c("gkx")("5840"),
        heroDebugTracing: c("gkx")("4639"),
        pkgCohort: c("SiteData").pkg_cohort,
        timeout: a,
        qplActionMap: d("OneTraceQPLLogger").qplActionMap,
        useDocumentBodyForVCRoot: !0,
        navigationCancelsInteractions: !1,
        heroNestedRootsFix: c("gkx")("4180"),
        qplPointFilterRegex: /^((server_)?adp_|Relay_)/,
        allowedQPLPointTypes: b
    };
    g.DEFAULT_TRACING_CONFIG = e
}), 98);
__d("JSSPStatsTypedLogger", ["Banzai", "GeneratedLoggerUtils"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = {}
        }
        var c = a.prototype;
        c.log = function() {
            b("GeneratedLoggerUtils").log("logger:JSSPStatsLoggerConfig", this.$1, b("Banzai").BASIC)
        };
        c.logVital = function() {
            b("GeneratedLoggerUtils").log("logger:JSSPStatsLoggerConfig", this.$1, b("Banzai").VITAL)
        };
        c.logImmediately = function() {
            b("GeneratedLoggerUtils").log("logger:JSSPStatsLoggerConfig", this.$1, {
                signal: !0
            })
        };
        c.clear = function() {
            this.$1 = {};
            return this
        };
        c.getData = function() {
            return babelHelpers["extends"]({}, this.$1)
        };
        c.updateData = function(a) {
            this.$1 = babelHelpers["extends"]({}, this.$1, a);
            return this
        };
        c.setBootUpTime = function(a) {
            this.$1.boot_up_time = a;
            return this
        };
        c.setShutDownTime = function(a) {
            this.$1.shut_down_time = a;
            return this
        };
        c.setTime = function(a) {
            this.$1.time = a;
            return this
        };
        c.setTraceSize = function(a) {
            this.$1.trace_size = a;
            return this
        };
        c.setWeight = function(a) {
            this.$1.weight = a;
            return this
        };
        return a
    }();
    c = {
        boot_up_time: !0,
        shut_down_time: !0,
        time: !0,
        trace_size: !0,
        weight: !0
    };
    e.exports = a
}), null);
__d("JSSelfProfiler", ["FBLogger", "JSSPStatsTypedLogger", "SiteData", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b) {
            this.$1 = a, this.$5 = b, this.$4 = !1
        }
        a.startRecording = function(b, d) {
            if (!a.isSupported()) {
                var e = new Error("JS Self Profiling is not supported");
                e.stack;
                throw e
            }
            e = performance.now();
            try {
                d = new Profiler({
                    sampleInterval: b,
                    maxBufferSize: d
                });
                e = performance.now() - e;
                d = new a(d, b);
                d.setStartUpTime(e);
                return d
            } catch (a) {
                c("FBLogger")("JSSelfProfiler").catching(a).warn("Could not initialize profiler")
            }
            return null
        };
        var d = a.prototype;
        d.stopRecording = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                if (this.$4) {
                    var a = new Error("The profiling has stopped before stopRecording() is called");
                    a.stack;
                    throw a
                }
                a = performance.now();
                var b = (yield this.$1.stop());
                this.$3 = performance.now() - a;
                b.resources = b.resources.map(function(a) {
                    return a.startsWith("data:") ? "inline JavaScript" : a
                });
                b.frames.forEach(function(a) {
                    a.resourceId != null && c("SiteData").push_phase === "dev" && (a.name = "")
                });
                a = {
                    trace: b,
                    stats: {
                        timeOrigin: performance.timeOrigin,
                        requestedSampleInterval: this.$5,
                        actualSampleInterval: this.$1.sampleInterval
                    }
                };
                this.$6 = JSON.stringify(b).length;
                this.$4 = !0;
                return a
            });

            function d() {
                return a.apply(this, arguments)
            }
            return d
        }();
        d.setStartUpTime = function(a) {
            this.$2 = a
        };
        d.logStats = function() {
            if (this.$2 == null) {
                c("FBLogger")("JSSelfProfiler").warn("JSSP start up time is null/undefined");
                return
            }
            if (this.$3 == null) {
                c("FBLogger")("JSSelfProfiler").warn("JSSP shut down time is null/undefined");
                return
            }
            new(c("JSSPStatsTypedLogger"))().setBootUpTime(this.$2).setShutDownTime(this.$3).setTraceSize(this.$6).log()
        };
        a.isSupported = function() {
            return window.performance != null && typeof window.Profiler === "function" && performance.timeOrigin != null
        };
        a.setIsHeaderSent = function() {
            a.isHeaderSent = !0
        };
        return a
    }();
    a.isHeaderSent = !1;
    g["default"] = a
}), 98);
__d("JSSelfProfilerLoomProvider", ["JSSelfProfiler", "JSSelfProfilerConfig", "asyncToGeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function() {
        function a(a) {
            this.$1 = a;
            a = c("JSSelfProfilerConfig").SAMPLE_INTERVAL;
            var b = c("JSSelfProfilerConfig").MAX_BUFFER_SIZE;
            this.$2 = c("JSSelfProfiler").startRecording(a, b)
        }
        var d = a.prototype;
        d.loomTraceWillEnd = function() {
            var a = b("asyncToGeneratorRuntime").asyncToGenerator(function*() {
                var a = this.$1,
                    b = this.$2;
                if (a != null && b != null) {
                    a.jsSelfProfilerData = (yield b.stopRecording());
                    b.logStats();
                    return
                }
                this.$1 = null;
                this.$2 = null
            });

            function c() {
                return a.apply(this, arguments)
            }
            return c
        }();
        return a
    }();
    a = {
        loomProviderId: "JSSelfProfiler",
        isSupported: function() {
            return c("JSSelfProfiler").isSupported()
        },
        getInstance: function(a) {
            return new h(a)
        }
    };
    g["default"] = a
}), 98);
__d("useCometTailLoadPageletTracker", ["IntersectionObserver", "cr:1703077", "intersectionObserverEntryIsIntersecting", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = d("react");
    var h = e.useCallback,
        i = e.useEffect,
        j = e.useRef;

    function a(a, d, e) {
        var f = j(null),
            g = j(!1),
            k = j(null);
        i(function() {
            return function() {
                k.current && k.current(), k.current = null
            }
        }, [a, d]);
        return h(function(h) {
            if (b("cr:1703077") && e === !0 && a != null && d != null && h && f.current !== h) {
                f.current = h;
                k.current && (k.current(), k.current = null);
                var i = function(e) {
                        Array.prototype.forEach.call(e, function(e) {
                            c("intersectionObserverEntryIsIntersecting")(e) && !g.current && (g.current = !0, b("cr:1703077") && b("cr:1703077").logPageletConsumed(a, d, e.time))
                        })
                    },
                    j = new(c("IntersectionObserver"))(i);
                j.observe(h);
                k.current = function() {
                    j.disconnect()
                }
            }
        }, [a, d, e])
    }
    g["default"] = a
}), 98);
__d("HeroTracingCoreDependencies", ["cr:3798", "cr:449", "cr:683059", "useCometTailLoadPageletTracker"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        useTailLoadPageletTracker: c("useCometTailLoadPageletTracker"),
        UserTimingUtils: b("cr:3798"),
        VCTracker: b("cr:449"),
        VisualCompletion: b("cr:683059")
    };
    g["default"] = a
}), 98);
__d("HeroLogger", ["HeroTracingCoreDependencies", "hero-tracing-placeholder", "interaction-tracing-metrics", "performanceNowSinceAppStart", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {},
        i = 0,
        j = new Map();

    function a(a) {
        var b = i++;
        j.set(b, a);
        return function() {
            j["delete"](b)
        }
    }

    function b(a, b) {
        a = (a = a) != null ? a : c("uuid")();
        if (d("hero-tracing-placeholder").HeroPendingPlaceholderTracker.isInteractionActive(a)) return a;
        k(a, "Interaction Start", b);
        d("hero-tracing-placeholder").HeroPendingPlaceholderTracker.addInteraction(a);
        return a
    }

    function e(a, b) {
        d("hero-tracing-placeholder").HeroPendingPlaceholderTracker.removeInteraction(a);
        var c = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(a);
        c != null && (d("interaction-tracing-metrics").InteractionTracingMetricsCore.addMarkerPoint(a, "HeroTrace_end", "AppTiming"), b === "ABORT" && (d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationInt(a, "aborted", 1), d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotation(a, "cancelType", "aborted")));
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.complete(a)
    }

    function k(a, b, d, e) {
        a = b + a;
        h[a] = (a = d) != null ? a : c("performanceNowSinceAppStart")();
        (e == null ? void 0 : e.userTiming) !== !1 && (c("HeroTracingCoreDependencies").UserTimingUtils == null ? void 0 : c("HeroTracingCoreDependencies").UserTimingUtils.measureStart(b))
    }

    function f(a, b, e, f, g) {
        e = (e = e) != null ? e : c("performanceNowSinceAppStart")();
        k(a, b, e);
        var h;
        f != null && g != null ? h = (f.length > 0 ? f[f.length - 1] : "") + ":" + g : h = b + "_" + a;
        d("hero-tracing-placeholder").HeroPendingPlaceholderTracker.addPlaceholder(a, b, h);
        if (j.size) {
            var i = {
                placeholderID: b + a,
                interactionID: a,
                spanUUID: b,
                startTime: e,
                pageletStack: f,
                description: g
            };
            j.forEach(function(a) {
                a.onStart(i)
            })
        }
    }

    function l(a, b, e, f, g, i, k, l) {
        var m = g + a;
        m = h[m];
        k = (k = k) != null ? k : c("performanceNowSinceAppStart")();
        m != null && n(a, b, e, f, m, k, i, l);
        if (j.size) {
            var o = {
                placeholderID: g + a,
                interactionID: a,
                pageletStack: b,
                spanType: e,
                name: f,
                spanUUID: g,
                data: i,
                endTime: k
            };
            j.forEach(function(a) {
                a.onEnd(o)
            })
        }
        d("hero-tracing-placeholder").HeroPendingPlaceholderTracker.removePlaceholder(a, g)
    }

    function m(a, b, c, e, f, g, h, i) {
        l(a, b, c, e, f, g, h, i), d("hero-tracing-placeholder").HeroPendingPlaceholderTracker.removePlaceholder(a, f)
    }

    function n(a, b, e, f, g, h, i, j) {
        var k;
        h === void 0 && (h = c("performanceNowSinceAppStart")());
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addSubspan(a, f, "HeroTracing", g, (k = h) != null ? k : c("performanceNowSinceAppStart")(), babelHelpers["extends"]({}, i, {
            pagelet: b[b.length - 1],
            pageletStack: b,
            spanType: e
        }));
        (j == null ? void 0 : j.userTiming) !== !1 && (c("HeroTracingCoreDependencies").UserTimingUtils == null ? void 0 : c("HeroTracingCoreDependencies").UserTimingUtils.measureModern(f + ("[" + a.slice(0, 3) + "]"), {
            end: h,
            start: g
        }, e))
    }
    g.subscribeToPlaceholders = a;
    g.genHeroInteractionUUIDAndMarkStart = b;
    g.endHeroInteraction = e;
    g.markStart = k;
    g.markStartPlaceholder = f;
    g.markEnd = l;
    g.markEndPlaceholder = m;
    g.measure = n
}), 98);
__d("HeroTracingCoreConfig", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        alwaysMarkMutationRootAsVisualChange: c("gkx")("8232"),
        enableCascadingRenderDetector: c("gkx")("443"),
        enableHeroLoggingVerbose: c("gkx")("2954"),
        enableReactProfiling: c("gkx")("1407308"),
        logNestedReactUpdates: c("gkx")("678680") && c("gkx")("1902022"),
        addExistingPageletMountPoint: c("gkx")("4635")
    };
    g["default"] = a
}), 98);
__d("usePageletVCTracker", ["HeroTracingCoreConfig", "HeroTracingCoreDependencies", "interaction-tracing-metrics", "performanceNowSinceAppStart", "react", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useRef;

    function a(a) {
        var b = a.excludeFromMainVC,
            e = a.interactionUUID,
            f = a.isMutationRoot,
            g = a.observeTextMutation,
            j = a.pageletName,
            k = a.pageletType,
            l = a.vcCallback,
            m = a.alwaysMarkMutationRootAsVisualChange,
            n = c("useStable")(function() {
                return typeof WeakMap === "function" ? new WeakMap() : new Map()
            }),
            o = i(null);
        return h(function(a) {
            if (a == null) return;
            var h = n.has(a),
                i = n.get(a);
            i == null && (i = c("performanceNowSinceAppStart")(), n.set(a, i));
            var p, q = e != null ? d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(e) : null;
            e != null && o.current !== e ? q && q.vcTracker && (p = q.vcTracker, f === !0 && (g != null && (p.config.observeTextMutation = g), h && m === !1 ? p.observeMutation(a) : p.addMutationRoot(a))) : !h && e == null && b === !0 && c("HeroTracingCoreDependencies").VisualCompletion && (p = c("HeroTracingCoreDependencies").VisualCompletion.getCurrentNavigationTrace());
            i = h && c("HeroTracingCoreConfig").addExistingPageletMountPoint && q != null && q.start > i;
            q = i && q != null ? q.start : c("performanceNowSinceAppStart")();
            if (e != null && (!h || i)) {
                d("interaction-tracing-metrics").InteractionTracingMetricsCore.addMountPoint(e, q, j);
                (h = p) == null ? void 0 : h.trackPagelet(a, j, q, l, k, b)
            }
            o.current = e
        }, [m, b, e, f, g, j, k, n, l])
    }
    g["default"] = a
}), 98);
__d("useHeroTracingDOMTracking", ["HeroTracingCoreDependencies", "mergeRefs", "react", "usePageletVCTracker"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useMemo;
    a = function(a) {
        var b = a.vcCallback,
            d = a.excludeFromMainVC,
            e = a.isMutationRoot,
            f = a.interactionUUID,
            g = a.name,
            i = a.pageletName,
            j = a.observeTextMutation,
            k = a.pageletType,
            l = a.position,
            m = a.trackTailLoad;
        a = a.alwaysMarkMutationRootAsVisualChange;
        var n = c("usePageletVCTracker")({
                excludeFromMainVC: d,
                interactionUUID: f,
                isMutationRoot: e,
                observeTextMutation: j,
                pageletName: g,
                pageletType: k,
                vcCallback: b,
                alwaysMarkMutationRootAsVisualChange: a
            }),
            o = c("HeroTracingCoreDependencies").useTailLoadPageletTracker(i, l, m);
        return h(function() {
            return c("mergeRefs")(n, o)
        }, [n, o])
    };
    g["default"] = a
}), 98);
__d("HeroTracingPlatformDependencies", ["LegacyHidden", "useHeroTracingDOMTracking"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        HostInstanceTrackableComponent: c("LegacyHidden"),
        useHostInstanceTracking: c("useHeroTracingDOMTracking")
    };
    g["default"] = a
}), 98);
__d("useHeroCascadingRenderDetector", ["HeroTracingCoreDependencies", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function() {
        function a() {
            this.$1 = new Map()
        }
        var b = a.prototype;
        b.logRender = function(a, b, c, d) {
            a = this.$2(a);
            a.set(b, {
                isNested: c === "nested-update",
                renderDuration: d
            })
        };
        b.logCommit = function(a, b, c, d) {
            a = this.$2(a);
            var e = a.get(b);
            if (e == null || c !== "nested-update") return;
            a.set(b, babelHelpers["extends"]({}, e, {
                isNested: !0,
                layoutDuration: d
            }))
        };
        b.logPostCommit = function(a, b, c, d) {
            a = this.$2(a);
            var e = a.get(b);
            if (e == null || c !== "nested-update") return;
            a.set(b, babelHelpers["extends"]({}, e, {
                effectDuration: d,
                isNested: !0
            }))
        };
        b.getPageletReport = function(a, b) {
            var d = this.$2(a);
            if (d.size === 0) return;
            var e = {
                    cascadingRenderCount: 0,
                    cascadingRenderTotalDuration: 0,
                    maxChainedCascadingRenderCount: 0
                },
                f = Array.from(d.keys()).reverse(),
                g = !1,
                h = 0;
            for (var f = f, i = Array.isArray(f), j = 0, f = i ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var k, l;
                if (i) {
                    if (j >= f.length) break;
                    l = f[j++]
                } else {
                    j = f.next();
                    if (j.done) break;
                    l = j.value
                }
                l = l;
                if (l > b) continue;
                k = (k = d.get(l)) != null ? k : {};
                var m = k.effectDuration;
                m = m === void 0 ? 0 : m;
                var n = k.isNested;
                n = n === void 0 ? !1 : n;
                var o = k.layoutDuration;
                o = o === void 0 ? 0 : o;
                k = k.renderDuration;
                k = k === void 0 ? 0 : k;
                n && (e.cascadingRenderCount += 1, e.cascadingRenderTotalDuration += m + k + o);
                c("HeroTracingCoreDependencies").UserTimingUtils != null && n && c("HeroTracingCoreDependencies").UserTimingUtils.measureModern("\u26a0\ufe0f " + a + " [cascading commit block]", {
                    end: l + k + o + m,
                    start: l
                }, "ReactCascadingRender");
                n && g ? h++ : (e.maxChainedCascadingRenderCount = Math.max(h, e.maxChainedCascadingRenderCount), h = 0);
                g = n
            }
            return e
        };
        b.cleanup = function(a) {
            this.$1["delete"](a)
        };
        b.$2 = function(a) {
            if (this.$1.has(a)) return this.$1.get(a);
            else {
                var b = new Map();
                this.$1.set(a, b);
                return b
            }
        };
        return a
    }();

    function a() {
        return c("useStable")(function() {
            return new h()
        })
    }
    g["default"] = a
}), 98);
__d("HeroInteraction.react", ["ExecutionEnvironment", "HeroLogger", "HeroPagelet.react", "HeroTracingCoreConfig", "HeroTracingCoreDependencies", "HeroTracingPlatformDependencies", "HiddenSubtreePassiveContext", "Promise", "PromiseAnnotate", "RelayProfilerContext", "VisualCompletionUtil", "clearImmediate", "hero-tracing-placeholder", "interaction-tracing-metrics", "objectEntries", "objectValues", "react", "setImmediateAcrossTransitions", "setTimeoutAcrossTransitions", "useHeroCascadingRenderDetector", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useCallback,
        j = e.useContext,
        k = e.useEffect,
        l = e.useLayoutEffect,
        m = e.useMemo,
        n = e.useRef,
        o = c("HeroTracingCoreConfig").enableCascadingRenderDetector ? c("useHeroCascadingRenderDetector") : function() {
            return null
        },
        p = "Interaction Start",
        q = "root",
        r = {
            userTiming: !1
        },
        s = new Set();

    function t(a, b) {
        d("HeroLogger").markStart(a, b)
    }

    function u(a, b, c, e) {
        d("HeroLogger").markStartPlaceholder(a, b, void 0, c, e)
    }

    function v(a, b, e, f) {
        d("HeroLogger").markEnd(a, e, "SuspensePromise", "Promise Wait: " + f, b, void 0, void 0, c("HeroTracingCoreConfig").enableHeroLoggingVerbose ? void 0 : r)
    }

    function w(a, b, e, f) {
        d("HeroLogger").markEndPlaceholder(a, e, "PlaceholderWait", "Placeholder Wait: " + f, b, void 0, void 0, c("HeroTracingCoreConfig").enableHeroLoggingVerbose ? void 0 : r)
    }

    function x(a, b, e) {
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addHeroRelay(b, {
            pageletStack: e,
            queries: a
        });
        for (var a = a, f = Array.isArray(a), g = 0, a = f ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var h;
            if (f) {
                if (g >= a.length) break;
                h = a[g++]
            } else {
                g = a.next();
                if (g.done) break;
                h = g.value
            }
            h = h;
            d("HeroLogger").measure(b, e, "Relay", h.name, h.start, h.end, void 0, c("HeroTracingCoreConfig").enableHeroLoggingVerbose ? void 0 : r);
            for (var i = 0; i < h.flushes.length; i++) {
                var j = h.flushes[i];
                d("HeroLogger").measure(b, e, "RelayFlush", h.name + "(" + j.label + ")", h.start, j.time, {
                    flush: j.label,
                    queryName: h.name
                }, c("HeroTracingCoreConfig").enableHeroLoggingVerbose ? void 0 : r)
            }
        }
    }

    function y(a, b, c) {
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addHeroBootload(b, {
            moduleIDs: Array.from(a),
            pageletStack: c
        })
    }

    function z(a) {
        if (!a) return "No placeholder";
        var b = a.boundaryName != null ? "@" + a.boundaryName : "";
        a = d("hero-tracing-placeholder").HeroPlaceholderUtils.createThenableDescription(a.thenables) || "No Promises";
        return a + b
    }

    function A(a, b) {
        if (a == null) return null;
        var d = {
            commitCount: 0,
            lastBaseDuration: 0,
            maxBaseDuration: 0,
            totalActualDuration: 0,
            totalCommitDuration: 0,
            totalPostCommitDuration: 0,
            zeroDurationCommitCount: 0,
            zeroDurationPostCommitCount: 0
        };
        for (var a = c("objectEntries")(a), e = Array.isArray(a), f = 0, a = e ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var g;
            if (e) {
                if (f >= a.length) break;
                g = a[f++]
            } else {
                f = a.next();
                if (f.done) break;
                g = f.value
            }
            g = g;
            var h = g[0];
            g = g[1];
            if (h > b) break;
            h = g.actualDuration;
            h = h === void 0 ? 0 : h;
            var i = g.baseDuration;
            i = i === void 0 ? 0 : i;
            var j = g.commitDuration;
            j = j === void 0 ? 0 : j;
            var k = g.postCommitDuration;
            k = k === void 0 ? 0 : k;
            d.commitCount++;
            g.commitDuration === 0 && d.zeroDurationCommitCount++;
            g.postCommitDuration === 0 && d.zeroDurationPostCommitCount++;
            d.maxBaseDuration = Math.max(d.maxBaseDuration, i);
            d.lastBaseDuration = i;
            d.totalActualDuration += h;
            d.totalCommitDuration += j;
            d.totalPostCommitDuration += k
        }
        return d
    }

    function a(a, e) {
        var f, g = a.children,
            B = a.excludeFromMainVC,
            C = a.hidden,
            D = a.htmlAttributes,
            E = a.interactionDesc,
            F = a.interactionUUID,
            aa = a.observeTextMutation,
            G = a.pageletName,
            H = a.renderTrackedDOMElement;
        a = a.alwaysMarkMutationRootAsVisualChange;
        var I = j(d("hero-tracing-placeholder").HeroInteractionContext.Context),
            J = j(d("hero-tracing-placeholder").HeroInteractionIDContext),
            K = n(null),
            L = n(null),
            M = j(c("HiddenSubtreePassiveContext")),
            N = (E = E) != null ? E : "No Description",
            O = n({}),
            P = n({}),
            Q = n({}),
            R = n(null),
            ba = n(J),
            S = c("useStable")(d("hero-tracing-placeholder").HeroPlaceholderUtils.getSimpleUUID),
            T = m(function() {
                var a;
                return [].concat(I.pageletStack, [(a = G) != null ? a : q])
            }, [I.pageletStack, G]),
            U = n([]),
            V = n(new Set()),
            W = o(),
            X = i(function() {
                return c("objectValues")(O.current).some(function(a) {
                    return a.shouldHold
                })
            }, []),
            Y = i(function(a, b, c) {
                L.current !== a && K.current == null && !M.getCurrentState().hidden && !X() && (K.current = d("VisualCompletionUtil").foregroundRequestAnimationFrame(function() {
                    K.current = null, !M.getCurrentState().hidden && L.current !== a && !X() && (L.current = a, d("HeroLogger").markEnd(a, T, "Interaction", "Interaction Done: " + b, p), c !== a && d("HeroLogger").endHeroInteraction(a, "SUCCESS"), I.unhold(a, a + "_" + S), x(U.current, a, T), y(V.current, a, T), U.current = [], V.current = new Set())
                }))
            }, [M, I, S, T, X]),
            Z = i(function() {
                var a = R.current;
                a != null && Y(a.interactionUUID, a.interactionDesc, J)
            }, [J, Y]),
            $ = i(function(a, b, c) {
                var e;
                e = a != null && ((e = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(a.interactionUUID)) == null ? void 0 : (e = e.annotations["int"]) == null ? void 0 : e.heroNestedRootsFix) === 1;
                var f = R.current;
                f != null && L.current !== f.interactionUUID && (d("HeroLogger").markEnd(f.interactionUUID, T, "Interaction", "Interaction Aborted (" + b + "): " + f.interactionDesc, p), I.unhold(f.interactionUUID, f.interactionUUID + "_" + S), c !== f.interactionUUID ? d("HeroLogger").endHeroInteraction(f.interactionUUID, "ABORT") : c != null && d("interaction-tracing-metrics").InteractionTracingMetricsCore.addMetadata(c, "childInteractionAborted", 1), a !== null && f.interactionUUID === a.interactionUUID && (d("HeroLogger").genHeroInteractionUUIDAndMarkStart(a.interactionUUID), e || I.hold(a.interactionUUID, T, "Sub Interaction:" + a.interactionDesc, a.interactionUUID + "_" + S)));
                f != null && (x(U.current, f.interactionUUID, T), y(V.current, f.interactionUUID, T));
                U.current = [];
                V.current = new Set();
                L.current = null;
                K.current && K.current();
                K.current = null;
                R.current = a;
                ba.current = c;
                a !== null && (e && I.hold(a.interactionUUID, T, "Sub Interaction:" + a.interactionDesc, a.interactionUUID + "_" + S))
            }, [I, S, T]);
        E = n(null);
        k(function() {
            return function() {
                var a = function() {
                    return $(null, "Unmount")
                };
                a()
            }
        }, [$]);
        l(function() {
            var a = null;
            F != null && (a = {
                interactionDesc: N,
                interactionUUID: F
            });
            $(a, "New Interaction", J);
            F != null && Y(F, N, J)
        }, [N, F, J, $, Y]);
        l(function() {
            if (F != null) {
                var a = M.getCurrentState().hidden,
                    b = M.subscribeToChanges(function(b) {
                        b = b.hidden;
                        a !== b && (a = b, b ? $({
                            interactionDesc: N,
                            interactionUUID: F
                        }, "Hidden") : Y(F, N, J))
                    });
                F != null && Y(F, N, J);
                return function() {
                    return b.remove()
                }
            }
        }, [M, F, N, $, Y, J]);
        E = m(function() {
            var a = {
                consumeBootload: function(a) {
                    V.current.add(a)
                },
                hold: function(c, e, f, g, h) {
                    f === void 0 && (f = "Hold");
                    g = (g = g) != null ? g : d("hero-tracing-placeholder").HeroPlaceholderUtils.getSimpleUUID();
                    var i = new(b("Promise"))(function() {});
                    d("PromiseAnnotate").setDisplayName(i, f);
                    a.suspenseCallback(c, g, e, new Set([i]), h);
                    a.registerPlaceholder(c, g, e);
                    return g
                },
                logHeroRender: function(a, b, e) {
                    L.current !== a && d("HeroLogger").markEnd(a, [].concat(e), "HeroRendering", "Hero Rendering: " + b, p, void 0, void 0, c("HeroTracingCoreConfig").enableHeroLoggingVerbose ? void 0 : r)
                },
                logMetadata: function(a, b, c) {
                    var d;
                    c = c[c.length - 1];
                    d = (d = P.current[c]) != null ? d : Object.create(null);
                    b != null ? d[a] = b : delete d[a];
                    P.current[c] = d
                },
                logPageletVC: function(a, b, c, e, f) {
                    var g = f[f.length - 1],
                        h = P.current[g];
                    h = h != null ? babelHelpers["extends"]({}, h) : void 0;
                    h && d("interaction-tracing-metrics").InteractionTracingMetricsCore.addMountPointMetadata(a, g, h);
                    e != null && d("HeroLogger").measure(a, [].concat(f), "VCWithoutImage", "VCWithoutImage: " + f[f.length - 1], Math.min(b, e), e, h);
                    if (c != null) {
                        h = Object.assign((e = h) != null ? e : babelHelpers["extends"]({}, null), A(Q.current[g], c), W == null ? void 0 : W.getPageletReport(g, c));
                        Q.current[g] = {};
                        W == null ? void 0 : W.cleanup(g);
                        d("HeroLogger").measure(a, [].concat(f), "VC", "VC: " + f[f.length - 1], Math.min(b, c), c, h)
                    }
                },
                logReactCommit: function(a, b, d, e, f, g, h) {
                    c("HeroTracingCoreDependencies").UserTimingUtils == null ? void 0 : c("HeroTracingCoreDependencies").UserTimingUtils.measureReactCommit(b, f, e);
                    if (L.current !== a && g) {
                        b = h[h.length - 1];
                        W == null ? void 0 : W.logCommit(b, f, d, e);
                        g = (a = Q.current[b]) != null ? a : Object.create(null);
                        d = (h = g[f]) != null ? h : Object.create(null);
                        d.commitDuration = e;
                        g[f] = d;
                        Q.current[b] = g
                    }
                },
                logReactPostCommit: function(a, b, d, e, f, g, h) {
                    c("HeroTracingCoreDependencies").UserTimingUtils == null ? void 0 : c("HeroTracingCoreDependencies").UserTimingUtils.measureReactPostCommit(b, e);
                    if (L.current !== a && g) {
                        b = h[h.length - 1];
                        W == null ? void 0 : W.logPostCommit(b, f, d, e);
                        g = (a = Q.current[b]) != null ? a : Object.create(null);
                        d = (h = g[f]) != null ? h : Object.create(null);
                        d.postCommitDuration = e;
                        g[f] = d;
                        Q.current[b] = g
                    }
                },
                logReactRender: function(a, b, c, e, f, g, h, i, j) {
                    if (L.current !== a) {
                        d("HeroLogger").measure(a, [].concat(j), "ReactRender", "ReactRender: " + b, e, f, {
                            actualDuration: g,
                            baseDuration: h,
                            phase: c
                        });
                        if (i) {
                            a = j[j.length - 1];
                            W == null ? void 0 : W.logRender(a, f, c, g);
                            e = (b = Q.current[a]) != null ? b : Object.create(null);
                            j = (i = e[f]) != null ? i : Object.create(null);
                            j.actualDuration = g;
                            j.baseDuration = h;
                            e[f] = j;
                            Q.current[a] = e
                        }
                    }
                },
                pageletStack: I.pageletStack,
                registerPlaceholder: function(a, b, c) {
                    var d = O.current[b];
                    K.current && K.current();
                    K.current = null;
                    if (d != null) {
                        d.shouldHold = !0;
                        return
                    }
                    d = new Set();
                    O.current[b] = {
                        pageletStack: c,
                        shouldHold: !0,
                        thenables: d
                    };
                    u(a, b, c, z(O.current[b]))
                },
                removePlaceholder: function(a, b) {
                    var c = O.current[b] != null;
                    if (!c) return;
                    c = O.current[b];
                    !c;
                    delete O.current[b];
                    Z();
                    w(a, b, c.pageletStack, z(c))
                },
                suspenseCallback: function(a, b, e, f, g) {
                    var h = O.current[b];
                    g = {
                        boundaryName: g,
                        pageletStack: e,
                        shouldHold: (g = h == null ? void 0 : h.shouldHold) != null ? g : !1,
                        thenables: f
                    };
                    O.current[b] = g;
                    g = z(g);
                    h == null && u(a, b, e, g);
                    f.forEach(function(b) {
                        if (!s.has(b)) {
                            var f;
                            s.add(b);
                            c("ExecutionEnvironment").canUseDOM && c("setTimeoutAcrossTransitions")(function() {
                                s["delete"](b)
                            }, 6e4);
                            var g = (f = d("PromiseAnnotate").getDisplayName(b)) != null ? f : "Promise",
                                h = d("hero-tracing-placeholder").HeroPlaceholderUtils.getSimpleUUID();
                            t(a, h);
                            b.then(function() {
                                v(a, h, e, g)
                            })
                        }
                    });
                    f = z(h);
                    h != null && g !== f && (w(a, b, e, f), u(a, b, e, g))
                },
                unhold: function(b, c) {
                    a.removePlaceholder(b, c)
                }
            };
            return a
        }, [W, I.pageletStack, Z]);
        var ca = m(function() {
            return {
                consumeBootload: function(a) {
                    V.current.add(a)
                },
                retainQuery: function(a) {
                    U.current.push(a)
                },
                wrapPrepareQueryResource: function(a) {
                    return a()
                }
            }
        }, []);
        f = (f = G) != null ? f : q;
        return h.jsx(d("hero-tracing-placeholder").HeroInteractionContext.Context.Provider, {
            value: E,
            children: h.jsx(d("hero-tracing-placeholder").HeroInteractionIDContext.Provider, {
                value: F,
                children: h.jsx(d("hero-tracing-placeholder").HeroCurrentInteractionForLoggingContext.Provider, {
                    value: R,
                    children: h.jsx(c("RelayProfilerContext").Provider, {
                        value: ca,
                        children: h.jsx(c("HeroPagelet.react"), {
                            excludeFromMainVC: B,
                            isMutationRoot: !0,
                            name: f,
                            observeTextMutation: aa,
                            ref: e,
                            alwaysMarkMutationRootAsVisualChange: (E = a) != null ? E : c("HeroTracingCoreConfig").alwaysMarkMutationRootAsVisualChange,
                            children: function(b) {
                                function a(a, c) {
                                    return b.apply(this, arguments)
                                }
                                a.toString = function() {
                                    return b.toString()
                                };
                                return a
                            }(function(a, b) {
                                return H ? h.jsxs(h.Fragment, {
                                    children: [H(a, g), h.jsx(b, {})]
                                }) : h.jsxs(c("HeroTracingPlatformDependencies").HostInstanceTrackableComponent, {
                                    htmlAttributes: babelHelpers["extends"]({}, D),
                                    mode: C === !0 ? "hidden" : "visible",
                                    ref: a,
                                    children: [h.jsx(b, {}), g]
                                })
                            })
                        })
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a.displayName = "HeroInteraction";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("HeroPagelet.react", ["HeroReactProfiler.react", "HeroTracingPlatformDependencies", "hero-tracing-placeholder", "interaction-tracing-metrics", "mergeRefs", "performanceNowSinceAppStart", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useMemo;

    function a(a, b) {
        var e = a.children,
            f = a.excludeFromMainVC,
            g = a.isMutationRoot,
            l = a.name,
            m = a.pageletName,
            n = a.observeTextMutation,
            o = a.pageletType,
            p = a.position,
            q = a.trackTailLoad;
        a = a.alwaysMarkMutationRootAsVisualChange;
        var r = j(d("hero-tracing-placeholder").HeroInteractionContext.Context),
            s = j(d("hero-tracing-placeholder").HeroInteractionIDContext),
            t = k(function() {
                return babelHelpers["extends"]({}, r, {
                    pageletStack: [].concat(r.pageletStack, [l])
                })
            }, [r, l]),
            u = k(function() {
                return c("performanceNowSinceAppStart")()
            }, [s]),
            v = i(function() {
                s != null && (d("interaction-tracing-metrics").InteractionTracingMetricsCore.addFirstMarkerPoint(s, "Queue_" + l, "VisualCompletion", u), d("interaction-tracing-metrics").InteractionTracingMetricsCore.addFirstMarkerPoint(s, "Render_" + l, "VisualCompletion", c("performanceNowSinceAppStart")()));
                return null
            }, [s, l, u]),
            w = i(function(a, b) {
                s != null && t.logPageletVC(s, u, a, b, t.pageletStack)
            }, [s, t, u]),
            x = c("HeroTracingPlatformDependencies").useHostInstanceTracking({
                vcCallback: w,
                excludeFromMainVC: f,
                isMutationRoot: g,
                interactionUUID: s,
                name: l,
                pageletName: m,
                observeTextMutation: n,
                pageletType: o,
                position: p,
                trackTailLoad: q,
                alwaysMarkMutationRootAsVisualChange: a
            });
        w = k(function() {
            return c("mergeRefs")(x, b)
        }, [x, b]);
        return h.jsx(d("hero-tracing-placeholder").HeroInteractionContext.Context.Provider, {
            value: t,
            children: h.jsx(c("HeroReactProfiler.react"), {
                id: l,
                isPagelet: !0,
                children: e(w, v)
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a.displayName = "HeroPagelet";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("HeroReactProfiler.react", ["HeroTracingCoreConfig", "HeroTracingCoreDependencies", "addAnnotations", "hero-tracing-placeholder", "interaction-tracing", "interaction-tracing-metrics", "performanceNowSinceAppStart", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext;
    e = function(a) {
        a = a.children;
        return a
    };
    e.displayName = "HeroReactProfilerNoOp";
    var k = 0;

    function l() {
        var a = k++;
        c("HeroTracingCoreDependencies").UserTimingUtils == null ? void 0 : c("HeroTracingCoreDependencies").UserTimingUtils.measureModern("Nested update " + a, {
            duration: 100,
            start: c("performanceNowSinceAppStart")()
        }, "ReactNestedUpdate");
        console.trace("nested update " + a)
    }

    function a(a) {
        var b = a.children,
            e = a.id,
            f = a.isPagelet,
            g = f === void 0 ? !1 : f;
        f = a.logDurationToQPL;
        var k = f === void 0 ? !1 : f,
            m = j(d("hero-tracing-placeholder").HeroInteractionContext.Context),
            n = j(d("hero-tracing-placeholder").HeroInteractionIDContext);
        a = i(function(a, b, e, f, h, i) {
            if (n == null) return;
            m.logReactRender(n, a, b, h, i, e, f, g, m.pageletStack);
            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addReactRender(n, a, h, i, e, f, b);
            k && c("interaction-tracing").InteractionTracingCore.getPendingInteractions().forEach(function(b) {
                b = b.getTrace();
                if (b) {
                    var d, f = a.replace(/_[0-9]+$/, "_{N}");
                    f = "ReactRenderDuration_" + f;
                    d = ((d = (d = b.annotations["int"]) == null ? void 0 : d[f]) != null ? d : 0) + e;
                    c("addAnnotations")(b.annotations, {
                        "int": (b = {}, b[f] = d, b)
                    })
                }
            })
        }, [m, n, g, k]);
        f = i(function(a, b, c, d) {
            n != null && m.logReactCommit(n, a, b, c, d, g, m.pageletStack)
        }, [m, n, g]);
        var o = i(function(a, b, c, d) {
            n != null && m.logReactPostCommit(n, a, b, c, d, g, m.pageletStack)
        }, [m, n, g]);
        return h.jsx(h.Profiler, {
            id: e,
            onCommit: f,
            onNestedUpdateScheduled: c("HeroTracingCoreConfig").logNestedReactUpdates ? l : null,
            onPostCommit: o,
            onRender: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a.displayName = "HeroReactProfiler";
    b = h.Profiler != null && c("HeroTracingCoreConfig").enableReactProfiling ? a : e;
    g["default"] = b
}), 98);
__d("hero-tracing", ["HeroInteraction.react", "HeroLogger", "HeroPagelet.react", "HeroReactProfiler.react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g.HeroInteraction = c("HeroInteraction.react"), g.HeroPagelet = c("HeroPagelet.react"), g.HeroLogger = d("HeroLogger"), g.HeroReactProfiler = c("HeroReactProfiler.react")
}), 98);
__d("HeroTracingDebugTracing", ["QPLEvent", "hero-tracing", "interaction-tracing-metrics", "performanceNowSinceAppStart"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 600,
        i = 150,
        j = 5;

    function k(a) {
        var b;
        b = a == null ? void 0 : (b = a.annotations.string) == null ? void 0 : b.tracePolicy;
        return ((a = (a == null ? void 0 : a.qplEvent) ? d("QPLEvent").getMarkerId(a.qplEvent) : null) != null ? a : "unknown") + ":" + (typeof b === "string" ? b : "unknown")
    }

    function l(a, b, c, e, f) {
        var g;
        if (c.interactionID !== a.traceId) g = "OtherInteraction";
        else if (b.has(c.placeholderID)) g = "LatePlaceholder";
        else if (!e) g = "IncompletePlaceholder";
        else return;
        b = {};
        b.type = g;
        (e == null ? void 0 : e.spanType) && (b.spanType = e == null ? void 0 : e.spanType);
        if (g === "OtherInteraction") {
            var h = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(c.interactionID);
            b.interactionType = k(h)
        }
        h = (h = e == null ? void 0 : e.endTime) != null ? h : f;
        f = (e = (f = e == null ? void 0 : e.name) != null ? f : c.description) != null ? e : "[No Description]";
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addSubspan(a.traceId, g === "OtherInteraction" ? "OtherInteraction: " + f : f, g === "OtherInteraction" ? "HeroDebug" : "LatePlaceholder", c.startTime, Math.max(h, c.startTime), b)
    }
    var m = "LatePlaceholder";

    function a(a, b, e) {
        if (!(b.heroLatePlaceholderDetection || b.heroDebugTracing)) return;
        var f = a.getTraceId(),
            g = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(f);
        if (!g) return;
        var n = g,
            o = new Map(),
            p = new Map(),
            q = new Set(),
            r = 0,
            s = d("hero-tracing").HeroLogger.subscribeToPlaceholders({
                onStart: function(a) {
                    if (a.interactionID !== f && !b.heroDebugTracing) return;
                    a.interactionID === f && n.completed != null && q.add(a.placeholderID);
                    o.set(a.placeholderID, a)
                },
                onEnd: function(a) {
                    if (a.interactionID !== f && !b.heroDebugTracing) return;
                    p.set(a.placeholderID, a)
                }
            });

        function t() {
            s(), a.unlockInteractionLogging(m)
        }

        function u() {
            var a = c("performanceNowSinceAppStart")(),
                e = new Set();
            o.forEach(function(b) {
                var c = p.get(b.placeholderID);
                b.interactionID !== f && e.add(b.interactionID);
                l(n, q, b, c, a)
            });
            b.heroDebugTracing && e.forEach(function(b) {
                var c = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(b);
                if (c) {
                    d("interaction-tracing-metrics").InteractionTracingMetricsCore.addSubspan(f, "OtherInteraction: " + k(c), "HeroDebug", Math.max(c.start, n.start), Math.min((c = c.completed) != null ? c : a, a), {
                        otherInteractionID: b
                    })
                }
            });
            t()
        }

        function v() {
            r === 0 || r <= j && Array.from(q).some(function(a) {
                return !p.has(a)
            }) ? (setTimeout(v, r === 0 ? h : i), r++) : u()
        }
        a.lockInteractionLogging(m);
        a.onCompleteSync(function() {
            if (!e()) {
                t();
                return
            }
            b.heroLatePlaceholderDetection ? setTimeout(function() {
                v()
            }) : u()
        })
    }
    g.addHeroDebugging = a
}), 98);
__d("InteractionTracingLogger", ["performanceNowSinceAppStart"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new RegExp(/^late_mutation\/(un)?expected_([0-9]+)$/),
        i = 4;

    function j(a, b, c, d) {
        a.QuickPerformanceLogger.markerAnnotate(b, {
            "int": {
                numReactCommit: c.size
            }
        }, {
            instanceKey: d
        })
    }

    function k(a, b, c, d, e) {
        a.QuickPerformanceLogger.markerAnnotate(b, {
            string_array: (a = {}, a[c] = d, a)
        }, {
            instanceKey: e
        })
    }

    function l(a, b, c, d, e, f) {
        a.QuickPerformanceLogger.markerPoint(b, c, {
            data: d != null ? {
                string: {
                    __key: d
                }
            } : null,
            instanceKey: e,
            timestamp: f
        })
    }

    function m(a, b, c, d) {
        a.QuickPerformanceLogger.markerAnnotate(b, c.annotations, {
            instanceKey: d
        });
        for (var e in c.tagSet) {
            var f = Array.from(c.tagSet[e]).sort();
            k(a, b, e, f, d)
        }
    }

    function n(a, b, c, d, e) {
        for (var f in d) {
            var g = d[f],
                i = g.data,
                j = g.timestamp;
            g = g.type;
            if (!a.allowedQPLPointTypes.has(g) || ((g = a.qplPointFilterRegex) == null ? void 0 : g.exec(f))) continue;
            g = i;
            h.test(f) && f !== "late_mutation/unexpected_1" && (i == null ? void 0 : i.reactStack) && (g = o(d[f], ["reactStack"]));
            l(b, c, f, g && Object.keys(g).length ? JSON.stringify(g) : void 0, e, j + a.appStart)
        }
    }

    function o(a, b) {
        a = a.data;
        var c = a != null ? JSON.parse(JSON.stringify(a)) : null;
        c != null && b.forEach(function(a) {
            return delete c[a]
        });
        return c
    }

    function p(a, b, c, d, e) {
        for (var f in d) {
            var g;
            if ((g = a.qplPointFilterRegex) == null ? void 0 : g.exec(f)) continue;
            for (g = 0; g < d[f].length; g++) {
                var h = d[f][g],
                    j = h.data,
                    k = h.end,
                    m = h.start;
                h = h.type;
                if (!a.allowedQPLPointTypes.has(h)) continue;
                h = d[f].length === 1 ? f : f + "_" + (g >= i ? "MAX" : g + 1);
                l(b, c, h + "_start", void 0, e, m + a.appStart);
                l(b, c, h + "_end", Object.keys(j).length ? JSON.stringify(j) : void 0, e, k + a.appStart)
            }
        }
    }

    function a(a, b, c, d, e, f) {
        f = (f == null ? void 0 : f.qplMarkerType) ? {
            type: f.qplMarkerType
        } : babelHelpers["extends"]({}, null);
        b.QuickPerformanceLogger.markerStart(c, e, d + a.appStart, f)
    }

    function b(a, b, d, e, f, g) {
        j(b, d, f.commitSet, g);
        m(b, d, f, g);
        n(a, b, d, f.markerPoints, g);
        p(a, b, d, f.subSpans, g);
        f = a.qplActionMap[e];
        b.QuickPerformanceLogger.markerEnd(d, f, g, c("performanceNowSinceAppStart")() + a.appStart);
        return f
    }

    function d(a) {
        var b;
        return ((b = a.annotations["int"]) == null ? void 0 : b.isError) === 1 ? "FAIL" : a.wasOffline ? "OFFLINE" : ((b = a.annotations.string) == null ? void 0 : b.cancelType) === "timeout" ? "TIMEOUT" : a.wasCanceled || ((b = a.annotations["int"]) == null ? void 0 : b.aborted) === 1 ? "CANCEL" : "SUCCESS"
    }
    g.initQPL = a;
    g.logQPL = b;
    g.getTraceStatus = d
}), 98);
__d("InteractionCloning", ["InteractionTracingLogger", "QPLEvent", "interaction-tracing-metrics", "uuid"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        a = (a = a.annotations.string) == null ? void 0 : a.clonedInteractionId;
        return a != null ? d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(a) : null
    }

    function i(a, b, c) {
        var e = h(a);
        e != null && (e.annotations === a.annotations && (a.annotations = babelHelpers["extends"]({}, a.annotations)), e.annotations.string === a.annotations.string && (a.annotations.string = babelHelpers["extends"]({}, a.annotations.string)));
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotation(a.traceId, b, c)
    }

    function j(a, b, c) {
        var e = h(a);
        e != null && (e.tagSet === a.tagSet && (a.tagSet = babelHelpers["extends"]({}, a.tagSet)));
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addTag(a.traceId, b, c)
    }

    function a(a, b, c, e) {
        var f = h(a);
        f != null && (f.markerPoints === a.markerPoints && (a.markerPoints = babelHelpers["extends"]({}, a.markerPoints)));
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addMarkerPoint(a.traceId, b, c, e)
    }

    function b(a, b, c, e, f, g) {
        var i = h(a);
        i != null && (i.subSpans === a.subSpans && (a.subSpans = babelHelpers["extends"]({}, a.subSpans)));
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addSubspan(a.traceId, b, c, e, f, g)
    }

    function k(a, b, e, f, g, h) {
        var k = c("uuid")(),
            l = d("interaction-tracing-metrics").InteractionTracingMetricsCore.addTracedInteraction(k, a.start, function() {});
        l = Object.assign(l, a);
        l.traceId = k;
        l.annotations = babelHelpers["extends"]({}, a.annotations);
        l.annotations.string = babelHelpers["extends"]({}, a.annotations.string);
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotation(k, "clonedInteractionId", a.traceId);
        i(l, "interactionId", k);
        j(l, "traceID", k);
        l.qplEvent = b;
        l.debugName = e;
        d("InteractionTracingLogger").initQPL(f, g, b, l.start, h, {
            qplMarkerType: f.qplMarkerType
        });
        k = {
            interaction_class: l.interactionClass,
            interaction_id: l.traceId,
            qpl_marker_id: "" + d("QPLEvent").getMarkerId(b),
            sample_rate: 1,
            trace_policy: (a = l) == null ? void 0 : a.tracePolicy,
            type: "INTERACTION"
        };
        h = (e = g.WebLoom) == null ? void 0 : e.startTrace(l.traceId, k, l.start + f.appStart, void 0);
        b = h == null ? void 0 : h.traceReferenceId;
        b != null && i(l, "loomRefId", b);
        return l
    }

    function l(a, b, c, e, f) {
        var g = d("InteractionTracingLogger").getTraceStatus(a);
        e = d("InteractionTracingLogger").logQPL(e, f, b, g, a, c);
        (b = f.WebLoom) == null ? void 0 : b.endTraceForInteraction(a, e)
    }
    e = {
        addMarkerPoint_cloneSafe: a,
        addSubspan_cloneSafe: b,
        clone: function(a, b, c, d) {
            var e = a.getTrace();
            if (e == null) return;
            a = a.getConfigAndDependencies();
            var f = a.cfg;
            a = a.deps;
            e = k(e, b, c, f, a, d);
            l(e, b, d, f, a)
        },
        cloneAndStart: k,
        log: l
    };
    f = e;
    g["default"] = f
}), 98);
__d("InteractionTracingUserTimingUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c) {
        if (a.UserTimingUtils == null) return;
        if (b.markerPoints.visuallyComplete) {
            var d;
            (d = a.UserTimingUtils) == null ? void 0 : d.measureModern("VisuallyComplete(" + c + ")[" + b.traceId.slice(0, 3) + "]", {
                end: b.markerPoints.visuallyComplete.timestamp,
                start: b.start
            }, "VC")
        }
        if (b.markerPoints.vcWithoutImage) {
            (d = a.UserTimingUtils) == null ? void 0 : d.measureModern("VCWithoutImage(" + c + ")[" + b.traceId.slice(0, 3) + "]", {
                end: b.markerPoints.vcWithoutImage.timestamp,
                start: b.start
            }, "VCWithoutImage")
        }
    }
    f.markInteraction = a
}), 66);
__d("LateMutationUtilities", ["addAnnotations", "vc-tracker"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c, d) {
        h(c, d) && (j(c, d), m(a, b, c), o(c), p(c))
    }

    function h(a, b) {
        a = a.interactionType === "INITIAL_LOAD";
        b = Object.prototype.hasOwnProperty.call(b.markerPoints, "ssr_shown");
        return a && b
    }

    function i(a, b, d) {
        b = b.getReactComponentStackFromDOMElement;
        var e = !1;
        for (var f = d.elements.length - 1; f >= 0; f--) {
            var g = d.elements[f];
            if (a.logLateMutationReactStack && b && g.element && (g.hadLateMutationExpected || g.hadLateMutationUnexpected)) {
                var h = b(g.element);
                if (h != null) {
                    var i = h.indexOf("HeroPagelet");
                    i >= 0 && h.splice(i);
                    !e && g.hadLateMutationUnexpected && (c("addAnnotations")(d.annotations, {
                        string: {
                            lateMutationStack: h.join(",")
                        }
                    }), e = !0);
                    g.reactStack = h
                }
            }
        }
    }

    function j(a, b) {
        var c = null;
        a.pagelets.forEach(function(a) {
            a.name === "root" && (c = a.mutationSeq)
        });
        a.elements.forEach(function(a) {
            var d = a.pagelet;
            d != null && c != null && a.mutationSeq > c && a.type === "component" && (k(a, b) ? (d.data.hadLateMutationExpected = 1, a.hadLateMutationExpected = !0) : (d.data.hadLateMutationUnexpected = 1, a.hadLateMutationUnexpected = !0))
        })
    }

    function k(a, b) {
        var c;
        return ((c = a.pagelet) == null ? void 0 : c.excludeFromMainVC) || l(a, b)
    }

    function l(a, b) {
        a = a.element;
        while (a) {
            if (a.getAttribute(c("vc-tracker").VisualCompletionConstants.ATTRIBUTE_NAME) === c("vc-tracker").VisualCompletionConstants.IGNORE_LATE_MUTATION || b.lateMutationIgnoreElements.has(a)) return !0;
            a = a.parentElement
        }
        return !1
    }

    function m(a, b, d) {
        i(a, b, d);
        a = 10;
        b = 0;
        var e = 0,
            f = 0;
        for (var g = d.elements.length - 1; g >= 0; g--) {
            var h = d.elements[g];
            (h.hadLateMutationExpected || h.hadLateMutationUnexpected) && (e += h.hadLateMutationExpected ? 1 : 0, f += h.hadLateMutationUnexpected ? 1 : 0, b = h.hadLateMutationExpected && e + f >= a ? 1 : 0)
        }
        c("addAnnotations")(d.annotations, {
            "int": {
                lmCountExpected: e,
                lmCountUnexpected: f
            },
            bool: {
                hadLateMutationExpected: e > 0,
                hadLateMutationUnexpected: f > 0
            }
        });
        h = a - f - b;
        g = [];
        var j;
        b = !1;
        var k = 1;
        e = 1;
        f = 1;
        for (var l = d.elements.length - 1; l >= 0; l--) {
            var m = d.elements[l];
            if (m.hadLateMutationUnexpected || m.hadLateMutationExpected) {
                var o = {
                    hadLateMutationExpected: m.hadLateMutationExpected,
                    hadLateMutationUnexpected: m.hadLateMutationUnexpected,
                    mutationType: m.mutationType,
                    type: m.type,
                    height: m.rectangle.bottom - m.rectangle.top,
                    width: m.rectangle.right - m.rectangle.left
                };
                m.element && (o.tagName = m.element.tagName);
                m.pagelet && (o.pagelet = m.pagelet.name);
                !b && m.hadLateMutationUnexpected && (o.reactStack = m.reactStack, b = !0);
                j = {
                    markerPointData: o,
                    markerPointTitle: n(o, m.hadLateMutationUnexpected ? f : e),
                    element: m,
                    timestamp: m.latency
                };
                (e <= h || m.hadLateMutationUnexpected) && k < a && (m.hadLateMutationUnexpected ? f++ : e++, g.push(j), k++)
            }
        }
        j && k === a && g.push(j);
        o = g.length;
        if (o > 1) {
            m = g[o - 1];
            m.markerPointData.reactStack = m.element.reactStack
        }
        g.forEach(function(a) {
            return d.markerPoints.set(a.markerPointTitle, {
                data: a.markerPointData,
                timestamp: a.timestamp
            })
        })
    }

    function n(a, b) {
        return "late_mutation/" + (a.hadLateMutationUnexpected ? "unexpected" : "expected") + "_" + b
    }

    function o(a) {
        var b = a.pagelets.reduce(function(a, b) {
            return "firstPaint" in b.points ? Math.min(a, b.points.firstPaint) : a
        }, Number.MAX_SAFE_INTEGER);
        b !== Number.MAX_SAFE_INTEGER && c("addAnnotations")(a.annotations, {
            "int": {
                progressiveRenderCost: a.vcWithoutImage - b
            }
        })
    }

    function p(a) {
        var b = a.pagelets.reduce(function(a, b) {
                return "firstPaint" in b.points && b.data.lateMutation ? Math.min(a, b.points.firstPaint) : a
            }, Number.MAX_SAFE_INTEGER),
            d = a.pagelets.reduce(function(a, b) {
                return "vcWithoutImage" in b.points && b.data.lateMutation ? Math.max(a, b.points.vcWithoutImage) : a
            }, Number.MIN_SAFE_INTEGER);
        b !== Number.MAX_SAFE_INTEGER && d !== Number.MIN_SAFE_INTEGER && c("addAnnotations")(a.annotations, {
            "int": {
                SsrPageletLmCost: d - b
            }
        })
    }
    g.logLateMutationData = a;
    g.logLateMutationMarkerPoints = m
}), 98);
__d("NetInfo", ["NetworkStatus", "Promise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map();
    a = {
        isConnected: {
            addEventListener: function(a, b) {
                (a = h.get(b)) == null ? void 0 : a.remove();
                var d = c("NetworkStatus").onChange(function(a) {
                    b(a.online)
                });
                h.set(b, d);
                return {
                    remove: function() {
                        d.remove(), h["delete"](b)
                    }
                }
            },
            removeEventListener: function(a, b) {
                (a = h.get(b)) == null ? void 0 : a.remove();
                h["delete"](b)
            },
            fetch: function() {
                return b("Promise").resolve(c("NetworkStatus").isOnline())
            }
        }
    };
    d = a;
    g["default"] = d
}), 98);
__d("InteractionTracingCore", ["HeroTracingDebugTracing", "InteractionCloning", "InteractionTracingLogger", "InteractionTracingUserTimingUtils", "JSScheduler", "LateMutationUtilities", "MemoryUtils", "NetInfo", "Promise", "VisibilityState", "WebAPIs", "addAnnotations", "clearTimeout", "hero-tracing", "hero-tracing-placeholder", "interaction-tracing-metrics", "one-trace", "performanceNavigationStart", "performanceNowSinceAppStart", "regeneratorRuntime", "setTimeoutAcrossTransitions", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "InteractionTracingLogging",
        i = c("performanceNavigationStart")(),
        j = new Set(),
        k, l = null,
        m = 0,
        n = new Set(),
        o = 1;
    c("one-trace").subscribe("trace-end-before-logging", function(a) {
        if (a.traceType === "LONGTASK" || a.traceType === "INPUT_DELAY") {
            var b = a.traceType;
            j.forEach(function(e) {
                var f = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(e.getTraceId());
                if (f) {
                    d("interaction-tracing-metrics").InteractionTracingMetricsCore.addSubspan(e.getTraceId(), b, b, Math.max(a.startTime, f.start), (e = a.endTime) != null ? e : c("performanceNowSinceAppStart")(), {});
                    if (f.type != null) {
                        var g;
                        e = f.type;
                        g = (g = (g = a.annotations.string_array) == null ? void 0 : g.affectedInteractions) != null ? g : [];
                        c("addAnnotations")(a.annotations, {
                            string_array: {
                                affectedInteractions: g.concat([e + "(" + ((g = f.tracePolicy) != null ? g : "") + ")"])
                            }
                        })
                    }
                }
            })
        }
    });

    function p(a, b) {
        if (typeof window.qpl_tag === "function") {
            b.tagSet.CometTags || (b.tagSet.CometTags = new Set());
            var c = b.type === "INITIAL_LOAD" || b.type === "NAVIGATION",
                d = b.tagSet.CometTags;
            b = window.qpl_tag();
            b && b.length && b.forEach(function(b) {
                b && b.length && b.forEach(function(b) {
                    d.add(b), c && a.VisualCompletion && a.VisualCompletion.addTag("CometTags", b)
                })
            })
        }
    }

    function q(a, b, c, e, f) {
        var g = d("VisibilityState").getHiddenSpans(b, c);
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addHiddenTiming(a, g);
        g.length > 0 && d("interaction-tracing-metrics").InteractionTracingMetricsCore.addMarkerPoint(a, "backgrounded", "AppTiming", g[0].start);
        ((a = e.annotations["int"]) == null ? void 0 : a.hidden) === void 0 && f.addAnnotationInt("hidden", Number(d("VisibilityState").wasHidden(b, c)))
    }

    function r(a, b) {
        var e;
        e = (e = b.completed) != null ? e : c("performanceNowSinceAppStart")();
        var f = b.markerPoints.visuallyComplete ? b.markerPoints.visuallyComplete.timestamp : e,
            g = [],
            h = null;
        a.forEach(function(a) {
            !a.isOnline ? (h = a.timestamp, h < f && (b.wasOffline = !0)) : h != null && (g.push({
                end: a.timestamp,
                start: h
            }), h = null)
        });
        h != null && g.push({
            end: e,
            start: h
        });
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addOfflineTiming(b.traceId, g)
    }

    function s(a, b, d) {
        var e;
        d.interactionClass && b.addAnnotation("interactionClass", d.interactionClass);
        var f = d.start;
        e = (e = d.completed) != null ? e : c("performanceNowSinceAppStart")();
        q(d.traceId, f, e, d, b);
        b.addAnnotationInt("navStartOffset", d.start);
        if (a.getMetadata) {
            var g = a.getMetadata();
            Object.keys(g).forEach(function(a) {
                var c = g[a];
                typeof c === "string" ? b.addAnnotation(a, c) : typeof c === "number" && b.addAnnotationInt(a, c)
            })
        }
        a.pkgCohort != null && b.addAnnotation("pkg_cohort", a.pkgCohort)
    }

    function t(a) {
        var b = a.traceId;
        a = d("hero-tracing-placeholder").HeroPendingPlaceholderTracker.dump(b);
        a.forEach(function(a) {
            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addTag(b, "pendingPlaceholder", a)
        })
    }

    function u(a, b, c) {
        var d = b.getReactComponentStackFromDOMElement;
        d && a.logVCReactStack && c.onBeforeComplete(function(a) {
            a && ["vcWithoutImage", "visuallyComplete"].forEach(function(b) {
                b = a.markerPoints.get(b);
                if (b && b.element) {
                    var c = d(b.element);
                    if (c != null) {
                        var e = c.indexOf("HeroPagelet");
                        e >= 0 && c.splice(e);
                        e = b.data || {};
                        e.reactStack = c;
                        b.data = e
                    }
                }
            })
        })
    }

    function v(a, b, c, e) {
        c.onBeforeComplete(function(c) {
            if (!c) return;
            d("LateMutationUtilities").logLateMutationData(a, b, c, e)
        })
    }

    function w(a, b) {
        var c;
        (c = a.vcTracker) == null ? void 0 : c.onComplete(function(c) {
            if (c) {
                a.vcStateLog = c.stateLog;
                a.hasVcReport = !0;
                for (var d in c.annotations)
                    for (var e in c.annotations[d]) a.annotations[d][e] = c.annotations[d][e];
                c.markerPoints.forEach(function(b, c) {
                    var d = b.data;
                    b = b.timestamp;
                    a.markerPoints[c] = {
                        data: d,
                        timestamp: b,
                        type: "VisualCompletion"
                    }
                });
                c.tagSet.forEach(function(a, c) {
                    a.forEach(function(a) {
                        b.addTag(c, a)
                    })
                })
            }
        })
    }

    function x(a) {
        a = a.replace(/\d{4,}/, "");
        return a
    }
    var y = 0,
        z = new Map(),
        A = {
            checkRevisit: function(a) {
                return a == null ? !1 : n.has(a)
            },
            checkAndMarkRevisit: function(a) {
                var b = A.checkRevisit(a);
                a != null && n.add(a);
                return b
            },
            clone: function(a, b, d) {
                return c("InteractionCloning").clone(a, b, d, o++)
            },
            getNextInstanceKey: function() {
                return o++
            },
            getCurrentTabTracePolicy: function() {
                var a;
                return (a = l) != null ? a : "comet.app"
            },
            setCurrentTabTracePolicy: function(a) {
                l = a
            },
            onStartInteraction: function(a) {
                var b = y++;
                z.set(b, a);
                return function() {
                    z["delete"](b)
                }
            },
            startInteraction: function(a, b) {
                b === void 0 && (b = function() {});
                var c = d("hero-tracing").HeroLogger.genHeroInteractionUUIDAndMarkStart(a.interactionID);
                return A.trace(a.cfg, a.deps, a.qplEvent, b, a.interactionClass, a.traceType, a.tracePolicy, c, a.startTime, a.eventQueueTime, a.debugName)
            },
            trace: function(a) {
                function b(b, c, d, e, f, g, h, i, j, k, l) {
                    return a.apply(this, arguments)
                }
                b.toString = function() {
                    return a.toString()
                };
                return b
            }(function(a, e, f, g, n, q, y, A, B, C, D) {
                A === void 0 && (A = c("uuid")());
                C === void 0 && (C = null);
                var E = (B = B) != null ? B : q === "INITIAL_LOAD" ? 0 : c("performanceNowSinceAppStart")(),
                    F = [],
                    G = l,
                    H = o++,
                    I = y != null ? x(y) : null,
                    J = a.enableMemoryLogging ? d("MemoryUtils").getCurrentMemory().usedJSHeapSize : null;
                k || (k = d("WebAPIs").onBeforeUnload(function() {
                    j.forEach(function(a) {
                        var b;
                        ((b = a.getTrace()) == null ? void 0 : (b = b.annotations["int"]) == null ? void 0 : b.success_on_unload) === 1 ? a.forceCompleteTrace() : a.cancelTrace("unload", !0)
                    }), k && k.remove(), k = null
                }));

                function K(a, c) {
                    var d;
                    return b("regeneratorRuntime").async(function(f) {
                        while (1) switch (f.prev = f.next) {
                            case 0:
                                if (!(R != null)) {
                                    f.next = 5;
                                    break
                                }
                                if (!(Y.length > 0)) {
                                    f.next = 4;
                                    break
                                }
                                f.next = 4;
                                return b("regeneratorRuntime").awrap(b("Promise").all(Y));
                            case 4:
                                (d = e.WebLoom) == null ? void 0 : d.endTraceForInteraction(a, c);
                            case 5:
                            case "end":
                                return f.stop()
                        }
                    }, null, this)
                }
                var L = new Set([h]);

                function M(a) {
                    a === void 0 && (a = !1);
                    var b = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(A);
                    if (!b || !j.has(N)) return;
                    b.completed == null && (b.completed = c("performanceNowSinceAppStart")());
                    t(b);
                    var e = [].concat(U);
                    U.length = 0;
                    e.forEach(function(a) {
                        a(b, !0)
                    });
                    a ? P(b, !0) : c("JSScheduler").scheduleLoggingPriCallback(function() {
                        P(b, !0)
                    })
                }
                var N = {
                        addGlobalMetadata: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addGlobalMetadata(A, a, b)
                        },
                        addLoomTraceEndDependency: function(a) {
                            Y.push(a)
                        },
                        addMarkerPoint: function(a, b, e, f) {
                            e === void 0 && (e = c("performanceNowSinceAppStart")()), d("interaction-tracing-metrics").InteractionTracingMetricsCore.addMarkerPoint(A, a, b, e, f)
                        },
                        addSubspan: function(a, b, c, e, f) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addSubspan(A, a, b, c, e, f || {})
                        },
                        addMetadata: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addMetadata(A, a, b)
                        },
                        addAnnotation: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotation(A, a, b)
                        },
                        addAnnotationInt: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationInt(A, a, b)
                        },
                        addAnnotationDouble: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationDouble(A, a, b)
                        },
                        addAnnotationBoolean: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationBoolean(A, a, b)
                        },
                        addAnnotationStringArray: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationStringArray(A, a, b)
                        },
                        addAnnotationIntArray: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationIntArray(A, a, b)
                        },
                        addAnnotationDoubleArray: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationDoubleArray(A, a, b)
                        },
                        addAnnotationBooleanArray: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationBooleanArray(A, a, b)
                        },
                        addTag: function(a, b) {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addTag(A, a, b)
                        },
                        lockInteractionLogging: function(a) {
                            L.add(a)
                        },
                        unlockInteractionLogging: function(a) {
                            L.has(a) && (L["delete"](a), L.size === 0 && aa())
                        },
                        cancelTrace: function(a, b) {
                            N.addAnnotation("cancelType", a);
                            a = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(A);
                            if (!a || !j.has(N)) return;
                            a.wasCanceled = !0;
                            M(b)
                        },
                        forceCompleteTrace: function() {
                            M(!0)
                        },
                        getConfigAndDependencies: function() {
                            return {
                                cfg: a,
                                deps: e
                            }
                        },
                        getTrace: function() {
                            return d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(A)
                        },
                        getTraceId: function() {
                            return A
                        },
                        markTraceAsSuccessOnUnload: function() {
                            N.addAnnotationInt("success_on_unload", 1)
                        },
                        observeMutation: function(a) {
                            e.InteractionVC && e.InteractionVC.observeMutation(A, a)
                        },
                        onComplete: function(a) {
                            T.push(a)
                        },
                        onCompleteSync: function(a) {
                            U.push(a)
                        },
                        onLog: function(a) {
                            V.push(a)
                        },
                        onBeforeLog: function(a) {
                            W.push(a)
                        },
                        onVcMetricsComplete: function(a) {
                            X.push(a)
                        },
                        setTracePolicy: function(b) {
                            if (b == null) return;
                            b = x(b);
                            c("one-trace").setTracePolicy(A, b);
                            I = b;
                            N.addAnnotation("tracePolicy", I);
                            if (R == null && a.disableLoomTrace !== !0) {
                                b = (b = e.WebLoom) == null ? void 0 : b.maybeStartTraceForInteraction(A, n, f, I, E);
                                R = b == null ? void 0 : b.traceReferenceId;
                                S = b == null ? void 0 : b.loomProviders
                            }
                            b = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(A);
                            b && (b.tracePolicy = I, b.vcTracker && b.vcTracker.setTracePolicy(I))
                        },
                        setInstanceIdentifier: function(a) {},
                        getInstanceKey: function() {
                            return H
                        }
                    },
                    aa = function() {
                        var b;
                        if (!j.has(N)) return;
                        var g = $;
                        c("clearTimeout")(ca);
                        ba.remove();
                        j["delete"](N);
                        r(F, g);
                        (b = e.HeroBootloadPerfStore) == null ? void 0 : b.addStaticResourcesStats(g);
                        b = [].concat(W);
                        W.length = 0;
                        b.forEach(function(a) {
                            a(g)
                        });
                        b = d("InteractionTracingLogger").getTraceStatus(g);
                        var h = d("InteractionTracingLogger").logQPL(a, e, f, b, g, H);
                        g.qplAction = h;
                        g.traceStatus = b;
                        g.debugName = D;
                        b = [].concat(V);
                        V.length = 0;
                        b.forEach(function(a) {
                            a(g, d("InteractionTracingLogger").getTraceStatus(g))
                        });
                        delete g.vcTracker;
                        g.lateMutationIgnoreElements.clear();
                        K(g, h);
                        d("InteractionTracingUserTimingUtils").markInteraction(e, g, q);
                        setTimeout(function() {
                            d("interaction-tracing-metrics").InteractionTracingMetricsCore["delete"](A)
                        }, 30 * 6e4)
                    };

                function O(a) {
                    a ? L.forEach(function(a) {
                        N.unlockInteractionLogging(a)
                    }) : N.unlockInteractionLogging(h)
                }
                var P = function(b, c) {
                    var f;
                    if (!j.has(N)) return;
                    N.addAnnotationInt("startTimestamp", E + i);
                    p(e, b);
                    N.addAnnotation("tracePolicy", (f = I) != null ? f : a.defaultTracePolicy);
                    G != null && N.addAnnotation("referrer", G);
                    N.addAnnotation("interactionId", A);
                    if (J != null) {
                        f = d("MemoryUtils").getCurrentMemory().usedJSHeapSize;
                        f != null && (N.addAnnotationInt("usedJSHeapSizeStart", J), N.addAnnotationInt("usedJSHeapSizeEnd", f))
                    }
                    s(a, N, b);
                    e.VisualCompletion && Z != null && Z();
                    f = [].concat(T);
                    T.length = 0;
                    f.forEach(function(a) {
                        a(b, c)
                    });
                    R != null && N.addAnnotation("loomRefId", R);
                    S != null && S.forEach(function(a) {
                        return N.addTag("loomProviders", a)
                    });
                    f = b.vcTracker;
                    f && !b.hasVcReport ? (f.onComplete(function() {
                        O(c)
                    }), c && f.forceMeasurement()) : O(c)
                };

                function Q(a, b) {
                    b === void 0 && (b = c("performanceNowSinceAppStart")()), F.push({
                        isOnline: a,
                        timestamp: b
                    })
                }
                c("NetInfo").isConnected.fetch().then(function(a) {
                    q === "INITIAL_LOAD" ? c("NetInfo").isConnected.fetch().then(function(a) {
                        a || Q(a)
                    })["catch"]() : a || Q(a)
                })["catch"]();
                var ba = c("NetInfo").isConnected.addEventListener("connectionChange", function(a) {
                        Q(a)
                    }),
                    R, S;
                if (I != null && a.disableLoomTrace !== !0) {
                    y = (B = e.WebLoom) == null ? void 0 : B.maybeStartTraceForInteraction(A, n, f, I, E);
                    R = y == null ? void 0 : y.traceReferenceId;
                    S = y == null ? void 0 : y.loomProviders
                }
                d("InteractionTracingLogger").initQPL(a, e, f, E, H, {
                    qplMarkerType: a.qplMarkerType
                });
                var T = [],
                    U = [],
                    V = [],
                    W = [],
                    X = [],
                    Y = [],
                    Z = null;
                e.VisualCompletion && (Z = e.VisualCompletion.addTracedInteraction(q, A, f));
                c("one-trace").startTrace(A, I, q, E);
                N.onLog(function(a, b) {
                    c("one-trace").endTrace(A, (b = a.completed) != null ? b : c("performanceNowSinceAppStart")(), d("InteractionTracingLogger").getTraceStatus(a))
                });
                var ca = c("setTimeoutAcrossTransitions")(function() {
                    N.cancelTrace("timeout", !1)
                }, a.timeout);
                if (a.cancelOnBackground === !0) {
                    var da = d("VisibilityState").subscribe(function(a, b) {
                        b && N.cancelTrace("background", !0)
                    });
                    N.onCompleteSync(function() {
                        da()
                    })
                }
                B = function(a, b) {
                    var d;
                    b === void 0 && (b = !1);
                    if (!j.has(N)) return;
                    e.VCTracker && ((d = a.vcTracker) == null ? void 0 : d.unlock(e.VCTracker.VisualCompletionConstants.INTERACTION_TRACING_HOLD));
                    a.completed == null && (a.completed = c("performanceNowSinceAppStart")());
                    d = [].concat(U);
                    U.length = 0;
                    d.forEach(function(b) {
                        b(a)
                    });
                    if (a.type === "INITIAL_LOAD" && ((d = window) == null ? void 0 : (d = d.document) == null ? void 0 : d.readyState) === "loading") {
                        var f;
                        d = function d() {
                            var e;
                            c("JSScheduler").scheduleLoggingPriCallback(function() {
                                P(a, b)
                            });
                            (e = window) == null ? void 0 : (e = e.document) == null ? void 0 : e.removeEventListener("DOMContentLoaded", d)
                        };
                        (f = window) == null ? void 0 : (f = f.document) == null ? void 0 : f.addEventListener("DOMContentLoaded", d)
                    } else c("JSScheduler").scheduleLoggingPriCallback(function() {
                        P(a, b)
                    })
                };
                var $ = d("interaction-tracing-metrics").InteractionTracingMetricsCore.addTracedInteraction(A, E, B);
                d("interaction-tracing-metrics").InteractionTracingMetricsCore.setInteractionType(A, n, q, f);
                switch (q) {
                    case "INITIAL_LOAD":
                        N.addAnnotationInt("navSequence", ++m);
                        if (e.VisualCompletion) {
                            y = e.VisualCompletion.traceNavigation(A, 0, "INITIAL_LOAD", m);
                            $ && ($.vcTracker = y);
                            a.useDocumentBodyForVCRoot === !0 && window.document != null && (y.observeMutation(window.document.body), y.registerNavigationMutationRoot(window.document.body))
                        }
                        break;
                    case "NAVIGATION":
                        N.addAnnotationInt("navSequence", ++m);
                        j.forEach(function(c) {
                            var b = d("interaction-tracing-metrics").InteractionTracingMetricsCore.get(c.getTraceId());
                            if (!a.navigationCancelsInteractions && b && b.type === "INTERACTION") return;
                            c.cancelTrace("navigation", !1)
                        });
                        if (e.VisualCompletion) {
                            B = e.VisualCompletion.traceNavigation(A, E, "NAVIGATION", m);
                            $ && ($.vcTracker = B);
                            a.useDocumentBodyForVCRoot === !0 && window.document != null && (B.observeMutation(window.document.body), B.registerNavigationMutationRoot(window.document.body))
                        }
                        break;
                    case "INTERACTION":
                        if (e.InteractionVC) {
                            y = e.InteractionVC.startVisualCompletionTrace(A, E, q);
                            $ && ($.vcTracker = y)
                        }
                        break
                }
                j.add(N);
                d("HeroTracingDebugTracing").addHeroDebugging(N, a, function() {
                    return R != null
                });
                a.heroNestedRootsFix && N.addAnnotationInt("heroNestedRootsFix", 1);
                I != null && N.setTracePolicy(I);
                if ($ && $.vcTracker) {
                    B = $.vcTracker;
                    e.VCTracker && B.lock(e.VCTracker.VisualCompletionConstants.INTERACTION_TRACING_HOLD);
                    u(a, e, B);
                    v(a, e, B, $);
                    B.onComplete(function(a) {
                        var b = [].concat(X);
                        X.length = 0;
                        a && b.forEach(function(b) {
                            b($, a)
                        })
                    });
                    w($, N);
                    a.setupVcTracker && a.setupVcTracker(B)
                }
                g(N);
                z.forEach(function(a) {
                    return a(N)
                });
                if (C != null) {
                    y = E;
                    d("interaction-tracing-metrics").InteractionTracingMetricsCore.addSubspan(A, "EventQueued", "DOMEventTiming", y, y + C, {})
                }
                return A
            }),
            getPendingInteractions: function() {
                return new Set(j)
            }
        };
    a = A;
    g["default"] = a
}), 98);
__d("NavigationTracingUtils", ["interaction-tracing-metrics", "performance", "performanceNavigationStart"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("performanceNavigationStart")();

    function a(a) {
        var b, e = (c("performance") == null ? void 0 : c("performance").timing) || {};
        b = (c("performance") == null ? void 0 : (b = c("performance").navigation) == null ? void 0 : b.redirectCount) || 0;
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationInt(a, "redirectCount", b);
        b = typeof c("performance").getEntriesByType === "function" ? c("performance").getEntriesByType("navigation")[0] : null;
        (b == null ? void 0 : b.nextHopProtocol) && d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotation(a, "httpProtocol", b.nextHopProtocol);
        (b == null ? void 0 : b.type) ? d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotation(a, "navigationType", b.type): ((b = c("performance").navigation) == null ? void 0 : b.type) != null && d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotation(a, "navigationType", c("performance").navigation.type);
        for (b in e) typeof e[b] === "number" && e[b] >= h && d("interaction-tracing-metrics").InteractionTracingMetricsCore.addMarkerPoint(a, b, "NavigationTiming", e[b] - h);
        d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationInt(a, "documentDOMElementCount", document.getElementsByTagName("*").length)
    }

    function b(a) {
        var b = document.referrer;
        if (typeof b === "string") {
            b = /^\w+:\/\/[^\/]+/.exec(b);
            b && b[0] && d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotation(a, "referrer", b[0])
        }
    }
    g.addNavigationTiming = a;
    g.addReferrer = b
}), 98);
__d("NavigationTracingCore", ["InteractionTracingCore", "NavigationTracingUtils", "interaction-tracing-metrics", "performanceNowSinceAppStart"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        if (b != null) {
            c("InteractionTracingCore").setCurrentTabTracePolicy(b);
            b = c("InteractionTracingCore").checkAndMarkRevisit(b);
            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationInt(a, "revisit", Number(b))
        }
    }

    function i(a, b) {
        if (b != null) {
            b = c("InteractionTracingCore").checkAndMarkRevisit(b);
            d("interaction-tracing-metrics").InteractionTracingMetricsCore.addAnnotationInt(a, "instance_revisit", Number(b))
        }
    }

    function a(a, b) {
        var e, f = (e = a.traceStartTime) != null ? e : c("performanceNowSinceAppStart")();
        return c("InteractionTracingCore").startInteraction(a, function(c) {
            var e = c.getTraceId();
            h(e, a.tracePolicy);
            i(e, a.instanceIdentifier);
            c.setTracePolicy(a.tracePolicy);
            c.addMarkerPoint("traceStart", "AppTiming", f);
            c.onComplete(function(a) {
                d("NavigationTracingUtils").addNavigationTiming(e), d("NavigationTracingUtils").addReferrer(e)
            });
            b && b(c)
        })
    }

    function b(a, b) {
        return c("InteractionTracingCore").startInteraction(a, function(c) {
            try {
                var e = c.getTraceId(),
                    f = a.tracePolicy;
                h(e, a.tracePolicy);
                c.onComplete(function(a) {
                    d("NavigationTracingUtils").addNavigationTiming(e)
                });
                var g = babelHelpers["extends"]({}, c, {
                    setTracePolicy: function(a) {
                        if (f == null) {
                            a = a;
                            h(e, a);
                            a != null && c.setTracePolicy(a)
                        }
                    },
                    setInstanceIdentifier: function(a) {
                        i(e, a)
                    }
                });
                b && b(g)
            } catch (a) {
                if (a.message !== "can't access dead object") throw a
            }
        })
    }
    e = {
        traceInitialLoad: a,
        traceNavigation: b
    };
    g["default"] = e
}), 98);
__d("interaction-tracing", ["InteractionCloning", "InteractionTracingCore", "InteractionTracingLogger", "NavigationTracingCore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        InteractionTracingCore: c("InteractionTracingCore"),
        InteractionCloning: c("InteractionCloning"),
        NavigationTracing: c("NavigationTracingCore"),
        getTraceStatus: d("InteractionTracingLogger").getTraceStatus
    };
    b = a;
    g["default"] = b
}), 98);
__d("InteractionTracing", ["Env", "InteractionTracingConfigDefault", "InteractionTracingMetrics", "JSSelfProfilerLoomProvider", "JSSelfProfilerTrackedInteractions", "WebSession", "cr:70", "interaction-tracing"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var e = a.cfg,
            f = babelHelpers.objectWithoutPropertiesLoose(a, ["cfg"]);
        if (c("Env").jssp_header_sent && c("Env").jssp_targeting_enabled) {
            var g = c("JSSelfProfilerTrackedInteractions").interactions;
            if (g) {
                g = !!g.find(function(b) {
                    return b.tracePolicy === a.tracePolicy && b.action === a.traceType
                });
                if (g) {
                    (g = b("cr:70").WebLoom) == null ? void 0 : g.addProvider(c("JSSelfProfilerLoomProvider"))
                }
            }
        }
        return babelHelpers["extends"]({}, f, {
            cfg: babelHelpers["extends"]({}, d("InteractionTracingConfigDefault").DEFAULT_TRACING_CONFIG, e),
            deps: b("cr:70")
        })
    }
    a = babelHelpers["extends"]({}, c("interaction-tracing").InteractionTracingCore, {
        transformStartMetadata: h,
        startInteraction: function(a, b) {
            return c("interaction-tracing").InteractionTracingCore.startInteraction(h(a), b)
        },
        trace: function(a) {
            function b(b, c, d, e, f, g, h, i, j) {
                return a.apply(this, arguments)
            }
            b.toString = function() {
                return a.toString()
            };
            return b
        }(function(a, e, f, g, h, i, j, k, l) {
            l = c("interaction-tracing").InteractionTracingCore.trace(babelHelpers["extends"]({}, d("InteractionTracingConfigDefault").DEFAULT_TRACING_CONFIG, l), b("cr:70"), a, e, f, g, h, i, j, k);
            a = d("WebSession").getSessionId();
            a != null && c("InteractionTracingMetrics").addMetadata(l, "websession_id", a);
            return l
        }),
        navigation: c("interaction-tracing").NavigationTracing,
        getTraceStatus: c("interaction-tracing").getTraceStatus
    });
    g["default"] = a
}), 98);
__d("CometRelayFlightEventLogger", ["InteractionTracing"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map();

    function a(a) {
        a.name === "execute.start" && a.params.name === "MarketplacePDPContainerQuery" && h.set(a.executeId, {
            totalDuration: 0,
            totalFlightPayloadDeserializeDuration: 0,
            totalModuleDuration: 0,
            totalPayloadDuration: 0
        });
        if (a.executeId != null && !h.has(a.executeId)) return;
        if (a.name === "execute.next") {
            var b = h.get(a.executeId);
            b && (b.totalDuration += a.duration, b.totalPayloadDuration += a.duration)
        }
        if (a.name === "execute.async.module") {
            b = h.get(a.executeId);
            b && (b.totalDuration += a.duration, b.totalModuleDuration += a.duration)
        }
        if (a.name === "execute.flight.payload_deserialize") {
            b = h.get(a.executeId);
            b && (b.totalFlightPayloadDeserializeDuration += a.duration)
        }
        if (a.name === "execute.complete") {
            b = h.get(a.executeId);
            if (b) {
                var d = b.totalDuration,
                    e = b.totalFlightPayloadDeserializeDuration,
                    f = b.totalModuleDuration,
                    g = b.totalPayloadDuration;
                c("InteractionTracing").getPendingInteractions().forEach(function(a) {
                    a.addAnnotationInt("MarketplacePDPContainerQueryModuleProcessingSuccessDuration", f), a.addAnnotationInt("MarketplacePDPContainerQueryPayloadProcessingSuccessDuration", g), a.addAnnotationInt("MarketplacePDPContainerQueryFlightDeserializationSuccessDuration", e), a.addAnnotationInt("MarketplacePDPContainerQueryRelayProcessingSuccessDuration", d)
                })
            }
            h["delete"](a.executeId)
        }
        a.name === "execute.error" && h["delete"](a.executeId)
    }
    g.log = a
}), 98);
__d("useCometRouteTracePolicy", ["useCurrentRoute"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "comet.app";

    function a() {
        var a;
        return (a = (a = c("useCurrentRoute")()) == null ? void 0 : a.tracePolicy) != null ? a : h
    }
    g["default"] = a
}), 98);
__d("useCometInteractionTracing", ["CometInteractionTracingConfig", "InteractionTracing", "forEachObject", "react", "useCometRouteTracePolicy", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useCallback,
        i = 0;

    function j() {
        return i++
    }

    function a(a, b, e, f, g) {
        var i = (f = f) != null ? f : c("useCometRouteTracePolicy")(),
            k = "" + j();
        return h(function(f, h, j, l, m) {
            var n = c("uuid")(),
                o = (l = l) != null ? l : i,
                p = o + "_" + k + (m != null ? "_" + m : "");
            c("InteractionTracing").trace(a, function(a) {
                var b = c("InteractionTracing").checkAndMarkRevisit(o),
                    d = c("InteractionTracing").checkAndMarkRevisit(p);
                a.addMetadata("revisit", b ? 1 : 0);
                a.addMetadata("instance_revisit", d ? 1 : 0);
                g != null && c("forEachObject")(g, function(b, c) {
                    c != null && b != null && a.addMetadata(c, b)
                });
                f(a)
            }, b, e, o, n, h, j, d("CometInteractionTracingConfig").tracingConfig)
        }, [a, b, e, i])
    }
    g["default"] = a
}), 98);
__d("CometNotificationsThinClientConnectionHandler", ["relay-runtime", "unrecoverableViolation", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "comet_notifications_thin_client",
        i = "__connection_next_edge_index";

    function a(a, b) {
        var e, f = a.get(b.dataID);
        if (!f) return;
        var g = d("relay-runtime").ConnectionInterface.get(),
            h = g.EDGES,
            n = g.END_CURSOR,
            o = g.HAS_NEXT_PAGE,
            p = g.HAS_PREV_PAGE,
            q = g.PAGE_INFO,
            r = g.PAGE_INFO_TYPE;
        g = g.START_CURSOR;
        var s = f.getLinkedRecord(b.fieldKey),
            t = s && s.getLinkedRecord(q);
        if (!s) {
            f.setValue(null, b.handleKey);
            return
        }
        var u = d("relay-runtime").generateClientID(f.getDataID(), b.handleKey),
            v = f.getLinkedRecord(b.handleKey);
        e = (e = v) != null ? e : a.get(u);
        var w = e && e.getLinkedRecord(q);
        if (!e) {
            var x = a.create(u, s.getType());
            x.setValue(0, i);
            x.copyFieldsFrom(s);
            u = s.getLinkedRecords(h);
            if (u) {
                var y = d("relay-runtime").ConnectionInterface.get(),
                    z = y.NODE;
                u = u.reduce(function(b, c) {
                    if (!c) return b;
                    var d = c.getLinkedRecord(z);
                    d = d == null ? void 0 : d.getType();
                    return d === "NotifPageCachedNotificationRow" ? b : b.concat(j(a, x, c))
                }, []);
                x.setLinkedRecords(u, h)
            }
            f.setLinkedRecord(x, b.handleKey);
            w = a.create(d("relay-runtime").generateClientID(x.getDataID(), q), r);
            w.setValue(!1, o);
            w.setValue(!1, p);
            w.setValue(null, n);
            w.setValue(null, g);
            t && w.copyFieldsFrom(t);
            x.setLinkedRecord(w, q)
        } else {
            v == null && f.setLinkedRecord(e, b.handleKey);
            var A = e;
            y = s.getLinkedRecords(h);
            y && (y = y.map(function(b) {
                return j(a, A, b)
            }));
            u = A.getLinkedRecords(h);
            r = A.getLinkedRecord(q);
            A.copyFieldsFrom(s);
            u && A.setLinkedRecords(u, h);
            r && A.setLinkedRecord(r, q);
            v = [];
            f = b.args;
            if (u && y)
                if (f.after != null)
                    if (w && f.after === w.getValue(n)) {
                        e = new Set();
                        k(u, v, e);
                        k(y, v, e)
                    } else {
                        c("warning")(!1, "Relay: Unexpected after cursor `%s`, edges must be fetched from the end of the list (`%s`).", f.after, w && w.getValue(n));
                        return
                    }
            else if (f.before != null)
                if (w && f.before === w.getValue(g)) {
                    s = new Set();
                    k(y, v, s);
                    k(u, v, s)
                } else {
                    c("warning")(!1, "Relay: Unexpected before cursor `%s`, edges must be fetched from the beginning of the list (`%s`).", f.before, w && w.getValue(g));
                    return
                }
            else {
                r = l(u);
                q = new Set();
                m(y, v, r, q)
            } else y ? v = y : v = u;
            v != null && v !== u && A.setLinkedRecords(v, h);
            if (w && t)
                if (f.after == null && f.before == null) w.copyFieldsFrom(t);
                else if (f.before != null || f.after == null && f.last) {
                w.setValue(!!t.getValue(p), p);
                b = t.getValue(g);
                typeof b === "string" && w.setValue(b, g)
            } else if (f.after != null || f.before == null && f.first) {
                w.setValue(!!t.getValue(o), o);
                e = t.getValue(n);
                typeof e === "string" && w.setValue(e, n)
            }
        }
    }

    function b(a, b, c) {
        b = d("relay-runtime").getRelayHandleKey(h, b, null);
        return a.getLinkedRecord(b, c)
    }

    function j(a, b, e) {
        if (e == null) return e;
        var f = d("relay-runtime").ConnectionInterface.get(),
            g = f.EDGES;
        f = f.NODE;
        var h = b.getValue(i);
        if (typeof h !== "number") throw c("unrecoverableViolation")("CometNotificationsThinClientConnectionHandler: Expected edgeIndex to be a number", "Notifications");
        g = d("relay-runtime").generateClientID(b.getDataID(), g, h);
        var j = e.getLinkedRecord(f);
        if (j) {
            var k = d("relay-runtime").generateClientID(e.getDataID(), f, h);
            k = a.create(k, j.getType());
            k.copyFieldsFrom(j);
            e.setLinkedRecord(k, f)
        }
        j = a.create(g, e.getType());
        j.copyFieldsFrom(e);
        b.setValue(h + 1, i);
        return j
    }

    function k(a, b, c) {
        var e = d("relay-runtime").ConnectionInterface.get();
        e = e.NODE;
        for (var f = 0; f < a.length; f++) {
            var g = a[f];
            if (!g) continue;
            var h = g.getLinkedRecord(e);
            h = h && h.getDataID();
            if (h != null) {
                if (c.has(h)) continue;
                c.add(h)
            }
            b.push(g)
        }
    }

    function l(a) {
        var b = {},
            c = d("relay-runtime").ConnectionInterface.get();
        c = c.NODE;
        for (var e = 0; e < a.length; e++) {
            var f = a[e];
            if (!f) continue;
            f = f.getLinkedRecord(c);
            var g = f && f.getType();
            if (g === "NotifPageNotificationRow") {
                g = f == null ? void 0 : (g = f.getLinkedRecord("notif")) == null ? void 0 : g.getValue("id");
                typeof g === "string" && (b[g] = f)
            }
        }
        return b
    }

    function m(a, b, c, e) {
        var f = d("relay-runtime").ConnectionInterface.get();
        f = f.NODE;
        for (var g = 0; g < a.length; g++) {
            var h, i = a[g];
            if (!i) continue;
            var j = i.getLinkedRecord(f),
                k = j && j.getDataID();
            if (k != null) {
                if (e.has(k)) continue;
                e.add(k)
            }
            k = j == null ? void 0 : j.getType();
            h = j == null ? void 0 : (h = j.getLinkedRecord("notif")) == null ? void 0 : h.getValue("id");
            if (j && k === "NotifPageCachedNotificationRow") {
                if (typeof h === "string") {
                    k = c[h];
                    k && (k.copyFieldsFrom(j), i.setLinkedRecord(k, f), b.push(i))
                }
            } else b.push(i)
        }
    }
    g.update = a;
    g.getConnection = b;
    g.buildConnectionEdge = j
}), 98);
__d("CometNewsFeedConnectionHandler", ["FBLogger", "RelayFBConnectionHandler_UNSTABLE", "gkx", "relay-runtime", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "comet_news_feed",
        i = "__connection_next_edge_index",
        j = "received_edges_count";

    function a(a, b) {
        var e, f = a.get(b.dataID);
        if (!f) return;
        var g = d("relay-runtime").ConnectionInterface.get();
        g = g.EDGES;
        if (b.args.before != null) throw c("unrecoverableViolation")("The newsfeed connection does not support backward pagination by design", "comet_feed");
        var h = f.getLinkedRecord(b.fieldKey);
        if (!h) {
            c("FBLogger")("comet_feed").mustfix("Newsfeed connection is null in the store, this means no feed stories will be shown");
            return
        }
        var m = d("relay-runtime").generateClientID(f.getDataID(), b.handleKey),
            n = f.getLinkedRecord(b.handleKey);
        e = (e = n) != null ? e : a.get(m);
        if (!e) {
            var o = a.create(m, h.getType());
            o.setValue(0, i);
            o.copyFieldsFrom(h);
            m = h.getLinkedRecords(g);
            m && (m = m.map(function(b) {
                return d("relay-runtime").ConnectionHandler.buildConnectionEdge(a, o, b)
            }), o.setLinkedRecords(m, g), o.setValue(m.length, j));
            f.setLinkedRecord(o, b.handleKey);
            k(a, m, m, o, h);
            return
        }
        n == null && f.setLinkedRecord(e, b.handleKey);
        var p = e;
        m = h.getLinkedRecords(g);
        m && (m = m.map(function(b) {
            return d("relay-runtime").ConnectionHandler.buildConnectionEdge(a, p, b)
        }), p.setValue(m.length, j));
        n = p.getLinkedRecords(g);
        p.copyFieldsFrom(h);
        f = [];
        e = new Set();
        if (b.args.after != null || ((b = (b = m) == null ? void 0 : b.length) != null ? b : 0) === 0) {
            l((b = n) != null ? b : [], f, e)
        }
        l((n = m) != null ? n : [], f, e);
        p.setLinkedRecords(f, g);
        k(a, m, f, p, h)
    }

    function k(a, b, e, f, g) {
        var h = d("relay-runtime").ConnectionInterface.get(),
            i = h.END_CURSOR,
            j = h.HAS_NEXT_PAGE,
            k = h.HAS_PREV_PAGE,
            l = h.PAGE_INFO;
        h = h.PAGE_INFO_TYPE;
        g = g.getLinkedRecord(l);
        var m = f.getLinkedRecord(l);
        m == null && (m = a.create(d("relay-runtime").generateClientID(f.getDataID(), l), h), f.setLinkedRecord(m, l));
        a = g == null ? void 0 : g.getValue(i);
        m.setValue(!1, k);
        if (c("gkx")("1250838")) {
            m.setValue(((h = b == null ? void 0 : b.length) != null ? h : 0) > 0 || (g == null ? void 0 : g.getValue(j)) === !0, j)
        } else {
            m.setValue(((f = b == null ? void 0 : b.length) != null ? f : 0) > 0, j)
        }
        l = e != null ? e[e.length - 1] : null;
        k = null;
        l != null && (k = l.getValue("cursor"));
        if (k == null && a == null) {
            c("FBLogger")("comet_feed").info("Unable to set end_cursor as neither the server end cursor, or last edge cursor is defined, this can happen on initial load when there are no stories but shouldn't happen otherwise", "comet_feed");
            return
        }
        m.setValue((h = a) != null ? h : k, i)
    }

    function b(a, b, c) {
        b = d("relay-runtime").getRelayHandleKey(h, b, null);
        return a.getLinkedRecord(b, c)
    }

    function e(a, b, c) {
        return d("RelayFBConnectionHandler_UNSTABLE").unstable_getAllConnectionsWithKey(a, b, c, h)
    }

    function l(a, b, e) {
        var f = d("relay-runtime").ConnectionInterface.get();
        f = f.NODE;
        for (var g = 0; g < a.length; g++) {
            var h = a[g];
            if (!h) continue;
            var i = h.getLinkedRecord(f);
            if (!i) continue;
            i = i && i.getDataID();
            if (i == null) {
                c("FBLogger")("comet_feed").mustfix("Found edge without deduplication nodeID in comet_news_feed, this can lead to duplicate feed stories being rendered");
                b.push(h);
                continue
            }
            if (e.has(i)) continue;
            e.add(i);
            b.push(h)
        }
    }

    function f(a, b, e, f) {
        if (e == null) return e;
        var g = d("relay-runtime").ConnectionInterface.get();
        g = g.EDGES;
        var h = b.getValue(i);
        if (typeof h !== "number") throw c("unrecoverableViolation")("CometNewsFeedConnectionHandler: Expected edgeIndex to be a number", "comet_feed");
        f = (f = f) != null ? f : d("relay-runtime").generateClientID(b.getDataID(), g, h);
        g = a.create(f, e.getType());
        g.copyFieldsFrom(e);
        b.setValue(h + 1, i);
        return g
    }
    g.update = a;
    g.getConnection = b;
    g.unstable_getAllConnectionsWithKey = e;
    g.buildConnectionEdge = f;
    g.insertEdgeBefore = d("relay-runtime").ConnectionHandler.insertEdgeBefore
}), 98);
__d("CometRelayQueryProfiler", ["emptyFunction", "interaction-tracing", "performanceNow", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        if (!b) return c("emptyFunction");
        var d = c("performanceNow")();
        return function(a) {
            var e = {
                usedCache: b.usedCache,
                usedPrefetcher: b.usedPrefetcher
            };
            a && (e.error = a.message);
            c("interaction-tracing").InteractionTracingCore.getPendingInteractions().forEach(function(a) {
                a.addSubspan("Relay_" + b.queryName, "RelayQuery", d, c("performanceNow")(), e)
            })
        }
    }
    var i = !1;

    function a() {
        if (i) return;
        d("relay-runtime").RelayProfiler.attachProfileHandler("fetchRelayQuery", h);
        i = !0
    }
    g.install = a
}), 98);
__d("RelayFBCometMutations", ["recoverableViolation", "relay-runtime", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 1;

    function a(a) {
        return function(b, e) {
            var f = e.variables.input || {},
                g = f.actor_id,
                i = f.client_mutation_id;
            f = babelHelpers.objectWithoutPropertiesLoose(f, ["actor_id", "client_mutation_id"]);
            c("warning")(i == null, "RelayFBCometMutations: Found `client_mutation_id` in mutation input`. In the Facebook context, `client_mutation_id` and `actor_id` are added automatically.");
            var j;
            b.options != null && b.options.actorID != null && typeof b.options.actorID === "string" ? j = b.options.actorID : c("recoverableViolation")("RelayFBCometMutations: Expected a non-nullable string actorID to be set on the Relay environment. https://fburl.com/wiki/m19zmtlh", "relay");
            if (g != null && g !== j) {
                var k = d("relay-runtime").getRequest(e.mutation);
                k = k.params.name;
                c("recoverableViolation")('You passed an actor_id parameter "' + g + '" to mutation "' + k + '", but the parameter was overridden by the actor_id "' + ((k = j) != null ? k : "") + '" defined in the ActorContext that wraps your React tree. Update your code to avoid passing the actor_id parameter to your mutation.', "relay");
                j = g
            }
            g = babelHelpers["extends"]({}, e.variables, {
                input: babelHelpers["extends"]({}, f, {
                    actor_id: j,
                    client_mutation_id: (k = i) != null ? k : "" + h++
                })
            });
            return a(b, {
                configs: e.configs,
                mutation: e.mutation,
                onCompleted: e.onCompleted,
                onError: e.onError,
                optimisticResponse: e.optimisticResponse,
                optimisticUpdater: e.optimisticUpdater,
                updater: e.updater,
                uploadables: e.uploadables,
                variables: g
            })
        }
    }
    g.addFBisms = a
}), 98);
__d("react-relay/relay-hooks/MatchContainer", ["react"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = g || b("react"),
        i = h.useMemo;

    function a(a) {
        var b = a.fallback,
            c = a.loader,
            d = a.match;
        a = a.props;
        if (d != null && typeof d !== "object") throw new Error("MatchContainer: Expected `match` value to be an object or null/undefined.");
        d = (d = d) != null ? d : {};
        var e = d.__id,
            f = d.__fragments,
            g = d.__fragmentOwner,
            j = d.__fragmentPropName;
        d = d.__module_component;
        if (g != null && typeof g !== "object" || j != null && typeof j !== "string" || f != null && typeof f !== "object" || e != null && typeof e !== "string") throw new Error("MatchContainer: Invalid 'match' value, expected an object that has a '...SomeFragment' spread.");
        c = d != null ? c(d) : null;
        d = i(function() {
            if (j != null && e != null && f != null) {
                var a = {};
                a[j] = {
                    __id: e,
                    __fragments: f,
                    __fragmentOwner: g
                };
                return a
            }
            return null
        }, [e, f, g, j]);
        if (c != null && d != null) return h.jsx(c, babelHelpers["extends"]({}, a, d));
        else {
            return (c = b) != null ? c : null
        }
    }
    a.displayName = a.name + " [from " + e.id + "]";
    e.exports = a
}), null);
__d("RelayFBMatchContainer", ["RelayFBModuleLoader", "react", "react-relay/relay-hooks/MatchContainer"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.fallback,
            e = a.match;
        a = a.props;
        return h.jsx(c("react-relay/relay-hooks/MatchContainer"), {
            fallback: b,
            loader: d("RelayFBModuleLoader").read,
            match: e,
            props: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("RelayFBModuleResource", ["Promise", "RelayFBModuleLoader", "isPromise", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {};

    function i(a) {
        if (a === null || typeof a !== "object") throw c("unrecoverableViolation")("ModuleResource.read(): Expected `match` value to be an object.", "relay");
        a = a.__module_component;
        return a == null ? null : d("RelayFBModuleLoader").read(a)
    }

    function a(a) {
        var d = [],
            e = [];
        for (var f = 0; f < a.length; f++) try {
            var g = i(a[f]);
            d.push(g)
        } catch (a) {
            if (c("isPromise")(a)) e.push(a);
            else throw a
        }
        if (e.length > 0) {
            g = a.map(function(a, b) {
                return (a = j(a)) != null ? a : "UNKNOWN_" + b
            });
            var k = g.join(":");
            f = h[k];
            f == null && (f = h[k] = b("Promise").all(e)["finally"](function() {
                delete h[k]
            }));
            throw f
        }
        return d
    }

    function j(a) {
        if (a === null || typeof a !== "object") throw c("unrecoverableViolation")("ModuleResource.getModuleId(): Expected `match` value to be an object.", "relay");
        a = a.__module_component;
        if (a == null) return null;
        a = d("RelayFBModuleLoader").getModuleReference(a);
        return a.getModuleId()
    }
    g.read = i;
    g.readAll = a;
    g.getModuleId = j
}), 98);
__d("RelayFlightClientImpl.client", ["invariant", "react-relay/relay-hooks/useFragment", "react-relay/relay-hooks/useLazyLoadQuery", "relay-runtime"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b, d) {
        return c("react-relay/relay-hooks/useLazyLoadQuery")(a, b, {
            fetchPolicy: "store-only",
            UNSTABLE_renderPolicy: d == null ? void 0 : d.UNSTABLE_renderPolicy
        })
    }

    function b(a) {
        return a
    }

    function e(a, b) {
        a = a.params.id;
        a != null || h(0, 23333);
        return {
            id: a,
            variables: b
        }
    }
    f = {
        loadFragmentForClient: b,
        loadQueryForClient: e,
        useFragment: c("react-relay/relay-hooks/useFragment"),
        useReadQuery: a,
        readInlineData: d("relay-runtime").readInlineData
    };
    g["default"] = f
}), 98);
__d("RelayFlight.hybrid", ["RelayFlightClientImpl.client", "err", "relay-runtime/query/GraphQLTag", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null;

    function i() {
        return a.__flight_execution_mode_DO_NOT_USE === "flight"
    }

    function j() {
        if (!i() && h == null) {
            var a = b("RelayFlightClientImpl.client");
            h = a
        }
        if (h == null) throw c("err")("Expected RelayFlight::initialize_INTERNAL_DO_NOT_USE() to be called before using other APIs.");
        return h
    }

    function e(a) {
        if (h != null) {
            c("warning")(h === a, "RelayFlight::initialize_INTERNAL_DO_NOT_USE(): Already initialized, this module may not be initialized again.");
            return
        }
        h = a
    }
    var k = function() {
            var a = j();
            return a.readInlineData.apply(a, arguments)
        },
        l = function() {
            var a = j();
            return a.useFragment.apply(a, arguments)
        };

    function f(a, b, c) {
        var d = j();
        return d.useReadQuery(a, b, c)
    }

    function m(a) {
        var b = j();
        return b.loadFragmentForClient(a)
    }

    function n(a, b) {
        var c = j();
        return c.loadQueryForClient(a, b)
    }
    g.isServer_INTERNAL_DO_NOT_USE = i;
    g.initialize_INTERNAL_DO_NOT_USE = e;
    g.readInlineData = k;
    g.useFragment = l;
    g.useReadQuery = f;
    g.loadFragmentForClient = m;
    g.loadQueryForClient = n;
    g.graphql = d("relay-runtime/query/GraphQLTag").graphql
}), 98);
__d("useFragmentNodes_DEPRECATED", ["mapObject", "react", "react-relay/relay-hooks/FragmentResource", "react-relay/relay-hooks/useRelayEnvironment", "relay-runtime", "useUnsafeRef_DEPRECATED", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef,
        j = b.useState;

    function a(a, b, e) {
        var f = c("react-relay/relay-hooks/useRelayEnvironment")(),
            g = d("react-relay/relay-hooks/FragmentResource").getFragmentResourceForEnvironment(f),
            m = i(!1),
            n = j(0),
            o = n[1];
        n = l(a, b);
        var p = c("useUnsafeRef_DEPRECATED")(0),
            q = c("useUnsafeRef_DEPRECATED")(0);
        f = k(f);
        n = k(n);
        f = f || n;
        n = j(b);
        var r = n[0];
        n = n[1];
        var s = Object.keys(b).filter(function(b) {
                return !Object.prototype.hasOwnProperty.call(a, b)
            }),
            t = s.some(function(a) {
                return r[a] !== b[a]
            });
        s = s.some(function(a) {
            return !d("relay-runtime").isScalarAndEqual(r[a], b[a])
        });
        s = f || s;
        s && q.current++;
        f && p.current++;
        t && n(b);
        var u = g.readSpec(a, b, e),
            v = i(!0);

        function w() {
            v.current = !0;
            var a = g.checkMissedUpdatesSpec(u);
            a && y()
        }

        function x() {
            v.current = !1
        }

        function y() {
            var a;
            if (m.current === !1 || v.current === !1) return;
            q.current = ((a = q.current) != null ? a : 0) + 1;
            o(function(a) {
                return a + 1
            })
        }
        h(function() {
            m.current = !0;
            var a = g.subscribeSpec(u, y);
            return function() {
                m.current = !1, a.dispose()
            }
        }, [p.current]);
        s = c("mapObject")(u, function(a, b) {
            return a.data
        });
        return {
            data: s,
            disableStoreUpdates: x,
            enableStoreUpdates: w,
            shouldUpdateGeneration: q.current
        }
    }

    function k(a) {
        var b = j(a),
            c = b[0];
        b = b[1];
        c = c !== a;
        c && b(a);
        return c
    }

    function l(a, b) {
        return JSON.stringify(d("relay-runtime").stableCopy(c("mapObject")(a, function(a, c) {
            c = b[c];
            return d("relay-runtime").getFragmentIdentifier(a, c)
        })))
    }
    g["default"] = a
}), 98);
__d("createSuspenseFragmentContainer_DEPRECATED", ["mapObject", "react", "react-relay/assertFragmentMap", "react-relay/relay-hooks/useRelayEnvironment", "relay-runtime", "useFragmentNodes_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo;

    function a(a, b) {
        var e = a.displayName || a.name || "Unknown",
            f = "RelaySuspenseFragmentContainer(" + e + ")";
        c("react-relay/assertFragmentMap")(e, b);
        e = b;
        var g = c("mapObject")(e, d("relay-runtime").getFragment);

        function j(b, d) {
            var e = c("react-relay/relay-hooks/useRelayEnvironment")(),
                j = i(function() {
                    return {
                        environment: e
                    }
                }, [e]),
                k = c("useFragmentNodes_DEPRECATED")(g, b, f),
                l = k.data;
            k = k.shouldUpdateGeneration;
            return i(function() {
                var c;
                return h.jsx(a, babelHelpers["extends"]({}, b, l, {
                    ref: (c = b.componentRef) != null ? c : d,
                    relay: j
                }))
            }, [k, d])
        }
        j.displayName = f;
        b = h.forwardRef(j);
        return b
    }
    g["default"] = a
}), 98);
__d("createSuspensePaginationContainer_DEPRECATED", ["areEqual", "createSuspenseFragmentContainer_DEPRECATED", "forEachObject", "mapObject", "react", "react-relay/relay-hooks/useRelayEnvironment", "relay-runtime", "unrecoverableViolation", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useMemo,
        l = b.useReducer,
        m = b.useRef,
        n = "forward";

    function a(a, b, e) {
        var f = a.displayName || a.name || "Unknown",
            g = c("mapObject")(b, d("relay-runtime").getFragment),
            h = r(g),
            i = d("relay-runtime").getRequest(e.query);
        h = p(a, f, h.direction, s(h), e.getVariables);
        h = c("createSuspenseFragmentContainer_DEPRECATED")(h, b);
        return o(a, f, g, e.getFragmentRefsFromResponse, i, h)
    }

    function o(a, b, e, f, g, k) {
        var n = "RelaySuspensePaginationContainer(" + b + ")";
        a = function(a, b) {
            var o = c("react-relay/relay-hooks/useRelayEnvironment")(),
                p = {};
            c("forEachObject")(e, function(b, c) {
                b = d("relay-runtime").getSelector(b, a[c]);
                b = b != null && b.kind === "PluralReaderSelector" ? (c = (c = b.selectors[0]) == null ? void 0 : c.owner.variables) != null ? c : {} : (c = b == null ? void 0 : b.owner.variables) != null ? c : {};
                p = babelHelpers["extends"]({}, p, b)
            });
            var r = d("relay-runtime").getDataIDsFromObject(e, a),
                s = l(q, {
                    dataIDs: r,
                    mirroredEnvironment: o,
                    mirroredParentVariables: p,
                    refetchFragmentRefs: {},
                    refetchVariables: null
                }),
                t = s[0],
                u = s[1],
                v = m(!1),
                w = m(null),
                x = function() {
                    w.current && (w.current.dispose(), w.current = null)
                };
            j(function() {
                return function() {
                    v.current = !0, x()
                }
            }, []);
            (o !== t.mirroredEnvironment || !c("areEqual")(p, t.mirroredParentVariables) || !c("areEqual")(t.dataIDs, r)) && (x(), u({
                dataIDs: r,
                environment: o,
                parentVariables: p,
                type: "reset"
            }));
            s = i(function(a, b) {
                if (v.current === !0) {
                    c("warning")(!1, "Relay: Unexpected fetch on unmounted component `%s`. It looks like some instances of your container still trying to fetch data but they already unmounted. Please make sure you clear all timers, intervals, async calls, etc that may trigger a fetch.", n);
                    return null
                }
                a = d("relay-runtime").__internal.getOperationVariables(g.operation, g.params.providedVariables, a);
                var e = b && b.force ? {
                        force: !0
                    } : {},
                    h = d("relay-runtime").createOperationDescriptor(g, a, e),
                    i = null,
                    j = o.retain(h),
                    k = {
                        dispose: function() {
                            var a = i;
                            i = null;
                            a && a.unsubscribe();
                            j.dispose()
                        }
                    };
                e = function() {
                    var a = {
                        complete: function() {
                            x(), u({
                                type: "complete"
                            }), b && b.onComplete && b.onComplete(null)
                        },
                        error: function(a) {
                            function b(b) {
                                return a.apply(this, arguments)
                            }
                            b.toString = function() {
                                return a.toString()
                            };
                            return b
                        }(function(a) {
                            x(), u({
                                type: "abort"
                            }), b && b.onComplete && b.onComplete(a)
                        }),
                        next: function() {
                            var a = o.lookup(h.fragment);
                            u({
                                fragmentRefs: f(a.data),
                                type: "next"
                            })
                        },
                        unsubscribe: function() {
                            if (v.current === !0) return;
                            x();
                            u({
                                type: "abort"
                            })
                        }
                    };
                    i = d("relay-runtime").__internal.fetchQuery(o, h).subscribe(a);
                    return k
                };
                x();
                w.current = e();
                u({
                    refetchVariables: a,
                    type: "fetch"
                });
                return k
            }, [o]);
            return h.jsx(k, babelHelpers["extends"]({}, a, t.refetchFragmentRefs, {
                forwardedRef: b,
                isLoading: w.current != null,
                parentVariables: (r = t.refetchVariables) != null ? r : p,
                refetch: s
            }))
        };
        a.displayName = n;
        b = h.forwardRef(a);
        return b
    }

    function p(a, b, e, f, g) {
        return function(j) {
            var l, m = j.forwardedRef,
                o = j.isLoading,
                p = j.parentVariables,
                q = j.refetch;
            j.relay;
            var r = babelHelpers.objectWithoutPropertiesLoose(j, ["forwardedRef", "isLoading", "parentVariables", "refetch", "relay"]),
                s = c("react-relay/relay-hooks/useRelayEnvironment")();
            j = f(r);
            var u = t(b, e, j),
                v = i(function(a, b) {
                    if (u == null || !u.hasMore) {
                        b && b.onComplete && b.onComplete(null);
                        return null
                    }
                    var f = d("relay-runtime").ConnectionInterface.get(),
                        h = f.END_CURSOR;
                    f = f.START_CURSOR;
                    var i = u.cursor;
                    c("warning")(i, "Relay: Cannot `loadMore` without valid `%s` (got `%s`)", e === n ? h : f, i);
                    return q(g(r, {
                        count: a,
                        cursor: i
                    }, p), b)
                }, [u, q, r, p]),
                w = i(function(a, b, c) {
                    return q(g(r, {
                        count: a,
                        cursor: null
                    }, babelHelpers["extends"]({}, p, b || {})), babelHelpers["extends"]({}, c, {
                        force: !0
                    }))
                }, [q, r, p]),
                x = !!(u && u.hasMore && u.cursor);
            j = k(function() {
                return {
                    environment: s,
                    hasMore: x,
                    isLoading: o,
                    loadMore: v,
                    refetchConnection: w
                }
            }, [s, x, o, v, w]);
            return h.jsx(a, babelHelpers["extends"]({}, r, {
                ref: (l = r.componentRef) != null ? l : m,
                relay: j
            }))
        }
    }

    function q(a, b) {
        var c;
        switch (b.type) {
            case "reset":
                c = {
                    dataIDs: b.dataIDs,
                    mirroredEnvironment: b.environment,
                    mirroredParentVariables: b.parentVariables,
                    refetchFragmentRefs: {},
                    refetchVariables: null
                };
                break;
            case "fetch":
                c = babelHelpers["extends"]({}, a, {
                    refetchVariables: b.refetchVariables
                });
                break;
            case "abort":
                c = babelHelpers["extends"]({}, a);
                break;
            case "next":
                c = babelHelpers["extends"]({}, a, {
                    refetchFragmentRefs: b.fragmentRefs
                });
                break;
            case "complete":
            default:
                c = babelHelpers["extends"]({}, a);
                break
        }
        return c
    }

    function r(a) {
        var b = null;
        for (var d in a) {
            var e = a[d];
            e = e && e.metadata && e.metadata.connection;
            if (e != null) {
                if (!Array.isArray(e)) throw c("unrecoverableViolation")("SuspensePaginationContainer: Expected metadata to be array, got " + ("`" + typeof e + "` instead."), "relay");
                if (e.length !== 1) throw c("unrecoverableViolation")("SuspensePaginationContainer: Only a single @connection is " + ("supported, `" + d + "` has " + e.length + "."), "relay");
                if (b) throw c("unrecoverableViolation")("SuspensePaginationContainer: Only a single fragment with @connection is supported.", "relay");
                b = babelHelpers["extends"]({}, e[0], {
                    fragmentName: d
                })
            }
        }
        if (b === null) throw c("unrecoverableViolation")("SuspensePaginationContainer: A @connection directive must be present.", "relay");
        return b
    }

    function s(a) {
        var b = a.path;
        if (!b) throw c("unrecoverableViolation")("SuspensePaginationContainer: Unable to synthesize a getConnectionFromProps function.", "relay");
        return function(c) {
            c = c[a.fragmentName];
            for (var d = 0; d < b.length; d++) {
                if (!c || typeof c !== "object") return null;
                c = c[b[d]]
            }
            return c
        }
    }

    function t(a, b, e) {
        if (e == null) return null;
        var f = d("relay-runtime").ConnectionInterface.get(),
            g = f.EDGES,
            h = f.END_CURSOR,
            i = f.HAS_NEXT_PAGE,
            j = f.HAS_PREV_PAGE,
            k = f.PAGE_INFO;
        f = f.START_CURSOR;
        if (typeof e !== "object") throw c("unrecoverableViolation")("SuspensePaginationContainer: Expected `getConnectionFromProps()` in " + ("`" + a + "` to return `null` or a plain object with ") + (g + " and " + k + " properties, got `" + e + "`."), "relay");
        var l = e[g];
        e = e[k];
        if (l == null || e == null) return null;
        if (!Array.isArray(l)) throw c("unrecoverableViolation")("SuspensePaginationContainer: Expected `getConnectionFromProps()` in " + ("`" + a + "` to return an object with " + g + ": Array, got ") + ("`" + l + "`."), "relay");
        if (typeof e !== "object") throw c("unrecoverableViolation")("SuspensePaginationContainer: Expected `getConnectionFromProps()` in " + ("`" + a + "` to return an object with " + k + ": Object, ") + ("got `" + e + "`."), "relay");
        g = b === n ? e[i] : e[j];
        e = b === n ? e[h] : e[f];
        if (typeof g !== "boolean" || l.length !== 0 && e === void 0) {
            c("warning")(!1, "Relay: Cannot paginate without %s fields in `%s`. Be sure to fetch %s (got `%s`) and %s (got `%s`).", k, a, b === n ? i : j, g, b === n ? h : f, e);
            return null
        }
        return {
            cursor: e,
            edgeCount: l.length,
            hasMore: g
        }
    }
    g["default"] = a
}), 98);
__d("createSuspenseQueryRenderer_DEPRECATED", ["react", "react-relay/ReactRelayContext", "react-relay/relay-hooks/useLazyLoadQueryNode", "react-relay/relay-hooks/useMemoOperationDescriptor", "react-relay/relay-hooks/useRelayEnvironment", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo;

    function a(a) {
        var b = d("relay-runtime").getRequest(a),
            e = "RelaySuspenseQueryRenderer(" + b.params.name + ")";

        function g(b) {
            var f = b.UNSTABLE_renderPolicy,
                g = b.children,
                k = b.fetchKey,
                l = b.fetchPolicy;
            b = b.variables;
            var m = c("react-relay/relay-hooks/useRelayEnvironment")();
            b = c("react-relay/relay-hooks/useMemoOperationDescriptor")(a, b, {
                force: !0
            });
            var n = i(function() {
                    return j(m)
                }, [m]),
                o = c("react-relay/relay-hooks/useLazyLoadQueryNode")({
                    componentDisplayName: e,
                    fetchKey: k,
                    fetchObservable: d("relay-runtime").__internal.fetchQuery(m, b),
                    fetchPolicy: l,
                    query: b,
                    renderPolicy: f
                });
            return h.jsx(c("react-relay/ReactRelayContext").Provider, {
                value: n,
                children: i(function() {
                    return g(o)
                }, [g, o])
            })
        }
        g.displayName = g.name + " [from " + f.id + "]";
        g.displayName = e;
        return g
    }

    function j(a) {
        return {
            environment: a
        }
    }
    g["default"] = a
}), 98);
__d("isRelayFBLocalEnvironment", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a.options != null && a.options.isLocal === !0 ? !0 : !1
    }
    f["default"] = a
}), 66);
__d("react-relay/relay-hooks/useBlockingPaginationFragment", ["invariant", "Promise", "react", "react-relay/relay-hooks/useLoadMoreFunction", "react-relay/relay-hooks/useRefetchableFragmentNode", "react-relay/relay-hooks/useStaticFragmentNodeWarning", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    c = h || b("react");
    var i = c.useCallback,
        j = c.useEffect,
        k = c.useRef,
        l = c.useState,
        m = b("relay-runtime").getFragment,
        n = b("relay-runtime").getFragmentIdentifier,
        o = b("relay-runtime").getPaginationMetadata;

    function a(a, c, d) {
        d === void 0 && (d = "useBlockingPaginationFragment()");
        a = m(a);
        b("react-relay/relay-hooks/useStaticFragmentNodeWarning")(a, "first argument of " + d);
        var e = o(a, d),
            f = e.connectionPathInFragmentData,
            h = e.identifierField,
            j = e.paginationRequest,
            k = e.paginationMetadata;
        e = e.stream;
        e === !1 || g(0, 18372);
        e = b("react-relay/relay-hooks/useRefetchableFragmentNode")(a, c, d);
        c = e.fragmentData;
        var l = e.fragmentRef,
            q = e.refetch,
            r = e.disableStoreUpdates;
        e = e.enableStoreUpdates;
        var s = n(a, l),
            t = p({
                componentDisplayName: d,
                connectionPathInFragmentData: f,
                direction: "backward",
                disableStoreUpdates: r,
                enableStoreUpdates: e,
                fragmentData: c,
                fragmentIdentifier: s,
                fragmentNode: a,
                fragmentRef: l,
                identifierField: h,
                paginationMetadata: k,
                paginationRequest: j
            }),
            u = t[0],
            v = t[1],
            w = t[2];
        t = p({
            componentDisplayName: d,
            connectionPathInFragmentData: f,
            direction: "forward",
            disableStoreUpdates: r,
            enableStoreUpdates: e,
            fragmentData: c,
            fragmentIdentifier: s,
            fragmentNode: a,
            fragmentRef: l,
            identifierField: h,
            paginationMetadata: k,
            paginationRequest: j
        });
        d = t[0];
        f = t[1];
        var x = t[2];
        r = i(function(a, b) {
            x();
            w();
            return q(a, babelHelpers["extends"]({}, b, {
                __environment: void 0
            }))
        }, [x, w, q]);
        return {
            data: c,
            loadNext: d,
            loadPrevious: u,
            hasNext: f,
            hasPrevious: v,
            refetch: r
        }
    }

    function p(a) {
        var c = a.disableStoreUpdates,
            d = a.enableStoreUpdates;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["disableStoreUpdates", "enableStoreUpdates"]);
        var e = l(null),
            f = e[0],
            g = e[1],
            h = k(null),
            i = k(null),
            m = function() {
                i.current != null && (i.current(), i.current = null)
            };
        e = function() {
            m()
        };
        var n = {
            complete: m,
            start: function() {
                c();
                var a = new(b("Promise"))(function(a) {
                    i.current = function() {
                        h.current = null, a()
                    }
                });
                h.current = a;
                g(a)
            },
            next: m,
            error: m
        };
        a = b("react-relay/relay-hooks/useLoadMoreFunction")(babelHelpers["extends"]({}, a, {
            observer: n,
            onReset: e
        }));
        n = a[0];
        e = a[1];
        a = a[2];
        if (f != null && f === h.current) throw f;
        j(function() {
            f !== h.current && d()
        }, [f]);
        return [n, e, a]
    }
    e.exports = a
}), null);
__d("react-relay/relay-hooks/useIsParentQueryActive", ["react-relay/relay-hooks/useIsOperationNodeActive", "react-relay/relay-hooks/useStaticFragmentNodeWarning", "relay-runtime"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("relay-runtime").getFragment;

    function a(a, c) {
        a = g(a);
        b("react-relay/relay-hooks/useStaticFragmentNodeWarning")(a, "first argument of useIsParentQueryActive()");
        return b("react-relay/relay-hooks/useIsOperationNodeActive")(a, c)
    }
    e.exports = a
}), null);
__d("CometRelay", ["CometRelayQueryProfiler", "RelayFBCometMutations", "RelayFBEnvironmentActorID", "RelayFBMatchContainer", "RelayFBModuleResource", "RelayFBSubscription", "RelayFlight.hybrid", "configureRelayForWWW", "createSuspenseFragmentContainer_DEPRECATED", "createSuspensePaginationContainer_DEPRECATED", "createSuspenseQueryRenderer_DEPRECATED", "enqueueMutation", "isRelayFBLocalEnvironment", "react", "react-relay/relay-hooks/EntryPointContainer.react", "react-relay/relay-hooks/ProfilerContext", "react-relay/relay-hooks/RelayEnvironmentProvider", "react-relay/relay-hooks/loadEntryPoint", "react-relay/relay-hooks/loadQuery", "react-relay/relay-hooks/useBlockingPaginationFragment", "react-relay/relay-hooks/useEntryPointLoader", "react-relay/relay-hooks/useFragment", "react-relay/relay-hooks/useIsParentQueryActive", "react-relay/relay-hooks/useLazyLoadQuery", "react-relay/relay-hooks/usePaginationFragment", "react-relay/relay-hooks/usePreloadedQuery", "react-relay/relay-hooks/useQueryLoader", "react-relay/relay-hooks/useRefetchableFragment", "react-relay/relay-hooks/useRelayEnvironment", "react-relay/relay-hooks/useSubscribeToInvalidationState", "relay-runtime", "useFBMutation__TEMPORARY", "useFBSubscription"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    a = c("RelayFBSubscription").addFBisms(d("relay-runtime").requestSubscription);
    c("configureRelayForWWW")();
    d("RelayFlight.hybrid").isServer_INTERNAL_DO_NOT_USE() || d("CometRelayQueryProfiler").install();
    f.exports = {
        ConnectionHandler: d("relay-runtime").ConnectionHandler,
        EntryPointContainer: c("react-relay/relay-hooks/EntryPointContainer.react"),
        MatchContainer: c("RelayFBMatchContainer"),
        ModuleResource: {
            getModuleId: d("RelayFBModuleResource").getModuleId,
            read: d("RelayFBModuleResource").read,
            readAll: d("RelayFBModuleResource").readAll
        },
        MutationTypes: d("relay-runtime").MutationTypes,
        ProfilerContext: c("react-relay/relay-hooks/ProfilerContext"),
        RangeOperations: d("relay-runtime").RangeOperations,
        RelayEnvironmentProvider: c("react-relay/relay-hooks/RelayEnvironmentProvider"),
        RelayFeatureFlags: d("relay-runtime").RelayFeatureFlags,
        VIEWER_ID: d("relay-runtime").VIEWER_ID,
        applyOptimisticMutation: d("relay-runtime").applyOptimisticMutation,
        commitLocalUpdate: d("relay-runtime").commitLocalUpdate,
        commitMutation: d("RelayFBCometMutations").addFBisms(d("relay-runtime").commitMutation),
        commitMutation__TEMPORARY: d("RelayFBCometMutations").addFBisms(d("relay-runtime").commitMutation),
        createPayloadFor3DField: d("relay-runtime").createPayloadFor3DField,
        createSuspenseFragmentContainer_DEPRECATED: c("createSuspenseFragmentContainer_DEPRECATED"),
        createSuspensePaginationContainer_DEPRECATED: c("createSuspensePaginationContainer_DEPRECATED"),
        createSuspenseQueryRenderer_DEPRECATED: c("createSuspenseQueryRenderer_DEPRECATED"),
        enqueueMutation: d("RelayFBCometMutations").addFBisms(d("enqueueMutation").enqueueMutation),
        fetchQuery: d("relay-runtime").fetchQuery,
        generateUniqueClientID: d("relay-runtime").generateUniqueClientID,
        getActorID: d("RelayFBEnvironmentActorID").getActorID,
        graphql: d("relay-runtime").graphql,
        isLocalEnvironment: c("isRelayFBLocalEnvironment"),
        loadEntryPoint: c("react-relay/relay-hooks/loadEntryPoint"),
        loadQuery: d("react-relay/relay-hooks/loadQuery").loadQuery,
        readInlineData: d("relay-runtime").readInlineData,
        requestSubscription: a,
        useBlockingPaginationFragment: c("react-relay/relay-hooks/useBlockingPaginationFragment"),
        useEntryPointLoader: c("react-relay/relay-hooks/useEntryPointLoader"),
        useFragment: c("react-relay/relay-hooks/useFragment"),
        useIsParentQueryActive: c("react-relay/relay-hooks/useIsParentQueryActive"),
        useLazyLoadQuery: c("react-relay/relay-hooks/useLazyLoadQuery"),
        useMutation: c("useFBMutation__TEMPORARY"),
        useMutation__TEMPORARY: c("useFBMutation__TEMPORARY"),
        usePaginationFragment: c("react-relay/relay-hooks/usePaginationFragment"),
        usePreloadedQuery: c("react-relay/relay-hooks/usePreloadedQuery"),
        useQueryLoader: c("react-relay/relay-hooks/useQueryLoader"),
        useRefetchableFragment: c("react-relay/relay-hooks/useRefetchableFragment"),
        useRelayEnvironment: function() {
            return c("react-relay/relay-hooks/useRelayEnvironment")()
        },
        useSubscribeToInvalidationState: c("react-relay/relay-hooks/useSubscribeToInvalidationState"),
        useSubscription: c("useFBSubscription")
    }
}), 34);
__d("CometMissingFieldHandlers", ["UFI2CommentsConnectionHandler", "getRelayFBMissingFieldHandlers", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = [].concat(c("getRelayFBMissingFieldHandlers")(), [{
        handle: function(a, b, c, e) {
            if (b != null && b.getType() === d("relay-runtime").ROOT_TYPE && a.name === "user" && Object.prototype.hasOwnProperty.call(c, "id")) return c.id;
            if (b != null && b.getType() === d("relay-runtime").ROOT_TYPE && a.name === "story" && Object.prototype.hasOwnProperty.call(c, "story_id")) return c.story_id;
            if (b != null && b.getType() === "Story" && a.name === "comet_sections") {
                var f = b.getLinkedRecord(a.name, {
                    renderLocation: "homepage_stream"
                });
                if (f != null) return f.getDataID()
            }
            f = b == null ? void 0 : b.getValue("id");
            if (b != null && typeof f === "string" && b.getType() === "Feedback" && a.name.startsWith("__UFI2CommentsProvider_feedback_display_comments_ufi2_comments")) {
                var g = e.get(f);
                if (!g) return void 0;
                g = d("UFI2CommentsConnectionHandler").getConnection(g, "UFI2CommentsProvider_feedback_display_comments", {
                    feedback_source: 1
                });
                return !g ? void 0 : g.getDataID()
            }
            if (b != null && typeof f === "string" && b.getType() === "Feedback" && a.name === "display_comments") {
                g = e.get(f);
                if (!g) return void 0;
                e = g.getLinkedRecord("display_comments", c);
                if (e) return e.getDataID();
                e = g.getLinkedRecord("display_comments");
                if (e) return e.getDataID();
                Object.prototype.hasOwnProperty.call(c, "is_initial_fetch") && (e = g.getLinkedRecord("display_comments", babelHelpers["extends"]({}, c, {
                    is_initial_fetch: !c.is_initial_fetch
                })));
                return e ? e.getDataID() : void 0
            }
            return b != null && a.name === "video" && Object.prototype.hasOwnProperty.call(c, "id") ? c.id : void 0
        },
        kind: "linked"
    }]);
    b = a;
    g["default"] = b
}), 98);
__d("ReactFlightDOMRelayClient", ["cr:1342471"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:1342471")
}), 98);
__d("RelayFBFlightPayloadDeserializer", ["ReactFlightDOMRelayClient"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = a;
        var b = c("ReactFlightDOMRelayClient").createResponse();
        for (var d = 0; d < a.length; d++) {
            var e = a[d];
            c("ReactFlightDOMRelayClient").resolveRow(b, e)
        }
        c("ReactFlightDOMRelayClient").close(b);
        return b
    }
    b = a;
    g["default"] = b
}), 98);
__d("RelayFBFlightServerErrorHandler", ["FBLogger", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        switch (a) {
            case "FAIL_JS_ERROR":
                c("FBLogger")("react-flight").addMetadata("REACT_FLIGHT", "ERROR_MESSAGE", b[0].message).addMetadata("REACT_FLIGHT", "ERROR_STACK", b[0].message + "\n" + b[0].stack).warn('RelayFBFlightServerErrorHandler: HaaS threw a JSRuntimeException "%s". Please see Component Stack for more details.\n%s', b[0].message, b[0].message + "\n" + b[0].stack);
                c("warning")(!1, 'RelayFBFlightServerErrorHandler: HaaS threw a JSRuntimeException "%s". Please see Component Stack for more details.\n%s', b[0].message, b[0].message + "\n" + b[0].stack);
                break;
            case "FAIL_RELAY_FLIGHT_RENDERER_CONTINUATION_ERROR":
            case "FAIL_RELAY_FLIGHT_RENDERER_ERROR":
                c("FBLogger")("react-flight").addMetadata("REACT_FLIGHT", "ERROR_MESSAGE", b[0].message).addMetadata("REACT_FLIGHT", "ERROR_STACK", b[0].stack).warn("RelayFBFlightServerErrorHandler: %s.\nPlease see Component Stack for more details.\n%s", b[0].message, b[0].stack);
                c("warning")(!1, "RelayFBFlightServerErrorHandler: %s\nPlease see Component Stack for more details.\n%s", b[0].message, b[0].stack);
                break;
            default:
                c("FBLogger")("react-flight").addMetadata("REACT_FLIGHT", "ERROR_MESSAGE", b[0].message).addMetadata("REACT_FLIGHT", "ERROR_STACK", b[0].stack).warn("RelayFBFlightServerErrorHandler: %s.\n%s", b[0].message, b[0].stack), c("warning")(!1, "RelayFBFlightServerErrorHandler: %s\n%s", b[0].message, b[0].stack)
        }
    }
    b = a;
    g["default"] = b
}), 98);
__d("PinnedCommentEventsConnectionHandler", ["expectationViolation", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        a = a.get(b.dataID);
        if (!a) return;
        var c = a.getLinkedRecords(b.fieldKey);
        if (!c) {
            a.setValue(null, b.handleKey);
            return
        }
        var d = a.getLinkedRecords(b.handleKey);
        if (!d) {
            a.setLinkedRecords(c, b.handleKey);
            return
        }
        var e;
        d == null ? e = c : c == null ? e = d : e = h(d, c);
        a.setLinkedRecords((d = e) != null ? d : [], b.handleKey)
    }

    function h(a, b) {
        var d = 0,
            e = 0,
            f = new Set(),
            g = [],
            h = function(a) {
                var b = a == null ? void 0 : a.getValue("id");
                if (b == null) {
                    c("expectationViolation")("Pinned Comment Event should have id");
                    return
                }
                if (f.has(b)) return;
                f.add(b);
                g.push(a)
            };
        while (d < a.length && e < b.length) {
            var i, j;
            i = (i = a[d]) == null ? void 0 : i.getValue("vod_time_offset");
            j = (j = b[e]) == null ? void 0 : j.getValue("vod_time_offset");
            if (typeof i != "number") {
                d++;
                continue
            }
            if (typeof j != "number") {
                e++;
                continue
            }
            if (i > j) {
                h(a[d]);
                d++;
                continue
            }
            if (i < j) {
                h(b[e]);
                e++;
                continue
            }
            h(a[d]);
            h(b[e]);
            d++;
            e++
        }
        for (i = d; i < a.length; i++) h(a[i]);
        for (j = e; j < b.length; j++) h(b[j]);
        return g
    }

    function i(a) {
        return d("relay-runtime").getRelayHandleKey("pinned_comment_events", a, null)
    }

    function j(a, b, c) {
        return (a = a.getLinkedRecords(i(b), c)) != null ? a : []
    }

    function b(a, b, c, d) {
        a.setLinkedRecords(j(a, b, d).filter(function(a) {
            return (a == null ? void 0 : a.getValue("id")) !== c
        }), i(b));
        return
    }
    g.update = a;
    g.getEvents = j;
    g.deleteEvent = b
}), 98);
__d("mergeCommentEdgesSortedByTimestampInVideo", ["expectationViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a) {
        a = a == null ? void 0 : (a = a.getLinkedRecord("node")) == null ? void 0 : a.getValue("timestamp_in_video");
        return typeof a !== "number" ? null : a
    };

    function a(a, b) {
        var d = 0,
            e = 0,
            f = new Set(),
            g = [],
            i = function(a) {
                var b;
                b = a == null ? void 0 : (b = a.getLinkedRecord("node")) == null ? void 0 : b.getValue("id");
                if (b == null) {
                    c("expectationViolation")("Node should have id");
                    return
                }
                if (f.has(b)) return;
                f.add(b);
                g.push(a)
            };
        while (d < a.length && e < b.length) {
            var j = h(a[d]),
                k = h(b[e]);
            if (j == null) {
                d++;
                continue
            }
            if (k == null) {
                e++;
                continue
            }
            if (j < k) {
                i(a[d]);
                d++;
                continue
            }
            if (j > k) {
                i(b[e]);
                e++;
                continue
            }
            i(a[d]);
            i(b[e]);
            d++;
            e++
        }
        for (j = d; j < a.length; j++) i(a[j]);
        for (k = e; k < b.length; k++) i(b[k]);
        return g
    }
    g["default"] = a
}), 98);
__d("VideoTimestampedCommentsConnectionHandler", ["mergeCommentEdgesSortedByTimestampInVideo", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var e = a.get(b.dataID);
        if (!e) return;
        var f = e.getLinkedRecord(b.fieldKey);
        if (!f) {
            e.setValue(null, b.handleKey);
            return
        }
        var g = e.getLinkedRecord(b.handleKey);
        if (!g) {
            a = a.create(d("relay-runtime").generateClientID(e.getDataID(), b.handleKey), f.getType());
            a.copyFieldsFrom(f);
            e.setLinkedRecord(a, b.handleKey);
            return
        }
        e = f.getLinkedRecords("edges");
        a = g.getLinkedRecords("edges");
        a == null ? b = e : e == null ? b = a : b = c("mergeCommentEdgesSortedByTimestampInVideo")(a, e);
        g.setLinkedRecords((f = b) != null ? f : [], "edges")
    }

    function b(a, b, c) {
        b = d("relay-runtime").getRelayHandleKey("video_timestamped_comments", b, null);
        return a.getLinkedRecord(b, c)
    }

    function e(a, b) {
        var d = a.getLinkedRecords("edges");
        if (!d) {
            a.setLinkedRecords([b], "edges");
            return
        }
        d = c("mergeCommentEdgesSortedByTimestampInVideo")(d, [b]);
        a.setLinkedRecords((b = d) != null ? b : [], "edges");
        return
    }
    g.update = a;
    g.getConnection = b;
    g.insertEdge = e
}), 98);
__d("cometHandlerProvider", ["BizKitNotificationsThinClientConnectionHandler", "CometNewsFeedConnectionHandler", "CometNotificationsThinClientConnectionHandler", "PinnedCommentEventsConnectionHandler", "UFI2CommentsConnectionHandler", "VideoTimestampedCommentsConnectionHandler", "relay-runtime", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        switch (a) {
            case "connection":
                return d("relay-runtime").ConnectionHandler;
            case "video_timestamped_comments":
                return d("VideoTimestampedCommentsConnectionHandler");
            case "pinned_comment_events":
                return d("PinnedCommentEventsConnectionHandler");
            case "ufi2_comments":
                return d("UFI2CommentsConnectionHandler");
            case "comet_news_feed":
                return d("CometNewsFeedConnectionHandler");
            case "comet_notifications_thin_client":
                return d("CometNotificationsThinClientConnectionHandler");
            case "bizkit_notifications_thin_client":
                return d("BizKitNotificationsThinClientConnectionHandler");
            case "deleteRecord":
                return d("relay-runtime").MutationHandlers.DeleteRecordHandler;
            case "appendEdge":
                return d("relay-runtime").MutationHandlers.AppendEdgeHandler;
            case "prependEdge":
                return d("relay-runtime").MutationHandlers.PrependEdgeHandler;
            case "deleteEdge":
                return d("relay-runtime").MutationHandlers.DeleteEdgeHandler;
            case "appendNode":
                return d("relay-runtime").MutationHandlers.AppendNodeHandler;
            case "prependNode":
                return d("relay-runtime").MutationHandlers.PrependNodeHandler
        }
        throw c("unrecoverableViolation")("RelayCometEnvironment: No handler defined for `" + a + "`.", "comet_ui")
    }
    g["default"] = a
}), 98);
__d("CometRelayPerfStoreCommon", ["performanceNow", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 5 * 6e4,
        i = {},
        j = {},
        k = {};

    function a(a) {
        if (a.name === "network.start") {
            var b = {
                flushes: [],
                hasteResponseLogEvents: [],
                name: a.params.name,
                start: c("performanceNow")()
            };
            j[a.networkRequestId] = b;
            i[a.params.name] = b;
            c("setTimeout")(function() {
                delete j[a.networkRequestId], b && delete i[b.name]
            }, h)
        } else if (a.name === "network.next") {
            var d = j[a.networkRequestId];
            if (d) {
                var e = a.response,
                    f = function(a) {
                        d.flushes.push({
                            label: (a = a.label) != null ? a : "root",
                            time: c("performanceNow")()
                        })
                    };
                e instanceof Array ? e.forEach(f) : f(e)
            }
        } else if (a.name === "network.complete") {
            f = j[a.networkRequestId];
            f && (f.end = c("performanceNow")())
        } else if (a.name === "queryresource.fetch") {
            if (a.operation.root.node.name != null) {
                e = a.operation.root.node.name;
                f = i[e];
                f != null && (k[a.resourceID] = f, c("setTimeout")(function() {
                    delete k[a.resourceID]
                }, h))
            }
        } else if (a.name === "queryresource.retain") {
            e = k[a.resourceID];
            if (e != null) {
                f = a.profilerContext;
                f && f.retainQuery && f.retainQuery(e)
            }
        } else if (a.name === "network.info") {
            f = a.info;
            if (f != null && typeof f === "object" && Object.prototype.hasOwnProperty.call(f, "prefetched")) {
                e = j[a.networkRequestId];
                e && (e.start = 0)
            }
            if (f != null && typeof f === "object" && "srPayloadStats" in f && f.srPayloadStats != null && typeof f.srPayloadStats === "object") {
                e = j[a.networkRequestId];
                e && e.hasteResponseLogEvents.push(f.srPayloadStats)
            }
        } else if (a.name === "entrypoint.root.consume") {
            e = a.profilerContext;
            e && typeof e.consumeBootload === "function" && e.consumeBootload(a.rootModuleID)
        }
    }
    g.log = a
}), 98);
__d("CometRelayPerfStore", ["CometRelayPerfStoreCommon", "ExecutionEnvironment"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (!c("ExecutionEnvironment").canUseDOM) return;
        d("CometRelayPerfStoreCommon").log(a)
    }
    g.log = a
}), 98);
__d("MosUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        if (a === 0 || b === 0) return 0;
        if (a < b) {
            var c = a;
            a = b;
            b = c
        }
        c = a / b;
        return c > 16 / 9 ? Math.round(a / (16 / 9)) : b
    }

    function b(a, b) {
        var c = null,
            d = null,
            e = null,
            f = null;
        for (var g = 0; g < a.length; g++) {
            var h = a[g].qualityLabel;
            if (h <= b) e = a[g].mosValue, c = h;
            else {
                f = a[g].mosValue;
                d = h;
                break
            }
        }
        if (c === null && d === null) return 0;
        else if (c === null && f !== null) return f;
        else if (d === null && e !== null) return e;
        else if (f !== null && e !== null && c !== null && d !== null) {
            h = e + (b - c) * (f - e) / (d - c);
            return h < 0 ? 0 : h > 100 ? 100 : h
        }
        return 0
    }

    function c(a) {
        a = a.split(",");
        var b = [];
        for (var c = 0; c < a.length; c++) {
            var d = a[c].split(":");
            if (d.length !== 2) return null;
            var e = Number(d[0]);
            d = Number(d[1]);
            if (isNaN(e) || isNaN(d)) return null;
            b.push({
                qualityLabel: e,
                mosValue: d
            })
        }
        return b
    }
    f.getQualityLabel = a;
    f.getMosValue = b;
    f.parsePlaybackMos = c
}), 66);
__d("oz-player/networks/OzBandwidthUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = .3,
        h = 3,
        i = 50,
        j = 10,
        k = 5,
        l = new Map([
            ["51", .03],
            ["52", .06],
            ["53", .08],
            ["54", .1],
            ["55", .13],
            ["56", .16],
            ["57", .18],
            ["58", .2],
            ["59", .23],
            ["60", .26],
            ["61", .28],
            ["62", .31],
            ["63", .33],
            ["64", .36],
            ["65", .39],
            ["66", .42],
            ["67", .44],
            ["68", .47],
            ["69", .5],
            ["70", .53],
            ["71", .56],
            ["72", .59],
            ["73", .62],
            ["74", .65],
            ["75", .68],
            ["76", .71],
            ["77", .74],
            ["78", .78],
            ["79", .81],
            ["80", .85],
            ["81", .88],
            ["82", .92],
            ["83", .96],
            ["84", 1],
            ["85", 1.04],
            ["86", 1.08],
            ["87", 1.13],
            ["88", 1.18],
            ["89", 1.23],
            ["90", 1.28],
            ["91", 1.34],
            ["92", 1.41],
            ["93", 1.48],
            ["94", 1.56],
            ["95", 1.65],
            ["96", 1.76],
            ["97", 1.89],
            ["98", 2.06],
            ["99", 2.33]
        ]);

    function a(a, b, c, d) {
        if (a.length === 0) return null;
        var e = n(a);
        a = q(a, b);
        b = a.average;
        a = a.totalWeight;
        var f = j,
            g = k,
            h = i;
        if (c.length > 0) {
            f = o(c.map(function(a) {
                return a.timeToFirstByteMs
            }));
            c = p(c.map(function(a) {
                return {
                    value: a.timeToFirstByteMs,
                    weight: 1
                }
            }), d);
            h = c.average;
            g = c.totalWeight
        }
        return {
            bandwidthEstimate: b,
            bandwidthStandardDeviation: e,
            bandwidthTotalWeight: a,
            timeToFirstByteMsEstimate: h,
            timeToFirstByteMsStandardDeviation: f,
            timeToFirstByteMsTotalWeight: g
        }
    }

    function m(a) {
        var b = 0;
        for (var c = 0; c < a.length; c++) b += a[c].bytes * 8e3 / a[c].timeInMs;
        return b / a.length
    }

    function n(a) {
        return o(a.map(function(a) {
            return a.bytes * 8e3 / a.timeInMs
        }))
    }

    function o(a) {
        var b = a.reduce(function(a, b) {
                return a + b
            }, 0) / a.length,
            c = 0;
        for (var d = 0; d < a.length; d++) c += Math.pow(a[d] - b, 2);
        return Math.round(Math.sqrt(c / a.length))
    }

    function p(a, b) {
        b = Math.exp(Math.log(.5) / b);
        var c = 0,
            d = 0;
        for (var e = 0; e < a.length; e++) {
            var f = Math.pow(b, a[e].weight);
            c = a[e].value * (1 - f) + c * f;
            d += a[e].weight
        }
        f = Math.round(c / (1 - Math.pow(b, d)));
        return {
            average: f,
            totalWeight: d
        }
    }

    function q(a, b) {
        return p(a.map(function(a) {
            return {
                value: a.bytes * 8e3 / a.timeInMs,
                weight: a.timeInMs / 1e3
            }
        }), b)
    }

    function r(a, b) {
        var c = m(a),
            d = [];
        for (var e = 0; e < a.length; e++) Math.abs(c - a[e].bytes * 8e3 / a[e].timeInMs) < b && d.push(a[e]);
        return d
    }

    function b(a, b, c, d) {
        var e = n(a);
        a = r(a, e * c);
        c = q(a, b);
        return c.average - e * d
    }

    function c(a, b, c) {
        c = l.get(String(c));
        var d = a.bandwidthEstimate,
            e = a.bandwidthStandardDeviation,
            f = a.timeToFirstByteMsStandardDeviation;
        a = a.timeToFirstByteMsEstimate;
        var i = 1,
            j = 1;
        c != null && (i = 1 - c * e / d, i = isNaN(i) ? 1 : Math.max(i, g), j = 1 + c * f / a, j = isNaN(j) ? 1 : j, j = Math.min(j, h));
        return 8e3 * b / (d * i) + a * j
    }
    f.getBandwidthDiagnostics = a;
    f.getMeanBandwidth = m;
    f.getStandardDeviationOfBandwidth = n;
    f.getExponentiallyWeightedMovingAverage = p;
    f.getExponentiallyWeightedMovingAverageOfBandwidth = q;
    f.getBandwidthSamplesWithinRangeOfMean = r;
    f.getBandwidthEstimate = b;
    f.getEstimatedRequestTimeToLastByteMs = c
}), 66);
__d("OzSystemicRiskUtils", ["oz-player/networks/OzBandwidthUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 50;

    function i(a, b, c) {
        a = d("oz-player/networks/OzBandwidthUtils").getEstimatedRequestTimeToLastByteMs(a, b, c);
        return b / a * 8e3
    }

    function a(a, b, c, d) {
        a = a * b;
        b = a * c / 8e3;
        c = i(d, b, h);
        return a < c
    }

    function j(a, b, c, d) {
        if (a > 0) return c <= a;
        return d != null && d > 0 ? d <= b : !1
    }

    function b(a) {
        var b = a.bandwidthDiagnostics,
            c = a.bitrate,
            d = a.bufferAhead,
            e = a.config,
            f = a.hasMadeInitialDecision,
            g = a.initialRiskFactor,
            k = a.lowMosResolution,
            l = a.minWatchableMos,
            m = a.previousMos,
            n = a.previousResolution,
            o = a.remainingVideoDurationMs;
        a = a.segmentFetchRangeDurationMs;
        c = c * a / 8e3;
        a = i(b, c, e.getNumber("systemic_risk_abr_high_estimate_confidence", 52));
        b = i(b, c, h);
        c = j(k, l, n, m);
        k = 1;
        c || (k = b / a);
        l = 1;
        b = e.getNumber("systemic_risk_abr_document_hidden_risk_factor", 0);
        b > 0 && document.hidden ? l = b : !f && !c && (l = g);
        a = l * (c ? e.getNumber("systemic_risk_abr_low_mos_risk_factor", 1.3) : e.getNumber("systemic_risk_abr_risk_factor", 1.75));
        b = (o - d * 1e3) / o;
        f = a * k;
        g = f * b;
        l = Math.max(g, 1);
        return {
            bandwidth: k,
            buffer: b,
            encoding: a,
            lowMos: c,
            multiplier: l,
            previousMos: m,
            previousResolution: n
        }
    }
    g.getBandwidthEstimateForRequest = i;
    g.isEffectiveBitrateBelowBandwidthEstimate = a;
    g.getRiskFactorsForRepresentation = b
}), 98);
__d("oz-player/configs/MockOzConfig", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a(a) {
            a === void 0 && (a = {}), this.$1 = a
        }
        var b = a.prototype;
        b.getBool = function(a, b) {
            return typeof this.$1[a] === "boolean" ? this.$1[a] : b
        };
        b.getNumber = function(a, b) {
            return typeof this.$1[a] === "number" ? this.$1[a] : b
        };
        b.getString = function(a, b) {
            return typeof this.$1[a] === "string" ? this.$1[a] : b
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("oz-player/shims/www/getOzGlobalConfigSourceWWW", ["oz-player/configs/MockOzConfig", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        allow_subsequent_prefetch: (b = c("qex")._("2085")) != null ? b : !0,
        bandwidth_header_expire_threshold: (d = c("qex")._("234")) != null ? d : 0,
        clear_prefetch_on_unload: (e = c("qex")._("2086")) != null ? e : !1,
        systemic_risk_abr_prefetch_initial_risk_factor: (f = c("qex")._("2087")) != null ? f : 3,
        prefetch_retention_duration_ms: (b = c("qex")._("2088")) != null ? b : 0,
        prefetch_resolution_threshold: (d = c("qex")._("2089")) != null ? d : 1e3,
        systemic_risk_abr_prefetch_low_mos_resolution: (e = c("qex")._("2090")) != null ? e : 260,
        systemic_risk_abr_min_watchable_mos: (f = c("qex")._("2091")) != null ? f : 0,
        systemic_risk_abr_parse_prefetch_mos: (b = c("qex")._("2092")) != null ? b : !1
    };

    function a() {
        return new(c("oz-player/configs/MockOzConfig"))(h)
    }
    g["default"] = a
}), 98);
__d("oz-player/shims/getOzGlobalConfigSource", ["oz-player/shims/www/getOzGlobalConfigSourceWWW"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("oz-player/shims/www/getOzGlobalConfigSourceWWW")
}), 98);
__d("oz-player/configs/OzGlobalConfig", ["oz-player/shims/getOzGlobalConfigSource"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("oz-player/shims/getOzGlobalConfigSource")();
    a = {
        getBool: function(a, b) {
            return h ? h.getBool(a, b) : b
        },
        getNumber: function(a, b) {
            return h ? h.getNumber(a, b) : b
        },
        getString: function(a, b) {
            return h ? h.getString(a, b) : b
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("oz-player/shims/www/OzCacheStorageWWW", ["WebStorage"], (function(a, b, c, d, e, f, g) {
    var h = "_oz_",
        i = "_@_",
        j = c("WebStorage").getLocalStorage();
    a = {
        get: function(a) {
            if (j == null) return null;
            a = j.getItem(h + a);
            typeof a === "string" && a.startsWith(i) && (a = a.substring(i.length));
            return a
        },
        set: function(a, b) {
            j != null && j.setItem(h + a, b)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("oz-player/shims/OzCacheStorage", ["oz-player/shims/www/OzCacheStorageWWW"], (function(a, b, c, d, e, f, g) {
    g["default"] = c("oz-player/shims/www/OzCacheStorageWWW")
}), 98);
__d("oz-player/shims/www/OzWindowEventsWWW", ["cr:925100"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        onUnload: function(a) {
            b("cr:925100").onUnload(a)
        }
    };
    c = a;
    g["default"] = c
}), 98);
__d("oz-player/shims/OzWindowEvents", ["oz-player/shims/www/OzWindowEventsWWW"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("oz-player/shims/www/OzWindowEventsWWW")
}), 98);
__d("oz-player/networks/OzBandwidthCache", ["oz-player/configs/OzGlobalConfig", "oz-player/shims/OzCacheStorage", "oz-player/shims/OzWindowEvents"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a, b, d, e) {
            var f = this;
            this.$1 = a;
            this.$2 = b;
            this.$3 = d;
            this.$4 = e;
            c("oz-player/shims/OzWindowEvents").onUnload(function() {
                f.updateCache()
            })
        }
        var b = a.prototype;
        b.getCachedBandwidth = function() {
            var a = c("oz-player/shims/OzCacheStorage").get(this.$1);
            if (a == null) return null;
            a = Number(a);
            return isNaN(a) ? null : a
        };
        b.getCachedSamples = function() {
            if (this.$5 != null) return this.$5;
            var b = c("oz-player/shims/OzCacheStorage").get(this.$2);
            if (b == null) return null;
            this.$5 = a.deserialize(b);
            return this.$5
        };
        b.updateCache = function() {
            c("oz-player/shims/OzCacheStorage").set(this.$1, String(this.$3()));
            var b = c("oz-player/configs/OzGlobalConfig").getNumber("bandwidth_ttfb_samples_to_save", 5);
            if (b > 0) {
                var d = this.$4(),
                    e = d.bandwidth.length,
                    f = d.navigationTiming.length;
                e = {
                    bandwidth: d.bandwidth.slice(Math.max(0, e - b), e),
                    navigationTiming: d.navigationTiming.slice(Math.max(0, f - b), f)
                };
                c("oz-player/shims/OzCacheStorage").set(this.$2, a.serialize(e))
            }
        };
        a.deserialize = function(a) {
            var b = {};
            try {
                b = JSON.parse(a)
            } catch (a) {}
            return typeof b === "object" && Array.isArray(b.b) && Array.isArray(b.t) ? {
                bandwidth: b.b.reduce(function(a, b) {
                    typeof b.b === "number" && typeof b.t === "number" && typeof b.s === "number" && a.push({
                        bytes: b.b,
                        timeInMs: b.t,
                        timestamp: b.s
                    });
                    return a
                }, []),
                navigationTiming: b.t.reduce(function(a, b) {
                    typeof b.t === "number" && typeof b.s === "number" && (typeof b.l === "number" && typeof b.b === "number" ? a.push({
                        timeToFirstByteMs: b.t,
                        timeToLastByteMs: b.l,
                        bytes: b.b,
                        timestamp: b.s
                    }) : a.push({
                        timeToFirstByteMs: b.t,
                        timeToLastByteMs: 0,
                        bytes: 0,
                        timestamp: b.s
                    }));
                    return a
                }, [])
            } : null
        };
        a.serialize = function(a) {
            a = {
                b: a.bandwidth.map(function(a) {
                    return {
                        b: a.bytes,
                        s: a.timestamp,
                        t: a.timeInMs
                    }
                }),
                t: a.navigationTiming.map(function(a) {
                    return {
                        s: a.timestamp,
                        t: a.timeToFirstByteMs,
                        l: a.timeToLastByteMs,
                        b: a.bytes
                    }
                })
            };
            return JSON.stringify(a)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("oz-player/networks/OzNetworkSamples", ["oz-player/configs/OzGlobalConfig"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = !1, this.$2 = [], this.$3 = [], this.$4 = null, this.$5 = null, this.$6 = null
        }
        var b = a.prototype;
        b.setBandwidthCache = function(a) {
            this.$4 = a
        };
        b.getRecentBandwidthSamples = function() {
            return this.$7().recentBandwidthSamples
        };
        b.getRecentNavigationTimingSamples = function() {
            return this.$7().recentNavigationTimingSamples
        };
        b.setBandwidthEstimateFromHeaders = function(a) {
            this.$5 = a, this.$6 = Date.now()
        };
        b.getBandwidthEstimateFromHeaders = function() {
            var a = c("oz-player/configs/OzGlobalConfig").getNumber("bandwidth_header_expire_threshold", 0),
                b = this.$6;
            return a > 0 && b != null && Date.now() - b > a ? null : this.$5
        };
        b.$7 = function() {
            if (!this.$1 && this.$4 != null && c("oz-player/configs/OzGlobalConfig").getNumber("bandwidth_ttfb_samples_to_save", 5) > 0) {
                this.$1 = !0;
                var a = this.$4.getCachedSamples();
                a != null && (this.$2 = a.bandwidth, this.$3 = a.navigationTiming)
            }
            return {
                recentBandwidthSamples: this.$2,
                recentNavigationTimingSamples: this.$3
            }
        };
        b.addBandwidthSample = function(a) {
            this.$2.push(babelHelpers["extends"]({}, a, {
                timestamp: Date.now()
            })), this.$2.length > c("oz-player/configs/OzGlobalConfig").getNumber("max_bandwidth_sample_count", 30) && this.$2.shift()
        };
        b.addNavigationTimingSample = function(a) {
            this.$3.push(babelHelpers["extends"]({}, a, {
                timestamp: Date.now()
            })), this.$3.length > c("oz-player/configs/OzGlobalConfig").getNumber("max_bandwidth_sample_count", 30) && this.$3.shift()
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("oz-player/shims/www/OzEventEmitterWWW", ["BaseEventEmitter"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("BaseEventEmitter")
}), 98);
__d("oz-player/shims/OzEventEmitter", ["oz-player/shims/www/OzEventEmitterWWW"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("oz-player/shims/www/OzEventEmitterWWW")
}), 98);
__d("oz-player/networks/OzBandwidthEstimatorBase", ["oz-player/configs/OzGlobalConfig", "oz-player/networks/OzBandwidthCache", "oz-player/networks/OzBandwidthUtils", "oz-player/networks/OzNetworkSamples", "oz-player/shims/OzEventEmitter"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 1e6,
        i = "bandwidthEstimate",
        j = "bandwidthAndTTFBSamples";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b;
            b = a.call(this) || this;
            b.$OzBandwidthEstimatorBase2 = new(c("oz-player/networks/OzNetworkSamples"))();
            b.$OzBandwidthEstimatorBase1 = new(c("oz-player/networks/OzBandwidthCache"))(i, j, function() {
                return b.getAdjustedBandwidth(c("oz-player/configs/OzGlobalConfig"))
            }, function() {
                return {
                    bandwidth: b.$OzBandwidthEstimatorBase2.getRecentBandwidthSamples(),
                    navigationTiming: b.$OzBandwidthEstimatorBase2.getRecentNavigationTimingSamples()
                }
            });
            b.$OzBandwidthEstimatorBase2.setBandwidthCache(b.$OzBandwidthEstimatorBase1);
            return b
        }
        var e = b.prototype;
        e.getNetworkSamples = function() {
            return this.$OzBandwidthEstimatorBase2
        };
        e.getStandardDeviationOfBandwidth = function() {
            return d("oz-player/networks/OzBandwidthUtils").getStandardDeviationOfBandwidth(this.$OzBandwidthEstimatorBase2.getRecentBandwidthSamples())
        };
        e.getSampleCount = function() {
            return this.$OzBandwidthEstimatorBase2.getRecentBandwidthSamples().length
        };
        e.getAdjustedBandwidth = function(a) {
            return this.$OzBandwidthEstimatorBase2.getRecentBandwidthSamples().length === 0 ? this.getDefaultEstimate(a) : this.$OzBandwidthEstimatorBase3(a)
        };
        e.getBandwidthDiagnostics = function(a) {
            throw new Error("must be implementd by subclasses")
        };
        e.getBandwidth = function(a) {
            throw new Error("must be implementd by subclasses")
        };
        e.getBandwidthDiagnosticsFromHeaders = function(a) {
            a = this.getBandwidthDiagnostics(a);
            if (a == null) return null;
            var b = this.$OzBandwidthEstimatorBase2.getBandwidthEstimateFromHeaders();
            if (b == null) return a;
            var c, d;
            if (a != null) c = a.timeToFirstByteMsEstimate, d = a.timeToFirstByteMsStandardDeviation, a = a.timeToFirstByteMsTotalWeight;
            else return null;
            return {
                bandwidthEstimate: b.meanEstimate,
                bandwidthStandardDeviation: 1,
                bandwidthTotalWeight: 1,
                timeToFirstByteMsEstimate: c,
                timeToFirstByteMsStandardDeviation: d,
                timeToFirstByteMsTotalWeight: a
            }
        };
        e.getDefaultEstimate = function(a) {
            var b = this.$OzBandwidthEstimatorBase1.getCachedBandwidth();
            return typeof b === "number" && b > 0 ? b : a.getNumber("default_bandwidth_estimate", h)
        };
        e.$OzBandwidthEstimatorBase3 = function(a) {
            return this.getBandwidth(a)
        };
        e.addBandwidthSample = function(a, b) {
            this.$OzBandwidthEstimatorBase2.addBandwidthSample({
                bytes: a,
                timeInMs: b
            }), this.emit("bandwidth_sampled")
        };
        e.addNavigationTimingSample = function(a, b, c) {
            a = {
                timeToFirstByteMs: a,
                timeToLastByteMs: b,
                bytes: c
            };
            this.enqueueNavigationTimingSample(a);
            this.$OzBandwidthEstimatorBase2.addNavigationTimingSample(a)
        };
        e.enqueueNavigationTimingSample = function(a) {};
        e.setBandwidthEstimateFromHeaders = function(a) {
            this.$OzBandwidthEstimatorBase2.setBandwidthEstimateFromHeaders(a)
        };
        return b
    }(c("oz-player/shims/OzEventEmitter"));
    g["default"] = a
}), 98);
__d("oz-player/networks/OzBandwidthEstimator", ["oz-player/networks/OzBandwidthEstimatorBase", "oz-player/networks/OzBandwidthUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.getBandwidthDiagnostics = function(a) {
            return d("oz-player/networks/OzBandwidthUtils").getBandwidthDiagnostics(this.getNetworkSamples().getRecentBandwidthSamples(), a.getNumber("bandwidth_estimator_half_life", 6), this.getNetworkSamples().getRecentNavigationTimingSamples(), a.getNumber("time_to_first_byte_estimate_half_life_ms", 500))
        };
        c.getBandwidth = function(a) {
            var b = d("oz-player/networks/OzBandwidthUtils").getBandwidthEstimate(this.getNetworkSamples().getRecentBandwidthSamples(), a.getNumber("bandwidth_estimator_half_life", 6), a.getNumber("bandwidth_estimator_outlier_exclusion_factor", 50), a.getNumber("bandwidth_estimator_std_dev_penalty_factor", 0));
            return b > 0 ? b : this.getDefaultEstimate(a)
        };
        return b
    }(c("oz-player/networks/OzBandwidthEstimatorBase"));
    b = new a();
    e = b;
    g["default"] = e
}), 98);
__d("oz-player/parsers/getMIMECodecs", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a + '; codecs="' + b + '"'
    }
    f["default"] = a
}), 66);
__d("CometDASHPrefetchCache", ["ConstUriUtils", "MosUtils", "OzSystemicRiskUtils", "clearTimeout", "oz-player/configs/OzGlobalConfig", "oz-player/networks/OzBandwidthEstimator", "oz-player/parsers/getMIMECodecs", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 6e4,
        i = 2e3,
        j = 500;
    a = function() {
        function a() {
            this.$1 = new Map()
        }
        var b = a.prototype;
        b.fetch = function(a) {
            this.$1.size === 0 && (this.$2(a), this.$3(a))
        };
        b.clear = function() {
            var a = this;
            this.$1.forEach(function(b, c) {
                a.$4(c)
            });
            this.$1.clear()
        };
        b.hasCacheValue = function(a) {
            return this.$1.has(a)
        };
        b.getCacheValue = function(a) {
            var b = this.$1.get(a);
            b && (this.$4(a), this.$1["delete"](a));
            return b == null ? void 0 : b.request
        };
        b.getCachedRepresentations = function() {
            var a = [];
            this.$1.forEach(function(b) {
                b = b.representationID;
                a.indexOf(b) === -1 && a.push(b)
            });
            return a
        };
        b.$4 = function(a) {
            a = this.$1.get(a);
            a && a.cancelTimeoutID != null && c("clearTimeout")(a.cancelTimeoutID)
        };
        b.$3 = function(a) {
            a = a.find(function(a) {
                return a.mimeType.indexOf("audio") > -1
            });
            if (a == null) return;
            this.$5(a)
        };
        b.$2 = function(a) {
            a = a.filter(function(a) {
                return a.mimeType.indexOf("video") > -1
            });
            if (a.length === 0) return;
            var b = a[0];
            a.sort(function(a, b) {
                return a.bandwidth - b.bandwidth
            });
            a = this.$6(a);
            if (a.length === 0) return;
            var e = c("oz-player/networks/OzBandwidthEstimator").getBandwidthDiagnostics(c("oz-player/configs/OzGlobalConfig"));
            if (e == null) {
                this.$5(b);
                return
            }
            b = null;
            for (var f = 0; f < a.length; f++) {
                var g = a[Math.max(f - 1, 0)],
                    k = Math.min(g.height, g.width),
                    l = null,
                    m = c("oz-player/configs/OzGlobalConfig").getNumber("systemic_risk_abr_prefetch_low_mos_resolution", 0);
                if (c("oz-player/configs/OzGlobalConfig").getBool("systemic_risk_abr_parse_prefetch_mos", !1)) {
                    g = d("MosUtils").parsePlaybackMos(g.playbackResolutionMOS);
                    g != null && (l = d("MosUtils").getMosValue(g, j), m = 0)
                }
                g = d("OzSystemicRiskUtils").getRiskFactorsForRepresentation({
                    bandwidthDiagnostics: e,
                    bitrate: a[f].bandwidth,
                    bufferAhead: 0,
                    config: c("oz-player/configs/OzGlobalConfig"),
                    hasMadeInitialDecision: !1,
                    initialRiskFactor: c("oz-player/configs/OzGlobalConfig").getNumber("systemic_risk_abr_prefetch_initial_risk_factor", 1),
                    lowMosResolution: m,
                    minWatchableMos: c("oz-player/configs/OzGlobalConfig").getNumber("systemic_risk_abr_min_watchable_mos", 0),
                    previousMos: l,
                    previousResolution: k,
                    remainingVideoDurationMs: h,
                    segmentFetchRangeDurationMs: i
                });
                m = g.multiplier;
                if (isNaN(m)) break;
                l = d("OzSystemicRiskUtils").isEffectiveBitrateBelowBandwidthEstimate(a[f].bandwidth, m, i, e);
                if (l) b = a[f];
                else break
            }
            g = (k = b) != null ? k : a[0];
            this.$5(g)
        };
        b.$5 = function(a) {
            var b = this;
            a.segments.forEach(function(c) {
                c = b.$7(a.baseURL, c);
                if (c == null) return;
                var d = window.fetch(c).then(function(a) {
                    return {
                        initiator: "FETCH",
                        response: a
                    }
                });
                d = d["catch"](function() {});
                b.$8(c, {
                    representationID: a.representationID,
                    request: d
                })
            })
        };
        b.$8 = function(a, b) {
            var d = this;
            this.$4(a);
            var e = c("oz-player/configs/OzGlobalConfig").getNumber("prefetch_retention_duration_ms", 0),
                f = null;
            e > 0 && (f = c("setTimeout")(function() {
                d.$1["delete"](a)
            }, e));
            this.$1.set(a, babelHelpers["extends"]({}, b, {
                cancelTimeoutID: f
            }))
        };
        b.$7 = function(a, b) {
            return (a = d("ConstUriUtils").getUri(a)) == null ? void 0 : (a = a.addQueryParam("bytestart", b.start)) == null ? void 0 : (a = a.addQueryParam("byteend", b.end)) == null ? void 0 : a.toString()
        };
        b.$6 = function(a) {
            var b;
            a = a.filter(function(a) {
                var b;
                return (b = window.MediaSource) == null ? void 0 : b.isTypeSupported(c("oz-player/parsers/getMIMECodecs")(a.mimeType, a.codecs))
            });
            var d = (b = window.devicePixelRatio) != null ? b : 1,
                e = c("oz-player/configs/OzGlobalConfig").getNumber("prefetch_resolution_threshold", 0);
            e === 0 && (e = Infinity);
            b = a.filter(function(a) {
                a = Math.min(a.width, a.height);
                return a / d <= e
            });
            return b.length > 0 ? b : a.length > 0 ? [a[0]] : []
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("CometDASHPrefetchCacheManager", ["CometDASHPrefetchCache", "RunComet", "oz-player/configs/OzGlobalConfig"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            var a = this;
            this.$1 = new Map();
            c("oz-player/configs/OzGlobalConfig").getBool("clear_prefetch_on_unload", !1) && d("RunComet").onUnload(function() {
                a.$1.forEach(function(a) {
                    a.clear()
                })
            })
        }
        var b = a.prototype;
        b.fetch = function(a, b) {
            var d = this.$1.get(a),
                e = c("oz-player/configs/OzGlobalConfig").getBool("allow_subsequent_prefetch", !1);
            d || (d = new(c("CometDASHPrefetchCache"))(), this.$1.set(a, d), e || d.fetch(b));
            e && d.fetch(b)
        };
        b.get = function(a) {
            return this.$1.get(a)
        };
        return a
    }();
    b = new a();
    e = b;
    g["default"] = e
}), 98);
__d("cometPrefetchVideoDashV2", ["CometDASHPrefetchCacheManager"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (window.__comet_ssr_is_server_env_DO_NOT_USE === !0) return;
        c("CometDASHPrefetchCacheManager") != null && a != null && Array.isArray(a) && a.forEach(function(a) {
            if (a != null && a.video_id != null) {
                var b = String(a.video_id),
                    d = [];
                Array.isArray(a.representations) && a.representations.forEach(function(a) {
                    var b = [];
                    if (a != null && Array.isArray(a.segments) && typeof a.representation_id === "string" && typeof a.mime_type === "string" && typeof a.codecs === "string" && typeof a.bandwidth === "number" && typeof a.width === "number" && typeof a.height === "number" && typeof a.base_url === "string" && typeof a.playback_resolution_mos === "string") {
                        var c = {
                            bandwidth: a.bandwidth,
                            baseURL: a.base_url,
                            codecs: a.codecs,
                            height: a.height,
                            mimeType: a.mime_type,
                            playbackResolutionMOS: a.playback_resolution_mos,
                            representationID: a.representation_id,
                            segments: [],
                            width: a.width
                        };
                        a.segments.forEach(function(a) {
                            a != null && typeof a.start === "number" && typeof a.end === "number" && b.push({
                                end: a.end,
                                start: a.start
                            })
                        });
                        b.length > 0 && (c.segments = b, d.push(c))
                    }
                });
                d.length > 0 && c("CometDASHPrefetchCacheManager").fetch(b, d)
            }
        })
    }
    b = a;
    g["default"] = b
}), 98);
__d("CometRelayErrorHandling", ["errorCode", "SilenceableErrorMessageUtils"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;
    try {
        i = new WeakMap()
    } catch (a) {
        i = null
    }

    function a(a) {
        var b;
        (b = i) == null ? void 0 : b.set(a, !0)
    }

    function b(a) {
        var b, c = a == null ? void 0 : a.source;
        b = (b = c == null ? void 0 : c.errorCode) != null ? b : c == null ? void 0 : c.code;
        if (b === 1357001) return !1;
        return b === 1675030 ? !0 : ((c = i) == null ? void 0 : c.get(a)) === !0 || d("SilenceableErrorMessageUtils").shouldHideErrorMessage(d("SilenceableErrorMessageUtils").getMetadataFromError(a))
    }
    g.markErrorAsHandled = a;
    g.shouldSkipErrorSideEffects = b
}), 98);
__d("cometWrapWithRetryOnError", ["relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return d("relay-runtime").Observable.create(function(c) {
            var d, e = function e() {
                d = a.subscribe({
                    complete: c.complete,
                    error: function(a) {
                        var d = function(b) {
                            c.error((b = b) != null ? b : a)
                        };
                        d = b(a, e, d);
                        d || c.error(a)
                    },
                    next: c.next
                })
            };
            e();
            return function() {
                return d.unsubscribe()
            }
        })
    }
    g["default"] = a
}), 98);
__d("cometWrapNetworkObservable", ["CometRelayErrorHandling", "cometWrapWithRetryOnError", "cr:1196", "cr:641", "gkx", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        if (!b("cr:641")) return function(a) {
            return a
        };
        else return function(a) {
            return d("relay-runtime").Observable.create(function(e) {
                return h(a).subscribe({
                    complete: e.complete,
                    error: function(a) {
                        var f, g, h, i = e.error(a);
                        if (d("CometRelayErrorHandling").shouldSkipErrorSideEffects(a)) return i;
                        a = a == null ? void 0 : a.source;
                        f = (f = (f = a == null ? void 0 : a.errorCode) != null ? f : a == null ? void 0 : a.code) != null ? f : a == null ? void 0 : a.error;
                        g = (g = a == null ? void 0 : a.errorDescription) != null ? g : a == null ? void 0 : a.description;
                        h = (h = a == null ? void 0 : a.errorSummary) != null ? h : a == null ? void 0 : a.summary;
                        var j = null;
                        if (c("gkx")("2581")) {
                            var k;
                            j = (k = a == null ? void 0 : a.debug_info) != null ? k : a == null ? void 0 : a.message;
                            g === j && (j = null)
                        }
                        f && h && g && b("cr:641")(f, h, g, a == null ? void 0 : a.redirectTo, !0, j);
                        return i
                    },
                    next: function(a) {
                        if (Array.isArray(a))
                            for (var b = a, c = Array.isArray(b), d = 0, b = c ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                var f;
                                if (c) {
                                    if (d >= b.length) break;
                                    f = b[d++]
                                } else {
                                    d = b.next();
                                    if (d.done) break;
                                    f = d.value
                                }
                                f = f;
                                f = i(f);
                                if (f != null) {
                                    e.error(f);
                                    return
                                }
                            } else {
                                f = i(a);
                                if (f != null) {
                                    e.error(f);
                                    return
                                }
                            }
                        e.next(a)
                    }
                })
            })
        }
    }

    function h(a) {
        return !b("cr:1196") ? a : c("cometWrapWithRetryOnError")(a, b("cr:1196"))
    }

    function i(a) {
        var b = a.data;
        a = Object.prototype.hasOwnProperty.call(a, "errors") ? a.errors : void 0;
        if (Array.isArray(a))
            for (var a = a, c = Array.isArray(a), e = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (c) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                if (f != null && typeof f === "object" && (f.severity === "CRITICAL" || f.severity === "ERROR") && Array.isArray(f.path) && f.path.length === 3 && f.path[0] === "viewer" && f.path[1] === "news_feed" && f.path[2] === "edges") {
                    f = b == null ? void 0 : (f = b.viewer) == null ? void 0 : f.news_feed;
                    var g = f == null ? void 0 : f.edges;
                    if (f != null && (g == null || Array.isArray(g) && g.length === 0)) return d("relay-runtime").RelayError.create("CometNewsFeed", "Error evaluating Comet News Feed, edges cannot be resolved.")
                }
            }
    }
    g["default"] = a
}), 98);
__d("createCometStore", ["CometRelayConfig", "RelayFBGCScheduler", "RelayFBOperationLoader", "cr:2928", "gkx", "relayFBGetDataID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("gkx")("1151941");

    function a(a) {
        var e = new(b("cr:2928").RecordSource)();
        e = new(b("cr:2928").Store)(e, {
            gcReleaseBufferSize: d("CometRelayConfig").gc_release_buffer_size,
            gcScheduler: c("RelayFBGCScheduler"),
            getDataID: c("relayFBGetDataID"),
            log: a,
            operationLoader: c("RelayFBOperationLoader"),
            queryCacheExpirationTime: void 0
        });
        h || e.holdGC();
        return e
    }
    g["default"] = a
}), 98);
__d("GraphqlLiveQueryEventFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("getFalcoLogPolicy_DO_NOT_USE")("1743656");
    b = d("FalcoLoggerInternal").create("graphql_live_query_event", a);
    e = b;
    g["default"] = e
}), 98);
__d("LiveQueryEventsLoggingResolver", ["GraphqlLiveQueryEventFalcoEvent", "Random", "RealtimeFrameworksCounterFalcoEvent", "gkx"], (function(a, b, c, d, e, f, g) {
    var h = "default",
        i = "without_sampling";

    function a() {
        if (c("gkx")("1133447")) return {
            force_log_context: i,
            sampling_rate: 1,
            client_has_ods_usecase_counters: !0
        };
        else if (d("Random").coinflip(1e4)) return {
            force_log_context: h,
            sampling_rate: 1e4,
            client_has_ods_usecase_counters: !0
        }
    }

    function b(a, b, d, e, f, g, h, i) {
        g != null && g.sampling_rate != null && c("GraphqlLiveQueryEventFalcoEvent").log(function() {
            return {
                event: a,
                event_source: "web",
                event_reason: b,
                config_id: e,
                doc_id_str: d,
                force_log_context: g.force_log_context,
                logging_sampling_rate: g.sampling_rate,
                live_query_request_id: f,
                error_info: h,
                initial_response_latency_ms: i
            }
        }), c("RealtimeFrameworksCounterFalcoEvent").log(function() {
            return {
                event: a,
                event_detail: b,
                use_case: e,
                use_case_type: "live_query"
            }
        })
    }
    g.tempResolveLoggingContext = a;
    g.logEvent = b
}), 98);
__d("makeGraphQLLiveQueryRequest", ["RealtimeGraphQLRequest"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "FBLQ";

    function a(a) {
        var b = a.doc_id,
            d = a.variables,
            e = a.is_intern,
            f = a.graphiql_impersonation,
            g = a.resumption_group_name,
            i = a.enable_canonical_naming,
            j = a.instrumentation_data,
            k = a.config_id,
            l = a.live_query_request_id,
            m = a.actor_id,
            n = a.access_token,
            o = a.logging_context,
            p = a.last_response_digest;
        a = a.priming_token;
        var q = h + ":" + k;
        b = {
            method: q,
            doc_id: b,
            body: {
                variables: (q = d) != null ? q : {}
            }
        };
        e != null && (b = babelHelpers["extends"]({}, b, {
            is_intern: e
        }));
        d = {
            config_id: k,
            live_query_request_id: l
        };
        p != null && (d = babelHelpers["extends"]({}, d, {
            last_response_digest: p
        }));
        m != null && (d = babelHelpers["extends"]({}, d, {
            actor_id: m
        }));
        a != null && (d = babelHelpers["extends"]({}, d, {
            priming_token: a
        }));
        o != null && (d = babelHelpers["extends"]({}, d, {
            logging_context: o
        }));
        n != null && (d = babelHelpers["extends"]({}, d, {
            access_token: n
        }));
        f != null && (d = babelHelpers["extends"]({}, d, {
            graphiql_impersonation: f
        }));
        i === !0 && (d = babelHelpers["extends"]({}, d, {
            enable_canonical_naming: !0
        }));
        g != null && (d = babelHelpers["extends"]({}, d, {
            resumption_group_name: g
        }));
        b = babelHelpers["extends"]({}, b, {
            extra_headers: d
        });
        j != null && (b = babelHelpers["extends"]({}, b, {
            instrumentation_data: j
        }));
        return new(c("RealtimeGraphQLRequest"))(b)
    }
    f.exports = a
}), 34);
__d("liveQueryFetch", ["invariant", "LiveQueryEventsLoggingResolver", "LiveQueryWebRelayKillList", "RelayGraphQLRequestUtils", "RelayRuntime", "makeGraphQLLiveQueryRequest", "nullthrows", "promiseDone", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = b("RelayRuntime").Observable,
        i = b("RelayRuntime").RelayError;

    function a(a, c, d) {
        if (!l() || k(d.config_id)) return h.create(function(a) {
            a.complete();
            return
        });
        var e = Date.now(),
            f = 0;
        a.id != null || g(0, 13279);
        var m = j();
        a.metadata.live != null && (typeof a.metadata.live.live_query_request_id === "string" && (m = a.metadata.live.live_query_request_id), typeof a.metadata.live.timeStamp === "number" && (e = a.metadata.live.timeStamp));
        var n = {
            doc_id: b("nullthrows")(a.id),
            config_id: d.config_id,
            actor_id: d.actor_id,
            variables: c,
            live_query_request_id: m
        };
        d.access_token !== "" && (n = babelHelpers["extends"]({}, n, {
            access_token: d.access_token
        }));
        var o = b("LiveQueryEventsLoggingResolver").tempResolveLoggingContext();
        o != null && (o = babelHelpers["extends"]({}, o, {
            client_send_request_timestamp: e
        }), n = babelHelpers["extends"]({}, n, {
            logging_context: o
        }));
        return h.create(function(a) {
            var c = b("makeGraphQLLiveQueryRequest")(n).onResponse(function(c) {
                var d = Date.now(),
                    h;
                try {
                    h = b("RelayGraphQLRequestUtils").parsePayload(c), typeof h === "object" || g(0, 12937)
                } catch (c) {
                    b("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_parsing_response", n.doc_id, n.config_id, m, o, c.message);
                    return a.error(c)
                }
                if (!("errors" in h) && !("data" in h)) {
                    b("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_empty_response", n.doc_id, n.config_id, m, o, "Parsed network response is empty");
                    return a.error(i.createWarning("EmptyResponseError", "Parsed network response is empty"))
                }
                if (h.errors)
                    for (var c = h.errors, j = Array.isArray(c), k = 0, c = j ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var l;
                        if (j) {
                            if (k >= c.length) break;
                            l = c[k++]
                        } else {
                            k = c.next();
                            if (k.done) break;
                            l = k.value
                        }
                        l = l;
                        if (l.severity === "CRITICAL") {
                            l = b("RelayGraphQLRequestUtils").createErrorFromPayload(l);
                            b("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_in_response", n.doc_id, n.config_id, m, o, l.message);
                            return a.error(l)
                        }
                    }
                f == 0 ? b("LiveQueryEventsLoggingResolver").logEvent("client_update", "live_query_initial", n.doc_id, n.config_id, m, o, null, d - e) : b("LiveQueryEventsLoggingResolver").logEvent("client_update", "regular_response_update", n.doc_id, n.config_id, m, o);
                f += 1;
                a.closed || a.next(h)
            }).onError(function(a) {
                b("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_received", n.doc_id, n.config_id, m, o, a.message)
            }).onActive(function() {
                b("LiveQueryEventsLoggingResolver").logEvent("client_subscribe", "initial_subscribe_request", n.doc_id, n.config_id, m, o)
            }).onPause(function(a, c) {
                b("LiveQueryEventsLoggingResolver").logEvent("client_unsubscribe", "subscription_paused", n.doc_id, n.config_id, m, o)
            }).onResume(function(a) {
                b("LiveQueryEventsLoggingResolver").logEvent("client_subscribe", "subscription_resumed", n.doc_id, n.config_id, m, o)
            }).send();
            return function() {
                b("promiseDone")(c, function(a) {
                    a.cancel(), b("LiveQueryEventsLoggingResolver").logEvent("client_unsubscribe", "regular_unsubscribe", n.doc_id, n.config_id, m, o)
                })
            }
        })
    }

    function j() {
        return b("uuid")()
    }

    function k(a) {
        for (var c = b("LiveQueryWebRelayKillList").liveQueryWebRelayKillList, d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= c.length) break;
                f = c[e++]
            } else {
                e = c.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            if (a === f) return !0
        }
        return !1
    }

    function l() {
        return "WebSocket" in window
    }
    e.exports = a
}), null);
__d("liveQueryFetchWithWWWInitial", ["invariant", "LiveQueryEventsLoggingResolver", "LiveQueryWebRelayKillList", "RelayGraphQLRequestUtils", "RelayRuntime", "makeGraphQLLiveQueryRequest", "nullthrows", "promiseDone", "uuid"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b, e, f) {
        if (!k() || j(e.config_id)) return f;
        var g = Date.now();
        a.id != null || h(0, 13279);
        var l = i();
        a.metadata.live != null && (typeof a.metadata.live.live_query_request_id === "string" && (l = a.metadata.live.live_query_request_id), typeof a.metadata.live.timeStamp === "number" && (g = a.metadata.live.timeStamp));
        var m = {
            doc_id: c("nullthrows")(a.id),
            config_id: e.config_id,
            actor_id: e.actor_id,
            variables: b,
            live_query_request_id: l
        };
        e.access_token !== "" && (m = babelHelpers["extends"]({}, m, {
            access_token: e.access_token
        }));
        var n = d("LiveQueryEventsLoggingResolver").tempResolveLoggingContext();
        n != null && (m = babelHelpers["extends"]({}, m, {
            logging_context: n
        }));
        return d("RelayRuntime").Observable.create(function(a) {
            var b = !1,
                e = null;
            f.subscribe({
                next: function(c) {
                    var e = Date.now();
                    if (c.extensions != null && c.extensions.is_final === !0) {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_update", "www_initials_is_final", m.doc_id, m.config_id, l, n, null, e - g);
                        if (c.extensions != null && c.extensions.live_query != null) {
                            e = c.extensions.live_query;
                            typeof e.priming_token === "string" && (m = babelHelpers["extends"]({}, m, {
                                priming_token: e.priming_token
                            }));
                            typeof e.response_digest === "string" && (m = babelHelpers["extends"]({}, m, {
                                last_response_digest: e.response_digest
                            }));
                            typeof e.disable === "boolean" && (b = e.disable)
                        }
                    }
                    a.next(c)
                },
                error: function(b) {
                    a.error(b)
                },
                complete: function() {
                    if (b) {
                        a.complete();
                        return function() {}
                    }
                    e = c("makeGraphQLLiveQueryRequest")(m).onResponse(function(b) {
                        var e;
                        try {
                            e = c("RelayGraphQLRequestUtils").parsePayload(b), typeof e === "object" || h(0, 12937)
                        } catch (b) {
                            d("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_parsing_response", m.doc_id, m.config_id, l, n, b.message);
                            return a.error(b)
                        }
                        if (!("errors" in e) && !("data" in e)) {
                            d("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_empty_response", m.doc_id, m.config_id, l, n, "Parsed network response is empty");
                            return a.error(d("RelayRuntime").RelayError.createWarning("EmptyResponseError", "Parsed network response is empty"))
                        }
                        if (e.errors)
                            for (var b = e.errors, f = Array.isArray(b), g = 0, b = f ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                var i;
                                if (f) {
                                    if (g >= b.length) break;
                                    i = b[g++]
                                } else {
                                    g = b.next();
                                    if (g.done) break;
                                    i = g.value
                                }
                                i = i;
                                if (i.severity === "CRITICAL") {
                                    i = c("RelayGraphQLRequestUtils").createErrorFromPayload(i);
                                    d("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_in_response", m.doc_id, m.config_id, l, n, i.message);
                                    return a.error(i)
                                }
                            }
                        d("LiveQueryEventsLoggingResolver").logEvent("client_update", "regular_response_update", m.doc_id, m.config_id, l, n);
                        a.closed || a.next(e)
                    }).onError(function(a) {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_received", m.doc_id, m.config_id, l, n, a.message)
                    }).onActive(function() {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_subscribe", "initial_subscribe_request", m.doc_id, m.config_id, l, n)
                    }).onPause(function(a, b) {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_unsubscribe", "subscription_paused", m.doc_id, m.config_id, l, n)
                    }).onResume(function(a) {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_subscribe", "subscription_resumed", m.doc_id, m.config_id, l, n)
                    }).send()
                }
            });
            return function() {
                e != null && c("promiseDone")(e, function(a) {
                    a.cancel(), d("LiveQueryEventsLoggingResolver").logEvent("client_unsubscribe", "regular_unsubscribe", m.doc_id, m.config_id, l, n)
                })
            }
        })
    }

    function i() {
        return c("uuid")()
    }

    function j(a) {
        for (var b = c("LiveQueryWebRelayKillList").liveQueryWebRelayKillList, d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= b.length) break;
                f = b[e++]
            } else {
                e = b.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            if (a === f) return !0
        }
        return !1
    }

    function k() {
        return "WebSocket" in window
    }
    g["default"] = a
}), 98);
__d("createCometRelayEnvironmentConfig", ["ActorURIConfig", "CometMissingFieldHandlers", "CometRelayFlightEventLogger", "CometRelayPerfStore", "CometRootInitServerFlag", "RelayAPIConfig", "RelayFBFlightPayloadDeserializer", "RelayFBFlightServerErrorHandler", "RelayFBOperationLoader", "RelayRequiredFieldLogger", "cometHandlerProvider", "cometPrefetchVideoDashV2", "cometWrapNetworkObservable", "cr:1121434", "cr:1445039", "cr:1467370", "cr:5655", "cr:851", "createCometStore", "createRelayFBNetwork", "createRelayFBNetworkFetch", "createRelayFBSubscribeFunction", "liveQueryFetch", "liveQueryFetchWithWWWInitial", "relay-runtime", "relayFBGetDataID"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        var d = c("RelayAPIConfig").actorID === a && b == null ? " DEFAULT" : "";
        b = b == null ? "" : " - " + b;
        return "CometRelayEnvironment (" + String(a) + b + ")" + d
    }

    function i(a, b) {
        return c("createRelayFBNetwork")(c("createRelayFBNetworkFetch")({
            actorID: a,
            batchResponseChunks: !0,
            getAdditionalData: function() {
                var b = {};
                a != null && (b[c("ActorURIConfig").PARAMETER_ACTOR] = a);
                c("RelayAPIConfig").useXController === !1 && c("RelayAPIConfig").accessToken !== "" && (b.access_token = c("RelayAPIConfig").accessToken);
                return b
            },
            graphURI: b,
            liveQueryFetchFn: c("liveQueryFetch"),
            liveQueryFetchWithWWWInitialFn: c("liveQueryFetchWithWWWInitial"),
            wrapObservableFn: c("cometWrapNetworkObservable")()
        }), c("createRelayFBSubscribeFunction")({
            actorID: a
        }), null, c("cometPrefetchVideoDashV2"))
    }

    function j(a) {
        return b("cr:1445039") != null ? b("cr:1445039").create(String(a), 2e3) : null
    }

    function k(a) {
        var c = b("cr:1121434") != null ? b("cr:1121434")() : null;
        return function(e) {
            c && c(e), a && a.log(e), b("cr:5655") && b("cr:5655").log(e), d("CometRelayPerfStore").log(e), d("CometRelayFlightEventLogger").log(e), b("cr:851") && b("cr:851").log(e)
        }
    }

    function l(a) {
        return a != null ? function(b) {
            return a.log(b)
        } : null
    }

    function a(a) {
        var e = a.actorID,
            f = a.actorEnvironmentKey;
        a = a.graphURI;
        a = a === void 0 ? void 0 : a;
        var g = j(e);
        return {
            UNSTABLE_defaultRenderPolicy: "partial",
            actorID: e,
            configName: h(e, f),
            getDataID: c("relayFBGetDataID"),
            handlerProvider: c("cometHandlerProvider"),
            isServer: d("CometRootInitServerFlag").isServerEnvironment(),
            log: k(g),
            missingFieldHandlers: c("CometMissingFieldHandlers"),
            network: i(e, a),
            operationLoader: c("RelayFBOperationLoader"),
            operationTracker: new(d("relay-runtime").__internal.OperationTracker)(),
            reactFlightPayloadDeserializer: c("RelayFBFlightPayloadDeserializer"),
            reactFlightServerErrorHandler: c("RelayFBFlightServerErrorHandler"),
            requiredFieldLogger: d("RelayRequiredFieldLogger").create(),
            scheduler: b("cr:1467370"),
            store: c("createCometStore")(l(g))
        }
    }
    g.createCometEnvironmentConfigName = h;
    g.createCometNetwork = i;
    g.createCometRelayEventLogger = j;
    g.createCometEnvironmentLogFn = k;
    g.createCometStoreLoggerFn = l;
    g.createCometRelayEnvironmentConfig = a
}), 98);
__d("cometCreateMulitActorEnvironmentConfig", ["CometMissingFieldHandlers", "CometRootInitServerFlag", "RelayFBFlightPayloadDeserializer", "RelayFBFlightServerErrorHandler", "RelayFBOperationLoader", "RelayRequiredFieldLogger", "cometHandlerProvider", "cr:1467370", "createCometRelayEnvironmentConfig", "createCometStore", "relayFBGetDataID"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, e, f) {
        f === void 0 && (f = void 0);
        var g = d("createCometRelayEnvironmentConfig").createCometRelayEventLogger(a);
        return {
            createConfigNameForActor: function(a) {
                return d("createCometRelayEnvironmentConfig").createCometEnvironmentConfigName(String(a), e) + " (Multi Actor)"
            },
            createNetworkForActor: function(a) {
                return d("createCometRelayEnvironmentConfig").createCometNetwork(String(a), f)
            },
            createStoreForActor: function() {
                return c("createCometStore")(d("createCometRelayEnvironmentConfig").createCometStoreLoggerFn(g))
            },
            getDataID: c("relayFBGetDataID"),
            handlerProvider: c("cometHandlerProvider"),
            isServer: d("CometRootInitServerFlag").isServerEnvironment(),
            logFn: d("createCometRelayEnvironmentConfig").createCometEnvironmentLogFn(g),
            missingFieldHandlers: c("CometMissingFieldHandlers"),
            operationLoader: c("RelayFBOperationLoader"),
            reactFlightPayloadDeserializer: c("RelayFBFlightPayloadDeserializer"),
            reactFlightServerErrorHandler: c("RelayFBFlightServerErrorHandler"),
            requiredFieldLogger: d("RelayRequiredFieldLogger").create(),
            scheduler: b("cr:1467370")
        }
    }
    g["default"] = a
}), 98);
__d("relay-runtime/multi-actor-environment/ActorSpecificEnvironment", ["relay-runtime/network/wrapNetworkWithLogObserver", "relay-runtime/store/RelayOperationTracker", "relay-runtime/store/RelayPublishQueue", "relay-runtime/store/StoreInspector", "relay-runtime/store/defaultGetDataID", "relay-runtime/util/registerEnvironmentWithDevTools"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a(a) {
            var c = this;
            this.configName = a.configName;
            this.actorIdentifier = a.actorIdentifier;
            this.multiActorEnvironment = a.multiActorEnvironment;
            this.__log = a.logFn;
            this.requiredFieldLogger = a.requiredFieldLogger;
            this.$3 = new(b("relay-runtime/store/RelayOperationTracker"))();
            this.$5 = a.store;
            this.$2 = b("relay-runtime/network/wrapNetworkWithLogObserver")(this, a.network);
            this.$4 = new(b("relay-runtime/store/RelayPublishQueue"))(a.store, a.handlerProvider, b("relay-runtime/store/defaultGetDataID"), a.missingFieldHandlers);
            this.$1 = a.defaultRenderPolicy;
            this.options = {
                actorID: this.actorIdentifier
            };
            this["@@RelayModernEnvironment"] = !0;
            b("relay-runtime/util/registerEnvironmentWithDevTools")(this)
        }
        var c = a.prototype;
        c.getPublishQueue = function() {
            return this.$4
        };
        c.UNSTABLE_getDefaultRenderPolicy = function() {
            return this.$1
        };
        c.applyMutation = function(a) {
            return this.multiActorEnvironment.applyMutation(this, a)
        };
        c.applyUpdate = function(a) {
            return this.multiActorEnvironment.applyUpdate(this, a)
        };
        c.revertUpdate = function(a) {
            return this.multiActorEnvironment.revertUpdate(this, a)
        };
        c.replaceUpdate = function(a, b) {
            return this.multiActorEnvironment.replaceUpdate(this, a, b)
        };
        c.check = function(a) {
            return this.multiActorEnvironment.check(this, a)
        };
        c.subscribe = function(a, b) {
            return this.multiActorEnvironment.subscribe(this, a, b)
        };
        c.retain = function(a) {
            return this.multiActorEnvironment.retain(this, a)
        };
        c.commitUpdate = function(a) {
            return this.multiActorEnvironment.commitUpdate(this, a)
        };
        c.commitPayload = function(a, b) {
            return this.multiActorEnvironment.commitPayload(this, a, b)
        };
        c.getNetwork = function() {
            return this.$2
        };
        c.getStore = function() {
            return this.$5
        };
        c.getOperationTracker = function() {
            return this.$3
        };
        c.getScheduler = function() {
            return this.multiActorEnvironment.getScheduler()
        };
        c.lookup = function(a) {
            return this.multiActorEnvironment.lookup(this, a)
        };
        c.execute = function(a) {
            return this.multiActorEnvironment.execute(this, a)
        };
        c.executeSubscription = function(a) {
            return this.multiActorEnvironment.executeSubscription(this, a)
        };
        c.executeMutation = function(a) {
            return this.multiActorEnvironment.executeMutation(this, a)
        };
        c.executeWithSource = function(a) {
            return this.multiActorEnvironment.executeWithSource(this, a)
        };
        c.isRequestActive = function(a) {
            return this.multiActorEnvironment.isRequestActive(this, a)
        };
        c.isServer = function() {
            return this.multiActorEnvironment.isServer()
        };
        return a
    }();
    e.exports = a
}), null);
__d("relay-runtime/multi-actor-environment/MultiActorEnvironment", ["relay-runtime/handlers/RelayDefaultHandlerProvider", "relay-runtime/multi-actor-environment/ActorSpecificEnvironment", "relay-runtime/network/RelayObservable", "relay-runtime/store/OperationExecutor", "relay-runtime/store/RelayModernStore", "relay-runtime/store/RelayRecordSource", "relay-runtime/store/defaultGetDataID", "relay-runtime/store/defaultRequiredFieldLogger"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a(a) {
            var c;
            this.$1 = new Map();
            this.$12 = a.operationLoader;
            this.$3 = a.createNetworkForActor;
            this.$16 = a.scheduler;
            this.$6 = (c = a.getDataID) != null ? c : b("relay-runtime/store/defaultGetDataID");
            this.$7 = a.handlerProvider ? a.handlerProvider : b("relay-runtime/handlers/RelayDefaultHandlerProvider");
            this.$9 = (c = a.logFn) != null ? c : g;
            this.$11 = new Map();
            this.$15 = (c = a.requiredFieldLogger) != null ? c : b("relay-runtime/store/defaultRequiredFieldLogger");
            this.$17 = a.shouldProcessClientComponents;
            this.$18 = (c = a.treatMissingFieldsAsNull) != null ? c : !1;
            this.$8 = (c = a.isServer) != null ? c : !1;
            this.$10 = (c = a.missingFieldHandlers) != null ? c : [];
            this.$4 = a.createStoreForActor;
            this.$13 = a.reactFlightPayloadDeserializer;
            this.$14 = a.reactFlightServerErrorHandler;
            this.$2 = a.createConfigNameForActor;
            this.$5 = (c = a.defaultRenderPolicy) != null ? c : "partial"
        }
        var c = a.prototype;
        c.forActor = function(a) {
            var c = this.$1.get(a);
            if (c == null) {
                var d = new(b("relay-runtime/multi-actor-environment/ActorSpecificEnvironment"))({
                    configName: this.$2 ? this.$2(a) : null,
                    actorIdentifier: a,
                    multiActorEnvironment: this,
                    logFn: this.$9,
                    requiredFieldLogger: this.$15,
                    store: this.$4 != null ? this.$4(a) : new(b("relay-runtime/store/RelayModernStore"))(b("relay-runtime/store/RelayRecordSource").create()),
                    network: this.$3(a),
                    handlerProvider: this.$7,
                    defaultRenderPolicy: this.$5,
                    missingFieldHandlers: this.$10
                });
                this.$1.set(a, d);
                return d
            } else return c
        };
        c.check = function(a, c) {
            var d = this;
            return this.$10 == null || this.$10.length === 0 ? a.getStore().check(c, {
                handlers: [],
                defaultActorIdentifier: a.actorIdentifier,
                getSourceForActor: function(a) {
                    return d.forActor(a).getStore().getSource()
                },
                getTargetForActor: function() {
                    return b("relay-runtime/store/RelayRecordSource").create()
                }
            }) : this.$19(a, c, this.$10)
        };
        c.$19 = function(a, c, d) {
            var e = this,
                f = new Map([
                    [a.actorIdentifier, b("relay-runtime/store/RelayRecordSource").create()]
                ]);
            c = a.getStore().check(c, {
                handlers: d,
                defaultActorIdentifier: a.actorIdentifier,
                getSourceForActor: function(a) {
                    return e.forActor(a).getStore().getSource()
                },
                getTargetForActor: function(a) {
                    var c = f.get(a);
                    c == null && (c = b("relay-runtime/store/RelayRecordSource").create(), f.set(a, c));
                    return c
                }
            });
            a = function() {
                if (h) {
                    if (i >= g.length) return "break";
                    d = g[i++]
                } else {
                    i = g.next();
                    if (i.done) return "break";
                    d = i.value
                }
                var a = d,
                    b = a[0],
                    c = a[1];
                c.size() > 0 && e.$20(function() {
                    var a = e.forActor(b).getPublishQueue();
                    a.commitSource(c);
                    a.run()
                })
            };
            for (var g = f, h = Array.isArray(g), i = 0, g = h ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var j = a();
                if (j === "break") break
            }
            return c
        };
        c.subscribe = function(a, b, c) {
            return a.getStore().subscribe(b, c)
        };
        c.retain = function(a, b) {
            return a.getStore().retain(b)
        };
        c.applyUpdate = function(a, b) {
            var c = this,
                d = a.getPublishQueue();
            a = function() {
                c.$20(function() {
                    d.revertUpdate(b), d.run()
                })
            };
            this.$20(function() {
                d.applyUpdate(b), d.run()
            });
            return {
                dispose: a
            }
        };
        c.revertUpdate = function(a, b) {
            var c = a.getPublishQueue();
            this.$20(function() {
                c.revertUpdate(b), c.run()
            })
        };
        c.replaceUpdate = function(a, b, c) {
            var d = a.getPublishQueue();
            this.$20(function() {
                d.revertUpdate(b), d.applyUpdate(c), d.run()
            })
        };
        c.applyMutation = function(a, c) {
            var d = this.$21(a, {
                createSource: function() {
                    return b("relay-runtime/network/RelayObservable").create(function(a) {})
                },
                isClientPayload: !1,
                operation: c.operation,
                optimisticConfig: c,
                updater: null
            }).subscribe({});
            return {
                dispose: function() {
                    return d.unsubscribe()
                }
            }
        };
        c.commitUpdate = function(a, b) {
            var c = a.getPublishQueue();
            this.$20(function() {
                c.commitUpdate(b), c.run()
            })
        };
        c.commitPayload = function(a, c, d) {
            this.$21(a, {
                createSource: function() {
                    return b("relay-runtime/network/RelayObservable").from({
                        data: d
                    })
                },
                isClientPayload: !0,
                operation: c,
                optimisticConfig: null,
                updater: null
            }).subscribe({})
        };
        c.lookup = function(a, b) {
            return a.getStore().lookup(b)
        };
        c.execute = function(a, b) {
            var c = b.operation;
            return this.$21(a, {
                createSource: function() {
                    return a.getNetwork().execute(c.request.node.params, c.request.variables, c.request.cacheConfig || {}, null)
                },
                isClientPayload: !1,
                operation: c,
                optimisticConfig: null,
                updater: null
            })
        };
        c.executeSubscription = function(a, b) {
            var c = b.operation;
            b = b.updater;
            return this.$21(a, {
                createSource: function() {
                    return a.getNetwork().execute(c.request.node.params, c.request.variables, c.request.cacheConfig || {}, null)
                },
                isClientPayload: !1,
                operation: c,
                optimisticConfig: null,
                updater: b
            })
        };
        c.executeMutation = function(a, b) {
            var c = b.operation,
                d = b.optimisticResponse,
                e = b.optimisticUpdater,
                f = b.updater,
                g = b.uploadables,
                h;
            (d || e) && (h = {
                operation: c,
                response: d,
                updater: e
            });
            return this.$21(a, {
                createSource: function() {
                    return a.getNetwork().execute(c.request.node.params, c.request.variables, babelHelpers["extends"]({}, c.request.cacheConfig, {
                        force: !0
                    }), g)
                },
                isClientPayload: !1,
                operation: c,
                optimisticConfig: h,
                updater: f
            })
        };
        c.executeWithSource = function(a, b) {
            return this.$21(a, {
                createSource: function() {
                    return b.source
                },
                isClientPayload: !1,
                operation: b.operation,
                optimisticConfig: null,
                updater: null
            })
        };
        c.isRequestActive = function(a, b) {
            a = this.$11.get(b);
            return a === "active"
        };
        c.isServer = function() {
            return this.$8
        };
        c.$21 = function(a, c) {
            var d = this,
                e = c.createSource,
                f = c.isClientPayload,
                g = c.operation,
                h = c.optimisticConfig,
                i = c.updater;
            return b("relay-runtime/network/RelayObservable").create(function(c) {
                var j = b("relay-runtime/store/OperationExecutor").execute({
                    actorIdentifier: a.actorIdentifier,
                    getDataID: d.$6,
                    isClientPayload: f,
                    operation: g,
                    operationExecutions: d.$11,
                    operationLoader: d.$12,
                    operationTracker: a.getOperationTracker(),
                    optimisticConfig: h,
                    getPublishQueue: function(a) {
                        return d.forActor(a).getPublishQueue()
                    },
                    reactFlightPayloadDeserializer: d.$13,
                    reactFlightServerErrorHandler: d.$14,
                    scheduler: d.$16,
                    shouldProcessClientComponents: d.$17,
                    sink: c,
                    source: e(),
                    getStore: function(a) {
                        return d.forActor(a).getStore()
                    },
                    treatMissingFieldsAsNull: d.$18,
                    updater: i,
                    log: d.$9
                });
                return function() {
                    return j.cancel()
                }
            })
        };
        c.$20 = function(a) {
            var b = this.$16;
            b != null ? b.schedule(a) : a()
        };
        c.commitMultiActorUpdate = function(a) {
            var b = function() {
                if (d) {
                    if (e >= c.length) return "break";
                    f = c[e++]
                } else {
                    e = c.next();
                    if (e.done) return "break";
                    f = e.value
                }
                var b = f,
                    g = b[0],
                    h = b[1];
                h.commitUpdate(function(b) {
                    a(g, h, b)
                })
            };
            for (var c = this.$1, d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f, g = b();
                if (g === "break") break
            }
        };
        c.getScheduler = function() {
            return this.$16
        };
        return a
    }();

    function g() {}
    e.exports = a
}), null);
__d("relay-runtime/multi-actor-environment", ["relay-runtime/multi-actor-environment/ActorIdentifier", "relay-runtime/multi-actor-environment/MultiActorEnvironment"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("relay-runtime/multi-actor-environment/ActorIdentifier").getActorIdentifier;
    e.exports = {
        MultiActorEnvironment: b("relay-runtime/multi-actor-environment/MultiActorEnvironment"),
        getActorIdentifier: a
    }
}), null);
__d("CometRelayMultiActorEnvironment", ["RelayAPIConfig", "cometCreateMulitActorEnvironmentConfig", "relay-runtime/multi-actor-environment"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map(),
        i = new(d("relay-runtime/multi-actor-environment").MultiActorEnvironment)(c("cometCreateMulitActorEnvironmentConfig")(c("RelayAPIConfig").actorID));

    function a(a) {
        var b = function(b, c, d) {
            a(String(b), c, d)
        };
        for (var c = h.values(), d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= c.length) break;
                f = c[e++]
            } else {
                e = c.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            f.commitMultiActorUpdate(b)
        }
        i.commitMultiActorUpdate(b)
    }

    function b(a, b) {
        var e;
        b != null ? (e = h.get(b), e == null && (e = new(d("relay-runtime/multi-actor-environment").MultiActorEnvironment)(c("cometCreateMulitActorEnvironmentConfig")(c("RelayAPIConfig").actorID, b)), h.set(b, e))) : e = i;
        return e.forActor(a)
    }
    g.commitMultiActorUpdate = a;
    g.forActor = b
}), 98);
__d("createRelayFBLocalEnvironment", ["RelayFBHandlerProvider", "RelayFBOperationLoader", "RelayRequiredFieldLogger", "RelayRuntime", "getRelayFBMissingFieldHandlers", "relayFBGetDataID", "resolveImmediate"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("RelayRuntime").Environment,
        h = b("RelayRuntime").RecordSource,
        i = b("RelayRuntime").Store,
        j = {
            execute: function(a) {
                throw new Error("RelayFBLocalEnvironment: Network requests are not allowed in the local environment, got: " + a.name)
            }
        };

    function a(a) {
        var c = a.handlerProvider,
            d = a.missingFieldHandlers,
            e = a.scheduler,
            f = a.store,
            k = a.configName,
            l = a.log,
            m = a.operationTracker;
        a = a.getDataID;
        c = new g({
            configName: (k = k) != null ? k : "RelayFBLocalEnvironment",
            handlerProvider: (k = c) != null ? k : b("RelayFBHandlerProvider"),
            missingFieldHandlers: (c = d) != null ? c : b("getRelayFBMissingFieldHandlers")(),
            operationLoader: b("RelayFBOperationLoader"),
            scheduler: e,
            store: (k = f) != null ? k : new i(new h(), {
                getDataID: b("relayFBGetDataID"),
                gcReleaseBufferSize: 10,
                gcScheduler: b("resolveImmediate"),
                operationLoader: b("RelayFBOperationLoader")
            }),
            network: j,
            operationTracker: m,
            log: l,
            getDataID: (d = a) != null ? d : b("relayFBGetDataID"),
            options: {
                isLocal: !0
            },
            requiredFieldLogger: b("RelayRequiredFieldLogger").create()
        });
        return c
    }
    e.exports = a
}), null);
__d("cometCreateLocalEnvironment", ["CometMissingFieldHandlers", "cometHandlerProvider", "createCometStore", "createRelayFBLocalEnvironment"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("createRelayFBLocalEnvironment")({
            configName: "CometRelayLocalEnvironment",
            handlerProvider: c("cometHandlerProvider"),
            missingFieldHandlers: c("CometMissingFieldHandlers"),
            scheduler: null,
            store: c("createCometStore")()
        })
    }
    g["default"] = a
}), 98);
__d("configureRelayFlight", ["RelayFlight.hybrid", "RelayFlightClientImpl.client"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        d("RelayFlight.hybrid").isServer_INTERNAL_DO_NOT_USE() || d("RelayFlight.hybrid").initialize_INTERNAL_DO_NOT_USE(c("RelayFlightClientImpl.client"))
    }
    g["default"] = a
}), 98);
__d("CometRelayEnvironmentFactory", ["CometRelayMultiActorEnvironment", "RelayAPIConfig", "cometCreateLocalEnvironment", "cometHandlerProvider", "configureRelayFlight", "configureRelayForWWW", "createCometRelayEnvironmentConfig", "relay-runtime/multi-actor-environment"], (function(a, b, c, d, e, f, g) {
    "use strict";
    c("configureRelayForWWW")();
    c("configureRelayFlight")();

    function a(a, b) {
        return d("CometRelayMultiActorEnvironment").forActor(d("relay-runtime/multi-actor-environment").getActorIdentifier(a), b)
    }
    e = a(c("RelayAPIConfig").actorID);

    function b(a) {
        return d("CometRelayMultiActorEnvironment").commitMultiActorUpdate(a)
    }
    f = {
        commitLocalUpdateForEachEnvironment: b,
        configEnvironment: d("createCometRelayEnvironmentConfig").createCometRelayEnvironmentConfig,
        createLocalEnvironment: c("cometCreateLocalEnvironment"),
        defaultEnvironment: e,
        getForActor: d("CometRelayMultiActorEnvironment").forActor,
        getForActorID: a,
        handlerProvider: c("cometHandlerProvider")
    };
    g.createLocalEnvironment = c("cometCreateLocalEnvironment");
    g.configEnvironment = d("createCometRelayEnvironmentConfig").createCometRelayEnvironmentConfig;
    g.cometHandlerProvider = c("cometHandlerProvider");
    g.commitLocalUpdateForEachEnvironment = b;
    g.defaultEnvironment = e;
    g.getForActorID = a;
    g.CometRelayEnvironmentFactory = f
}), 98);
__d("RelayEnvironmentFactoryProvider", ["CometRelayEnvironmentFactory", "FBLogger", "gkx", "react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function j() {
        if (c("gkx")("7227") === !0) throw c("unrecoverableViolation")("You called getFactory from a component that is not a descendent of RelayEnvironmentFactoryProvider", "comet_root");
        c("FBLogger")("comet_root").warn("RelayEnvironmentFactoryContext called without parent provider - using CometRelayEnvironmentFactory as fallback");
        return d("CometRelayEnvironmentFactory").CometRelayEnvironmentFactory
    }
    var k = h.createContext(null);

    function a() {
        var a = i(k);
        return a ? a : j()
    }

    function b(a) {
        var b = i(k);
        if (b) return b;
        return a ? a : j()
    }

    function e(a) {
        return h.jsx(k.Provider, {
            value: a.factory,
            children: a.children
        })
    }
    e.displayName = e.name + " [from " + f.id + "]";
    g.useRelayEnvironmentFactory = a;
    g.useRelayEnvironmentFactoryWithFallback = b;
    g.RelayEnvironmentFactoryProvider = e
}), 98);
__d("DateStrings", ["fbt"], (function(a, b, c, d, e, f, g, h) {
    var i, j, k, l, m, n, o, p, q;

    function a(a) {
        n || (n = [h._("Sunday"), h._("Monday"), h._("Tuesday"), h._("Wednesday"), h._("Thursday"), h._("Friday"), h._("Saturday")]);
        return n[a]
    }

    function b(a) {
        p || (p = [h._("SUNDAY"), h._("MONDAY"), h._("TUESDAY"), h._("WEDNESDAY"), h._("THURSDAY"), h._("FRIDAY"), h._("SATURDAY")]);
        return p[a]
    }

    function c(a) {
        o || (o = [h._("Sun"), h._("Mon"), h._("Tue"), h._("Wed"), h._("Thu"), h._("Fri"), h._("Sat")]);
        return o[a]
    }

    function d(a) {
        q || (q = [h._("SUN"), h._("MON"), h._("TUE"), h._("WED"), h._("THU"), h._("FRI"), h._("SAT")]);
        return q[a]
    }

    function r() {
        i = [h._("January"), h._("February"), h._("March"), h._("April"), h._("May"), h._("June"), h._("July"), h._("August"), h._("September"), h._("October"), h._("November"), h._("December")]
    }

    function e(a) {
        i || r();
        return i[a - 1]
    }

    function f() {
        i || r();
        return i.slice()
    }

    function s(a) {
        l || (l = [h._("JANUARY"), h._("FEBRUARY"), h._("MARCH"), h._("APRIL"), h._("MAY"), h._("JUNE"), h._("JULY"), h._("AUGUST"), h._("SEPTEMBER"), h._("OCTOBER"), h._("NOVEMBER"), h._("DECEMBER")]);
        return l[a - 1]
    }

    function t(a) {
        j || (j = [h._("Jan"), h._("Feb"), h._("Mar"), h._("Apr"), h._("May"), h._("Jun"), h._("Jul"), h._("Aug"), h._("Sep"), h._("Oct"), h._("Nov"), h._("Dec")]);
        return j[a - 1]
    }

    function u(a) {
        k || (k = [h._("JAN"), h._("FEB"), h._("MAR"), h._("APR"), h._("MAY"), h._("JUN"), h._("JUL"), h._("AUG"), h._("SEP"), h._("OCT"), h._("NOV"), h._("DEC")]);
        return k[a - 1]
    }

    function v(a) {
        m || (m = ["", h._("st"), h._("nd"), h._("rd"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("st"), h._("nd"), h._("rd"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("th"), h._("st")]);
        return m[a]
    }

    function w(a) {
        switch (a) {
            case 1:
                return h._("1st");
            case 2:
                return h._("2nd");
            case 3:
                return h._("3rd");
            case 4:
                return h._("4th");
            case 5:
                return h._("5th");
            case 6:
                return h._("6th");
            case 7:
                return h._("7th");
            case 8:
                return h._("8th");
            case 9:
                return h._("9th");
            case 10:
                return h._("10th");
            case 11:
                return h._("11th");
            case 12:
                return h._("12th");
            case 13:
                return h._("13th");
            case 14:
                return h._("14th");
            case 15:
                return h._("15th");
            case 16:
                return h._("16th");
            case 17:
                return h._("17th");
            case 18:
                return h._("18th");
            case 19:
                return h._("19th");
            case 20:
                return h._("20th");
            case 21:
                return h._("21st");
            case 22:
                return h._("22nd");
            case 23:
                return h._("23rd");
            case 24:
                return h._("24th");
            case 25:
                return h._("25th");
            case 26:
                return h._("26th");
            case 27:
                return h._("27th");
            case 28:
                return h._("28th");
            case 29:
                return h._("29th");
            case 30:
                return h._("30th");
            case 31:
                return h._("31st");
            default:
                throw new Error("Invalid day of month.")
        }
    }

    function x() {
        return h._("Day:")
    }

    function y() {
        return h._("Month:")
    }

    function z() {
        return h._("Year:")
    }

    function A() {
        return h._("Hour:")
    }

    function B() {
        return h._("Minute:")
    }

    function C() {
        return h._("dd")
    }

    function D() {
        return h._("mm")
    }

    function E() {
        return h._("yyyy")
    }

    function F() {
        return h._("h")
    }

    function G() {
        return h._("m")
    }

    function H(a) {
        return a < 12 ? h._("am") : h._("pm")
    }

    function I(a) {
        return a < 12 ? h._("AM") : h._("PM")
    }
    g.getWeekdayName = a;
    g.getUppercaseWeekdayName = b;
    g.getWeekdayNameShort = c;
    g.getUppercaseWeekdayNameShort = d;
    g._initializeMonthNames = r;
    g.getMonthName = e;
    g.getMonthNames = f;
    g.getUppercaseMonthName = s;
    g.getMonthNameShort = t;
    g.getUppercaseMonthNameShort = u;
    g.getOrdinalSuffix = v;
    g.getDayOfMonth = w;
    g.getDayLabel = x;
    g.getMonthLabel = y;
    g.getYearLabel = z;
    g.getHourLabel = A;
    g.getMinuteLabel = B;
    g.getDayPlaceholder = C;
    g.getMonthPlaceholder = D;
    g.getYearPlaceholder = E;
    g.getHourPlaceholder = F;
    g.getMinutePlaceholder = G;
    g.get12HourClockSuffix = H;
    g.getUppercase12HourClockSuffix = I
}), 98);
__d("IntlDateStringsTypedLoggerLite", ["generateLiteTypedLogger"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = b("generateLiteTypedLogger")("logger:IntlDateStringsLoggerConfig")
}), null);
__d("IntlDateFormatsCLDRWidthEnum", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        FULL: "full",
        LONG: "long",
        MEDIUM: "medium",
        SHORT: "short"
    });
    f["default"] = a
}), 66);
__d("RegionDatetimePatterns", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        DATE_SHORT: "date_short",
        DATETIME_SHORT_SHORT: "dateTime_short_short",
        TIME_SHORT: "time_short",
        TIME_MEDIUM: "time_medium",
        J: "j"
    });
    f["default"] = a
}), 66);
__d("getCLDRLocalizedFormat", ["CLDRDateFormatConfig", "FBLogger", "IntlDateFormatsCLDRWidthEnum", "RegionDatetimePatterns", "flipObject", "unrecoverableViolation"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("CLDRDateFormatConfig").CLDRConfigeratorFormats,
        h = b("CLDRDateFormatConfig").CLDRRegionalConfigeratorFormats,
        i = b("flipObject")(b("RegionDatetimePatterns"));

    function a(a) {
        if (a == null) throw b("unrecoverableViolation")('Format: "' + a + '", not supported by configurator.', "internationalization");
        var c, d, e = a.split("_"),
            f = e[0];
        e = e.slice(1);
        var l = f + "Formats";
        a in i ? d = h : d = g;
        switch (l) {
            case "dateFormats":
            case "timeFormats":
                var m = j(e[0]);
                if (m == null) throw b("unrecoverableViolation")('Format: "' + a + '", category: "' + l + '", with unsupported width: "undefined"', "internationalization");
                c = d[l][m];
                if (c == null) throw b("unrecoverableViolation")('Format: "' + a + '", category: "' + l + '", ' + ('width: "' + m + '", with unsupported localization'), "internationalization");
                break;
            case "dateTimeFormats":
                m = j(e[0]);
                e = j(e[1]);
                if (m == null || e == null) throw b("unrecoverableViolation")('Format: "' + a + '", category: "' + l + '", with unsupported width: dateFormatKey="undefined" timeFormatKey="undefined"', "internationalization");
                c = d[l][m];
                var n = d.dateFormats[m],
                    o = d.timeFormats[e];
                if (c == null) throw b("unrecoverableViolation")('Format: "' + a + '", category: "' + l + '", ' + ('date width: "' + m + '", and time width: ') + ('"' + e + '", with unsupported localization'), "internationalization");
                c = c.replace("{0}", o).replace("{1}", n);
                break;
            default:
                l = "availableFormats";
                m = f;
                m.includes("j") && (m = k(m, d.timeFormats));
                c = d[l][m];
                if (c == null) throw b("unrecoverableViolation")('Format: "' + a + '", with key: "' + m + '", not supported by CLDR', "internationalization")
        }
        return c
    }

    function j(a) {
        if (a == null) throw b("unrecoverableViolation")("Expected CLDR width key to not be null", "internationalization");
        return b("IntlDateFormatsCLDRWidthEnum")[a.toUpperCase()]
    }

    function k(a, c) {
        var d;
        c = c["short"];
        c == null ? (b("FBLogger")("formatDate").blameToPreviousFile().warn('CLDR `timeFormat`, width `short` required for 24 hour localization not found for availableKey: "%s"', a), d = "h") : d = c.includes("H") ? "H" : "h";
        return a.replace("j", d)
    }
    e.exports = a
}), null);
__d("intlGetDateNumerics", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        b = b.utc === !0;
        b ? b = {
            dateDay: a.getUTCDate(),
            dateDayOfWeek: a.getUTCDay(),
            dateMonth: a.getUTCMonth(),
            dateYear: a.getUTCFullYear(),
            dateHours: a.getUTCHours(),
            dateMinutes: a.getUTCMinutes(),
            dateSeconds: a.getUTCSeconds(),
            dateMilliseconds: a.getUTCMilliseconds()
        } : b = {
            dateDay: a.getDate(),
            dateDayOfWeek: a.getDay(),
            dateMonth: a.getMonth(),
            dateYear: a.getFullYear(),
            dateHours: a.getHours(),
            dateMinutes: a.getMinutes(),
            dateSeconds: a.getSeconds(),
            dateMilliseconds: a.getMilliseconds()
        };
        return b
    }
    f["default"] = a
}), 66);
__d("intlRenderJSDateSymbol", ["DateStrings", "padNumber", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f, g) {
        g === void 0 && (g = 0);
        e = e.skipSuffixLocalization === !0;
        g = g;
        var h = "";
        switch (b) {
            case "\\":
                g++;
                if (f == null) throw c("unrecoverableViolation")("Only deprecated calls to `intlRenderJSDateSymbol()` use `localizedJSFormat`.", "internationalization");
                h = f.charAt(g);
                break;
            case "d":
                h = c("padNumber")(a.dateDay, 2);
                break;
            case "j":
                h = a.dateDay;
                break;
            case "S":
                h = d("DateStrings").getOrdinalSuffix(a.dateDay);
                break;
            case "D":
                h = d("DateStrings").getWeekdayNameShort(a.dateDayOfWeek);
                break;
            case "l":
                h = d("DateStrings").getWeekdayName(a.dateDayOfWeek);
                break;
            case "F":
            case "f":
                h = d("DateStrings").getMonthName(a.dateMonth + 1);
                break;
            case "M":
                h = d("DateStrings").getMonthNameShort(a.dateMonth + 1);
                break;
            case "m":
                h = c("padNumber")(a.dateMonth + 1, 2);
                break;
            case "n":
                h = a.dateMonth + 1;
                break;
            case "Y":
                h = a.dateYear;
                break;
            case "y":
                h = ("" + a.dateYear).slice(2);
                break;
            case "a":
                e ? h = a.dateHours < 12 ? "am" : "pm" : h = d("DateStrings").get12HourClockSuffix(a.dateHours);
                break;
            case "A":
                e ? h = a.dateHours < 12 ? "AM" : "PM" : h = d("DateStrings").getUppercase12HourClockSuffix(a.dateHours);
                break;
            case "g":
                a.dateHours === 0 || a.dateHours === 12 ? h = "12" : h = a.dateHours % 12;
                break;
            case "G":
                h = a.dateHours;
                break;
            case "h":
                a.dateHours === 0 || a.dateHours === 12 ? h = "12" : h = c("padNumber")(a.dateHours % 12, 2);
                break;
            case "H":
                h = c("padNumber")(a.dateHours, 2);
                break;
            case "i":
                h = c("padNumber")(a.dateMinutes, 2);
                break;
            case "s":
                h = c("padNumber")(a.dateSeconds, 2);
                break;
            case "X":
                h = c("padNumber")(a.dateMilliseconds, 3);
                break;
            default:
                h = b
        }
        return {
            idx: g,
            rendered: String(h)
        }
    }
    g["default"] = a
}), 98);
__d("intlRenderCLDRDate", ["CLDRDateFormatConfig", "intlRenderJSDateSymbol", "unrecoverableViolation"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = /\w+/;

    function a(a, c, d) {
        var e = b("CLDRDateFormatConfig").intlDateSpecialChars,
            f = "",
            g = "",
            i = !1,
            j = [],
            k;
        a = a.split(e.cldrDelimiter + e.singleQuote).join(e.singleQuoteHolder);
        for (var l = 0, m = a.length; l < m; l++) {
            var n = a.charAt(l);
            !i ? n === e.cldrDelimiter ? i = !0 : f.length === 0 || f[0] === n ? f += n : n === e.singleQuoteHolder ? f += e.singleQuote : (k = h(f, d, c), j.push(k.rendered), f = n) : (f.length !== 0 && (k = h(f, d, c), j.push(k.rendered), f = ""), n === e.cldrDelimiter ? (i = !1, j.push(g), g = "") : n === e.singleQuoteHolder ? g += e.singleQuote : g += n)
        }
        if (g.length !== 0) throw b("unrecoverableViolation")('Format: "' + a + '" must contain closing str literal delimiter', "internationalization");
        f.length !== 0 && (k = h(f, d, c), j.push(k.rendered));
        return j.join("")
    }

    function h(a, c, d) {
        a = i(a);
        return b("intlRenderJSDateSymbol")(c, a, d)
    }

    function i(a) {
        if (a in b("CLDRDateFormatConfig").CLDRToPHPSymbolConversion) return b("CLDRDateFormatConfig").CLDRToPHPSymbolConversion[a];
        if (g.test(a)) throw b("unrecoverableViolation")('Unsupported CLDR symbol: "' + a + '". If string literal, wrap in delimiters', "internationalization");
        return a
    }
    e.exports = a
}), null);
__d("formatDate", ["CLDRDateFormatConfig", "CLDRDateRenderingClientRollout", "DateFormatConfig", "FBLogger", "IntlDateStringsTypedLoggerLite", "IsInternSite", "Random", "getCLDRLocalizedFormat", "intlGetDateNumerics", "intlRenderCLDRDate", "intlRenderJSDateSymbol", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = Object.freeze({
        today: null,
        yesterday: null,
        thisWeek: null,
        thisMonth: null,
        thisYear: null,
        withinDay: null,
        withinWeek: null,
        withinMonth: null,
        withinYear: null,
        older: null,
        future: null,
        allOtherTimes: null
    });

    function h(a, b, d) {
        a = a;
        d = d || {
            skipSuffixLocalization: !1,
            skipPatternLocalization: !1,
            utc: !1,
            formatInternal: !1,
            throwCLDRError: !1
        };
        if (b == null || b === "" || a == null || !(a || a === 0)) return "";
        typeof a === "string" && (isNaN(Number(a)) && c("FBLogger")("i18n-formatDate").event("date_string_must_be_timestamp").blameToPreviousFile().mustfix("The date passed to formatDate is a string, but not a timestamp. formatDate expects strings to be a string representation of a Unix " + ('timestamp but was passed "' + a + '"')), a = parseInt(a, 10));
        typeof a === "number" && (a = new Date(a * 1e3));
        if (!(a instanceof Date)) throw c("unrecoverableViolation")("The date passed to formatDate must be either a unix timestamp or JavaScript date object.", "internationalization");
        if (isNaN(a.getTime())) throw c("unrecoverableViolation")("Invalid date passed to formatDate", "internationalization");
        a.getTime() >= 1e15 && c("FBLogger")("i18n-formatDate").event("date_too_far_in_future").blameToPreviousFile().info("The date passed to formatDate is too far in the future. Did you mix up milliseconds/seconds?");
        b = k(a, b);
        a = c("intlGetDateNumerics")(a, d);
        return i(b, a, d)
    }
    h.DEFAULT_FORMAT = "M j, Y g:i A";
    h.periodNames = Object.freeze(Object.keys(a));

    function i(a, b, d) {
        var e = a,
            f = !!d.skipPatternLocalization,
            g = d.formatInternal === !0;
        if (!f && (g || !c("IsInternSite").is_intern_site))
            if (a in c("CLDRDateFormatConfig").supportedPHPFormatsKeys) try {
                    f = c("CLDRDateFormatConfig").supportedPHPFormatsKeys[a];
                    g = c("getCLDRLocalizedFormat")(f);
                    m(a, f, g);
                    return c("intlRenderCLDRDate")(g, d, b)
                } catch (a) {
                    c("FBLogger")("i18n-formatDate").event("CLDR_date_format_render_error").blameToPreviousFile().catching(a).mustfix("CLDR date format render error");
                    if (d.throwCLDRError === !0) throw a
                } else if (c("DateFormatConfig").formats[a]) e = c("DateFormatConfig").formats[a], m(a);
                else if (!c("IsInternSite").is_intern_site)
            if (a.length !== 1) throw c("unrecoverableViolation")("Trying to localize an unsupported date format: `" + a + "`", "internationalization");
        return j(e, d, b)
    }

    function j(a, b, d) {
        var e = [];
        for (var f = 0; f < a.length; f++) {
            var g = a.charAt(f);
            g = c("intlRenderJSDateSymbol")(d, g, b, a, f);
            e.push(g.rendered);
            f = g.idx
        }
        return e.join("")
    }

    function k(a, b) {
        var d = h.DEFAULT_FORMAT;
        if (typeof b === "string") return b;
        else if (typeof b === "object") {
            var e = a.getTime();
            for (var f = l(), g = Array.isArray(f), i = 0, f = g ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var j;
                if (g) {
                    if (i >= f.length) break;
                    j = f[i++]
                } else {
                    i = f.next();
                    if (i.done) break;
                    j = i.value
                }
                j = j;
                var k = b[j.name];
                if (k != null && j.start <= e && e < j.end) return k
            }
            c("FBLogger")("i18n-formatDate").event("matching_period_format_not_found").blameToPreviousFile().warn('Matching period not found for date "%s", using default format "%s". Current timestamp: "%s"', e, d, Date.now());
            return d
        } else {
            c("FBLogger")("i18n-formatDate").event("invalid_format_argument").blameToPreviousFile().warn('Called with invalid format "%s" (type: %s) for date "%s", using default: %s', b, typeof b, a.getTime(), d);
            return d
        }
    }

    function l() {
        var a = new Date(),
            b = a.getTime(),
            d = a.getFullYear(),
            e = a.getMonth(),
            f = new Date(d, a.getMonth() + 1, 0).getDate(),
            g = new Date(d, 1, 29).getMonth() === 1 ? 366 : 365,
            h = 1e3 * 60 * 60 * 24,
            i = new Date(a.setHours(0, 0, 0, 0)),
            j = new Date(d, e, i.getDate() + 1);
        a = a.getDate() - (a.getDay() - c("DateFormatConfig").weekStart + 6) % 7;
        var k = new Date(b).setDate(a);
        a = new Date(b).setDate(a + 7);
        var l = new Date(d, e, 1);
        e = new Date(d, e, f + 1);
        var m = new Date(d, 0, 1);
        d = new Date(d + 1, 0, 1);
        return [{
            name: "today",
            start: i.getTime(),
            end: j.getTime()
        }, {
            name: "withinDay",
            start: b - h,
            end: b + h
        }, {
            name: "yesterday",
            start: i.getTime() - h,
            end: i.getTime() - 1
        }, {
            name: "thisWeek",
            start: k,
            end: a
        }, {
            name: "withinWeek",
            start: b - h * 7,
            end: b + h * 7
        }, {
            name: "thisMonth",
            start: l.getTime(),
            end: e.getTime()
        }, {
            name: "withinMonth",
            start: b - h * f,
            end: b + h * f
        }, {
            name: "thisYear",
            start: m.getTime(),
            end: d.getTime()
        }, {
            name: "withinYear",
            start: b - h * g,
            end: b + h * g
        }, {
            name: "older",
            start: -Infinity,
            end: b
        }, {
            name: "future",
            start: b,
            end: +Infinity
        }, {
            name: "allOtherTimes",
            start: -Infinity,
            end: +Infinity
        }]
    }

    function m(a, b, d) {
        b === void 0 && (b = null), d === void 0 && (d = null), c("Random").random() < c("CLDRDateRenderingClientRollout").formatDateClientLoggerSamplingRate && c("IntlDateStringsTypedLoggerLite").log({
            datetime_format: a,
            logged_from_client: !0,
            cldr_key: b,
            cldr_value: d
        })
    }
    b = h;
    g["default"] = b
}), 98);
__d("BinarySearch", ["unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = {
        GREATEST_LOWER_BOUND: "GREATEST_LOWER_BOUND",
        GREATEST_STRICT_LOWER_BOUND: "GREATEST_STRICT_LOWER_BOUND",
        LEAST_STRICT_UPPER_BOUND: "LEAST_STRICT_UPPER_BOUND",
        LEAST_UPPER_BOUND: "LEAST_UPPER_BOUND",
        NEAREST: "NEAREST"
    };
    var h = function(a, b) {
            if (typeof a !== "number" || typeof b !== "number") throw c("unrecoverableViolation")("The default comparator can only be used with sequences of numbers.", "comet_infra");
            return a - b
        },
        i = e.GREATEST_LOWER_BOUND,
        j = e.GREATEST_STRICT_LOWER_BOUND,
        k = e.LEAST_STRICT_UPPER_BOUND,
        l = e.LEAST_UPPER_BOUND,
        m = e.NEAREST;

    function n(a, b, c, d, e) {
        e === void 0 && (e = h);
        var f = l;
        f = p(a, b, c, d, e, f);
        if (c <= f && f < d) {
            c = a(f);
            return e(c, b) === 0 ? c : void 0
        } else return void 0
    }

    function o(a, b, c, d, e) {
        e === void 0 && (e = h);
        var f = l;
        f = p(a, b, c, d, e, f);
        if (c <= f && f < d) return e(a(f), b) === 0 ? f : -1;
        else return -1
    }

    function p(a, b, d, e, f, g) {
        switch (g) {
            case l:
                return q(a, b, d, e, f);
            case i:
                return r(a, b, d, e, f);
            case k:
                return s(a, b, d, e, f);
            case j:
                return t(a, b, d, e, f);
            case m:
                return u(a, b, d, e, f);
            default:
                throw c("unrecoverableViolation")("Invalid mode " + g, "comet_infra")
        }
    }

    function q(a, b, c, d, e) {
        c = c;
        d = d;
        while (c + 1 < d) {
            var f = c + Math.floor((d - c) / 2);
            e(a(f), b) >= 0 ? d = f : c = f
        }
        return c < d && e(a(c), b) >= 0 ? c : d
    }

    function r(a, b, c, d, e) {
        return s(a, b, c, d, e) - 1
    }

    function s(a, b, c, d, e) {
        c = c;
        d = d;
        while (c + 1 < d) {
            var f = c + Math.floor((d - c) / 2);
            e(a(f), b) > 0 ? d = f : c = f
        }
        return c < d && e(a(c), b) > 0 ? c : d
    }

    function t(a, b, c, d, e) {
        return q(a, b, c, d, e) - 1
    }

    function u(a, b, c, d, e) {
        var f = r(a, b, c, d, e),
            g = Math.abs(e(a(f), b));
        e = Math.abs(e(a(f + 1), b));
        return g < e ? Math.max(f, c) : Math.min(f + 1, d - 1)
    }

    function a(a, b, c) {
        return n(function(b) {
            return a[b]
        }, b, 0, a.length, c)
    }

    function b(a, b, c) {
        return o(function(b) {
            return a[b]
        }, b, 0, a.length, c)
    }

    function d(a, b, c, d) {
        return p(function(b) {
            return a[b]
        }, b, 0, a.length, c, d)
    }
    g.GREATEST_LOWER_BOUND = i;
    g.GREATEST_STRICT_LOWER_BOUND = j;
    g.LEAST_STRICT_UPPER_BOUND = k;
    g.LEAST_UPPER_BOUND = l;
    g.NEAREST = m;
    g.find = n;
    g.findIndex = o;
    g.findBound = p;
    g.leastUpperBound = q;
    g.greatestLowerBound = r;
    g.leastStrictUpperBound = s;
    g.greatestStrictLowerBound = t;
    g.nearest = u;
    g.findInArray = a;
    g.findIndexInArray = b;
    g.findBoundInArray = d
}), 98);
__d("DocumentScrollViewPageOffsetsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometRouterDispatcherContextFactory.react", ["CometRouterDispatcherContext", "DocumentScrollViewPageOffsetsContext", "filterObject", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo;

    function a(a) {
        var b = a.actorID,
            d = a.children,
            e = a.from,
            f = a.tracePolicy,
            g = a.url,
            k = i(c("CometRouterDispatcherContext")),
            l = i(c("DocumentScrollViewPageOffsetsContext"));
        k = j(function() {
            var a, d = {
                actorID: b,
                from: e,
                pageOffsets: l,
                tracePolicy: f,
                url: g
            };
            d = c("filterObject")(d, function(a) {
                return a !== void 0
            });
            return (a = k) == null ? void 0 : a.withContext(d)
        }, [b, k, e, l, f, g]);
        return k == null ? d : h.jsx(c("CometRouterDispatcherContext").Provider, {
            value: k,
            children: d
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogContext", ["FBLogger", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");

    function a() {
        c("FBLogger")("comet_ui").blameToPreviousFrame().mustfix("Attempted to imperatively render a dialog without CometTransientDialogProvider in the tree. This is not allowed. Please add a CometTransientDialogProvider to render a dialog (https://fburl.com/dialog-provider).")
    }
    e = b.createContext(a);
    g["default"] = e
}), 98);
__d("CometHeroLogging", ["hero-tracing"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("hero-tracing").HeroLogger
}), 98);
__d("CometTransientDialogProvider.react", ["fbt", "BaseModal.react", "CometDialogContext", "CometErrorBoundary.react", "CometHeroLogging", "CometInteractionTracingQPLConfigContext", "FBLogger", "cometPushToast", "cr:945", "react", "useCometInteractionTracing", "useIsCalledDuringRender", "useIsMountedRef"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    e = d("react");
    var j = e.useCallback,
        k = e.useEffect,
        l = e.useRef,
        m = e.useState;

    function n(a) {
        var b = a.dialogConfig,
            e = a.dialogConfigsRef,
            f = a.displayBaseModal_DO_NOT_USE,
            g = a.removeDialogConfig,
            n = l(null);
        k(function() {
            return function() {
                n.current != null && window.cancelAnimationFrame(n.current)
            }
        }, []);
        a = b.dialog;
        var o = b.dialogProps,
            p = m(!1),
            q = p[0];
        p = p[1];
        var r = j(function() {
                for (var a = arguments.length, d = new Array(a), f = 0; f < a; f++) d[f] = arguments[f];
                n.current != null && window.cancelAnimationFrame(n.current);
                var h = e.current.indexOf(b);
                h < 0 && c("FBLogger")("comet_ui").blameToPreviousFrame().mustfix("Attempting to close a dialog that does not exist anymore.");
                n.current = window.requestAnimationFrame(function() {
                    g(b, d), n.current = null
                })
            }, [b, e, g]),
            s = j(function() {
                r(), d("cometPushToast").cometPushErrorToast({
                    message: h._("Something isn't working. This may be because of a technical error we're working to fix."),
                    truncateText: !1
                })
            }, [r]);
        a = i.jsx(a, babelHelpers["extends"]({}, o, {
            onClose: r,
            onHide: p
        }));
        return i.jsx(c("CometErrorBoundary.react"), {
            onError: s,
            children: f === !0 ? i.jsx(c("BaseModal.react"), {
                hidden: q,
                interactionDesc: b.interactionDesc,
                interactionUUID: b.interactionUUID,
                stackingBehavior: "above-nav",
                children: a
            }) : a
        })
    }
    n.displayName = n.name + " [from " + f.id + "]";

    function a(a) {
        var e = a.displayBaseModal_DO_NOT_USE,
            f = e === void 0 ? !0 : e;
        e = babelHelpers.objectWithoutPropertiesLoose(a, ["displayBaseModal_DO_NOT_USE"]);
        a = m([]);
        var g = a[0],
            h = a[1];
        a = d("CometInteractionTracingQPLConfigContext").useDialogTraceQPLEvent();
        var o = c("useCometInteractionTracing")(a, "fluid", "INTERACTION");
        a = c("useIsCalledDuringRender")();
        a = j(function(a, d, e, f) {
            var g = e.loadType,
                i = e.preloadTrigger,
                j = e.tracePolicy;
            o(function(e) {
                var k = c("CometHeroLogging").genHeroInteractionUUIDAndMarkStart(e.getTraceId());
                e.addMetadata("interaction_type", "dialog");
                e.addMetadata("load_type", g);
                i != null && e.addMetadata("preload_trigger", i);
                var l = "Dialog";
                h(function(b) {
                    return b.concat({
                        dialog: a,
                        dialogProps: d,
                        interactionDesc: l,
                        interactionUUID: k,
                        onClose: f,
                        tracePolicy: j
                    })
                });
                b("cr:945") && b("cr:945").logOpen(j, k)
            }, void 0, void 0, j)
        }, [a, o]);
        var p = l(g);
        k(function() {
            p.current = g
        }, [g]);
        var q = c("useIsMountedRef")(),
            r = j(function(a, c) {
                if (!q.current) return;
                h(function(b) {
                    var c = b.indexOf(a);
                    return c < 0 ? b : b.slice(0, c)
                });
                a.onClose && a.onClose.apply(a, c);
                b("cr:945") && b("cr:945").logClose(a.tracePolicy, a.interactionUUID)
            }, [q]);
        return i.jsxs(c("CometDialogContext").Provider, {
            value: a,
            children: [e.children, g.map(function(a, b) {
                return i.jsx(n, {
                    dialogConfig: a,
                    dialogConfigsRef: p,
                    displayBaseModal_DO_NOT_USE: f,
                    removeDialogConfig: r
                }, b)
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseActorProvider", ["CometRelay", "CometRouterDispatcherContextFactory.react", "CometTransientDialogProvider.react", "RelayEnvironmentFactoryProvider", "react", "recoverableViolation", "unrecoverableViolation", "usePrevious"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useMemo,
        j = e.useState;

    function a(a) {
        return function() {
            throw c("unrecoverableViolation")("You are " + a + " the Actor from a React component that is not a descendent of ActorProvider.", "groups_comet")
        }
    }
    var k = h.createContext({
        get: a("reading"),
        set: a("setting")
    });

    function b(a) {
        var b = a.actorEnvironmentKey_DO_NOT_USE_UNLESS_YOU_KNOW_WHAT_YOU_ARE_DOING,
            e = a.children,
            f = a.initialActorID,
            g = a.readonly,
            l = g === void 0 ? !1 : g;
        g = a.relayEnvironmentFactory;
        a = a.scope;
        a = a === void 0 ? null : a;
        var m = j(f),
            n = m[0],
            o = m[1];
        m = c("usePrevious")(a);
        var p = c("usePrevious")(f);
        g = d("RelayEnvironmentFactoryProvider").useRelayEnvironmentFactoryWithFallback(g);
        b = g.getForActorID(n, b);
        p = p != null && p !== f;
        m = m != null && m !== a;
        (p || m) && n !== f && o(f);
        a = i(function() {
            return {
                get: function() {
                    return n
                },
                set: function(a) {
                    if (l) {
                        c("recoverableViolation")("You tried to update the Actor ID, but the <ActorProvider /> closest to your useActor() call has a read-only Actor ID. To fix this, wrap the React tree that you want to set an Actor ID for with your own <ActorProvider />.", "groups_comet");
                        return
                    }
                    o(a)
                }
            }
        }, [n, l]);
        return h.jsx(k.Provider, {
            value: a,
            children: h.jsx(d("CometRelay").RelayEnvironmentProvider, {
                environment: b,
                getEnvironmentForActor: g.getForActor,
                children: h.jsx(c("CometRouterDispatcherContextFactory.react"), {
                    actorID: n,
                    children: h.jsx(c("CometTransientDialogProvider.react"), {
                        children: e
                    })
                })
            })
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";
    g.ActorContext = k;
    g.BaseActorProvider = b
}), 98);
__d("Actor", ["BaseActorProvider", "CometRelayEnvironmentFactory", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function a(a) {
        return h.jsx(d("BaseActorProvider").BaseActorProvider, babelHelpers["extends"]({}, a, {
            relayEnvironmentFactory: d("CometRelayEnvironmentFactory").CometRelayEnvironmentFactory,
            children: a.children
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        var a = i(d("BaseActorProvider").ActorContext);
        return [a.get(), a.set]
    }
    g.ActorProvider = a;
    g.useActor = b
}), 98);
__d("CometRouterRenderTypeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometRouterRouteTopNavTypeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext("default");
    g["default"] = b
}), 98);
__d("CometRouterStateContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometRouteRenderType", ["CometRouterRenderTypeContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        var a = h(c("CometRouterRenderTypeContext"));
        return a === "pushView"
    }

    function b() {
        var a = h(c("CometRouterRenderTypeContext"));
        return a === "hosted"
    }

    function e() {
        var a = h(c("CometRouterRenderTypeContext"));
        return a === "main"
    }
    g.useIsPushView = a;
    g.useIsHosted = b;
    g.useIsMain = e
}), 98);
__d("useCometRouterState", ["CometRouterStateContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometRouterStateContext"))
    }
    g["default"] = a
}), 98);